# Streamer Home changelog

## 1.3
- Version number shown in Launcher Settings header.
- Two more wallpaper types: Animals and Art (Wikimedia Commons featured pictures). 'People' is not offered: no free source without an API key that is safe for a living-room TV.
- Already in the code: small tiles, London name on weather card, weather photos by time of day + weather (30 min), 6 colour themes, wallpaper interval 5-60 min, footer 'Created by Claudiu'.

## 1.3
- Settings button now opens Launcher Settings: 6 colour themes, wallpaper interval 5-60 min, wallpaper types (Space / Nature / City), image status line, shortcut to system settings.
- Weather card: "London" shown beside the temperature; London photo matches time of day + weather and changes every 30 min (sky-colour fallback behind it).
- App tiles about half the width/height (quarter of the area). "Created by Claudiu" at the bottom. Clock has no panel behind it.
- Wikimedia requests now send a contact User-Agent; status of online requests visible in Settings.

## 1.2
- Restored missing LazyVerticalGrid/GridCells/itemsIndexed imports (All apps grid).
- Fixed build errors in the Copilot-edited design (FontFamily.Rounded does not exist in Compose -> SansSerif; `catch (_: ...)` not allowed in Kotlin 1.9).
- Zip now has the project files at the root (no extra folder), as the GitHub workflow expects.
- Back button is swallowed on the home screen (launcher never "goes back").
- Kept Copilot's design: small bold clock, settings button under the Wi-Fi button, focus pop/offset on tiles.

## 1.1
- Online backgrounds (NASA space + Bing landscapes), London photos on the weather card, glass/HUD look, bigger square tiles, fixed signing key.

## 1.0
- First working build: clock, weather, Wi-Fi popup, app tiles, All apps.
