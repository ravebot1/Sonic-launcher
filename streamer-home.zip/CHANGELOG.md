# Sonik Launcher changelog

## 1.9.3
- Weather card: size (Small to Extra large) and a See-through background (Settings > Weather card). Richer, shaded weather artwork (lit clouds, tapered rain, snowflakes, glowing lightning, soft fog).
- 4K wallpapers: Settings > Wallpaper quality. Sources: Bing daily pictures (UHD), Picsum (free Unsplash photos), Wikimedia Commons 3840 px and NASA. Gallery shows small previews and holds up to 40 pictures plus "More pictures".
- "Wallpaper changes every" is a drop-down; Never keeps one picture.
- Settings button is a proper cog icon.
- Updates: after the download the installer opens by itself, and an "Install downloaded update" button stays available.
- NASA space: retries a timeout and falls back to Commons space pictures. Image status now names the host for failed image downloads and shows why Commons pictures were rejected.

## 1.9.2
- FIX: Down from the weather card, the clock and the Settings button now jumps to the app tiles (or the playback card) by handling the key directly. 1.9.1 used a focus setting that may not have compiled.
- Weather card photos: London photos from Flickr tagged with the weather and time of day (rain, fog, snow, sunny, sunrise, sunset, night), Wikimedia Commons only as backup. Lighter shading so the photo is visible.
- Weather settings > Show on the card: new "5-day forecast" switch.

## 1.9.1
- Weather card: now shows the current temperature, the city and the next 5 days (icon, high, low) along the bottom. High / low and wind moved to the forecast panel (tap the card); Settings > Weather card > "Forecast panel shows" controls them.
- FIX: Down from the weather card or the Settings button now goes to the app tiles (or the playback card).
- FIX: wallpaper gallery "too small" tiles: London category pictures are now requested at 1920 px and small ones are filtered out; tiles that still fail are removed from the grid.
- FIX: "More pictures" now adds new pictures (new NASA picks, next pages of searches) instead of reshuffling the same ones.
- FIX: Wikimedia searches are sent one at a time with longer retries (rate limit), retry without the file-type filter when empty, and the image status names the search that found nothing.

## 1.9.0
- FIX: nothing behind an open panel can take focus any more (Left / Right in Settings no longer moves over the home tiles).
- FIX: Settings, Clock style and Weather settings jump back to the very top when you move up to the first row.
- Clock font is now a drop-down list (all 12 styles: Thin, Bold, Mono, Serif, Black, LED, Neon, Matrix, Slim, Italic, Outline, Pixel).
- Weather card: tap it, then "Weather settings..." (also in Settings > Weather card...): font, temperature colour, what the card shows, London photos or sky art only, photo interval, forecast days and hours.
- Weather photos: more search terms and categories, retry on rate limit, and the image status shows what was found.
- Wallpaper from this device: Settings > Wallpaper mode > "From this device..." (pictures list or system file picker), saved at 1920 x 1080.
- Wi-Fi and Settings buttons: smaller, no background (ring only when focused).

## 1.8.0
- FIX: Settings, All apps, Forecast, Clock, Home apps, Updates and the new Wallpaper gallery are now separate windows. The remote can no longer move focus onto the home tiles hidden behind them.
- FIX: removed the 1.7.0 focus overrides (up/down mapping) that could leave the home screen without a focus.
- Recent tiles are now recorded by the notification service itself (also while another app is open), including paused items.
- Four more clock styles: Slim, Italic, Outline, Pixel (next to LED, Neon, Matrix).
- Wallpaper gallery: pick a picture, it is saved at 1920 x 1080 as a fixed wallpaper. Settings > Wallpaper mode: Rotating / Fixed.

## 1.7.0
- Background grid lines removed.
- Up / Down in All apps and Choose home apps: focus now moves one row at a time (rows are scrolled in first). Down from the now-playing card goes to the app tiles and Up comes back.
- Tile size in Settings (Small / Medium / Large / Extra large).
- Recent tiles: the last things you played or watched (Deezer, YouTube, Tidal...) appear as tiles with their cover; tap reopens the app and resumes if it is still the active player. Settings: Off / 2 / 4 / 6 and Clear history.

## 1.6.1
- Name spelled Sonik Launcher (app label, Settings, About).

## 1.6.0
- Renamed to Sonic Launcher, new purple S icon and TV banner.
- Removed the footer text on the home screen; new About section in Settings.

## 1.5.0
- Smoother: the build is now optimised (R8, not debuggable), the clock ticks on its own instead of redrawing the whole screen every second, and Wi-Fi is read off the main thread.
- Space wallpapers use NASA's high-resolution files and any picture smaller than 1400 px is skipped.
- Clock fonts: LED, Neon and Matrix (drawn digits with glow and ghost segments).
- Sunrise / sunset: drawn icons with the words SUNRISE and SUNSET.
- Weather card: animated sky behind the photo (stars, sun glow, drifting clouds), known London photos as a fallback, and the image status shows what the card photos are doing.

## 1.4.2
- All apps / Choose home apps: the focused app is now always scrolled into view (focus used to move off-screen).
- Wallpapers and London photos: photos only (JPEG, landscape, large). Logos, maps, flags and NASA graphics are filtered out.
- Weather card: drawn weather artwork (sun, moon and stars, clouds, rain, snow, lightning, fog) instead of emoji; also in the forecast panel.
- Sunrise / sunset shown with sunrise and sunset symbols.

## 1.4.1
- Hold OK on a tile: the menu now opens when you let go of the button, so the release can no longer press "Open" by accident.

## 1.4
- Tap the weather card: hourly strip + 6-day forecast (rain chance, wind, humidity).
- Click the clock (or Settings > Clock style): font, size, box (none/glass/solid), text opacity, colour, 12/24h, seconds, and what shows under it (date, sunrise/sunset, day length, moon phase, tomorrow).
- Home apps: choose them in Settings, hold OK on a tile to open / app info / uninstall / move left-right / remove. Hold OK in All apps to add or remove.
- Now-playing card for Deezer, YouTube Music, Tidal (any media app): needs Notification access (Settings > Playback card). Prev / play-pause / next buttons.
- Updates from GitHub only when you press "Check for updates". Version code = GitHub run number (-PbuildNumber). Test builds toggle ignores pre-releases when off.
- Wallpaper type "London (time of day)": London pictures that follow time of day and weather.
- Animations (Full / Reduced / Off): staggered fade-in at start, springy tile focus with a light sweep, slow wallpaper zoom, panels fade/scale in, rain/snow on the weather card.


## 1.3
- Version number shown in Launcher Settings header.
- Two more wallpaper types: Animals and Art (Wikimedia Commons featured pictures). 'People' is not offered: no free source without an API key that is safe for a living-room TV.
- Already in the code: small tiles, London name on weather card, weather photos by time of day + weather (30 min), 6 colour themes, wallpaper interval 5-60 min, footer 'Created by Claudiu'.

## 1.3
- Settings button now opens Launcher Settings: 6 colour themes, wallpaper interval 5-60 min, wallpaper types (Space / Nature / City), image status line, shortcut to system settings.
- Weather card: "London" shown beside the temperature; London photo matches time of day + weather and changes every 30 min (sky-colour fallback behind it).
- App tiles about half the width/height (quarter of the area). "Created by Claudiu" at the bottom. Clock has no panel behind it.
- Wikimedia requests now send a contact User-Agent; status of online requests visible in Settings.

## 1.2
- Restored missing LazyVerticalGrid/GridCells/itemsIndexed imports (All apps grid).
- Fixed build errors in the Copilot-edited design (FontFamily.Rounded does not exist in Compose -> SansSerif; `catch (_: ...)` not allowed in Kotlin 1.9).
- Zip now has the project files at the root (no extra folder), as the GitHub workflow expects.
- Back button is swallowed on the home screen (launcher never "goes back").
- Kept Copilot's design: small bold clock, settings button under the Wi-Fi button, focus pop/offset on tiles.

## 1.1
- Online backgrounds (NASA space + Bing landscapes), London photos on the weather card, glass/HUD look, bigger square tiles, fixed signing key.

## 1.0
- First working build: clock, weather, Wi-Fi popup, app tiles, All apps.
