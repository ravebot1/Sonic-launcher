# Streamer Home changelog

## 1.4.1
- Hold OK on a tile: the menu now opens when you let go of the button, so the release can no longer press "Open" by accident.

## 1.4
- Tap the weather card: hourly strip + 6-day forecast (rain chance, wind, humidity).
- Click the clock (or Settings > Clock style): font, size, box (none/glass/solid), text opacity, colour, 12/24h, seconds, and what shows under it (date, sunrise/sunset, day length, moon phase, tomorrow).
- Home apps: choose them in Settings, hold OK on a tile to open / app info / uninstall / move left-right / remove. Hold OK in All apps to add or remove.
- Now-playing card for Deezer, YouTube Music, Tidal (any media app): needs Notification access (Settings > Playback card). Prev / play-pause / next buttons.
- Updates from GitHub only when you press "Check for updates". Version code = GitHub run number (-PbuildNumber). Test builds toggle ignores pre-releases when off.
- Wallpaper type "London (time of day)": London pictures that follow time of day and weather.
- Animations (Full / Reduced / Off): staggered fade-in at start, springy tile focus with a light sweep, slow wallpaper zoom, panels fade/scale in, rain/snow on the weather card.


## 1.3
- Version number shown in Launcher Settings header.
- Two more wallpaper types: Animals and Art (Wikimedia Commons featured pictures). 'People' is not offered: no free source without an API key that is safe for a living-room TV.
- Already in the code: small tiles, London name on weather card, weather photos by time of day + weather (30 min), 6 colour themes, wallpaper interval 5-60 min, footer 'Created by Claudiu'.

## 1.3
- Settings button now opens Launcher Settings: 6 colour themes, wallpaper interval 5-60 min, wallpaper types (Space / Nature / City), image status line, shortcut to system settings.
- Weather card: "London" shown beside the temperature; London photo matches time of day + weather and changes every 30 min (sky-colour fallback behind it).
- App tiles about half the width/height (quarter of the area). "Created by Claudiu" at the bottom. Clock has no panel behind it.
- Wikimedia requests now send a contact User-Agent; status of online requests visible in Settings.

## 1.2
- Restored missing LazyVerticalGrid/GridCells/itemsIndexed imports (All apps grid).
- Fixed build errors in the Copilot-edited design (FontFamily.Rounded does not exist in Compose -> SansSerif; `catch (_: ...)` not allowed in Kotlin 1.9).
- Zip now has the project files at the root (no extra folder), as the GitHub workflow expects.
- Back button is swallowed on the home screen (launcher never "goes back").
- Kept Copilot's design: small bold clock, settings button under the Wi-Fi button, focus pop/offset on tiles.

## 1.1
- Online backgrounds (NASA space + Bing landscapes), London photos on the weather card, glass/HUD look, bigger square tiles, fixed signing key.

## 1.0
- First working build: clock, weather, Wi-Fi popup, app tiles, All apps.
