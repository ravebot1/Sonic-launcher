package com.streamerhome.launcher

data class TileSpec(
    val label: String,
    // First package in the list that is installed on the device is used.
    val packages: List<String>,
    val accent: Long
)

object Config {
    // Weather location (change to your own coordinates).
    const val CITY = "London"
    const val LATITUDE = 51.55
    const val LONGITUDE = 0.05

    const val WEATHER_REFRESH_MS = 30L * 60L * 1000L

    // Online images
    const val NASA_API_KEY = "DEMO_KEY"                       // free key from api.nasa.gov if DEMO_KEY gets rate limited
    const val LONDON_CATEGORY = "Featured_pictures_of_London" // Wikimedia Commons category
    const val BG_INTERVAL_MS = 5L * 60L * 1000L               // background changes every 5 min
    const val LONDON_INTERVAL_MS = 45_000L                    // weather card photo changes every 45 s

    // Home-screen tiles. Edit labels / package names here.
    val tiles = listOf(
        TileSpec("YouTube", listOf("com.google.android.youtube.tv", "com.google.android.youtube"), 0xFFFF4B4B),
        TileSpec("Stremio", listOf("com.stremio.one"), 0xFF8B5CF6),
        TileSpec("Deezer", listOf("deezer.android.tv", "deezer.android.app"), 0xFFA238FF),
        TileSpec("OTT Navigator", listOf("studio.scillarium.ottnavigator"), 0xFF22C55E)
    )
}
