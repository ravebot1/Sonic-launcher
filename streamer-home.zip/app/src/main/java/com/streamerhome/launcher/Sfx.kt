package com.streamerhome.launcher

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.SystemClock

// Short UI sounds generated in code (no audio files): a tick for OK, a lower falling tone for Back,
// and a very soft tick when you move with the D-pad.
object Sfx {
    // 0 off, 1 OK / Back only, 2 also movement
    @Volatile
    var mode = 2

    private var clickTrack: AudioTrack? = null
    private var backTrack: AudioTrack? = null
    private var moveTrack: AudioTrack? = null
    @Volatile
    private var lastMove = 0L

    private fun build(f0: Double, f1: Double, ms: Int, volume: Double): AudioTrack? {
        return try {
            val rate = 44100
            val n = rate * ms / 1000
            val pcm = ShortArray(n)
            var phase = 0.0
            for (i in 0 until n) {
                val t = i.toDouble() / n
                phase += 2.0 * Math.PI * (f0 + (f1 - f0) * t) / rate
                val env = minOf(1.0, t * 30.0) * (1.0 - t) * (1.0 - t)
                pcm[i] = (Math.sin(phase) * env * volume * 32767.0).toInt().toShort()
            }
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(n * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(pcm, 0, n)
            track
        } catch (e: Throwable) {
            null
        }
    }

    @Synchronized
    fun init() {
        if (clickTrack == null) clickTrack = build(1500.0, 1100.0, 45, 0.35)
        if (backTrack == null) backTrack = build(700.0, 420.0, 70, 0.35)
        if (moveTrack == null) moveTrack = build(2300.0, 1900.0, 22, 0.16)
    }

    private fun play(t: AudioTrack?, need: Int) {
        if (mode < need || t == null) return
        try {
            t.stop()
            t.reloadStaticData()
            t.play()
        } catch (e: Throwable) {
            // sound is optional
        }
    }

    fun click() = play(clickTrack, 1)
    fun back() = play(backTrack, 1)
    fun move() {
        val now = SystemClock.uptimeMillis()
        if (now - lastMove < 90L) return
        lastMove = now
        play(moveTrack, 2)
    }
}
