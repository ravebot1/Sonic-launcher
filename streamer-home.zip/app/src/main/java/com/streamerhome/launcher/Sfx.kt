package com.streamerhome.launcher

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack

// Short UI sounds generated in code (no audio files): a crisp tick for OK, a lower falling tone for Back.
object Sfx {
    @Volatile
    var enabled = true

    private var clickTrack: AudioTrack? = null
    private var backTrack: AudioTrack? = null

    private fun build(f0: Double, f1: Double, ms: Int, volume: Double): AudioTrack? {
        return try {
            val rate = 44100
            val n = rate * ms / 1000
            val pcm = ShortArray(n)
            var phase = 0.0
            for (i in 0 until n) {
                val t = i.toDouble() / n
                phase += 2.0 * Math.PI * (f0 + (f1 - f0) * t) / rate
                val env = minOf(1.0, t * 30.0) * (1.0 - t) * (1.0 - t)
                pcm[i] = (Math.sin(phase) * env * volume * 32767.0).toInt().toShort()
            }
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(n * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(pcm, 0, n)
            track
        } catch (e: Throwable) {
            null
        }
    }

    @Synchronized
    fun init() {
        if (clickTrack == null) clickTrack = build(1500.0, 1100.0, 45, 0.35)
        if (backTrack == null) backTrack = build(700.0, 420.0, 70, 0.35)
    }

    private fun play(t: AudioTrack?) {
        if (!enabled || t == null) return
        try {
            t.stop()
            t.reloadStaticData()
            t.play()
        } catch (e: Throwable) {
            // sound is optional
        }
    }

    fun click() = play(clickTrack)
    fun back() = play(backTrack)
}
