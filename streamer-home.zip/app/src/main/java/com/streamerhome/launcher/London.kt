package com.streamerhome.launcher

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// London skyline wallpaper. The still scene (sky, skyline, water with reflections, bridge, bank) is drawn once
// into bitmaps; only the moving parts (Eye capsules, clock hands, boats, traffic, planes, lights, clouds,
// water glints) are drawn every frame.

private const val TAU = 6.2831855f

private fun hh(i: Int): Float {
    var x = i * 374761393 + 668265263
    x = (x xor (x ushr 13)) * 1274126177
    x = x xor (x ushr 16)
    return (x and 0xFFFFFF) / 16777215f
}

private fun skyFor(tod: String): List<Color> = when (tod) {
    "night" -> listOf(Color(0xFF030614), Color(0xFF0A1332), Color(0xFF1B2A5C))
    "sunrise" -> listOf(Color(0xFF1B2A5C), Color(0xFFB0577A), Color(0xFFFFB27A))
    "sunset" -> listOf(Color(0xFF1A1F4D), Color(0xFFC2506B), Color(0xFFFF9A5A))
    else -> listOf(Color(0xFF1F5FA8), Color(0xFF5FA6E0), Color(0xFFBFE3F7))
}

private class Sc(
    val w: Float,
    val h: Float,
    val tod: String,
    val blink: ArrayList<Offset> = ArrayList(),
    val beacons: ArrayList<Offset> = ArrayList()
) {
    val night = tod == "night"
    val glow = tod != "day"
    val u = h / 1080f
    val gy = h * 0.66f
    val bank = h * 0.885f
    val sky = skyFor(tod)
    val lp = when (tod) {
        "night" -> 0.55f
        "sunset" -> 0.35f
        "sunrise" -> 0.2f
        else -> 0.04f
    }
    val dark = if (night) Color(0xFF050914) else Color(0xFF16202E)
    val far = lerp(sky[2], dark, 0.3f)
    val mid = lerp(sky[2], dark, 0.5f)
    val near = lerp(sky[2], dark, 0.7f)
    val glassHi = lerp(sky[1], dark, 0.45f)
    val stone = lerp(mid, if (night) Color(0xFF4A5275) else Color(0xFFC9B88E), 0.5f)
    val stoneHi = lerp(stone, Color.White, 0.22f)
    val stoneLo = lerp(stone, Color.Black, 0.3f)
    val warm = Color(0xFFFFD98A)
    val cool = Color(0xFFCFE6FF)
    val red = Color(0xFFFF3B30)
    val gold = Color(0xFFE2B94F)
    val benCx = w * 0.07f
    val benTw = w * 0.03f
    val benH = h * 0.40f
    val eyeR = h * 0.19f
    val eyeCx = w * 0.305f
    val eyeCy = bank - eyeR * 1.12f
    val shX = w * 0.505f
    val shH = h * 0.60f
    val shW = w * 0.056f
    val cwX = w * 0.93f
    val t1 = w * 0.625f
    val t2 = w * 0.705f
    val abL = w * 0.555f
    val abR = w * 0.775f
    val deck = h * 0.745f
}

private fun DrawScope.poly(c: Color, vararg p: Float) {
    val path = Path()
    path.moveTo(p[0], p[1])
    var i = 2
    while (i < p.size) {
        path.lineTo(p[i], p[i + 1])
        i += 2
    }
    path.close()
    drawPath(path, c)
}

private fun DrawScope.polyB(b: Brush, vararg p: Float) {
    val path = Path()
    path.moveTo(p[0], p[1])
    var i = 2
    while (i < p.size) {
        path.lineTo(p[i], p[i + 1])
        i += 2
    }
    path.close()
    drawPath(path, b)
}

private fun DrawScope.ln(c: Color, x1: Float, y1: Float, x2: Float, y2: Float, wd: Float) {
    drawLine(c, Offset(x1, y1), Offset(x2, y2), wd)
}

private fun DrawScope.wins(s: Sc, x: Float, y: Float, bw: Float, bh: Float, seed: Int, sx: Float = 9f, sy: Float = 13f, boost: Float = 0f) {
    val stepX = sx * s.u
    val stepY = sy * s.u
    val ww = stepX * 0.5f
    val wh = stepY * 0.55f
    var iy = 0
    var yy = y + stepY * 0.6f
    while (yy < y + bh - stepY * 0.6f) {
        var ix = 0
        var xx = x + stepX * 0.55f
        while (xx < x + bw - stepX * 0.9f) {
            val hv = hh(seed * 977 + ix * 31 + iy * 7)
            if (hv < s.lp + boost) {
                val c = if (hh(seed * 13 + ix + iy * 5) > 0.7f) s.cool else s.warm
                drawRect(c.copy(alpha = 0.85f), Offset(xx, yy), Size(ww, wh))
                if (hh(seed * 3 + ix * 11 + iy) > 0.985f && s.blink.size < 220) s.blink.add(Offset(xx / s.w, yy / s.h))
            } else if (!s.night) {
                drawRect(Color.White.copy(alpha = 0.07f), Offset(xx, yy), Size(ww, wh))
            }
            xx += stepX
            ix++
        }
        yy += stepY
        iy++
    }
}

private fun DrawScope.beacon(s: Sc, x: Float, y: Float) {
    s.beacons.add(Offset(x / s.w, y / s.h))
    drawCircle(s.red.copy(alpha = 0.35f), 2.4f * s.u, Offset(x, y))
}

// ---------------------------------------------------------------- composable

@Composable
fun LondonWallpaper(tod: String, anim: Int, modifier: Modifier = Modifier) {
    val t: State<Float> = if (anim == 2) {
        remember { mutableStateOf(0.3f) }
    } else {
        rememberInfiniteTransition(label = "ldn").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(animation = tween(240000, easing = LinearEasing), repeatMode = RepeatMode.Restart),
            label = "ldnT"
        )
    }
    key(tod) {
        Box(
            modifier.drawWithCache {
                val k = min(1f, 1920f / size.width)
                val sw = max(2, (size.width * k).toInt())
                val sh = max(2, (size.height * k).toInt())
                val st = Sc(sw.toFloat(), sh.toFloat(), tod)
                val a = ImageBitmap(sw, sh)
                val b = ImageBitmap(sw, sh)
                val cs = CanvasDrawScope()
                cs.draw(this, layoutDirection, Canvas(a), Size(sw.toFloat(), sh.toFloat())) { drawBackdrop(st) }
                cs.draw(this, layoutDirection, Canvas(b), Size(sw.toFloat(), sh.toFloat())) { drawForeground(st, a) }
                val dyn = Sc(size.width, size.height, tod, st.blink, st.beacons)
                onDrawBehind {
                    drawImage(b, dstSize = IntSize(size.width.toInt(), size.height.toInt()))
                    drawLive(dyn, t.value)
                }
            }
        ) {}
    }
}

// ---------------------------------------------------------------- backdrop: sky, far city, north bank landmarks

private fun DrawScope.drawBackdrop(s: Sc) {
    val w = s.w
    val h = s.h
    val u = s.u
    drawRect(s.sky[2], Offset.Zero, Size(w, h))
    drawRect(Brush.verticalGradient(listOf(s.sky[0], s.sky[1], s.sky[2]), startY = 0f, endY = s.gy), Offset.Zero, Size(w, s.gy))
    if (s.night) {
        for (i in 0 until 240) {
            drawCircle(
                Color.White.copy(alpha = 0.3f + 0.4f * hh(i * 5 + 3)),
                (0.7f + hh(i * 5 + 2) * 1.6f) * u,
                Offset(hh(i * 5) * w, hh(i * 5 + 1) * s.gy * 0.75f)
            )
        }
    }
    // sun or moon
    val sc = Offset(w * 0.40f, h * (if (s.tod == "day") 0.16f else if (s.night) 0.15f else 0.5f))
    if (s.night) {
        drawCircle(Brush.radialGradient(listOf(Color(0x66BFD8FF), Color.Transparent), center = sc, radius = h * 0.26f), h * 0.26f, sc)
        drawCircle(Brush.radialGradient(listOf(Color.White, Color(0xFFD5DEEE)), center = Offset(sc.x - 10f * u, sc.y - 10f * u), radius = h * 0.06f), h * 0.04f, sc)
        for (k in 0 until 7) {
            val a = hh(k + 30) * TAU
            val d = h * 0.026f * hh(k + 40)
            drawCircle(Color(0x225A6C90), h * (0.004f + 0.006f * hh(k + 50)), Offset(sc.x + cos(a) * d, sc.y + sin(a) * d))
        }
    } else {
        val g = if (s.tod == "day") Color(0x88FFF3B0) else Color(0x99FFC070)
        drawCircle(Brush.radialGradient(listOf(g, Color.Transparent), center = sc, radius = h * 0.5f), h * 0.5f, sc)
        drawCircle(Color(0xFFFFF6D0), h * 0.04f, sc)
    }
    // glow along the horizon and city light pollution
    drawRect(
        Brush.verticalGradient(listOf(Color.Transparent, if (s.night) Color(0x55FF9A4A) else if (s.glow) Color(0x66FFB070) else Color(0x33FFFFFF)), startY = h * 0.34f, endY = s.gy),
        Offset(0f, h * 0.34f), Size(w, s.gy - h * 0.34f)
    )
    drawLayers(s)
    drawBt(s)
    drawWestminster(s)
    drawShard(s)
    drawStPauls(s)
    drawCluster(s)
    drawCanary(s)
    drawRect(
        Brush.verticalGradient(listOf(Color.Transparent, s.sky[2].copy(alpha = if (s.night) 0.16f else 0.3f)), startY = s.gy - h * 0.12f, endY = s.gy),
        Offset(0f, s.gy - h * 0.12f), Size(w, h * 0.12f)
    )
}

private fun DrawScope.drawBuilding(s: Sc, x: Float, bw: Float, bh: Float, col: Color, seed: Int, layer: Int) {
    val u = s.u
    val top = s.gy - bh
    drawRect(Brush.verticalGradient(listOf(lerp(col, s.glassHi, 0.25f), col), startY = top, endY = s.gy), Offset(x, top), Size(bw, bh))
    drawRect(Color.Black.copy(alpha = 0.12f), Offset(x + bw * 0.78f, top), Size(bw * 0.22f, bh))
    when ((hh(seed + 5) * 7f).toInt()) {
        1 -> drawRect(col, Offset(x + bw * 0.2f, top - bh * 0.12f), Size(bw * 0.6f, bh * 0.12f))
        2 -> poly(col, x - 1f, top, x + bw / 2f, top - bw * 0.35f, x + bw + 1f, top)
        3 -> {
            drawRect(col, Offset(x + bw * 0.5f - 1f * u, top - bh * 0.28f), Size(2f * u, bh * 0.28f))
            if (layer == 2) beacon(s, x + bw * 0.5f, top - bh * 0.28f)
        }
        4 -> drawRect(col, Offset(x + bw * 0.3f, top - bw * 0.22f), Size(bw * 0.28f, bw * 0.22f))
        5 -> drawArc(col, 180f, 180f, true, Offset(x + bw * 0.15f, top - bw * 0.35f), Size(bw * 0.7f, bw * 0.7f))
        6 -> {
            poly(col, x, top, x + bw * 0.15f, top - bw * 0.25f, x + bw * 0.85f, top - bw * 0.25f, x + bw, top)
        }
    }
    drawRect(lerp(col, Color.Black, 0.2f), Offset(x - 1.5f * u, top - 3f * u), Size(bw + 3f * u, 3f * u))
    if (layer >= 1) wins(s, x, top, bw, bh, seed, if (layer == 1) 11f else 9f, if (layer == 1) 15f else 13f)
}

private fun DrawScope.drawLayers(s: Sc) {
    for (layer in 0 until 3) {
        var x = -30f * s.u
        var idx = layer * 1000
        val col = when (layer) {
            0 -> s.far
            1 -> lerp(s.far, s.mid, 0.6f)
            else -> s.mid
        }
        while (x < s.w) {
            val bw = (24f + hh(idx) * (34f + layer * 10f)) * s.u
            val bh = s.h * (0.035f + 0.04f * layer + hh(idx + 1) * (0.1f + 0.04f * layer))
            drawBuilding(s, x, bw, bh, col, idx, layer)
            x += bw + (1f + hh(idx + 2) * 5f) * s.u
            idx += 3
        }
        val ha = when (layer) {
            0 -> 0.35f
            1 -> 0.22f
            else -> 0.12f
        }
        drawRect(
            Brush.verticalGradient(listOf(Color.Transparent, s.sky[2].copy(alpha = ha)), startY = s.gy - s.h * 0.2f, endY = s.gy),
            Offset(0f, s.gy - s.h * 0.2f), Size(s.w, s.h * 0.2f)
        )
    }
}

private fun DrawScope.flood(s: Sc, x: Float, y: Float, w: Float, h: Float, a: Float) {
    if (!s.glow) return
    drawRect(Brush.verticalGradient(listOf(Color.Transparent, s.warm.copy(alpha = a)), startY = y, endY = y + h), Offset(x, y), Size(w, h))
}

// ---------------------------------------------------------------- BT Tower

private fun DrawScope.drawBt(s: Sc) {
    val u = s.u
    val x = s.w * 0.405f
    val gy = s.gy
    val hgt = s.h * 0.34f
    drawRect(Brush.horizontalGradient(listOf(s.glassHi, s.near), startX = x - 5f * u, endX = x + 5f * u), Offset(x - 5f * u, gy - hgt * 0.78f), Size(10f * u, hgt * 0.78f))
    for (row in 0 until 3) {
        val y = gy - hgt * (0.5f + 0.08f * row)
        drawRect(s.near, Offset(x - 9f * u, y), Size(18f * u, 3f * u))
        for (k in 0 until 6) {
            val dx = cos(k * TAU / 6f + row) * 11f * u
            drawOval(s.mid, Offset(x + dx - 3f * u, y - 5f * u), Size(6f * u, 9f * u))
            drawOval(s.cool.copy(alpha = 0.25f), Offset(x + dx - 2f * u, y - 4f * u), Size(4f * u, 6f * u))
        }
    }
    val cy = gy - hgt * 0.88f
    drawRoundRect(Brush.horizontalGradient(listOf(s.glassHi, s.near), startX = x - 9f * u, endX = x + 9f * u), Offset(x - 9f * u, cy), Size(18f * u, hgt * 0.12f), CornerRadius(4f * u, 4f * u))
    for (k in 0 until 5) {
        ln(if (s.glow) s.cool.copy(alpha = 0.8f) else Color.White.copy(alpha = 0.2f), x - 8f * u, cy + (3f + k * 4f) * u, x + 8f * u, cy + (3f + k * 4f) * u, 1.6f * u)
    }
    ln(s.near, x, cy, x, gy - hgt, 2f * u)
    beacon(s, x, gy - hgt)
}

// ---------------------------------------------------------------- Palace of Westminster and Big Ben

private fun DrawScope.drawWestminster(s: Sc) {
    val u = s.u
    val gy = s.gy
    val cx = s.benCx
    val tw = s.benTw
    val bigH = s.benH
    val px0 = cx + tw * 0.45f
    val pw = s.w * 0.125f
    val ph = s.h * 0.065f
    // steep roofs and gables behind the main block
    for (k in 0 until 16) {
        val gx = px0 + pw * (k + 0.5f) / 16f
        val gh = ph * (0.5f + 0.25f * hh(k + 60))
        poly(s.stoneLo, gx - pw / 32f, gy - ph, gx, gy - ph - gh, gx + pw / 32f, gy - ph)
    }
    drawRect(Brush.verticalGradient(listOf(s.stoneHi, s.stone), startY = gy - ph, endY = gy), Offset(px0, gy - ph), Size(pw, ph))
    val bays = 28
    for (k in 0 until bays) {
        val bx = px0 + pw * k / bays
        val bwid = pw / bays
        ln(s.stoneLo.copy(alpha = 0.5f), bx, gy - ph, bx, gy, 1.2f * u)
        for (row in 0 until 3) {
            val wy = gy - ph + ph * (0.1f + 0.3f * row)
            val wh = ph * 0.22f
            val on = hh(k * 7 + row * 3 + 100) < s.lp + 0.35f
            val c = if (on && s.glow) s.warm.copy(alpha = 0.85f) else s.stoneLo.copy(alpha = 0.8f)
            val wx = bx + bwid * 0.3f
            val ww = bwid * 0.4f
            drawRect(c, Offset(wx, wy + wh * 0.3f), Size(ww, wh * 0.7f))
            poly(c, wx, wy + wh * 0.3f, wx + ww / 2f, wy, wx + ww, wy + wh * 0.3f)
        }
        poly(s.stone, bx + bwid * 0.3f, gy - ph, bx + bwid * 0.5f, gy - ph - ph * (0.3f + 0.12f * (k % 3)), bx + bwid * 0.7f, gy - ph)
    }
    drawRect(s.stoneLo, Offset(px0, gy - ph - 2f * u), Size(pw, 3f * u))
    // Central Tower with its spire
    val ctx = px0 + pw * 0.5f
    val ctw = s.w * 0.012f
    val cth = ph + s.h * 0.07f
    drawRect(Brush.horizontalGradient(listOf(s.stoneHi, s.stoneLo), startX = ctx - ctw / 2f, endX = ctx + ctw / 2f), Offset(ctx - ctw / 2f, gy - cth), Size(ctw, cth))
    poly(s.stoneLo, ctx - ctw * 0.6f, gy - cth, ctx, gy - cth - s.h * 0.05f, ctx + ctw * 0.6f, gy - cth)
    ln(s.gold, ctx, gy - cth - s.h * 0.05f, ctx, gy - cth - s.h * 0.062f, 1.4f * u)
    // Victoria Tower
    val vw = s.w * 0.022f
    val vx = px0 + pw - vw * 0.3f
    val vh = s.h * 0.21f
    drawRect(Brush.horizontalGradient(listOf(s.stoneHi, s.stone, s.stoneLo), startX = vx, endX = vx + vw), Offset(vx, gy - vh), Size(vw, vh))
    for (row in 0 until 7) {
        val wy = gy - vh * (0.1f + 0.12f * row) - 14f * u
        drawRect(if (s.glow && hh(row + 80) < 0.6f) s.warm.copy(alpha = 0.8f) else s.stoneLo, Offset(vx + vw * 0.38f, wy), Size(vw * 0.24f, 10f * u))
        ln(s.stoneLo, vx, wy + 14f * u, vx + vw, wy + 14f * u, 1f * u)
    }
    for (cxp in floatArrayOf(vx, vx + vw - vw * 0.2f)) {
        drawRect(s.stone, Offset(cxp, gy - vh - 10f * u), Size(vw * 0.2f, 10f * u))
        poly(s.stoneLo, cxp - 1f, gy - vh - 10f * u, cxp + vw * 0.1f, gy - vh - 22f * u, cxp + vw * 0.2f + 1f, gy - vh - 10f * u)
    }
    drawRect(s.stoneLo, Offset(vx - 2f * u, gy - vh - 3f * u), Size(vw + 4f * u, 3f * u))
    ln(s.near, vx + vw / 2f, gy - vh - 3f * u, vx + vw / 2f, gy - vh - 34f * u, 1.2f * u)
    poly(s.red.copy(alpha = 0.9f), vx + vw / 2f, gy - vh - 34f * u, vx + vw / 2f + 16f * u, gy - vh - 30f * u, vx + vw / 2f, gy - vh - 26f * u)

    // Elizabeth Tower (Big Ben)
    val x0 = cx - tw / 2f
    drawRect(s.stoneLo, Offset(x0 - tw * 0.04f, gy - bigH * 0.1f), Size(tw * 1.08f, bigH * 0.1f))
    val sx = cx - tw * 0.43f
    val sw = tw * 0.86f
    val shaftTop = gy - bigH * 0.62f
    val shaftBot = gy - bigH * 0.1f
    drawRect(Brush.horizontalGradient(listOf(s.stoneHi, s.stone, s.stoneLo), startX = sx, endX = sx + sw), Offset(sx, shaftTop), Size(sw, shaftBot - shaftTop))
    for (row in 0 until 5) {
        val ry = shaftTop + (shaftBot - shaftTop) * (row / 5f)
        ln(s.stoneLo.copy(alpha = 0.7f), sx, ry, sx + sw, ry, 1.6f * u)
        for (col in 0 until 3) {
            val ax = sx + sw * (0.12f + 0.3f * col)
            val aw = sw * 0.2f
            val ah = (shaftBot - shaftTop) / 5f * 0.62f
            val on = s.glow && hh(row * 5 + col + 300) < 0.45f
            val c = if (on) s.warm.copy(alpha = 0.85f) else s.stoneLo.copy(alpha = 0.55f)
            drawRect(c, Offset(ax, ry + ah * 0.35f + 4f * u), Size(aw, ah * 0.65f))
            poly(c, ax, ry + ah * 0.35f + 4f * u, ax + aw / 2f, ry + 4f * u, ax + aw, ry + ah * 0.35f + 4f * u)
        }
    }
    val stageTop = gy - bigH * 0.8f
    val stx = cx - tw * 0.56f
    val stw = tw * 1.12f
    drawRect(Brush.horizontalGradient(listOf(s.stoneHi, s.stone, s.stoneLo), startX = stx, endX = stx + stw), Offset(stx, stageTop), Size(stw, shaftTop - stageTop))
    drawRect(s.gold.copy(alpha = 0.8f), Offset(stx, shaftTop - 3f * u), Size(stw, 3f * u))
    drawRect(s.gold.copy(alpha = 0.8f), Offset(stx, stageTop), Size(stw, 3f * u))
    for (cxp in floatArrayOf(stx - tw * 0.02f, stx + stw - tw * 0.1f)) {
        drawRect(s.stone, Offset(cxp, stageTop - bigH * 0.04f), Size(tw * 0.12f, bigH * 0.04f))
        poly(s.stoneLo, cxp - 1f, stageTop - bigH * 0.04f, cxp + tw * 0.06f, stageTop - bigH * 0.075f, cxp + tw * 0.12f + 1f, stageTop - bigH * 0.04f)
    }
    val fc = Offset(cx, gy - bigH * 0.71f)
    val fr = tw * 0.4f
    if (s.glow) drawCircle(Brush.radialGradient(listOf(s.warm.copy(alpha = 0.55f), Color.Transparent), center = fc, radius = fr * 3f), fr * 3f, fc)
    drawCircle(s.gold, fr * 1.14f, fc)
    drawCircle(if (s.glow) Color(0xFFFFF4CF) else Color(0xFFF1EDE0), fr, fc)
    val ink = Color(0xFF2B2418)
    for (k in 0 until 60) {
        val a = k * TAU / 60f
        val big = k % 5 == 0
        val len = if (big) 0.22f else 0.09f
        drawLine(
            ink.copy(alpha = 0.85f),
            Offset(fc.x + cos(a) * fr * (0.96f - len), fc.y + sin(a) * fr * (0.96f - len)),
            Offset(fc.x + cos(a) * fr * 0.96f, fc.y + sin(a) * fr * 0.96f),
            (if (big) 2.2f else 1f) * u
        )
    }
    val belTop = gy - bigH * 0.9f
    drawRect(Brush.horizontalGradient(listOf(s.stoneHi, s.stoneLo), startX = cx - tw * 0.42f, endX = cx + tw * 0.42f), Offset(cx - tw * 0.42f, belTop), Size(tw * 0.84f, stageTop - belTop))
    for (k in 0 until 3) {
        val ax = cx - tw * 0.36f + tw * 0.25f * k
        val c = if (s.glow) s.warm.copy(alpha = 0.7f) else Color.Black.copy(alpha = 0.55f)
        drawRect(c, Offset(ax, belTop + 6f * u), Size(tw * 0.17f, stageTop - belTop - 6f * u))
        poly(c, ax, belTop + 6f * u, ax + tw * 0.085f, belTop, ax + tw * 0.17f, belTop + 6f * u)
    }
    val apex = Offset(cx, gy - bigH * 1.0f)
    polyB(
        Brush.verticalGradient(listOf(s.near, s.stone), startY = apex.y, endY = belTop),
        cx - tw * 0.46f, belTop, apex.x, apex.y, cx + tw * 0.46f, belTop
    )
    for (k in -2..2) ln(Color.Black.copy(alpha = 0.18f), cx + k * tw * 0.09f, belTop, apex.x, apex.y, 1f * u)
    drawCircle(s.gold, 2.6f * u, Offset(apex.x, apex.y - 2f * u))
    if (s.glow) {
        val lamp = Offset(cx, gy - bigH * 0.96f)
        drawCircle(Brush.radialGradient(listOf(Color(0xCCFFFFFF), Color.Transparent), center = lamp, radius = 16f * u), 16f * u, lamp)
    }
    flood(s, px0, gy - ph - 20f * u, pw, ph + 20f * u, 0.25f)
}

// ---------------------------------------------------------------- the Shard

private fun DrawScope.drawShard(s: Sc) {
    val u = s.u
    val gy = s.gy
    val hgt = s.shH
    val x = s.shX
    val bw = s.shW
    val ax = x + bw * 0.03f
    val ay = gy - hgt
    val xl = x - bw / 2f
    val xr = x + bw / 2f
    val rx = x + bw * 0.12f
    val l1 = lerp(s.glassHi, Color.White, if (s.night) 0.05f else 0.35f)
    val l2 = lerp(s.mid, s.dark, 0.3f)
    val r1 = lerp(s.glassHi, s.dark, 0.4f)
    val r2 = lerp(s.near, s.dark, 0.45f)
    polyB(Brush.verticalGradient(listOf(l1, l2), startY = ay, endY = gy), xl, gy, rx, gy, ax, ay)
    polyB(Brush.verticalGradient(listOf(r1, r2), startY = ay, endY = gy), rx, gy, xr, gy, ax, ay)
    val body = Path()
    body.moveTo(xl, gy)
    body.lineTo(xr, gy)
    body.lineTo(ax, ay)
    body.close()
    clipPath(body) {
        for (k in 1..5) {
            val bx = xl + (rx - xl) * k / 6f
            ln(Color.White.copy(alpha = 0.12f), bx, gy, ax, ay, 1f * u)
            val bx2 = rx + (xr - rx) * k / 6f
            ln(Color.White.copy(alpha = 0.07f), bx2, gy, ax, ay, 1f * u)
        }
        for (k in 1 until 64) {
            val f = k / 64f * 0.97f
            val lx = xl + (ax - xl) * f
            val rxx = xr + (ax - xr) * f
            val y = gy - hgt * f
            val on = s.glow && hh(k + 700) < 0.6f
            drawLine((if (on) s.warm else Color.White).copy(alpha = if (on) 0.5f else 0.08f), Offset(lx, y), Offset(rxx, y), (if (on) 1.6f else 1f) * u)
        }
        // illuminated crown
        drawRect(
            Brush.verticalGradient(
                listOf(Color(0xFFFFF6DC).copy(alpha = if (s.glow) 0.98f else 0.45f), Color(0xFFFFE2A0).copy(alpha = if (s.glow) 0.45f else 0.12f), Color.Transparent),
                startY = ay, endY = ay + hgt * 0.3f
            ),
            Offset(xl, ay), Size(bw, hgt * 0.3f)
        )
    }
    ln(Color.White.copy(alpha = 0.4f), rx, gy, ax, ay, 1.6f * u)
    // the splayed glass blades at the top
    for (k in 0 until 5) {
        val off = (k - 2) * bw * 0.055f
        val by = ay + hgt * 0.17f
        val tipY = ay - hgt * (0.012f + 0.022f * (2 - abs(k - 2)))
        polyB(
            Brush.verticalGradient(listOf(Color(0xFFFFF8E4).copy(alpha = 0.95f), Color(0xFFBFD6F0).copy(alpha = 0.15f)), startY = tipY, endY = by),
            ax + off - bw * 0.03f, by, ax + off + bw * 0.03f, by, ax + off * 0.5f, tipY
        )
    }
    if (s.glow) {
        val tip = Offset(ax, ay)
        drawCircle(Brush.radialGradient(listOf(Color(0xAAFFF1C8), Color(0x33FFD98A), Color.Transparent), center = tip, radius = bw * 2.8f), bw * 2.8f, tip)
        polyB(
            Brush.verticalGradient(listOf(Color.Transparent, Color(0x33FFFFFF)), startY = ay - 260f * u, endY = ay),
            ax - 3f * u, ay, ax + 3f * u, ay, ax + 16f * u, ay - 260f * u, ax - 16f * u, ay - 260f * u
        )
    }
    ln(s.near, ax, ay, ax, ay - 30f * u, 1.6f * u)
    beacon(s, ax, ay - 30f * u)
}

// ---------------------------------------------------------------- St Paul's Cathedral

private fun DrawScope.drawStPauls(s: Sc) {
    val u = s.u
    val gy = s.gy
    val cx = s.w * 0.605f
    val wn = s.w * 0.085f
    val nh = s.h * 0.055f
    val st = s.stone
    drawRect(Brush.verticalGradient(listOf(s.stoneHi, st), startY = gy - nh, endY = gy), Offset(cx - wn / 2f, gy - nh), Size(wn, nh))
    // portico: two rows of columns and a pediment
    val pw = wn * 0.42f
    for (k in 0 until 12) {
        val colx = cx - pw / 2f + pw * k / 11f
        drawRect(s.stoneLo.copy(alpha = 0.7f), Offset(colx - 1.2f * u, gy - nh * 0.55f), Size(2.4f * u, nh * 0.55f))
    }
    for (k in 0 until 8) {
        val colx = cx - pw * 0.4f + pw * 0.8f * k / 7f
        drawRect(s.stoneLo.copy(alpha = 0.7f), Offset(colx - 1.1f * u, gy - nh * 0.95f), Size(2.2f * u, nh * 0.35f))
    }
    poly(s.stoneHi, cx - pw * 0.5f, gy - nh * 0.97f, cx, gy - nh * 1.3f, cx + pw * 0.5f, gy - nh * 0.97f)
    for (k in 0 until 14) {
        val wx = cx - wn / 2f + wn * (k + 0.5f) / 14f
        if (abs(wx - cx) > pw * 0.55f) {
            drawRect(if (s.glow && hh(k + 410) < 0.5f) s.warm.copy(alpha = 0.8f) else s.stoneLo.copy(alpha = 0.6f), Offset(wx - 1.6f * u, gy - nh * 0.8f), Size(3.2f * u, nh * 0.45f))
        }
    }
    // west towers with tiered tops
    for (sgn in intArrayOf(-1, 1)) {
        val tx = cx + sgn * wn * 0.42f
        val tw = wn * 0.17f
        val t1 = s.h * 0.045f
        drawRect(Brush.horizontalGradient(listOf(s.stoneHi, st), startX = tx - tw / 2f, endX = tx + tw / 2f), Offset(tx - tw / 2f, gy - nh - t1), Size(tw, t1))
        drawRect(st, Offset(tx - tw * 0.4f, gy - nh - t1 - t1 * 0.6f), Size(tw * 0.8f, t1 * 0.6f))
        drawRect(s.stoneLo, Offset(tx - tw * 0.5f, gy - nh - t1 - 2f * u), Size(tw, 3f * u))
        drawArc(st, 180f, 180f, true, Offset(tx - tw * 0.3f, gy - nh - t1 * 1.6f - tw * 0.3f), Size(tw * 0.6f, tw * 0.6f))
        ln(s.gold, tx, gy - nh - t1 * 1.6f - tw * 0.3f, tx, gy - nh - t1 * 1.6f - tw * 0.55f, 1.4f * u)
    }
    // drum with columns, dome with ribs, lantern, ball and cross
    val dr = wn * 0.17f
    val drumH = s.h * 0.045f
    val drumTop = gy - nh - drumH - s.h * 0.012f
    drawRect(Brush.horizontalGradient(listOf(s.stoneHi, st, s.stoneLo), startX = cx - dr * 1.1f, endX = cx + dr * 1.1f), Offset(cx - dr * 1.1f, drumTop), Size(dr * 2.2f, drumH))
    for (k in 0 until 17) {
        val lx = cx - dr * 1.0f + dr * 2f * k / 16f
        ln(s.stoneLo.copy(alpha = 0.55f), lx, drumTop + drumH * 0.15f, lx, drumTop + drumH * 0.92f, 1.6f * u)
    }
    drawRect(s.stoneLo, Offset(cx - dr * 1.15f, drumTop - 2f * u), Size(dr * 2.3f, 3f * u))
    val domeBase = drumTop - 2f * u
    drawArc(Brush.horizontalGradient(listOf(s.stoneHi, st, s.stoneLo), startX = cx - dr, endX = cx + dr), 180f, 180f, true, Offset(cx - dr, domeBase - dr), Size(dr * 2f, dr * 2f))
    for (k in -5..5) {
        val bx = cx + dr * k / 6f
        val path = Path()
        path.moveTo(bx, domeBase)
        path.quadraticBezierTo(cx + (bx - cx) * 0.9f, domeBase - dr * 0.85f, cx, domeBase - dr)
        drawPath(path, Color.Black.copy(alpha = 0.2f), style = Stroke(1f * u))
    }
    val lt = domeBase - dr
    drawRect(st, Offset(cx - 5f * u, lt - 16f * u), Size(10f * u, 16f * u))
    for (k in 0 until 5) ln(s.stoneLo, cx - 4f * u + 2f * u * k, lt - 15f * u, cx - 4f * u + 2f * u * k, lt - 1f * u, 0.9f * u)
    drawArc(s.gold, 180f, 180f, true, Offset(cx - 5f * u, lt - 22f * u), Size(10f * u, 10f * u))
    drawCircle(s.gold, 2.6f * u, Offset(cx, lt - 25f * u))
    ln(s.gold, cx, lt - 27f * u, cx, lt - 37f * u, 1.6f * u)
    ln(s.gold, cx - 3.5f * u, lt - 33f * u, cx + 3.5f * u, lt - 33f * u, 1.6f * u)
    flood(s, cx - wn / 2f, lt - 20f * u, wn, gy - lt + 20f * u, 0.3f)
}

// ---------------------------------------------------------------- City towers: Walkie Talkie, Cheesegrater, Gherkin, Tower 42, Heron

private fun DrawScope.drawCluster(s: Sc) {
    val u = s.u
    val gy = s.gy
    // Walkie Talkie
    run {
        val x = s.w * 0.675f
        val hgt = s.h * 0.3f
        val wb = s.w * 0.02f
        val wt = s.w * 0.034f
        val p = Path()
        p.moveTo(x - wb / 2f, gy)
        p.cubicTo(x - wb * 0.5f, gy - hgt * 0.45f, x - wt * 0.55f, gy - hgt * 0.8f, x - wt / 2f, gy - hgt)
        p.lineTo(x + wt / 2f, gy - hgt)
        p.cubicTo(x + wt * 0.55f, gy - hgt * 0.8f, x + wb * 0.5f, gy - hgt * 0.45f, x + wb / 2f, gy)
        p.close()
        drawPath(p, Brush.horizontalGradient(listOf(s.glassHi, s.near), startX = x - wt / 2f, endX = x + wt / 2f))
        clipPath(p) {
            for (k in 1 until 56) {
                val y = gy - hgt * k / 56f
                val on = s.glow && hh(k + 910) < 0.55f
                drawLine((if (on) s.warm else Color.White).copy(alpha = if (on) 0.45f else 0.09f), Offset(x - wt, y), Offset(x + wt, y), 1.4f * u)
            }
            drawRect(Brush.verticalGradient(listOf(s.warm.copy(alpha = if (s.glow) 0.8f else 0.25f), Color.Transparent), startY = gy - hgt, endY = gy - hgt * 0.9f), Offset(x - wt, gy - hgt), Size(wt * 2f, hgt * 0.1f))
        }
        ln(Color.White.copy(alpha = 0.25f), x - wt / 2f, gy - hgt, x + wt / 2f, gy - hgt, 2f * u)
    }
    // Cheesegrater
    run {
        val x = s.w * 0.717f
        val hgt = s.h * 0.31f
        val bw = s.w * 0.028f
        val xl = x - bw / 2f
        val xr = x + bw / 2f
        polyB(Brush.horizontalGradient(listOf(s.glassHi, s.near), startX = xl, endX = xr), xl, gy, xr, gy, xr, gy - hgt, xl, gy - hgt * 0.62f)
        val body = Path()
        body.moveTo(xl, gy)
        body.lineTo(xr, gy)
        body.lineTo(xr, gy - hgt)
        body.lineTo(xl, gy - hgt * 0.62f)
        body.close()
        clipPath(body) {
            for (k in 1 until 40) {
                val y = gy - hgt * k / 40f
                val on = s.glow && hh(k + 930) < 0.5f
                drawLine((if (on) s.warm else Color.White).copy(alpha = if (on) 0.4f else 0.07f), Offset(xl, y), Offset(xr, y), 1.2f * u)
            }
            val brace = Color(0xFFC0503C).copy(alpha = if (s.night) 0.55f else 0.85f)
            for (lvl in 0 until 7) {
                val y0 = gy - hgt * lvl / 7f
                val y1 = gy - hgt * (lvl + 1) / 7f
                ln(brace, xl, y0, xr, y1, 1.8f * u)
                ln(brace, xr, y0, xl, y1, 1.8f * u)
            }
        }
    }
    // Gherkin
    run {
        val x = s.w * 0.762f
        val hgt = s.h * 0.33f
        val wb = s.w * 0.022f
        val wm = s.w * 0.036f
        val p = Path()
        p.moveTo(x - wb / 2f, gy)
        p.cubicTo(x - wb * 0.7f, gy - hgt * 0.15f, x - wm / 2f, gy - hgt * 0.28f, x - wm / 2f, gy - hgt * 0.4f)
        p.cubicTo(x - wm * 0.5f, gy - hgt * 0.7f, x - wm * 0.15f, gy - hgt * 0.93f, x, gy - hgt)
        p.cubicTo(x + wm * 0.15f, gy - hgt * 0.93f, x + wm * 0.5f, gy - hgt * 0.7f, x + wm / 2f, gy - hgt * 0.4f)
        p.cubicTo(x + wm / 2f, gy - hgt * 0.28f, x + wb * 0.7f, gy - hgt * 0.15f, x + wb / 2f, gy)
        p.close()
        drawPath(p, Brush.horizontalGradient(listOf(s.glassHi, s.near), startX = x - wm / 2f, endX = x + wm / 2f))
        clipPath(p) {
            for (k in -8..8) {
                val bx = x + k * wm * 0.1f
                ln(Color.Black.copy(alpha = 0.3f), bx, gy, bx + wm * 0.9f, gy - hgt, 3f * u)
                ln(Color.White.copy(alpha = 0.1f), bx + 3f * u, gy, bx + wm * 0.9f + 3f * u, gy - hgt, 1f * u)
                ln(Color.Black.copy(alpha = 0.18f), bx, gy, bx - wm * 0.9f, gy - hgt, 1.4f * u)
            }
            for (k in 1 until 46) {
                val y = gy - hgt * k / 46f
                if (s.glow && hh(k + 950) < 0.5f) drawLine(s.warm.copy(alpha = 0.35f), Offset(x - wm, y), Offset(x + wm, y), 1.3f * u)
            }
            drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = if (s.glow) 0.7f else 0.3f), Color.Transparent), startY = gy - hgt, endY = gy - hgt * 0.9f), Offset(x - wm, gy - hgt), Size(wm * 2f, hgt * 0.1f))
        }
    }
    // Tower 42
    run {
        val x = s.w * 0.808f
        val tiers = floatArrayOf(0.034f, 0.026f, 0.02f, 0.03f)
        val hs = floatArrayOf(0.12f, 0.08f, 0.04f, 0.04f)
        var y = gy
        for (i in 0 until 4) {
            val tw = s.w * tiers[i]
            val th = s.h * hs[i]
            drawRect(Brush.horizontalGradient(listOf(s.glassHi, s.near), startX = x - tw / 2f, endX = x + tw / 2f), Offset(x - tw / 2f, y - th), Size(tw, th))
            wins(s, x - tw / 2f, y - th, tw, th, 960 + i, 5f, 7f, 0.15f)
            drawRect(s.dark.copy(alpha = 0.35f), Offset(x - tw / 2f, y - th - 1.5f * u), Size(tw, 2.5f * u))
            y -= th
        }
        drawRect(s.near, Offset(x - 2f * u, y - 18f * u), Size(4f * u, 18f * u))
    }
    // Heron Tower with its mast
    run {
        val x = s.w * 0.84f
        val tw = s.w * 0.018f
        val th = s.h * 0.28f
        drawRect(Brush.horizontalGradient(listOf(s.glassHi, s.near), startX = x - tw / 2f, endX = x + tw / 2f), Offset(x - tw / 2f, gy - th), Size(tw, th))
        wins(s, x - tw / 2f, gy - th, tw, th, 980, 5f, 7f, 0.1f)
        drawRect(s.near, Offset(x - 1.5f * u, gy - th - s.h * 0.07f), Size(3f * u, s.h * 0.07f))
        beacon(s, x, gy - th - s.h * 0.07f)
    }
}

// ---------------------------------------------------------------- Canary Wharf

private fun DrawScope.drawCanary(s: Sc) {
    val u = s.u
    val gy = s.gy
    val x = s.cwX
    val items = arrayOf(
        floatArrayOf(-0.065f, 0.018f, 0.2f),
        floatArrayOf(-0.034f, 0.022f, 0.3f),
        floatArrayOf(0.034f, 0.022f, 0.31f),
        floatArrayOf(0.06f, 0.02f, 0.22f),
        floatArrayOf(0.078f, 0.016f, 0.17f)
    )
    for ((i, it) in items.withIndex()) {
        val bx = x + s.w * it[0]
        val bw = s.w * it[1]
        val bh = s.h * it[2]
        drawRect(Brush.horizontalGradient(listOf(s.glassHi, s.near), startX = bx - bw / 2f, endX = bx + bw / 2f), Offset(bx - bw / 2f, gy - bh), Size(bw, bh))
        wins(s, bx - bw / 2f, gy - bh, bw, bh, 1000 + i, 6f, 8f, 0.1f)
        drawRect(s.dark.copy(alpha = 0.3f), Offset(bx - bw / 2f, gy - bh), Size(bw, 3f * u))
    }
    val bw = s.w * 0.026f
    val bh = s.h * 0.4f
    drawRect(Brush.horizontalGradient(listOf(s.glassHi, s.mid, s.near), startX = x - bw / 2f, endX = x + bw / 2f), Offset(x - bw / 2f, gy - bh), Size(bw, bh))
    for (k in 1..5) ln(Color.White.copy(alpha = 0.1f), x - bw / 2f + bw * k / 6f, gy, x - bw / 2f + bw * k / 6f, gy - bh, 1.2f * u)
    wins(s, x - bw / 2f, gy - bh, bw, bh, 1100, 5f, 7f, 0.15f)
    poly(s.stoneLo, x - bw / 2f, gy - bh, x, gy - bh - s.h * 0.045f, x + bw / 2f, gy - bh)
    poly(Color.White.copy(alpha = if (s.glow) 0.5f else 0.12f), x - bw * 0.12f, gy - bh - s.h * 0.03f, x, gy - bh - s.h * 0.045f, x + bw * 0.12f, gy - bh - s.h * 0.03f)
    beacon(s, x, gy - bh - s.h * 0.045f - 2f * u)
}

// ---------------------------------------------------------------- foreground: river, bridge, Eye, bank

private fun DrawScope.drawForeground(s: Sc, a: ImageBitmap) {
    val u = s.u
    drawImage(a)
    val w0 = s.gy
    val w1 = s.bank
    drawRect(
        Brush.verticalGradient(listOf(lerp(s.sky[2], s.dark, 0.45f), lerp(s.sky[1], s.dark, 0.8f)), startY = w0, endY = w1),
        Offset(0f, w0), Size(s.w, w1 - w0)
    )
    // mirrored strips of the skyline with a ripple that grows towards the viewer
    val strip = max(2, (3f * u).toInt())
    var yd = w0.toInt()
    val yEnd = w1.toInt()
    while (yd < yEnd) {
        val sth = min(strip, yEnd - yd)
        val ys = (2f * w0 - yd - sth).toInt()
        if (ys >= 0 && ys + sth <= a.height) {
            val depth = (yd - w0) / (w1 - w0)
            val dx = (sin(yd * 0.09f) * 3f * u * (1f + depth * 2f)).toInt()
            val al = 0.5f * (1f - depth * 0.6f)
            withTransform({ scale(1f, -1f, Offset(0f, yd + sth / 2f)) }) {
                drawImage(
                    a,
                    srcOffset = IntOffset(0, ys), srcSize = IntSize(a.width, sth),
                    dstOffset = IntOffset(dx, yd), dstSize = IntSize(a.width, sth),
                    alpha = al
                )
            }
        }
        yd += sth
    }
    drawRect(
        Brush.verticalGradient(listOf(Color.Transparent, s.dark.copy(alpha = 0.45f)), startY = w0, endY = w1),
        Offset(0f, w0), Size(s.w, w1 - w0)
    )
    for (k in 0 until 80) {
        val y = w0 + (w1 - w0) * hh(k + 1200)
        val x = hh(k + 1300) * s.w
        drawLine(Color.White.copy(alpha = 0.06f), Offset(x, y), Offset(x + (30f + 70f * hh(k + 1400)) * u, y), 1.4f * u)
    }
    // north embankment wall along the far bank
    drawRect(Brush.verticalGradient(listOf(s.stoneLo, s.near), startY = s.gy - 2f * u, endY = s.gy + 10f * u), Offset(0f, s.gy - 2f * u), Size(s.w, 12f * u))
    drawTowerBridge(s)
    drawEyeStatic(s)
    drawSouthBank(s)
}

private fun DrawScope.drawTowerBridge(s: Sc) {
    val u = s.u
    val h = s.h
    val w = s.w
    val tbw = w * 0.02f
    val yb = h * 0.8f
    val yt = h * 0.46f
    val walk = h * 0.535f
    val blue = lerp(Color(0xFF3B6BC4), s.dark, if (s.night) 0.55f else 0.22f)
    val blueHi = lerp(blue, Color.White, 0.25f)
    val abW = w * 0.011f
    val abTop = h * 0.6f
    // shore abutment towers
    for (ax in floatArrayOf(s.abL, s.abR)) {
        drawRect(Brush.horizontalGradient(listOf(s.stoneHi, s.stoneLo), startX = ax - abW / 2f, endX = ax + abW / 2f), Offset(ax - abW / 2f, abTop), Size(abW, s.deck - abTop + 6f * u))
        poly(blue, ax - abW * 0.6f, abTop, ax, abTop - h * 0.03f, ax + abW * 0.6f, abTop)
        drawRect(if (s.glow) s.warm.copy(alpha = 0.8f) else s.stoneLo, Offset(ax - 2f * u, abTop + 10f * u), Size(4f * u, 10f * u))
    }
    // suspension chains with hangers
    for ((side, tx) in floatArrayOf(s.t1, s.t2).withIndex()) {
        val ax = if (side == 0) s.abL else s.abR
        val sx0 = ax
        val sy0 = abTop
        val sx1 = if (side == 0) tx - tbw * 0.3f else tx + tbw * 0.3f
        val sy1 = yt + (yb - yt) * 0.3f
        val sag = h * 0.05f
        var px = sx0
        var py = sy0
        for (i in 1..28) {
            val t = i / 28f
            val x = sx0 + (sx1 - sx0) * t
            val y = sy0 + (sy1 - sy0) * t + sag * 4f * t * (1f - t)
            ln(blue, px, py, x, y, 2.6f * u)
            ln(blueHi.copy(alpha = 0.6f), px, py - 2.2f * u, x, y - 2.2f * u, 0.9f * u)
            if (i % 2 == 0 && y < s.deck) ln(blue.copy(alpha = 0.8f), x, y, x, s.deck, 1f * u)
            px = x
            py = y
        }
    }
    // road decks
    drawRect(blue, Offset(s.abL, s.deck), Size(s.abR - s.abL, 7f * u))
    drawRect(Color.Black.copy(alpha = 0.3f), Offset(s.abL, s.deck + 7f * u), Size(s.abR - s.abL, 9f * u))
    var gx = s.abL
    while (gx < s.abR) {
        ln(blue.copy(alpha = 0.7f), gx, s.deck + 7f * u, gx + 9f * u, s.deck + 16f * u, 1f * u)
        ln(blue.copy(alpha = 0.7f), gx + 9f * u, s.deck + 7f * u, gx + 18f * u, s.deck + 16f * u, 1f * u)
        gx += 18f * u
    }
    if (s.glow) {
        var lx = s.abL
        while (lx < s.abR) {
            drawCircle(s.warm.copy(alpha = 0.9f), 1.8f * u, Offset(lx, s.deck - 2f * u))
            lx += 12f * u
        }
    }
    // high-level walkway
    val wx0 = s.t1
    val wx1 = s.t2
    drawRect(blue, Offset(wx0, walk), Size(wx1 - wx0, 4f * u))
    drawRect(blue, Offset(wx0, walk + 14f * u), Size(wx1 - wx0, 3f * u))
    var zx = wx0
    while (zx < wx1) {
        ln(blue, zx, walk + 4f * u, zx + 7f * u, walk + 14f * u, 1f * u)
        ln(blue, zx + 7f * u, walk + 4f * u, zx + 14f * u, walk + 14f * u, 1f * u)
        if (s.glow) drawRect(s.warm.copy(alpha = 0.6f), Offset(zx + 3f * u, walk + 6f * u), Size(3f * u, 5f * u))
        zx += 14f * u
    }
    // the two towers
    for (tx in floatArrayOf(s.t1, s.t2)) {
        val x0 = tx - tbw / 2f
        drawRect(Brush.horizontalGradient(listOf(s.stoneHi, s.stone, s.stoneLo), startX = x0, endX = x0 + tbw), Offset(x0 - 3f * u, yb - 14f * u), Size(tbw + 6f * u, 40f * u))
        drawRect(Brush.horizontalGradient(listOf(s.stoneHi, s.stone, s.stoneLo), startX = x0, endX = x0 + tbw), Offset(x0, yt + h * 0.03f), Size(tbw, yb - yt - h * 0.03f))
        for (row in 0 until 9) {
            val y = yt + h * 0.05f + (yb - yt - h * 0.08f) * row / 9f
            ln(s.stoneLo.copy(alpha = 0.6f), x0, y, x0 + tbw, y, 1.4f * u)
            for (col in 0 until 2) {
                val on = s.glow && hh(row * 3 + col + (tx / u).toInt()) < 0.55f
                val c = if (on) s.warm.copy(alpha = 0.85f) else s.stoneLo.copy(alpha = 0.6f)
                drawRect(c, Offset(x0 + tbw * (0.2f + 0.4f * col), y + 5f * u), Size(tbw * 0.2f, 10f * u))
                poly(c, x0 + tbw * (0.2f + 0.4f * col), y + 5f * u, x0 + tbw * (0.3f + 0.4f * col), y + 1f * u, x0 + tbw * (0.4f + 0.4f * col), y + 5f * u)
            }
        }
        // corner turrets with pointed roofs and the central roof
        for (k in 0 until 4) {
            val rx = x0 + (tbw - tbw * 0.22f) * k / 3f
            drawRect(s.stone, Offset(rx, yt - h * 0.005f), Size(tbw * 0.22f, h * 0.05f))
            poly(blue, rx - 1.5f * u, yt - h * 0.005f, rx + tbw * 0.11f, yt - h * 0.045f, rx + tbw * 0.22f + 1.5f * u, yt - h * 0.005f)
        }
        poly(blue, x0 + tbw * 0.12f, yt + h * 0.02f, tx, yt - h * 0.02f, x0 + tbw * 0.88f, yt + h * 0.02f)
        ln(s.near, tx, yt - h * 0.02f, tx, yt - h * 0.045f, 1.2f * u)
    }
    if (s.glow) {
        for (tx in floatArrayOf(s.t1, s.t2)) {
            drawCircle(Brush.radialGradient(listOf(s.warm.copy(alpha = 0.22f), Color.Transparent), center = Offset(tx, h * 0.62f), radius = h * 0.2f), h * 0.2f, Offset(tx, h * 0.62f))
        }
    }
}

private fun DrawScope.drawEyeStatic(s: Sc) {
    val u = s.u
    val cx = s.eyeCx
    val cy = s.eyeCy
    val r = s.eyeR
    val steel = if (s.night) Color(0xFFBFD6F5) else Color(0xFFE9EEF5)
    val dim = steel.copy(alpha = 0.55f)
    val foot = s.bank
    // A-frame legs and cross braces
    val f1 = cx + r * 0.3f
    val f2 = cx + r * 0.72f
    poly(lerp(steel, s.dark, 0.25f), cx - r * 0.03f, cy, cx + r * 0.03f, cy, f1 + r * 0.04f, foot, f1 - r * 0.04f, foot)
    poly(steel, cx - r * 0.03f, cy, cx + r * 0.03f, cy, f2 + r * 0.04f, foot, f2 - r * 0.04f, foot)
    for (k in 1..7) {
        val t = k / 8f
        val ya = cy + (foot - cy) * t
        ln(dim, cx + (f1 - cx) * t, ya, cx + (f2 - cx) * t, ya, 1.2f * u)
    }
    drawRect(s.stoneLo, Offset(f1 - r * 0.09f, foot - 4f * u), Size(r * 0.8f, 8f * u))
    if (s.glow) drawCircle(steel.copy(alpha = 0.12f), r, Offset(cx, cy), style = Stroke(r * 0.07f))
    drawCircle(steel, r, Offset(cx, cy), style = Stroke(r * 0.022f))
    drawCircle(dim, r * 0.95f, Offset(cx, cy), style = Stroke(r * 0.011f))
    for (k in 0 until 96) {
        val a1 = k * TAU / 96f
        val a2 = (k + 1) * TAU / 96f
        drawLine(
            dim,
            Offset(cx + cos(a1) * r * 0.995f, cy + sin(a1) * r * 0.995f),
            Offset(cx + cos(a2) * r * 0.955f, cy + sin(a2) * r * 0.955f),
            1f * u
        )
    }
    for (k in 0 until 32) {
        val a = k * TAU / 32f
        val rim = Offset(cx + cos(a) * r * 0.95f, cy + sin(a) * r * 0.95f)
        drawLine(dim, Offset(cx + cos(a + 0.9f) * r * 0.05f, cy + sin(a + 0.9f) * r * 0.05f), rim, 0.9f * u)
        drawLine(dim, Offset(cx + cos(a - 0.9f) * r * 0.05f, cy + sin(a - 0.9f) * r * 0.05f), rim, 0.9f * u)
        val a2 = a + TAU / 64f
        drawLine(dim.copy(alpha = 0.3f), Offset(cx + cos(a2) * r * 0.4f, cy + sin(a2) * r * 0.4f), rim, 0.8f * u)
    }
    drawCircle(dim, r * 0.055f, Offset(cx, cy))
    drawCircle(steel, r * 0.035f, Offset(cx, cy))
    drawCircle(s.dark, r * 0.014f, Offset(cx, cy))
}

private fun DrawScope.drawSouthBank(s: Sc) {
    val u = s.u
    val w = s.w
    val h = s.h
    val b = s.bank
    val roadTop = h * 0.925f
    val pav = b + h * 0.03f
    drawRect(Brush.verticalGradient(listOf(s.stoneLo, s.near), startY = b, endY = pav), Offset(0f, b), Size(w, pav - b))
    drawRect(s.stoneHi.copy(alpha = 0.6f), Offset(0f, b), Size(w, 2.5f * u))
    drawRect(Brush.verticalGradient(listOf(lerp(s.near, s.stone, 0.3f), s.near), startY = pav, endY = roadTop), Offset(0f, pav), Size(w, roadTop - pav))
    drawRect(Brush.verticalGradient(listOf(Color(0xFF0C121E), Color(0xFF04070D)), startY = roadTop, endY = h), Offset(0f, roadTop), Size(w, h - roadTop))
    drawRect(Color.White.copy(alpha = 0.1f), Offset(0f, roadTop), Size(w, 2f * u))
    var dx = 0f
    while (dx < w) {
        drawRect(Color.White.copy(alpha = 0.18f), Offset(dx, h * 0.968f), Size(26f * u, 2.5f * u))
        dx += 60f * u
    }
    // balustrade
    var x = 0f
    while (x < w) {
        drawRect(s.stone, Offset(x, b - 9f * u), Size(3.5f * u, 9f * u))
        x += 11f * u
    }
    drawRect(s.stoneHi, Offset(0f, b - 10.5f * u), Size(w, 2.5f * u))
    // trees
    for (i in 0 until 15) {
        val tx = w * (0.02f + 0.067f * i + 0.02f * hh(i + 1500))
        val trunkH = h * 0.05f
        val ty = pav - 4f * u
        drawRect(Color(0xFF0B0F14), Offset(tx - 2.5f * u, ty - trunkH), Size(5f * u, trunkH))
        for (j in 0 until 16) {
            val cx2 = tx + (hh(i * 40 + j) * 2f - 1f) * 30f * u
            val cy2 = ty - trunkH - 6f * u - hh(i * 40 + j + 20) * 40f * u
            val rr = (14f + hh(i * 40 + j + 10) * 16f) * u
            val base = lerp(Color(0xFF14361F), s.dark, if (s.night) 0.8f else 0.3f)
            drawCircle(Brush.radialGradient(listOf(lerp(base, s.sky[2], 0.25f), base), center = Offset(cx2 - rr * 0.3f, cy2 - rr * 0.4f), radius = rr * 1.3f), rr, Offset(cx2, cy2))
        }
    }
    // Victorian lamps with twin lanterns
    for (i in 0 until 14) {
        val lx = w * (0.045f + 0.0715f * i)
        val base = pav + 4f * u
        val top = base - h * 0.1f
        drawRect(Color(0xFF0B0F14), Offset(lx - 5f * u, base - 10f * u), Size(10f * u, 10f * u))
        drawRect(Color(0xFF0B0F14), Offset(lx - 2f * u, top), Size(4f * u, base - top - 10f * u))
        ln(Color(0xFF0B0F14), lx, top + 8f * u, lx - 12f * u, top + 2f * u, 2f * u)
        ln(Color(0xFF0B0F14), lx, top + 8f * u, lx + 12f * u, top + 2f * u, 2f * u)
        for (sgn in intArrayOf(-1, 1)) {
            val hx = lx + sgn * 12f * u
            val hy = top
            poly(Color(0xFF0B0F14), hx - 4f * u, hy, hx, hy - 7f * u, hx + 4f * u, hy)
            drawRect(if (s.glow) Color(0xFFFFE9B0) else Color(0xFF3A4452), Offset(hx - 3f * u, hy), Size(6f * u, 8f * u))
            if (s.glow) drawCircle(Brush.radialGradient(listOf(Color(0x66FFD98A), Color.Transparent), center = Offset(hx, hy + 4f * u), radius = 44f * u), 44f * u, Offset(hx, hy + 4f * u))
        }
    }
}

// ---------------------------------------------------------------- moving parts

private fun DrawScope.drawLive(s: Sc, p: Float) {
    val w = s.w
    val h = s.h
    val u = s.u
    // twinkling stars (kept in the clear sky, away from the Shard)
    if (s.night) {
        for (i in 0 until 70) {
            val x = hh(i * 7 + 2000) * w
            val y = hh(i * 7 + 2001) * h * 0.22f
            if (abs(x - s.shX) < s.shW) continue
            val tw = abs(sin(TAU * (8 + i % 9) * p + i))
            drawCircle(Color.White.copy(alpha = 0.7f * tw), (0.9f + hh(i * 7 + 2002) * 1.5f) * u, Offset(x, y))
        }
    }
    // clouds drifting
    val lit = when (s.tod) {
        "night" -> Color(0xFF7C8FC4)
        "sunrise", "sunset" -> Color(0xFFFFD2B0)
        else -> Color.White
    }
    val shade = when (s.tod) {
        "night" -> Color(0xFF2A3560)
        "sunrise", "sunset" -> Color(0xFFB0627A)
        else -> Color(0xFFB7C4D8)
    }
    val ca = if (s.night) 0.35f else 0.5f
    for (i in 0 until 5) {
        val sz = (220f + hh(i * 7 + 3) * 320f) * u
        val x = ((p * (2 + i % 3) + hh(i * 7)) % 1f) * (w + sz * 2f) - sz
        val y = h * (0.03f + 0.17f * hh(i * 7 + 1))
        for (j in 0 until 7) {
            val f = j / 6f
            val pr = sz * (0.09f + 0.1f * hh(i * 13 + j)) * (1f - abs(f - 0.5f) * 0.8f)
            val c = Offset(x + sz * f, y + sz * 0.05f * sin(j * 1.7f + i) - pr * 0.2f)
            drawCircle(
                Brush.radialGradient(listOf(lit.copy(alpha = ca), shade.copy(alpha = ca * 0.5f), Color.Transparent), center = Offset(c.x - pr * 0.25f, c.y - pr * 0.35f), radius = pr * 1.5f),
                pr * 1.5f, c
            )
        }
    }
    // aircraft with strobes (contrails by day)
    for (j in 0 until 2) {
        val dir = if (j % 2 == 0) 1f else -1f
        val t = (p * (2 + j) + hh(j + 300)) % 1f
        val px = (if (dir > 0f) t else 1f - t) * (w + 300f * u) - 150f * u
        val py = h * (0.05f + 0.05f * j) + t * h * 0.02f
        if (!s.night) drawLine(Color.White.copy(alpha = 0.35f), Offset(px - 9f * u * dir, py), Offset(px - 180f * u * dir, py), 2f * u, StrokeCap.Round)
        drawLine(if (s.night) Color.White else Color(0xFF223046), Offset(px - 9f * u * dir, py), Offset(px + 9f * u * dir, py), 3f * u, StrokeCap.Round)
        if (sin(TAU * (28f + j) * p) > 0.2f) drawCircle(Color.White.copy(alpha = 0.9f), 3f * u, Offset(px, py - 3f * u))
        drawCircle(s.red, 2f * u, Offset(px - 4f * u, py + 2f * u))
        drawCircle(Color(0xFF34D17A), 2f * u, Offset(px + 4f * u, py + 2f * u))
    }
    // window lights switching off and on, aviation beacons
    for ((i, b) in s.blink.withIndex()) {
        if (sin(TAU * (3 + i % 7) * p + i) > 0.6f) {
            drawRect(Color(0xE60A101C), Offset(b.x * w, b.y * h), Size(4.5f * u, 7f * u))
        }
    }
    for ((i, b) in s.beacons.withIndex()) {
        if (sin(TAU * (90 + i % 7) * p + i * 1.7f) > 0f) {
            val c = Offset(b.x * w, b.y * h)
            drawCircle(s.red.copy(alpha = 0.95f), 2.6f * u, c)
            drawCircle(s.red.copy(alpha = 0.25f), 9f * u, c)
        }
    }
    // Big Ben: the real time
    val tm = java.time.LocalTime.now()
    val mA = (tm.minute + tm.second / 60f) / 60f * TAU - TAU / 4f
    val hA = ((tm.hour % 12) + tm.minute / 60f) / 12f * TAU - TAU / 4f
    val fc = Offset(s.benCx, s.gy - s.benH * 0.71f)
    val fr = s.benTw * 0.4f
    val ink = Color(0xFF2B2418)
    drawLine(ink, fc, Offset(fc.x + cos(hA) * fr * 0.5f, fc.y + sin(hA) * fr * 0.5f), 3f * u, StrokeCap.Round)
    drawLine(ink, fc, Offset(fc.x + cos(mA) * fr * 0.82f, fc.y + sin(mA) * fr * 0.82f), 2f * u, StrokeCap.Round)
    drawCircle(ink, 2f * u, fc)
    drawWaterLive(s, p)
    drawEyeLive(s, p)
    // boats on the river
    for (i in 0 until 3) {
        val dir = if (i % 2 == 0) 1f else -1f
        val t = (p * (3 + i) + hh(i + 950)) % 1f
        val bx = (if (dir > 0f) t else 1f - t) * (w + 400f * u) - 200f * u
        val by = s.gy + (s.bank - s.gy) * (0.3f + 0.22f * i)
        drawBoat(s, bx, by, dir, i)
    }
    // traffic on the Embankment and over Tower Bridge
    for (i in 0 until 14) {
        val dir = if (i % 2 == 0) 1f else -1f
        val t = (p * (3 + i % 4) + hh(i + 300)) % 1f
        val x = (if (dir > 0f) t else 1f - t) * (w + 200f * u) - 100f * u
        val y = h * (if (dir > 0f) 0.955f else 0.985f)
        if (i % 5 == 0) drawBus(s, x, y, dir) else drawCar(s, x, y, dir, i)
    }
    for (i in 0 until 5) {
        val dir = if (i % 2 == 0) 1f else -1f
        val t = (p * (5 + i % 3) + hh(i + 400)) % 1f
        val x = s.abL + (if (dir > 0f) t else 1f - t) * (s.abR - s.abL)
        drawCar(s, x, s.deck - 1f * u, dir, i + 20)
    }
    if (s.tod != "night") {
        for (i in 0 until 5) {
            val x = ((p * 2 + hh(i + 400)) % 1f) * (w + 120f * u) - 60f * u
            val y = h * (0.12f + 0.1f * hh(i + 410)) + 10f * u * sin(TAU * 5f * p + i)
            val flap = sin(TAU * 40f * p + i) * 6f * u
            drawLine(Color(0xAA0B1A24), Offset(x - 11f * u, y - flap), Offset(x, y), 2f * u, StrokeCap.Round)
            drawLine(Color(0xAA0B1A24), Offset(x + 11f * u, y - flap), Offset(x, y), 2f * u, StrokeCap.Round)
        }
    }
    // mist drifting over the river
    for (k in 0 until 3) {
        val x = ((p * (1 + k) + k * 0.31f) % 1f) * (w * 1.6f) - w * 0.5f
        drawOval(
            Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = if (s.night) 0.04f else 0.07f), Color.Transparent), startX = x, endX = x + w * 0.7f),
            Offset(x, s.gy + h * 0.02f + h * 0.05f * k), Size(w * 0.7f, h * 0.05f)
        )
    }
}

private fun DrawScope.drawWaterLive(s: Sc, p: Float) {
    val w0 = s.gy + s.h * 0.01f
    val w1 = s.bank
    val u = s.u
    val gcol = if (s.night) s.cool else Color.White
    for (k in 0 until 90) {
        val x = hh(k * 3 + 1600) * s.w
        val d = hh(k * 3 + 1601)
        val y = w0 + (w1 - w0) * d
        val a = abs(sin(TAU * (6 + k % 7) * p + k))
        val len = (8f + 24f * hh(k * 3 + 1602)) * u * (0.5f + d)
        drawLine(gcol.copy(alpha = (if (s.night) 0.22f else 0.3f) * a), Offset(x - len / 2f, y), Offset(x + len / 2f, y), 1.6f * u, StrokeCap.Round)
    }
    if (s.glow) {
        val sources = floatArrayOf(s.benCx, s.shX, s.eyeCx, s.cwX, s.w * 0.762f, s.w * 0.605f, s.t1, s.t2, s.w * 0.84f)
        for ((i, sx) in sources.withIndex()) {
            val c = if (i == 2) s.cool else if (i == 3) s.red else s.warm
            for (j in 0 until 14) {
                val y = w0 + (w1 - w0) * (j + 0.5f) / 14f
                val wob = sin(TAU * (5 + j % 4) * p + j * 1.3f + i)
                val len = (6f + 16f * abs(wob)) * u * (1f + j * 0.15f)
                drawLine(c.copy(alpha = 0.5f * (1f - j / 14f)), Offset(sx + wob * (3f + j * 1.6f) * u - len / 2f, y), Offset(sx + wob * (3f + j * 1.6f) * u + len / 2f, y), 2f * u, StrokeCap.Round)
            }
        }
    }
}

private fun DrawScope.drawEyeLive(s: Sc, p: Float) {
    val u = s.u
    val r = s.eyeR
    val rot = p * TAU
    if (s.glow) {
        for (k in 0 until 48) {
            val a = k * TAU / 48f
            val c = Color.hsv((p * 360f * 3f + k * 7f) % 360f, 0.45f, 1f)
            val pt = Offset(s.eyeCx + cos(a) * r, s.eyeCy + sin(a) * r)
            drawCircle(c.copy(alpha = 0.25f), 4.5f * u, pt)
            drawCircle(c, 1.7f * u, pt)
        }
    }
    for (k in 0 until 32) {
        val a = k * TAU / 32f + rot
        val x = s.eyeCx + cos(a) * r * 1.045f
        val y = s.eyeCy + sin(a) * r * 1.045f
        val cw = r * 0.05f
        val ch = r * 0.07f
        if (s.glow) drawCircle(s.warm.copy(alpha = 0.22f), ch * 1.4f, Offset(x, y))
        drawRoundRect(
            if (s.glow) s.warm.copy(alpha = 0.9f) else Color(0xCCDCEBFA),
            Offset(x - cw / 2f, y - ch / 2f), Size(cw, ch), CornerRadius(cw / 2f, cw / 2f)
        )
        drawRoundRect(Color.White.copy(alpha = 0.6f), Offset(x - cw / 2f, y - ch / 2f), Size(cw, ch), CornerRadius(cw / 2f, cw / 2f), style = Stroke(1f * u))
        drawLine(Color.White.copy(alpha = 0.5f), Offset(x, y - ch / 2f), Offset(x - cos(a) * r * 0.045f, y - sin(a) * r * 0.045f - ch * 0.5f), 0.9f * u)
    }
}

private fun DrawScope.drawBoat(s: Sc, x: Float, y: Float, dir: Float, kind: Int) {
    val u = s.u
    val len = (if (kind == 0) 130f else 90f) * u
    val hull = lerp(Color(0xFF1B2433), s.dark, 0.3f)
    poly(hull, x - len / 2f, y - 9f * u, x + len / 2f, y - 9f * u, x + len * 0.42f, y, x - len * 0.42f, y)
    drawRect(lerp(Color(0xFFE8EDF3), s.dark, if (s.night) 0.6f else 0.3f), Offset(x - len * 0.36f, y - 22f * u), Size(len * 0.62f, 13f * u))
    for (k in 0 until (len / (9f * u)).toInt() - 2) {
        drawRect(if (s.glow) s.warm.copy(alpha = 0.9f) else Color(0xFF38506E), Offset(x - len * 0.32f + k * 9f * u, y - 20f * u), Size(5f * u, 6f * u))
    }
    drawRect(hull, Offset(x - len * 0.1f, y - 30f * u), Size(8f * u, 8f * u))
    drawCircle(Color(0xFF34D17A), 1.8f * u, Offset(x + dir * len / 2f, y - 9f * u))
    drawCircle(Color.White, 1.8f * u, Offset(x - dir * len / 2f, y - 9f * u))
    for (k in 1..3) {
        drawLine(Color.White.copy(alpha = 0.22f), Offset(x - dir * len * 0.45f, y - 1f * u + k * 2f * u), Offset(x - dir * (len * 0.45f + (30f + 25f * k) * u), y - 1f * u + k * 2.5f * u), 1.4f * u)
    }
}

private fun DrawScope.drawBus(s: Sc, x: Float, y: Float, dir: Float) {
    val u = s.u
    val len = 62f * u
    val ht = 30f * u
    drawRoundRect(Color(0xFFC8102E), Offset(x, y - ht), Size(len, ht), CornerRadius(3f * u, 3f * u))
    drawRect(Color(0xFF8C0B20), Offset(x, y - ht), Size(len, 3f * u))
    for (k in 0 until 8) {
        val wx = x + 4f * u + k * 7f * u
        val c = if (s.glow) s.warm.copy(alpha = 0.9f) else Color(0xFF9FB6CC)
        drawRect(c, Offset(wx, y - ht * 0.88f), Size(5f * u, 7f * u))
        drawRect(c, Offset(wx, y - ht * 0.48f), Size(5f * u, 7f * u))
    }
    drawCircle(Color(0xFF05070A), 4.5f * u, Offset(x + 12f * u, y))
    drawCircle(Color(0xFF05070A), 4.5f * u, Offset(x + len - 12f * u, y))
    val fx = if (dir > 0f) x + len else x
    if (s.glow) {
        drawCircle(Color(0xFFFFF2C0), 2.4f * u, Offset(fx, y - 6f * u))
        poly(Color(0x22FFF2C0), fx, y - 6f * u, fx + dir * 70f * u, y - 14f * u, fx + dir * 70f * u, y + 2f * u)
    }
    drawCircle(s.red, 2f * u, Offset(if (dir > 0f) x else x + len, y - 6f * u))
}

private fun DrawScope.drawCar(s: Sc, x: Float, y: Float, dir: Float, i: Int) {
    val u = s.u
    val len = 26f * u
    val cols = intArrayOf(0xFF111827.toInt(), 0xFF1F3A5F.toInt(), 0xFF5B1E26.toInt(), 0xFF2B2F36.toInt())
    val body = Color(cols[i % 4])
    drawRoundRect(body, Offset(x, y - 9f * u), Size(len, 9f * u), CornerRadius(3f * u, 3f * u))
    drawRoundRect(body, Offset(x + len * 0.22f, y - 15f * u), Size(len * 0.52f, 7f * u), CornerRadius(3f * u, 3f * u))
    drawRect(Color(0xFF9FB6CC).copy(alpha = 0.5f), Offset(x + len * 0.28f, y - 14f * u), Size(len * 0.4f, 5f * u))
    if (i % 4 == 1) drawRect(Color(0xFFFFC107), Offset(x + len * 0.4f, y - 18f * u), Size(5f * u, 3f * u))
    drawCircle(Color(0xFF05070A), 3f * u, Offset(x + 6f * u, y))
    drawCircle(Color(0xFF05070A), 3f * u, Offset(x + len - 6f * u, y))
    val fx = if (dir > 0f) x + len else x
    drawCircle(if (dir > 0f) Color(0xFFFFF2C0) else s.red, 2.2f * u, Offset(fx, y - 5f * u))
    if (dir > 0f && s.glow) poly(Color(0x22FFF2C0), fx, y - 5f * u, fx + 60f * u, y - 12f * u, fx + 60f * u, y + 2f * u)
}
