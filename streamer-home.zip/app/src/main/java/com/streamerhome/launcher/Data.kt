package com.streamerhome.launcher

import android.Manifest
import android.content.ComponentName
import android.content.pm.ApplicationInfo
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.FileProvider
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.widget.Toast
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

// ---------- Themes & saved settings ----------

data class ThemeSpec(val name: String, val accent: Color)

val Themes = listOf(
    ThemeSpec("Ice", Color(0xFF4FE3FF)),
    ThemeSpec("Violet", Color(0xFF9B8CFF)),
    ThemeSpec("Mint", Color(0xFF34D399)),
    ThemeSpec("Sunset", Color(0xFFFF8A4C)),
    ThemeSpec("Rose", Color(0xFFFF5C93)),
    ThemeSpec("Gold", Color(0xFFFFD166))
)

const val CAT_SPACE = 1
const val CAT_NATURE = 2
const val CAT_CITY = 4
const val CAT_ANIMALS = 8
const val CAT_ART = 16
const val CAT_LONDON = 32
const val CAT_MOVIES = 64
const val CAT_ALL = 127

const val INFO_DATE = 1
const val INFO_SUN = 2
const val INFO_DAYLEN = 4
const val INFO_MOON = 8
const val INFO_TOMORROW = 16
const val INFO_ROOM = 32

data class ClockCfg(
    val style: Int = 1,        // 0 Thin, 1 Bold, 2 Mono, 3 Serif, 4 Black, 5 LED, 6 Neon, 7 Matrix, 8 Slim, 9 Italic, 10 Outline, 11 Pixel
    val box: Int = 0,          // 0 none, 1 glass, 2 solid
    val size: Int = 0,         // 0 small, 1 medium, 2 large, 3 mini
    val opacity: Int = 100,   // whole clock including its box, 5..100 %
    val accentColor: Boolean = false,
    val h24: Boolean = true,
    val seconds: Boolean = false,
    val info: Int = INFO_DATE or INFO_SUN,
    val blend: Boolean = false   // clock takes a tone of the wallpaper behind it
)

const val WX_HL = 1
const val WX_WIND = 2
const val WX_HUM = 4
const val WX_COND = 8
const val WX_ICON = 16

data class WeatherCfg(
    val font: Int = 0,         // 0 Default, 1 Black, 2 Thin, 3 Serif, 4 Mono, 5 Script
    val color: Int = 0,        // 0 white, 1 theme colour (temperature)
    val info: Int = 31,        // WX_* bits shown on the card
    val photo: Int = 0,        // 0 London photos, 1 sky art only, 2 see-through
    val photoMin: Int = 30,    // minutes between photos
    val days: Int = 6,         // forecast panel
    val hours: Int = 10,
    val strip: Boolean = true,  // 5-day strip on the card
    val size: Int = 1,          // 0 small .. 3 extra large
    val icons: Int = 2,         // 0 Meteocons, 1 OpenWeather, 2 Drawn 3D, 3 Deluxe, 4 Neon
    val cardWind: Boolean = true, // wind line on the card
    val refreshMin: Int = 30    // minutes between weather updates
)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("streamer_home", Context.MODE_PRIVATE)

    fun themeIndex(c: Context): Int = sp(c).getInt("theme", 0).coerceIn(0, Themes.size - 1)
    fun setThemeIndex(c: Context, v: Int) = sp(c).edit().putInt("theme", v).apply()

    fun intervalMin(c: Context): Int = sp(c).getInt("interval", 10).coerceIn(0, 60)  // 0 = never change
    fun setIntervalMin(c: Context, v: Int) = sp(c).edit().putInt("interval", v).apply()

    // Accent colour follows the wallpaper, ambient glow behind the home row, tile style (0 icons, 1 banners)
    fun autoAccent(c: Context): Boolean = sp(c).getBoolean("auto_accent", false)
    fun setAutoAccent(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto_accent", v).apply()
    fun ambient(c: Context): Boolean = sp(c).getBoolean("ambient", true)
    fun setAmbient(c: Context, v: Boolean) = sp(c).edit().putBoolean("ambient", v).apply()
    // Wi-Fi button: 0 top right, 1 top left, 2 bottom left, 3 bottom right, 4 hidden
    fun wifiPos(c: Context): Int = sp(c).getInt("wifi_pos", 0).coerceIn(0, 4)
    fun setWifiPos(c: Context, v: Int) = sp(c).edit().putInt("wifi_pos", v).apply()
    fun tileStyle(c: Context): Int = sp(c).getInt("tile_style", 0).coerceIn(0, 1)
    fun setTileStyle(c: Context, v: Int) = sp(c).edit().putInt("tile_style", v).apply()

    // 4K wallpapers (3840 x 2160) instead of 1080p
    fun res4k(c: Context): Boolean = sp(c).getBoolean("res4k", false)
    fun setRes4k(c: Context, v: Boolean) = sp(c).edit().putBoolean("res4k", v).apply()

    // Home row: tile size (0 small .. 3 extra large) and how many "recently played" tiles to show
    fun tileSize(c: Context): Int = sp(c).getInt("tile_size", 1).coerceIn(0, 3)
    fun setTileSize(c: Context, v: Int) = sp(c).edit().putInt("tile_size", v).apply()
    // 0 = rotating wallpapers, 1 = the fixed one picked in the gallery
    fun wallMode(c: Context): Int = sp(c).getInt("wall_mode", 0).coerceIn(0, 2)
    fun setWallMode(c: Context, v: Int) = sp(c).edit().putInt("wall_mode", v).apply()
    // animated wallpaper (wall mode 2): 0 abstract, 1 nature, 2 city
    fun animStyle(c: Context): Int = sp(c).getInt("anim_style", 0).coerceIn(0, 2)
    fun setAnimStyle(c: Context, v: Int) = sp(c).edit().putInt("anim_style", v).apply()
    fun recentCount(c: Context): Int = sp(c).getInt("recent_count", 4).coerceIn(0, 6)
    fun setRecentCount(c: Context, v: Int) = sp(c).edit().putInt("recent_count", v).apply()

    fun categories(c: Context): Int {
        val raw = sp(c).getInt("cats", CAT_ALL)
        val v = raw and CAT_ALL
        return if (v == 0) CAT_ALL else v
    }
    fun setCategories(c: Context, v: Int) = sp(c).edit().putInt("cats", v).apply()

    // Night mode: 0 off, 1 soft, 2 deep (same wallpaper, darker after sunset)
    fun nightDim(c: Context): Int = sp(c).getInt("night_dim", 1).coerceIn(0, 2)
    fun setNightDim(c: Context, v: Int) = sp(c).edit().putInt("night_dim", v).apply()

    fun anim(c: Context): Int = sp(c).getInt("anim", 0).coerceIn(0, 2)
    fun setAnim(c: Context, v: Int) = sp(c).edit().putInt("anim", v).apply()

    // UI sounds (click on OK, lower tone on Back)
    fun sounds(c: Context): Boolean = sp(c).getBoolean("sounds", true)
    fun setSounds(c: Context, v: Boolean) = sp(c).edit().putBoolean("sounds", v).apply()

    fun clock(c: Context): ClockCfg {
        val p = sp(c)
        return ClockCfg(
            style = p.getInt("ck_style", 1).coerceIn(0, 11),
            box = p.getInt("ck_box", 0).coerceIn(0, 2),
            size = p.getInt("ck_size", 0).coerceIn(0, 3),
            opacity = p.getInt("ck_opacity", 100).coerceIn(5, 100),
            accentColor = p.getBoolean("ck_accent", false),
            h24 = p.getBoolean("ck_h24", true),
            seconds = p.getBoolean("ck_sec", false),
            info = p.getInt("ck_info", INFO_DATE or INFO_SUN) and 63,
            blend = p.getBoolean("ck_blend", false)
        )
    }

    fun setClock(c: Context, v: ClockCfg) {
        sp(c).edit()
            .putInt("ck_style", v.style)
            .putInt("ck_box", v.box)
            .putInt("ck_size", v.size)
            .putInt("ck_opacity", v.opacity)
            .putBoolean("ck_accent", v.accentColor)
            .putBoolean("ck_h24", v.h24)
            .putBoolean("ck_sec", v.seconds)
            .putInt("ck_info", v.info)
            .putBoolean("ck_blend", v.blend)
            .apply()
    }

    fun weather(c: Context): WeatherCfg {
        val p = sp(c)
        return WeatherCfg(
            font = p.getInt("wx_font", 0).coerceIn(0, 5),
            color = p.getInt("wx_color", 0).coerceIn(0, 1),
            info = p.getInt("wx_info", 31) and 31,
            photo = p.getInt("wx_photo", 0).coerceIn(0, 2),
            photoMin = p.getInt("wx_min", 30).coerceIn(5, 120),
            days = p.getInt("wx_days", 6).coerceIn(3, 6),
            hours = p.getInt("wx_hours", 10).coerceIn(4, 10),
            strip = p.getBoolean("wx_strip", true),
            size = p.getInt("wx_size", 1).coerceIn(0, 3),
            icons = p.getInt("wx_icons", 2).coerceIn(0, 4),
            cardWind = p.getBoolean("wx_cwind", true),
            refreshMin = p.getInt("wx_refresh", 30).coerceIn(5, 120)
        )
    }

    fun setWeather(c: Context, v: WeatherCfg) {
        sp(c).edit()
            .putInt("wx_font", v.font)
            .putInt("wx_color", v.color)
            .putInt("wx_info", v.info)
            .putInt("wx_photo", v.photo)
            .putInt("wx_min", v.photoMin)
            .putInt("wx_days", v.days)
            .putInt("wx_hours", v.hours)
            .putBoolean("wx_strip", v.strip)
            .putInt("wx_size", v.size)
            .putInt("wx_icons", v.icons)
            .putBoolean("wx_cwind", v.cardWind)
            .putInt("wx_refresh", v.refreshMin)
            .apply()
    }

    // Home tiles: ordered package names. null = never customised (use the defaults from Config).
    fun tiles(c: Context): List<String>? {
        val s = sp(c).getString("tiles", null) ?: return null
        return s.split(",").filter { it.isNotBlank() }
    }
    fun setTiles(c: Context, list: List<String>) = sp(c).edit().putString("tiles", list.joinToString(",")).apply()
    fun clearTiles(c: Context) = sp(c).edit().remove("tiles").apply()

    // Cinema wallpapers (TMDB), room temperature (Home Assistant), music visualiser
    fun tmdbKey(c: Context): String = sp(c).getString("tmdb_key", "") ?: ""
    fun setTmdbKey(c: Context, v: String) = sp(c).edit().putString("tmdb_key", v).apply()
    fun haUrl(c: Context): String = sp(c).getString("ha_url", "") ?: ""
    fun setHaUrl(c: Context, v: String) = sp(c).edit().putString("ha_url", v).apply()
    fun haToken(c: Context): String = sp(c).getString("ha_token", "") ?: ""
    fun setHaToken(c: Context, v: String) = sp(c).edit().putString("ha_token", v).apply()
    fun haEntity(c: Context): String = sp(c).getString("ha_entity", "") ?: ""
    fun setHaEntity(c: Context, v: String) = sp(c).edit().putString("ha_entity", v).apply()
    // 0 off, 1 bars, 2 mirror, 3 pills, 4 LED, 5 wave
    fun vizStyle(c: Context): Int = sp(c).getInt("viz_style", 0).coerceIn(0, 6)
    fun setVizStyle(c: Context, v: Int) = sp(c).edit().putInt("viz_style", v).apply()

    // Updates: stable releases only unless "test builds" is switched on
    fun testBuilds(c: Context): Boolean = sp(c).getBoolean("test_builds", false)
    fun setTestBuilds(c: Context, v: Boolean) = sp(c).edit().putBoolean("test_builds", v).apply()
}

// ---------- Weather (Open-Meteo, no API key) ----------

data class DayForecast(val label: String, val code: Int, val high: Int, val low: Int, val rain: Int) {
    val emoji: String get() = describe(code).first
    val text: String get() = describe(code).second
}

data class HourForecast(val label: String, val code: Int, val temp: Int, val rain: Int) {
    val emoji: String get() = describe(code).first
}

data class Weather(
    val temp: Int,
    val code: Int,
    val high: Int,
    val low: Int,
    val windMph: Int,
    val humidity: Int,
    val isDay: Boolean,
    val sunriseMin: Int = 7 * 60,
    val sunsetMin: Int = 18 * 60,
    val windDir: Int = 0,
    val gustMph: Int = 0,
    val days: List<DayForecast> = emptyList(),
    val hours: List<HourForecast> = emptyList()
) {
    val emoji: String get() = describe(code).first
    val label: String get() = describe(code).second

    // Used to pick matching photos: clear, cloud, rain, snow, fog, storm
    val group: String
        get() = when (code) {
            0, 1 -> "clear"
            2, 3 -> "cloud"
            45, 48 -> "fog"
            in 51..67, in 80..82 -> "rain"
            in 71..77, 85, 86 -> "snow"
            in 95..99 -> "storm"
            else -> "cloud"
        }
}

private fun describe(code: Int): Pair<String, String> = when (code) {
    0 -> "☀️" to "Clear"
    1 -> "🌤️" to "Mostly clear"
    2 -> "⛅" to "Partly cloudy"
    3 -> "☁️" to "Overcast"
    45, 48 -> "🌫️" to "Fog"
    in 51..57 -> "🌦️" to "Drizzle"
    in 61..67 -> "🌧️" to "Rain"
    in 71..77 -> "🌨️" to "Snow"
    in 80..82 -> "🌧️" to "Showers"
    85, 86 -> "🌨️" to "Snow showers"
    95, 96, 99 -> "⛈️" to "Thunderstorm"
    else -> "🌡️" to "Weather"
}

// sunrise / sunrise / day / night, based on the sun times (falls back to 07:00 - 18:00)
fun timeOfDay(nowMin: Int, w: Weather?): String {
    val sr = w?.sunriseMin ?: (7 * 60)
    val ss = w?.sunsetMin ?: (18 * 60)
    return when {
        kotlin.math.abs(nowMin - sr) <= 45 -> "sunrise"
        kotlin.math.abs(nowMin - ss) <= 45 -> "sunset"
        nowMin in sr..ss -> "day"
        else -> "night"
    }
}

// Open-Meteo gives the direction the wind blows FROM
fun compass(deg: Int): String {
    val n = listOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
    return n[(((deg % 360) + 360) % 360 + 22) / 45 % 8]
}

fun formatMinutes(m: Int): String = String.format(Locale.US, "%02d:%02d", m / 60, m % 60)

fun moonPhase(date: LocalDate): Pair<String, String> {
    val ref = LocalDate.of(2000, 1, 6) // a new moon
    val days = ChronoUnit.DAYS.between(ref, date).toDouble()
    val synodic = 29.530588853
    val age = ((days % synodic) + synodic) % synodic
    val idx = ((age / synodic) * 8 + 0.5).toInt() % 8
    val emojis = listOf("🌑", "🌒", "🌓", "🌔", "🌕", "🌖", "🌗", "🌘")
    val names = listOf(
        "New moon", "Waxing crescent", "First quarter", "Waxing gibbous",
        "Full moon", "Waning gibbous", "Last quarter", "Waning crescent"
    )
    return Pair(emojis[idx], names[idx])
}

object WeatherApi {
    private fun minutesOf(iso: String): Int =
        iso.substring(11, 13).toInt() * 60 + iso.substring(14, 16).toInt()

    fun fetch(): Weather? {
        return try {
            val url = URL(
                "https://api.open-meteo.com/v1/forecast" +
                    "?latitude=${Config.LATITUDE}&longitude=${Config.LONGITUDE}" +
                    "&current=temperature_2m,weather_code,wind_speed_10m,relative_humidity_2m,is_day,wind_direction_10m,wind_gusts_10m" +
                    "&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,precipitation_probability_max" +
                    "&hourly=temperature_2m,weather_code,precipitation_probability" +
                    "&wind_speed_unit=mph&timezone=auto&forecast_days=6"
            )
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 10000
            conn.readTimeout = 15000
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val json = JSONObject(text)
            val cur = json.getJSONObject("current")
            val daily = json.getJSONObject("daily")

            val dDate = daily.getJSONArray("time")
            val dCode = daily.getJSONArray("weather_code")
            val dMax = daily.getJSONArray("temperature_2m_max")
            val dMin = daily.getJSONArray("temperature_2m_min")
            val dRain = daily.optJSONArray("precipitation_probability_max")
            val dRise = daily.getJSONArray("sunrise")
            val dSet = daily.getJSONArray("sunset")

            val days = ArrayList<DayForecast>()
            for (i in 0 until minOf(6, dDate.length())) {
                val d = LocalDate.parse(dDate.getString(i))
                val label = if (i == 0) "Today"
                else d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault())
                days.add(
                    DayForecast(
                        label,
                        dCode.getInt(i),
                        dMax.getDouble(i).roundToInt(),
                        dMin.getDouble(i).roundToInt(),
                        dRain?.optInt(i, 0) ?: 0
                    )
                )
            }

            val hours = ArrayList<HourForecast>()
            val hourly = json.optJSONObject("hourly")
            if (hourly != null) {
                val hTime = hourly.getJSONArray("time")
                val hCode = hourly.getJSONArray("weather_code")
                val hTemp = hourly.getJSONArray("temperature_2m")
                val hRain = hourly.optJSONArray("precipitation_probability")
                val nowStr = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:00").format(LocalDateTime.now())
                var start = 0
                while (start < hTime.length() && hTime.getString(start) < nowStr) start++
                var i = start
                while (i < hTime.length() && hours.size < 10) {
                    hours.add(
                        HourForecast(
                            hTime.getString(i).substring(11, 16),
                            hCode.getInt(i),
                            hTemp.getDouble(i).roundToInt(),
                            hRain?.optInt(i, 0) ?: 0
                        )
                    )
                    i++
                }
            }

            Weather(
                temp = cur.getDouble("temperature_2m").roundToInt(),
                code = cur.getInt("weather_code"),
                high = dMax.getDouble(0).roundToInt(),
                low = dMin.getDouble(0).roundToInt(),
                windMph = cur.getDouble("wind_speed_10m").roundToInt(),
                humidity = cur.getDouble("relative_humidity_2m").roundToInt(),
                isDay = cur.optInt("is_day", 1) == 1,
                windDir = cur.optDouble("wind_direction_10m", 0.0).roundToInt(),
                gustMph = cur.optDouble("wind_gusts_10m", 0.0).roundToInt(),
                sunriseMin = minutesOf(dRise.getString(0)),
                sunsetMin = minutesOf(dSet.getString(0)),
                days = days,
                hours = hours
            )
        } catch (e: Exception) {
            null
        }
    }
}

// ---------- Online images (backgrounds + weather photos) ----------

object Remote {
    private const val UA =
        "StreamerHome/1.3 (https://github.com/ravebot1/launcher; personal Android TV launcher)"

    // Human-readable status of the last network calls, shown in Settings.
    private const val BROWSER_UA =
        "Mozilla/5.0 (Linux; Android 12; Google TV Streamer) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"

    @Volatile
    var status: String = "No image requests yet"

    // true = wallpapers in 3840 x 2160
    @Volatile
    var fourK: Boolean = false

    @Volatile
    var tmdbKey: String = ""
    fun tmdb(): String = if (tmdbKey.isNotBlank()) tmdbKey else Config.TMDB_API_KEY
    fun text(url: String, label: String): String? = httpText(url, label)

    // Which film each cinema wallpaper belongs to (for the trailer button)
    private val movieByUrl = java.util.concurrent.ConcurrentHashMap<String, Movie>()
    fun movieFor(url: String?): Movie? = if (url == null) null else movieByUrl[url]

    @Synchronized
    private fun noteOf(k: String): String = notes[k] ?: ""

    // Used by "Check the key" in Settings
    fun movieCheck(): String {
        if (tmdb().isBlank()) return "No TMDB key set"
        val n = movieUrls().size
        return if (n > 0) n.toString() + " films found. Pick the Movies type to use them."
        else "No films: " + noteOf("Movies") + " (HTTP 401 means the key is not valid)"
    }

    // Films now showing in cinemas (TMDB, 20 per page): their backdrops are wallpapers.
    // Three pages by default, so a mix holds up to 60 films.
    private fun movieUrls(first: Int = 1, pages: Int = 3): List<String> {
        val out = ArrayList<String>()
        val key = tmdb()
        if (key.isBlank()) {
            note("Movies", "no TMDB key set")
            return out
        }
        try {
            for (page in first until first + pages) {
                val text = httpText(
                    "https://api.themoviedb.org/3/movie/now_playing?api_key=" + URLEncoder.encode(key, "UTF-8") +
                        "&language=en-GB&region=" + Config.REGION + "&page=" + page,
                    "Movies"
                ) ?: break
                val root = JSONObject(text)
                val arr = root.optJSONArray("results") ?: break
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val bp = o.optString("backdrop_path")
                    if (bp.isEmpty() || bp == "null") continue
                    val url = "https://image.tmdb.org/t/p/original" + bp
                    movieByUrl[url] = Movie(o.getInt("id"), o.optString("title"), o.optString("release_date").take(4))
                    out.add(url)
                }
                if (page >= root.optInt("total_pages", page)) break
            }
            note("Movies", out.size.toString() + " in cinemas")
        } catch (e: Exception) {
            note("Movies", e.javaClass.simpleName)
        }
        return out
    }
    private fun wallThumb(): Int = if (fourK) 3840 else 1920
    private fun wallMin(): Int = if (fourK) 2000 else 1400
    private val notes = LinkedHashMap<String, String>()

    @Synchronized
    private fun note(key: String, value: String) {
        notes[key] = value
        status = notes.entries.joinToString("\n") { it.key + ": " + it.value }
    }

    private val cache = HashMap<String, Pair<Long, List<String>>>()

    @Synchronized
    private fun cached(key: String): List<String>? {
        val e = cache[key] ?: return null
        val fresh = System.currentTimeMillis() - e.first < 60L * 60L * 1000L
        return if (fresh && e.second.isNotEmpty()) e.second.shuffled() else null
    }

    @Synchronized
    private fun store(key: String, list: List<String>) {
        cache[key] = System.currentTimeMillis() to list
    }

    private val gate = Any()
    private var lastApi = 0L

    // Wikimedia answers HTTP 429 when several searches arrive together: send API calls one at a time
    private fun commonsGate() {
        synchronized(gate) {
            val wait = lastApi + 400L - System.currentTimeMillis()
            if (wait > 0) Thread.sleep(wait)
            lastApi = System.currentTimeMillis()
        }
    }

    private fun httpGet(url: String, label: String): ByteArray? {
        var attempt = 0
        while (true) {
            try {
                if (url.contains("commons.wikimedia.org/w/api.php")) commonsGate()
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                if (url.contains("flickr.com")) {
                    conn.setRequestProperty("User-Agent", BROWSER_UA)
                    conn.setRequestProperty("Referer", "https://www.flickr.com/")
                } else {
                    conn.setRequestProperty("User-Agent", UA)
                }
                val code = conn.responseCode
                val bytes = if (code == 200) conn.inputStream.use { it.readBytes() } else null
                conn.disconnect()
                if ((code == 429 || code == 503) && attempt < 2) {
                    attempt++
                    Thread.sleep(2500L * attempt)
                    continue
                }
                note(label, if (code == 200) "ok" else "HTTP $code")
                return bytes
            } catch (e: Exception) {
                if (e is java.net.SocketTimeoutException && attempt < 1) {
                    attempt++
                    continue
                }
                note(label, e.javaClass.simpleName)
                return null
            }
        }
    }

    private fun httpText(url: String, label: String): String? {
        val bytes = httpGet(url, label) ?: return null
        return String(bytes, Charsets.UTF_8)
    }

    private fun https(u: String): String = u.replaceFirst("http://", "https://")

    @Volatile
    private var apodBlockedUntil = 0L

    @Volatile
    private var picsumBlockedUntil = 0L

    // NASA Image Library: no API key and no DEMO_KEY rate limit (APOD answers 429 often)
    private fun nasaImagesUrls(term: String): List<String> {
        val out = ArrayList<String>()
        try {
            val q = URLEncoder.encode(term, "UTF-8")
            val text = httpText(
                "https://images-api.nasa.gov/search?media_type=image&page_size=60&q=" + q,
                "NASA library"
            ) ?: return out
            val items = JSONObject(text).getJSONObject("collection").getJSONArray("items")
            for (i in 0 until items.length()) {
                val links = items.getJSONObject(i).optJSONArray("links") ?: continue
                val href = links.optJSONObject(0)?.optString("href") ?: continue
                if (href.endsWith("~thumb.jpg")) out.add(https(href.removeSuffix("~thumb.jpg") + "~orig.jpg"))
            }
            out.shuffle()
            note("NASA library", term + ": " + out.size + " found")
        } catch (e: Exception) {
            note("NASA library", e.javaClass.simpleName)
        }
        return out.take(20)
    }

    private fun nasaUrls(): List<String> {
        val out = ArrayList<String>()
        if (System.currentTimeMillis() < apodBlockedUntil) return out
        try {
            val text = httpText(
                "https://api.nasa.gov/planetary/apod?api_key=${Config.NASA_API_KEY}&count=10",
                "NASA space"
            )
            if (text == null) apodBlockedUntil = System.currentTimeMillis() + 60L * 60L * 1000L
            if (text != null) {
                val arr = JSONArray(text)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (o.optString("media_type") == "image") {
                        val hd = o.optString("hdurl")
                        val u = if (hd.isNotEmpty()) hd else o.optString("url")
                        if (u.isNotEmpty()) out.add(https(u))
                    }
                }
            }
        } catch (e: Exception) {
            note("NASA space", e.javaClass.simpleName)
        }
        return out
    }

    private fun bingUrls(): List<String> {
        val out = ArrayList<String>()
        try {
            val text = httpText(
                "https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=8&mkt=en-GB",
                "Bing nature"
            )
            if (text != null) {
                val arr = JSONObject(text).getJSONArray("images")
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val base = o.optString("urlbase")
                    val u = o.optString("url")
                    if (fourK && base.isNotEmpty()) {
                        out.add("https://www.bing.com" + base + "_UHD.jpg")
                    } else if (u.isNotEmpty()) {
                        out.add(if (u.startsWith("http")) https(u) else "https://www.bing.com" + u)
                    }
                }
            }
        } catch (e: Exception) {
            note("Bing nature", e.javaClass.simpleName)
        }
        return out
    }

    // Picsum (free Unsplash photos, no key): landscape pictures big enough for 1080p or 4K
    private fun picsumUrls(): List<String> {
        val out = ArrayList<String>()
        if (System.currentTimeMillis() < picsumBlockedUntil) return out
        try {
            val page = (1..30).random()
            val text = httpText("https://picsum.photos/v2/list?page=" + page + "&limit=40", "Picsum") ?: run {
                // host not reachable (DNS or network): skip Picsum for 3 hours, other sources fill in
                picsumBlockedUntil = System.currentTimeMillis() + 3L * 60L * 60L * 1000L
                note("Picsum", "not reachable, skipped for 3 h")
                return out
            }
            val arr = JSONArray(text)
            val w = if (fourK) 3840 else 1920
            val h = if (fourK) 2160 else 1080
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ow = o.optInt("width")
                val oh = o.optInt("height")
                if (ow >= w && oh >= h && ow > oh) {
                    out.add("https://picsum.photos/id/" + o.getString("id") + "/" + w + "/" + h + ".jpg")
                }
            }
            note("Picsum", out.size.toString() + " found")
        } catch (e: Exception) {
            note("Picsum", e.javaClass.simpleName)
        }
        return out
    }

    private val spaceTerms = listOf(
        "nebula", "galaxy", "universe", "planets", "hubble", "webb telescope", "milky way",
        "supernova", "star cluster", "aurora", "jupiter", "saturn", "mars", "earth from space", "solar system"
    )

    // NASA first; if it is slow or rate limited, Commons space pictures fill in
    private fun spaceUrls(): List<String> {
        val terms = spaceTerms.shuffled()
        val n = ArrayList<String>()
        n.addAll(nasaImagesUrls(terms[0]))
        n.addAll(nasaImagesUrls(terms[1]))
        if (n.size < 10) n.addAll(nasaUrls())
        if (n.size < 10) n.addAll(commonsFeatured(terms[2] + " space"))
        return n.distinct()
    }

    // Small version of a wallpaper URL for the gallery grid (saves 4K downloads)
    fun thumbUrl(url: String): String =
        url.replace("/3840/2160.jpg", "/640/360.jpg")
            .replace("/1920/1080.jpg", "/640/360.jpg")
            .replace("_UHD.jpg", "_1366x768.jpg")
            .replace(Regex("/(1920|3840)px-"), "/960px-")
            .replace("/t/p/original/", "/t/p/w780/")

    // Known London photographs on Wikimedia Commons, used when the search finds too little
    private val londonFallback = listOf(
        "Tower_Bridge_from_Shad_Thames.jpg",
        "London_Eye_Twilight_April_2006.jpg",
        "Palace_of_Westminster,_London_-_Feb_2007.jpg",
        "Tower_Bridge_London_Feb_2006.jpg",
        "London_Skyline_(125508655).jpeg"
    ).map { "https://commons.wikimedia.org/wiki/Special:FilePath/" + it + "?width=1920" }

    // Pictures that turned out to be too small for a wallpaper
    private val smallUrls: MutableSet<String> = java.util.Collections.synchronizedSet(HashSet<String>())

    // Words that mean "logo / map / diagram", not a photograph
    private val badTitleWords = setOf(
        "logo", "nasa", "iss", "icon", "map", "maps", "flag", "flags", "coat", "arms", "diagram",
        "emblem", "seal", "badge", "poster", "stamp", "chart", "plan", "svg", "screenshot",
        "signature", "crest", "symbol", "banner", "wordmark", "sign", "ticket"
    )

    // Reads the image list out of a Wikimedia Commons API answer (photos only: JPEG, landscape, big enough).
    private fun parseCommons(text: String, minWidth: Int, what: String = ""): List<String> {
        val out = ArrayList<String>()
        val root = JSONObject(text)
        val pages = root.optJSONObject("query")?.optJSONObject("pages")
        if (pages == null) {
            note("Commons reply", (root.optJSONObject("error")?.optString("code") ?: "no results") + " for " + what)
            return out
        }
        val total = pages.length()
        var badWord = 0
        var badSize = 0
        var badType = 0
        var noInfo = 0
        var widest = 0
        val keys = pages.keys()
        while (keys.hasNext()) {
            val page = pages.optJSONObject(keys.next()) ?: continue
            val title = page.optString("title", "").lowercase()
            val words = title.split(Regex("[^a-z0-9]+"))
            if (words.any { it in badTitleWords }) {
                badWord++
                continue
            }
            val info = page.optJSONArray("imageinfo")
            val first = info?.optJSONObject(0)
            if (first == null) {
                noInfo++
                continue
            }
            val w = first.optInt("width", 0)
            val h = first.optInt("height", 0)
            if (w > widest) widest = w
            if (minWidth > 0 && (w < minWidth || w <= h || w > h * 4)) {
                badSize++
                continue
            }
            var u = first.optString("thumburl")
            if (u.isEmpty()) u = first.optString("url")
            val l = u.lowercase()
            if (l.endsWith(".jpg") || l.endsWith(".jpeg")) out.add(https(u)) else badType++
        }
        note("Commons filter", out.size.toString() + " of " + total + " kept (name " + badWord + ", size " + badSize + ", type " + badType + ", no info " + noInfo + ", widest " + widest + ", need " + minWidth + ")")
        return out
    }

    private fun commonsCategory(title: String, thumb: Int = 1920, minW: Int = 0): List<String> {
        return try {
            val text = httpText(
                "https://commons.wikimedia.org/w/api.php?action=query&generator=categorymembers" +
                    "&gcmtitle=Category:" + title +
                    "&gcmtype=file&gcmlimit=50&prop=imageinfo&iiprop=url%7Csize&iiurlwidth=" + thumb + "&format=json",
                "Commons London"
            )
            if (text != null) parseCommons(text, minW, title) else emptyList()
        } catch (e: Exception) {
            note("Commons London", e.javaClass.simpleName)
            emptyList()
        }
    }

    private fun commonsSearch(
        query: String,
        thumb: Int = 1280,
        minW: Int = if (thumb >= 3800) 2000 else if (thumb >= 1900) 1800 else 1200,
        offset: Int = 0
    ): List<String> {
        return try {
            var r = commonsQuery("$query filetype:bitmap", thumb, minW, offset)
            if (r.isEmpty()) r = commonsQuery(query, thumb, minW, offset)
            r
        } catch (e: Exception) {
            note("Commons photos", e.javaClass.simpleName)
            emptyList()
        }
    }

    private fun commonsQuery(search: String, thumb: Int, minW: Int, offset: Int): List<String> {
        val q = URLEncoder.encode(search, "UTF-8")
        val text = httpText(
            "https://commons.wikimedia.org/w/api.php?action=query&generator=search" +
                "&gsrsearch=" + q + "&gsroffset=" + offset +
                "&gsrnamespace=6&gsrlimit=40&prop=imageinfo&iiprop=url%7Csize&iiurlwidth=" + thumb + "&format=json",
            "Commons photos"
        )
        return if (text != null) parseCommons(text, minW, search) else emptyList()
    }

    // High-quality Commons pictures for a keyword (featured pictures first, plain search as fallback)
    private fun commonsFeatured(words: String): List<String> {
        val fp = commonsSearch(words + " incategory:\"Featured pictures on Wikimedia Commons\"", wallThumb())
        if (fp.size >= 4) return fp
        val plain = commonsSearch(words, wallThumb())
        return if (plain.size > fp.size) plain else fp
    }

    // Wallpapers for the chosen types (space = NASA, nature = Bing, city = London pictures)
    // London pictures that match the time of day (and the weather)
    private fun londonWallpaper(tod: String, group: String): List<String> {
        val words = ArrayList<String>()
        when (tod) {
            "night" -> words.add("night")
            "sunrise" -> words.add("sunrise")
            "sunset" -> words.add("sunset")
        }
        when (group) {
            "rain" -> words.add("rain")
            "snow" -> words.add("snow")
            "fog" -> words.add("fog")
            "storm" -> words.add("storm")
        }
        val queries = ArrayList<String>()
        queries.add(("London " + words.joinToString(" ")).trim())
        queries.add(
            when (tod) {
                "night" -> "London night skyline"
                "sunrise" -> "London sunrise"
                "sunset" -> "London sunset"
                else -> "London skyline"
            }
        )
        var result: List<String> = emptyList()
        for (q in queries) {
            val r = commonsSearch(q, wallThumb())
            if (r.size >= 6) {
                result = r
                break
            }
            if (r.size > result.size) result = r
        }
        if (result.size < 6) {
            val c = commonsCategory(Config.LONDON_CATEGORY, wallThumb(), wallMin())
            if (c.size > result.size) result = c
        }
        return if (result.size < 6) result + londonFallback else result
    }

    fun backgroundUrls(cats: Int, tod: String = "day", group: String = "cloud"): List<String> {
        val key = "bg-" + cats + (if ((cats and CAT_LONDON) != 0) "-" + tod + "-" + group else "") + (if (fourK) "-4k" else "")
        val hit = cached(key)
        if (hit != null) return hit
        // all chosen types are fetched at the same time, so a new choice shows up quickly
        val tasks = ArrayList<() -> List<String>>()
        if ((cats and CAT_SPACE) != 0) tasks.add { spaceUrls() }
        if ((cats and CAT_NATURE) != 0) {
            tasks.add { bingUrls() }
            tasks.add {
                val pics = picsumUrls()
                if (pics.isEmpty()) commonsFeatured("nature landscape") else pics
            }
        }
        if ((cats and CAT_CITY) != 0) tasks.add { commonsCategory(Config.LONDON_CATEGORY, wallThumb(), wallMin()) }
        if ((cats and CAT_ANIMALS) != 0) {
            tasks.add { commonsFeatured("wildlife") }
            tasks.add { commonsFeatured("bird") }
        }
        if ((cats and CAT_ART) != 0) {
            tasks.add { commonsFeatured("landscape painting") }
            tasks.add { commonsFeatured("seascape") }
        }
        if ((cats and CAT_LONDON) != 0) tasks.add { londonWallpaper(tod, group) }
        if ((cats and CAT_MOVIES) != 0) tasks.add { movieUrls() }
        val out = ArrayList<String>()
        tasks.map { t ->
            java.util.concurrent.CompletableFuture.supplyAsync {
                try { t() } catch (e: Exception) { emptyList<String>() }
            }
        }.forEach { out.addAll(it.get()) }
        if (out.isEmpty()) {
            out.addAll(bingUrls())
            out.addAll(nasaUrls())
        }
        store(key, out)
        return out.shuffled()
    }

    // Wallpaper gallery: round 0 = the usual list, later rounds = new pictures (fresh NASA picks, next search pages)
    fun galleryUrls(cats: Int, tod: String, group: String, round: Int): List<String> {
        if (round == 0) return backgroundUrls(cats, tod, group).take(40)
        val out = ArrayList<String>()
        if ((cats and CAT_SPACE) != 0) out.addAll(spaceUrls())
        val topics = ArrayList<String>()
        if ((cats and CAT_NATURE) != 0) topics.addAll(listOf("mountain landscape", "forest", "lake", "coast sunset", "waterfall", "aurora", "desert"))
        if ((cats and CAT_CITY) != 0) topics.addAll(listOf("city skyline", "city night", "skyscrapers", "old town"))
        if ((cats and CAT_ANIMALS) != 0) topics.addAll(listOf("wildlife", "bird", "big cat", "butterfly", "fox"))
        if ((cats and CAT_ART) != 0) topics.addAll(listOf("landscape painting", "seascape painting", "impressionist painting"))
        if ((cats and CAT_LONDON) != 0) topics.addAll(listOf("London skyline", "London Thames", "London night", "London bridge"))
        if ((cats and CAT_MOVIES) != 0) out.addAll(movieUrls(round * 3 + 1))
        if ((cats and CAT_NATURE) != 0) out.addAll(picsumUrls())
        if (topics.isNotEmpty()) {
            for (k in 0 until 2) {
                val n = round * 2 + k - 2
                out.addAll(commonsSearch(topics[n % topics.size], wallThumb(), offset = (n / topics.size) * 40))
            }
        }
        return out
    }

    // Public Flickr photos with all of these tags (no API key). Returns ~1024 px pictures.
    private fun flickrUrls(tags: List<String>): List<String> {
        val out = ArrayList<String>()
        try {
            // The feed is not always valid JSON (stray escapes), so read the picture links directly
            val text = httpText(
                "https://www.flickr.com/services/feeds/photos_public.gne?format=json&nojsoncallback=1&tagmode=all&tags=" +
                    URLEncoder.encode(tags.joinToString(","), "UTF-8"),
                "Flickr photos"
            ) ?: return out
            Regex("\"m\"\\s*:\\s*\"([^\"]+?_m\\.jpg)\"").findAll(text).forEach { m ->
                val u = m.groupValues[1].replace("\\/", "/")
                out.add(https(u.removeSuffix("_m.jpg") + "_b.jpg"))
            }
            note("Flickr " + tags.joinToString(" "), out.size.toString() + " found")
        } catch (e: Exception) {
            note("Flickr photos", e.javaClass.simpleName)
        }
        return out
    }

    // Openverse (free search over Flickr, Wikimedia and others, no key). Thumbnails come through its own proxy.
    private fun openverseUrls(query: String): List<String> {
        val out = ArrayList<String>()
        try {
            val text = httpText(
                "https://api.openverse.org/v1/images/?category=photograph&aspect_ratio=wide&mature=false&page_size=20&q=" +
                    URLEncoder.encode(query, "UTF-8"),
                "Openverse photos"
            ) ?: return out
            val arr = JSONObject(text).optJSONArray("results") ?: return out
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val t = o.optString("thumbnail")
                val u = if (t.isNotEmpty()) t else o.optString("url")
                if (u.startsWith("http")) out.add(https(u))
            }
            note("Openverse " + query, out.size.toString() + " found")
        } catch (e: Exception) {
            note("Openverse photos", e.javaClass.simpleName)
        }
        return out
    }

    // London photos that match the weather and the time of day (Flickr tags first, Wikimedia Commons as backup)
    fun weatherPhotoUrls(isDay: Boolean, group: String, tod: String): List<String> {
        val key = "wp-" + tod + "-" + (if (isDay) "d" else "n") + group
        val hit = cached(key)
        if (hit != null) return hit

        val cond = when (group) {
            "clear" -> if (isDay) "sunny" else ""
            "cloud" -> "cloudy"
            "rain" -> "rain"
            "snow" -> "snow"
            "fog" -> "fog"
            "storm" -> "storm"
            else -> ""
        }
        val todTag = if (tod == "night" || tod == "sunrise" || tod == "sunset") tod else ""
        val found = LinkedHashSet<String>()
        val sets = listOf(
            listOf("london", todTag, cond),
            listOf("london", cond),
            listOf("london", todTag),
            listOf("london")
        ).map { s -> s.filter { it.isNotEmpty() } }.distinct()
        for (s in sets) {
            found.addAll(flickrUrls(s))
            if (found.size >= 6) break
        }
        if (found.size < 6) {
            val qs = listOf(("london " + cond + " " + todTag).trim(), "london " + cond, "london skyline")
                .map { it.replace(Regex("\\s+"), " ").trim() }.distinct()
            for (q in qs) {
                found.addAll(openverseUrls(q))
                if (found.size >= 8) break
            }
        }
        if (found.size < 6) {
            val night = if (isDay) "" else "night"
            val queries = listOf(
                "London $night $cond",
                "London $night",
                if (isDay) "London skyline" else "London night skyline"
            ).map { it.replace(Regex("\\s+"), " ").trim() }.distinct()
            for (q in queries) {
                found.addAll(commonsSearch(q, 1280, 1000))
                if (found.size >= 8) break
            }
        }
        if (found.size < 4) found.addAll(commonsCategory(Config.LONDON_CATEGORY, 1280, 900))
        note("Weather photos", found.size.toString() + " found")
        val all = found.toList().shuffled() + (if (found.size < 6) londonFallback.shuffled() else emptyList())
        store(key, all)
        return all
    }

    // Downloads (once, cached on disk) and decodes an image, keeping its longest side <= maxSide.
    fun loadBitmap(context: Context, url: String, maxSide: Int, minSide: Int = 0): Bitmap? {
        if (smallUrls.contains(url)) return null
        return try {
            val dir = File(context.cacheDir, "remote")
            dir.mkdirs()
            val file = File(dir, Integer.toHexString(url.hashCode()) + ".img")
            if (!file.exists() || file.length() == 0L) {
                val host = try { URL(url).host } catch (e: Exception) { "" }
                var bytes = httpGet(url, "Images " + host)
                if (bytes == null && url.contains("staticflickr.com") && url.endsWith("_b.jpg")) {
                    // the 1024 px size is not always allowed: try smaller ones
                    val base = url.removeSuffix("_b.jpg")
                    for (alt in listOf("_c.jpg", "_z.jpg")) {
                        bytes = httpGet(base + alt, "Images " + host)
                        if (bytes != null) break
                    }
                }
                if (bytes == null) return null
                file.writeBytes(bytes)
                trimCache(dir)
            }
            if (minSide > 0) {
                val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.absolutePath, b)
                // 4K mode still accepts Full HD pictures (anything >= 1400 px) as a backup
                if (maxOf(b.outWidth, b.outHeight) < minOf(minSide, 1400)) {
                    file.delete()
                    smallUrls.add(url)
                    note("Last image", "skipped, too small (" + b.outWidth + "x" + b.outHeight + ")")
                    return null
                }
            }
            val bmp = decode(file, maxSide)
            if (bmp == null) {
                file.delete()
                note("Last image", "could not decode")
            } else {
                note("Last image", "shown " + bmp.width + "x" + bmp.height)
            }
            bmp
        } catch (e: Throwable) {
            note("Last image", e.javaClass.simpleName)
            null
        }
    }

    private val iconCache = HashMap<String, Bitmap>()
    private val iconMiss: MutableSet<String> = java.util.Collections.synchronizedSet(HashSet<String>())

    // Meteocons (MIT) weather icons: SVG downloaded once, rendered to a bitmap. null = use the drawn art.
    fun loadIcon(context: Context, name: String, px: Int = 256, style: Int = 0): Bitmap? {
        val folder = "fill"
        val key = (if (style == 1) "owm" else folder) + "/" + name
        synchronized(iconCache) { iconCache[key]?.let { return it } }
        if (iconMiss.contains(key)) return null
        return try {
            val dir = File(context.cacheDir, "icons")
            dir.mkdirs()
            if (style == 1) {
                val f = File(dir, "owm-" + name + ".png")
                if (!f.exists() || f.length() == 0L) {
                    val bytes = httpGet("https://openweathermap.org/img/wn/" + name + "@4x.png", "Weather icons")
                    if (bytes == null) {
                        iconMiss.add(key)
                        return null
                    }
                    f.writeBytes(bytes)
                }
                val png = BitmapFactory.decodeFile(f.absolutePath)
                if (png == null) {
                    f.delete()
                    iconMiss.add(key)
                    return null
                }
                synchronized(iconCache) { iconCache[key] = png }
                return png
            }
            val file = File(dir, folder + "-" + name + ".svg")
            if (!file.exists() || file.length() == 0L) {
                val bytes = httpGet("https://bmcdn.nl/assets/weather-icons/v2.0/" + folder + "/" + name + ".svg", "Weather icons")
                if (bytes == null) {
                    iconMiss.add(key)
                    return null
                }
                file.writeBytes(bytes)
            }
            val svg = file.inputStream().use { com.caverock.androidsvg.SVG.getFromInputStream(it) }
            svg.setDocumentWidth(px.toFloat())
            svg.setDocumentHeight(px.toFloat())
            val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
            svg.renderToCanvas(android.graphics.Canvas(bmp))
            synchronized(iconCache) { iconCache[key] = bmp }
            bmp
        } catch (e: Throwable) {
            note("Weather icons", e.javaClass.simpleName)
            iconMiss.add(key)
            null
        }
    }

    private fun trimCache(dir: File, keep: Int = 60, maxBytes: Long = 160L * 1024L * 1024L) {
        val files = dir.listFiles()?.sortedByDescending { it.lastModified() } ?: return
        var total = 0L
        files.forEachIndexed { i, f ->
            total += f.length()
            if (i >= keep || total > maxBytes) f.delete()
        }
    }

    private fun decode(file: File, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(file.absolutePath, opts)
    }
}

// ---------- Network / Wi-Fi ----------

data class NetInfo(
    val kind: String,
    val name: String,
    val detail: String,
    val level: Int, // -1 = none, 0..4 = signal strength
    val needsLocation: Boolean = false
)

object NetworkReader {
    @Suppress("DEPRECATION")
    fun read(context: Context): NetInfo {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
            ?: return NetInfo("none", "Not connected", "Check your network settings", -1)
        val caps = cm.getNetworkCapabilities(network)
            ?: return NetInfo("none", "Not connected", "Check your network settings", -1)

        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
            return NetInfo("ethernet", "Ethernet", "Wired connection", 4)
        }
        if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            return NetInfo("other", "Connected", "", 3)
        }

        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val raw = info?.ssid ?: ""
        val ssid = raw.trim('"')
        val hidden = ssid.isEmpty() || ssid == "<unknown ssid>"
        val hasPerm = context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

        val rssi = info?.rssi ?: -100
        val level = WifiManager.calculateSignalLevel(rssi, 5)
        val percent = ((rssi + 100) * 2).coerceIn(0, 100)
        val freq = info?.frequency ?: 0
        val band = when {
            freq >= 5925 -> "6 GHz"
            freq >= 4900 -> "5 GHz"
            freq > 0 -> "2.4 GHz"
            else -> ""
        }
        val speed = info?.linkSpeed ?: 0

        val parts = ArrayList<String>()
        if (band.isNotEmpty()) parts.add(band)
        if (speed > 0) parts.add("$speed Mbps")
        parts.add("Signal $percent%")

        return if (hidden) {
            NetInfo(
                "wifi",
                "Wi-Fi connected",
                if (hasPerm) "Name hidden. Make sure Location is switched on in system settings. " + parts.joinToString(" · ")
                else parts.joinToString(" · "),
                level,
                needsLocation = !hasPerm
            )
        } else {
            NetInfo("wifi", ssid, parts.joinToString(" · "), level)
        }
    }
}

// ---------- Apps ----------

data class AppEntry(val label: String, val pkg: String)

object Apps {
    fun label(pm: PackageManager, pkg: String): String {
        return try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    fun isSystem(pm: PackageManager, pkg: String): Boolean {
        return try {
            (pm.getApplicationInfo(pkg, 0).flags and ApplicationInfo.FLAG_SYSTEM) != 0
        } catch (e: Exception) {
            false
        }
    }

    fun launchIntent(pm: PackageManager, pkg: String): Intent? =
        pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)

    fun firstInstalled(pm: PackageManager, pkgs: List<String>): String? =
        pkgs.firstOrNull { launchIntent(pm, it) != null }

    fun launch(context: Context, pkg: String) {
        val intent = launchIntent(context.packageManager, pkg)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(intent)
                AppUse.record(context, pkg)
            } catch (e: Exception) {
                Toast.makeText(context, "Could not open app", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "App not installed", Toast.LENGTH_SHORT).show()
        }
    }

    fun installed(context: Context): List<AppEntry> {
        val pm = context.packageManager
        val categories = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val out = ArrayList<AppEntry>()
        for (category in categories) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == context.packageName) continue
                if (!seen.add(pkg)) continue
                out.add(AppEntry(ri.loadLabel(pm).toString(), pkg))
            }
        }
        return out.sortedBy { it.label.lowercase() }
    }

    // The 16:9 banner Android TV apps ship for the home screen (null if the app has none)
    fun banner(pm: PackageManager, pkg: String): ImageBitmap? {
        return try {
            val intent = launchIntent(pm, pkg)
            val d = (if (intent != null) pm.getActivityBanner(intent) else null) ?: pm.getApplicationBanner(pkg)
            d?.toBitmap(480, 270)?.asImageBitmap()
        } catch (e: Throwable) {
            null
        }
    }

    fun icon(pm: PackageManager, pkg: String): ImageBitmap? {
        return try {
            pm.getApplicationIcon(pkg).toBitmap(256, 256).asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }
}

// ---------- Colours taken from pictures ----------

// Colours for the clock, one per area: covers the top-left w x h screen pixels
class ContrastMap(val bmp: Bitmap, val w: Int, val h: Int)

object Tint {
    // A tone of the top-left of the picture (where the clock sits), shifted a little lighter or darker
    // so the clock reads as part of the scene
    fun blend(b: Bitmap): Color? {
        return try {
            val w = (b.width * 0.4f).toInt().coerceAtLeast(1)
            val h = (b.height * 0.3f).toInt().coerceAtLeast(1)
            val part = Bitmap.createBitmap(b, 0, 0, w, h)
            val px = Bitmap.createScaledBitmap(part, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            android.graphics.Color.colorToHSV(px, hsv)
            hsv[1] = hsv[1].coerceAtMost(0.7f)
            hsv[2] = (if (hsv[2] < 0.5f) hsv[2] + 0.26f else hsv[2] - 0.26f).coerceIn(0f, 1f)
            Color(android.graphics.Color.HSVToColor(hsv))
        } catch (e: Throwable) {
            null
        }
    }

    // "Adapt to wallpaper": the wallpaper behind the top-left of the screen is smoothed, darkened the way the home
    // screen darkens it, and every cell gets a colour that stands out against it (light on dark areas, dark on bright ones).
    fun contrast(b: Bitmap, sw: Int, sh: Int, night: Float): ContrastMap? {
        return try {
            if (sw < 200 || sh < 100) return null
            val rw = (sw * 0.6f).toInt()
            val rh = (sh * 0.5f).toInt()
            // Crop scaling of the wallpaper: screen pixels -> picture pixels
            val scale = maxOf(sw.toFloat() / b.width, sh.toFloat() / b.height)
            val ox = (b.width * scale - sw) / 2f
            val oy = (b.height * scale - sh) / 2f
            val x0 = (ox / scale).toInt().coerceIn(0, b.width - 1)
            val y0 = (oy / scale).toInt().coerceIn(0, b.height - 1)
            val x1 = ((rw + ox) / scale).toInt().coerceIn(x0 + 1, b.width)
            val y1 = ((rh + oy) / scale).toInt().coerceIn(y0 + 1, b.height)
            val part = Bitmap.createBitmap(b, x0, y0, x1 - x0, y1 - y0)
            val mw = 360
            val mh = (mw.toFloat() * rh / rw).toInt().coerceAtLeast(8)
            val base = Bitmap.createScaledBitmap(part, mw, mh, true)
            val tiny = Bitmap.createScaledBitmap(base, mw / 4, (mh / 4).coerceAtLeast(2), true)
            val soft = Bitmap.createScaledBitmap(tiny, mw, mh, true)
            val px = IntArray(mw * mh)
            soft.getPixels(px, 0, mw, 0, 0, mw, mh)
            val out = IntArray(mw * mh)
            val hsv = FloatArray(3)
            val nd = night.coerceIn(0f, 1f)
            for (y in 0 until mh) {
                val fy = (((y + 0.5f) / mh) * rh / sh).coerceIn(0f, 1f)
                // the dark gradient the home screen draws over the wallpaper (60% at the top, 25% in the middle)
                val oa = if (fy < 0.5f) 0.6f - 0.7f * fy else 0.25f + 0.9f * (fy - 0.5f)
                for (x in 0 until mw) {
                    val c = px[y * mw + x]
                    var r = android.graphics.Color.red(c) * (1f - oa) + 6f * oa
                    var g = android.graphics.Color.green(c) * (1f - oa) + 10f * oa
                    var bl = android.graphics.Color.blue(c) * (1f - oa) + 20f * oa
                    r = r * (1f - nd) + 4f * nd
                    g = g * (1f - nd) + 8f * nd
                    bl = bl * (1f - nd) + 24f * nd
                    val lum = (0.299f * r + 0.587f * g + 0.114f * bl) / 255f
                    android.graphics.Color.RGBToHSV(
                        r.toInt().coerceIn(0, 255), g.toInt().coerceIn(0, 255), bl.toInt().coerceIn(0, 255), hsv
                    )
                    hsv[0] = (hsv[0] + 180f) % 360f
                    if (lum > 0.5f) {
                        hsv[1] = (hsv[1] * 0.6f + 0.35f).coerceIn(0.35f, 0.85f)
                        hsv[2] = 0.13f
                    } else {
                        hsv[1] = (hsv[1] * 0.45f).coerceIn(0.08f, 0.38f)
                        hsv[2] = 1f
                    }
                    out[y * mw + x] = android.graphics.Color.HSVToColor(hsv)
                }
            }
            ContrastMap(Bitmap.createBitmap(out, mw, mh, Bitmap.Config.ARGB_8888), rw, rh)
        } catch (e: Throwable) {
            null
        }
    }

    // The most colourful tone of a picture, lifted so it reads well on a dark screen (null = nothing colourful)
    fun vibrant(b: Bitmap): Color? {
        return try {
            val n = 24
            val s = Bitmap.createScaledBitmap(b, n, n, true)
            val sr = FloatArray(12)
            val sg = FloatArray(12)
            val sb = FloatArray(12)
            val wt = FloatArray(12)
            val hsv = FloatArray(3)
            for (y in 0 until n) {
                for (x in 0 until n) {
                    val p = s.getPixel(x, y)
                    android.graphics.Color.colorToHSV(p, hsv)
                    if (hsv[2] < 0.15f) continue
                    val w = hsv[1] * hsv[2]
                    val bin = (hsv[0] / 30f).toInt().coerceIn(0, 11)
                    sr[bin] += android.graphics.Color.red(p) * w
                    sg[bin] += android.graphics.Color.green(p) * w
                    sb[bin] += android.graphics.Color.blue(p) * w
                    wt[bin] += w
                }
            }
            var best = 0
            for (i in 1 until 12) if (wt[i] > wt[best]) best = i
            if (wt[best] < 0.6f) return null
            val rgb = android.graphics.Color.rgb(
                (sr[best] / wt[best]).toInt().coerceIn(0, 255),
                (sg[best] / wt[best]).toInt().coerceIn(0, 255),
                (sb[best] / wt[best]).toInt().coerceIn(0, 255)
            )
            android.graphics.Color.colorToHSV(rgb, hsv)
            hsv[1] = hsv[1].coerceIn(0.55f, 1f)
            hsv[2] = hsv[2].coerceIn(0.85f, 1f)
            Color(android.graphics.Color.HSVToColor(hsv))
        } catch (e: Throwable) {
            null
        }
    }
}

// ---------- Default home app ----------

object HomeRole {
    fun isDefault(c: Context): Boolean {
        return try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            val ri = c.packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
            ri?.activityInfo?.packageName == c.packageName
        } catch (e: Exception) {
            false
        }
    }
}

// ---------- Notification access without the (broken on TV) system screen ----------

object ListenerAccess {
    // Needs once, from a computer: adb shell pm grant com.streamerhome.launcher android.permission.WRITE_SECURE_SETTINGS
    fun canWrite(c: Context): Boolean =
        c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    fun enable(c: Context): Boolean {
        return try {
            val cn = ComponentName(c, MediaListenerService::class.java).flattenToString()
            val cur = Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners") ?: ""
            if (cur.split(":").contains(cn)) true
            else Settings.Secure.putString(
                c.contentResolver, "enabled_notification_listeners",
                if (cur.isEmpty()) cn else cur + ":" + cn
            )
        } catch (e: Exception) {
            false
        }
    }
}

// ---------- Now playing (media sessions) ----------

data class MediaInfo(
    val pkg: String,
    val title: String,
    val artist: String,
    val art: Bitmap?,
    val playing: Boolean
)

object NowPlaying {
    // Needs "Notification access" for this app (Android only lets listeners read media sessions)
    fun hasAccess(context: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    private fun controllers(context: Context): List<MediaController> {
        return try {
            val msm = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            msm.getActiveSessions(ComponentName(context, MediaListenerService::class.java))
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun read(context: Context): MediaInfo? {
        val list = controllers(context)
        var playing: MediaController? = null
        var paused: MediaController? = null
        var other: MediaController? = null
        for (c in list) {
            val st = c.playbackState?.state ?: continue
            if (st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING) {
                playing = c
                break
            }
            if (paused == null && st == PlaybackState.STATE_PAUSED) paused = c
            else if (other == null && c.metadata != null && st != PlaybackState.STATE_STOPPED &&
                st != PlaybackState.STATE_NONE && st != PlaybackState.STATE_ERROR
            ) other = c
        }
        val c = playing ?: paused ?: other ?: return null
        val md = c.metadata ?: return null
        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            ?: return null
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
            ?: ""
        val art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        return MediaInfo(c.packageName, title, artist, art, c.playbackState?.state == PlaybackState.STATE_PLAYING)
    }

    // Last thing seen playing, kept on disk (written by the notification service too), so the card can come
    // back after an app drops its session (e.g. Back from Deezer)
    private fun lastSp(c: Context) = c.getSharedPreferences("streamer_home_last", Context.MODE_PRIVATE)

    fun remember(c: Context, m: MediaInfo) {
        lastSp(c).edit()
            .putString("pkg", m.pkg).putString("title", m.title).putString("artist", m.artist)
            .putLong("ts", System.currentTimeMillis()).apply()
    }

    fun last(c: Context): MediaInfo? {
        val p = lastSp(c)
        val pkg = p.getString("pkg", null) ?: return null
        val title = p.getString("title", null) ?: return null
        val artist = p.getString("artist", "") ?: ""
        if (System.currentTimeMillis() - p.getLong("ts", 0L) > 10L * 60_000L) return null
        return MediaInfo(pkg, title, artist, Recent.artBitmap(c, pkg, title, artist), false)
    }

    // Shown in Settings: what Android reports for each media session (state 3 playing, 2 paused, 1 stopped)
    fun debug(context: Context): String {
        if (!hasAccess(context)) return "No notification access"
        val l = controllers(context)
        if (l.isEmpty()) return "No active media sessions"
        return l.joinToString("\n") { c ->
            c.packageName + "  state=" + (c.playbackState?.state ?: -1) + "  " +
                (c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "no title")
        }
    }

    // action: 0 = previous, 1 = play/pause, 2 = next
    fun control(context: Context, pkg: String, action: Int) {
        try {
            val c = controllers(context).firstOrNull { it.packageName == pkg }
            if (c == null) {
                // the session is gone (app closed): just open the app
                Apps.launch(context, pkg)
                return
            }
            val t = c.transportControls
            when (action) {
                0 -> t.skipToPrevious()
                1 -> {
                    if (c.playbackState?.state == PlaybackState.STATE_PLAYING) t.pause() else t.play()
                }
                else -> t.skipToNext()
            }
        } catch (e: Exception) {
            // ignore
        }
    }
}

// ---------- Updates from GitHub (only when you ask) ----------

data class ReleaseInfo(
    val tag: String,
    val build: Int,
    val name: String,
    val notes: String,
    val apkUrl: String,
    val sizeMb: Double,
    val version: String = ""
)

object Updater {
    // Compares version numbers like 1.9.10 and 1.9.9 part by part
    fun cmpVersion(a: String, b: String): Int {
        val x = a.split(".").map { it.toIntOrNull() ?: 0 }
        val y = b.split(".").map { it.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(x.size, y.size)) {
            val d = x.getOrElse(i) { 0 } - y.getOrElse(i) { 0 }
            if (d != 0) return d
        }
        return 0
    }

    fun isNewer(version: String): Boolean = cmpVersion(version, Config.VERSION) > 0

    private const val UA = "StreamerHome (https://github.com/" + Config.GITHUB_REPO + ")"

    @Suppress("DEPRECATION")
    fun installedBuild(context: Context): Int {
        return try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionCode
        } catch (e: Exception) {
            0
        }
    }

    // Returns the newest release that has an .apk, or an error message
    fun fetchLatest(includeTests: Boolean = false): Pair<ReleaseInfo?, String> {
        return try {
            val conn = URL("https://api.github.com/repos/" + Config.GITHUB_REPO + "/releases?per_page=8")
                .openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            val code = conn.responseCode
            if (code != 200) {
                conn.disconnect()
                return Pair<ReleaseInfo?, String>(null, "GitHub answered HTTP " + code)
            }
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val arr = JSONArray(text)
            var best: ReleaseInfo? = null
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optBoolean("draft", false)) continue
                if (o.optBoolean("prerelease", false) && !includeTests) continue
                val tag = o.optString("tag_name")
                val build = tag.substringAfter("sonik-", "").toIntOrNull() ?: continue
                val ver = Regex("v(\\d+(?:\\.\\d+)+)").find(o.optString("name"))?.groupValues?.get(1) ?: continue
                val assets = o.optJSONArray("assets") ?: continue
                var url = ""
                var size = 0L
                for (j in 0 until assets.length()) {
                    val a = assets.getJSONObject(j)
                    if (a.optString("name").endsWith(".apk")) {
                        url = a.optString("browser_download_url")
                        size = a.optLong("size", 0L)
                        break
                    }
                }
                if (url.isEmpty()) continue
                val current = best
                if (current == null || cmpVersion(ver, current.version) > 0 || (ver == current.version && build > current.build)) {
                    val date = o.optString("published_at").take(10)
                    best = ReleaseInfo(
                        tag,
                        build,
                        o.optString("name", tag),
                        if (date.isEmpty()) "" else "Published " + date,
                        url,
                        size / 1048576.0,
                        ver
                    )
                }
            }
            val found = best
            if (found == null) Pair<ReleaseInfo?, String>(null, if (includeTests) "No releases found" else "No stable release yet")
            else Pair<ReleaseInfo?, String>(found, "")
        } catch (e: Exception) {
            Pair<ReleaseInfo?, String>(null, "Could not reach GitHub (" + e.javaClass.simpleName + ")")
        }
    }

    fun download(context: Context, url: String, onProgress: (Int) -> Unit): File? {
        return try {
            val dir = File(context.cacheDir, "update")
            dir.mkdirs()
            val file = File(dir, "streamer-home.apk")
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", UA)
            if (conn.responseCode != 200) {
                conn.disconnect()
                return null
            }
            val total = conn.contentLength
            conn.inputStream.use { input ->
                file.outputStream().use { output ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var last = -1
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val p = (done * 100L / total).toInt()
                            if (p != last) {
                                last = p
                                onProgress(p)
                            }
                        }
                    }
                }
            }
            conn.disconnect()
            file
        } catch (e: Exception) {
            null
        }
    }

    fun canInstall(context: Context): Boolean = context.packageManager.canRequestPackageInstalls()

    fun openInstallPermission(context: Context) {
        try {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + context.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            try {
                context.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e2: Exception) {
                // nothing else to try
            }
        }
    }

    // Installs through the system PackageInstaller (works on Google TV where the old VIEW intent may open nothing)
    @Suppress("DEPRECATION")
    fun install(context: Context, file: File): Boolean {
        val app = context.applicationContext
        try {
            val pi = app.packageManager.packageInstaller
            val params = android.content.pm.PackageInstaller.SessionParams(
                android.content.pm.PackageInstaller.SessionParams.MODE_FULL_INSTALL
            )
            val id = pi.createSession(params)
            val action = app.packageName + ".INSTALL_RESULT"
            val rcv = object : android.content.BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    val st = i.getIntExtra(android.content.pm.PackageInstaller.EXTRA_STATUS, -1)
                    if (st == android.content.pm.PackageInstaller.STATUS_PENDING_USER_ACTION) {
                        val conf = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                        if (conf != null) {
                            conf.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            try { c.startActivity(conf) } catch (e: Exception) {
                                Toast.makeText(c, "Could not open the installer", Toast.LENGTH_LONG).show()
                            }
                        }
                    } else {
                        if (st != android.content.pm.PackageInstaller.STATUS_SUCCESS) {
                            val msg = i.getStringExtra(android.content.pm.PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "status $st"
                            Toast.makeText(c, "Install failed: $msg", Toast.LENGTH_LONG).show()
                        }
                        try { c.unregisterReceiver(this) } catch (e: Exception) { }
                    }
                }
            }
            val filter = android.content.IntentFilter(action)
            if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(rcv, filter, Context.RECEIVER_EXPORTED)
            else app.registerReceiver(rcv, filter)
            pi.openSession(id).use { s ->
                file.inputStream().use { inp ->
                    s.openWrite("update", 0, file.length()).use { out ->
                        inp.copyTo(out)
                        s.fsync(out)
                    }
                }
                val flags = android.app.PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 31) android.app.PendingIntent.FLAG_MUTABLE else 0)
                val pending = android.app.PendingIntent.getBroadcast(app, id, Intent(action).setPackage(app.packageName), flags)
                s.commit(pending.intentSender)
            }
            return true
        } catch (e: Exception) {
            // fall back to the plain VIEW intent
        }
        return try {
            val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, "application/vnd.android.package-archive")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }
}

// ---------- Recently played / watched (tiles on the home row) ----------

data class RecentItem(val id: String, val pkg: String, val title: String, val artist: String)

object Recent {
    private fun sp(c: Context) = c.getSharedPreferences("streamer_home_recent", Context.MODE_PRIVATE)

    private fun dir(c: Context): File {
        val d = File(c.filesDir, "recent")
        d.mkdirs()
        return d
    }

    private fun idOf(pkg: String, title: String, artist: String): String =
        Integer.toHexString((pkg + "|" + title + "|" + artist).hashCode())

    fun list(c: Context): List<RecentItem> {
        val out = ArrayList<RecentItem>()
        try {
            val arr = JSONArray(sp(c).getString("items", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    RecentItem(
                        o.getString("id"),
                        o.getString("pkg"),
                        o.getString("title"),
                        o.optString("artist")
                    )
                )
            }
        } catch (e: Exception) {
            // empty list
        }
        return out
    }

    private fun save(c: Context, items: List<RecentItem>) {
        val arr = JSONArray()
        for (r in items) {
            val o = JSONObject()
            o.put("id", r.id)
            o.put("pkg", r.pkg)
            o.put("title", r.title)
            o.put("artist", r.artist)
            arr.put(o)
        }
        sp(c).edit().putString("items", arr.toString()).apply()
    }

    // Remembers what is playing: newest first, at most 12, with a small cover picture.
    @Synchronized
    fun add(c: Context, pkg: String, title: String, artist: String, art: Bitmap?) {
        val id = idOf(pkg, title, artist)
        val items = ArrayList<RecentItem>()
        items.add(RecentItem(id, pkg, title, artist))
        for (r in list(c)) {
            if (r.id != id) items.add(r)
        }
        val kept = items.take(12)
        save(c, kept)
        if (art != null) {
            try {
                val scale = 256f / maxOf(art.width, art.height)
                val small = if (scale < 1f) {
                    Bitmap.createScaledBitmap(
                        art,
                        (art.width * scale).toInt().coerceAtLeast(1),
                        (art.height * scale).toInt().coerceAtLeast(1),
                        true
                    )
                } else {
                    art
                }
                java.io.FileOutputStream(File(dir(c), id + ".jpg")).use {
                    small.compress(Bitmap.CompressFormat.JPEG, 85, it)
                }
            } catch (e: Exception) {
                // no picture, the app icon is used instead
            }
        }
        val keep = kept.map { it.id + ".jpg" }.toSet()
        dir(c).listFiles()?.forEach {
            if (it.name !in keep) it.delete()
        }
    }

    fun artBitmap(c: Context, pkg: String, title: String, artist: String): Bitmap? {
        return try {
            val f = File(dir(c), idOf(pkg, title, artist) + ".jpg")
            if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
        } catch (e: Exception) {
            null
        }
    }

    fun art(c: Context, item: RecentItem): ImageBitmap? {
        return try {
            val f = File(dir(c), item.id + ".jpg")
            if (!f.exists()) null else BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }

    fun clear(c: Context) {
        sp(c).edit().remove("items").apply()
        c.getSharedPreferences("streamer_home_last", Context.MODE_PRIVATE).edit().clear().apply()
        dir(c).listFiles()?.forEach { it.delete() }
    }

    // Opens the app. If that app is still playing this very item, bring its player back and press play.
    fun open(c: Context, item: RecentItem) {
        try {
            val msm = c.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val ctl = msm.getActiveSessions(ComponentName(c, MediaListenerService::class.java))
                .firstOrNull { it.packageName == item.pkg }
            if (ctl != null) {
                val title = ctl.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
                if (title == item.title) {
                    ctl.transportControls.play()
                    val pi = ctl.sessionActivity
                    if (pi != null) {
                        pi.send()
                        return
                    }
                }
            }
        } catch (e: Exception) {
            // fall through and just open the app
        }
        Apps.launch(c, item.pkg)
    }
}

// ---------- Fixed wallpaper (gallery or a picture on this device), saved at exactly 1920 x 1080 ----------

object Wallpaper {
    private fun file(c: Context) = File(c.filesDir, "wallpaper.jpg")

    fun exists(c: Context): Boolean = file(c).exists()

    // Crops to fill 16:9 and stores at 1920 x 1080
    private fun cropSave(c: Context, src: Bitmap): Boolean {
        return try {
            val tw = if (Remote.fourK) 3840 else 1920
            val th = if (Remote.fourK) 2160 else 1080
            val scale = maxOf(tw.toFloat() / src.width, th.toFloat() / src.height)
            val sw = maxOf(tw, (src.width * scale).toInt())
            val sh = maxOf(th, (src.height * scale).toInt())
            val scaled = Bitmap.createScaledBitmap(src, sw, sh, true)
            val out = Bitmap.createBitmap(scaled, (sw - tw) / 2, (sh - th) / 2, tw, th)
            java.io.FileOutputStream(file(c)).use { out.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            true
        } catch (e: Throwable) {
            false
        }
    }

    fun saveFixed(c: Context, url: String): Boolean {
        val src = Remote.loadBitmap(c, url, if (Remote.fourK) 4000 else 2600, 1400) ?: return false
        return cropSave(c, src)
    }

    fun saveFromUri(c: Context, uri: Uri): Boolean {
        val src = decodeUri(c, uri, if (Remote.fourK) 4000 else 2600) ?: return false
        return cropSave(c, src)
    }

    fun loadFixed(c: Context): ImageBitmap? {
        return try {
            val f = file(c)
            if (!f.exists()) null else BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap()
        } catch (e: Throwable) {
            null
        }
    }

    // Decodes a picture from a content Uri, longest side <= maxSide
    fun decodeUri(c: Context, uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, b) }
            if (b.outWidth <= 0 || b.outHeight <= 0) return null
            var sample = 1
            while (maxOf(b.outWidth, b.outHeight) / sample > maxSide) sample *= 2
            val o = BitmapFactory.Options().apply { inSampleSize = sample }
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        } catch (e: Throwable) {
            null
        }
    }

    fun mediaPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasMediaAccess(c: Context): Boolean =
        c.checkSelfPermission(mediaPermission()) == PackageManager.PERMISSION_GRANTED

    // Newest pictures in the device's media store (needs the media permission)
    fun localPictures(c: Context): List<Uri> {
        val out = ArrayList<Uri>()
        try {
            val base = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            c.contentResolver.query(
                base,
                arrayOf(android.provider.MediaStore.Images.Media._ID),
                null,
                null,
                android.provider.MediaStore.Images.Media.DATE_ADDED + " DESC"
            )?.use { cur ->
                val idCol = cur.getColumnIndexOrThrow(android.provider.MediaStore.Images.Media._ID)
                while (cur.moveToNext() && out.size < 60) {
                    out.add(android.content.ContentUris.withAppendedId(base, cur.getLong(idCol)))
                }
            }
        } catch (e: Exception) {
            // empty list
        }
        return out
    }
}


// ---------- Cinema: film info and trailers (TMDB + YouTube) ----------

class Movie(val id: Int, val title: String, val year: String)

object Cinema {
    // YouTube key of the film's trailer, or null
    fun trailerId(movieId: Int): String? {
        return try {
            val key = Remote.tmdb()
            if (key.isBlank()) return null
            val text = Remote.text(
                "https://api.themoviedb.org/3/movie/" + movieId + "/videos?api_key=" + URLEncoder.encode(key, "UTF-8") + "&language=en-US",
                "Trailer"
            ) ?: return null
            val arr = JSONObject(text).optJSONArray("results") ?: return null
            var best: String? = null
            var teaser: String? = null
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("site") != "YouTube") continue
                val k = o.optString("key")
                if (k.isEmpty()) continue
                if (o.optString("type") == "Trailer") {
                    if (best == null || o.optBoolean("official", false)) best = k
                } else if (teaser == null) {
                    teaser = k
                }
            }
            best ?: teaser
        } catch (e: Exception) {
            null
        }
    }

    // Opens the trailer in YouTube (TV app first)
    fun open(c: Context, ytId: String): Boolean {
        val uri = Uri.parse("https://www.youtube.com/watch?v=" + ytId)
        for (pkg in listOf("com.google.android.youtube.tv", "com.google.android.youtube", null)) {
            try {
                val i = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (pkg != null) i.setPackage(pkg)
                c.startActivity(i)
                return true
            } catch (e: Exception) {
                // try the next one
            }
        }
        return false
    }
}

// ---------- Room temperature through Home Assistant (Echo Dot has no public API) ----------

object RoomTemp {
    @Volatile
    var status: String = "Not set up"

    // Temperature sensors known to Home Assistant: (entity id, label)
    fun discover(c: Context): List<Pair<String, String>> {
        val base = Prefs.haUrl(c).trim().trimEnd('/')
        val token = Prefs.haToken(c).trim()
        if (base.isEmpty() || token.isEmpty()) {
            status = "Set the address and the token first"
            return emptyList()
        }
        return try {
            val conn = URL(base + "/api/states").openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 15000
            conn.setRequestProperty("Authorization", "Bearer " + token)
            val code = conn.responseCode
            if (code != 200) {
                conn.disconnect()
                status = if (code == 401) "HTTP 401: token not accepted" else "HTTP " + code
                return emptyList()
            }
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val arr = JSONArray(text)
            val out = ArrayList<Pair<String, String>>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optString("entity_id")
                val at = o.optJSONObject("attributes") ?: continue
                if (!id.startsWith("sensor.") || at.optString("device_class") != "temperature") continue
                val name = at.optString("friendly_name", id)
                out.add(Pair(id, name + "  ·  " + o.optString("state") + at.optString("unit_of_measurement") + "  ·  " + id))
            }
            status = out.size.toString() + " temperature sensors found"
            out.sortedBy { it.second }
        } catch (e: Exception) {
            status = "Could not reach Home Assistant (" + e.javaClass.simpleName + ")"
            emptyList()
        }
    }

    fun fetch(c: Context): String? {
        val base = Prefs.haUrl(c).trim().trimEnd('/')
        val token = Prefs.haToken(c).trim()
        val entity = Prefs.haEntity(c).trim()
        if (base.isEmpty() || token.isEmpty() || entity.isEmpty()) {
            status = "Not set up (address, token and sensor name are needed)"
            return null
        }
        return try {
            val conn = URL(base + "/api/states/" + entity).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("Authorization", "Bearer " + token)
            val code = conn.responseCode
            if (code != 200) {
                conn.disconnect()
                status = if (code == 401) "HTTP 401: token not accepted" else if (code == 404) "HTTP 404: sensor name not found" else "HTTP " + code
                return null
            }
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val o = JSONObject(text)
            val v = o.optString("state").toDoubleOrNull()
            if (v == null) {
                status = "Sensor says: " + o.optString("state")
                return null
            }
            val unit = o.optJSONObject("attributes")?.optString("unit_of_measurement", "°C") ?: "°C"
            val out = String.format(Locale.US, "%.1f", v) + unit
            status = "OK: " + out
            out
        } catch (e: Exception) {
            status = "Could not reach Home Assistant (" + e.javaClass.simpleName + ")"
            null
        }
    }
}

// ---------- Music visualiser: audio output capture, with a simulated fallback ----------

object AudioViz {
    const val BANDS = 48
    private var viz: android.media.audiofx.Visualizer? = null
    private val target = FloatArray(BANDS)
    private val hold = IntArray(BANDS)
    private var zero = 0
    private var agc = 0.35f

    // peak markers that hang for a moment and then fall
    val peaks = FloatArray(BANDS)

    @Volatile
    var simulated = false

    val status: String
        get() = if (viz != null && !simulated) "Capturing the audio output"
        else if (simulated) "Simulated animation (audio capture not available for this app)"
        else "Idle"

    fun hasPermission(c: Context): Boolean =
        c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    @Synchronized
    fun start(c: Context) {
        if (viz != null) return
        simulated = false
        zero = 0
        if (!hasPermission(c)) {
            simulated = true
            return
        }
        try {
            val v = android.media.audiofx.Visualizer(0)
            v.enabled = false
            v.captureSize = minOf(1024, android.media.audiofx.Visualizer.getCaptureSizeRange()[1])
            v.enabled = true
            viz = v
        } catch (e: Throwable) {
            viz = null
            simulated = true
        }
    }

    @Synchronized
    fun stop() {
        try {
            viz?.enabled = false
            viz?.release()
        } catch (e: Throwable) {
            // already gone
        }
        viz = null
    }

    // Fills out with 0..1 per band (quick rise, slow fall) and keeps the peak markers
    @Synchronized
    fun read(out: FloatArray, tMs: Long) {
        var real = false
        val v = viz
        if (v != null && !simulated) {
            try {
                val size = v.captureSize
                val fft = ByteArray(size)
                if (v.getFft(fft) == android.media.audiofx.Visualizer.SUCCESS) {
                    val bins = size / 2 - 1
                    var total = 0f
                    var top = 0f
                    for (i in 0 until BANDS) {
                        val lo = Math.pow(bins.toDouble(), i.toDouble() / BANDS).toInt().coerceAtLeast(1)
                        val hi = Math.pow(bins.toDouble(), (i + 1).toDouble() / BANDS).toInt().coerceIn(lo + 1, bins)
                        var m = 0f
                        for (k in lo until hi) {
                            val re = fft[2 * k].toInt()
                            val im = fft[2 * k + 1].toInt()
                            m = maxOf(m, kotlin.math.sqrt((re * re + im * im).toFloat()))
                        }
                        // the spectrum falls towards the highs: lift them so the whole range moves
                        val level = (kotlin.math.ln(1f + m) / kotlin.math.ln(1f + 181f)) * (0.85f + 0.9f * i / BANDS)
                        target[i] = level
                        total += level
                        if (level > top) top = level
                    }
                    // automatic gain: loud and quiet music both fill the display
                    agc = maxOf(agc * 0.996f, top, 0.2f)
                    for (i in 0 until BANDS) {
                        target[i] = Math.pow((target[i] / agc).coerceIn(0f, 1f).toDouble(), 1.25).toFloat()
                    }
                    if (total > 0.05f) zero = 0 else zero++
                    // about 3.5 seconds of pure silence while "playing": the app blocks capture, simulate instead
                    if (zero >= 80) simulated = true else real = true
                }
            } catch (e: Throwable) {
                simulated = true
            }
        }
        if (!real) {
            // a made-up groove: kick on every beat, snare on 2 and 4, hi-hats, a wandering melody
            val t = tMs / 1000.0
            val beatPos = t * 2.0
            val ph = beatPos % 1.0
            val kick = Math.exp(-ph * 6.0)
            val snare = if (beatPos.toInt() % 2 == 1) Math.exp(-ph * 9.0) else 0.0
            val hat = 0.35 + 0.65 * Math.abs(Math.sin(t * 16.0))
            for (i in 0 until BANDS) {
                val f = i / BANDS.toDouble()
                val bassW = Math.max(0.0, 1.0 - f * 5.0)
                val midW = Math.exp(-Math.pow((f - 0.4) * 4.0, 2.0))
                val hiW = Math.max(0.0, (f - 0.55) * 2.2)
                val melody = 0.5 + 0.5 * Math.sin(t * (1.3 + i * 0.11) + i * 0.9)
                val v2 = 0.1 + 0.85 * kick * bassW + 0.6 * snare * midW + 0.3 * hat * hiW * (0.5 + 0.5 * Math.sin(t * 23.0 + i)) +
                    0.3 * melody * midW + 0.06 * Math.sin(t * 9.0 + i * 2.1)
                target[i] = v2.coerceIn(0.0, 1.0).toFloat()
            }
        }
        for (i in 0 until BANDS) {
            val t = target[i]
            out[i] = if (t > out[i]) out[i] + (t - out[i]) * 0.65f else out[i] + (t - out[i]) * 0.14f
            if (out[i] >= peaks[i]) {
                peaks[i] = out[i]
                hold[i] = 14
            } else if (hold[i] > 0) {
                hold[i]--
            } else {
                peaks[i] = maxOf(0f, peaks[i] - 0.025f)
            }
        }
    }
}

// ---------- Apps you opened recently (for the top row of All apps) ----------

object AppUse {
    private fun sp(c: Context) = c.getSharedPreferences("streamer_home_use", Context.MODE_PRIVATE)

    fun list(c: Context): List<String> =
        (sp(c).getString("l", "") ?: "").split(",").filter { it.isNotBlank() }

    fun record(c: Context, pkg: String) {
        if (pkg == c.packageName) return
        val l = ArrayList<String>()
        l.add(pkg)
        for (p in list(c)) if (p != pkg) l.add(p)
        sp(c).edit().putString("l", l.take(12).joinToString(",")).apply()
    }
}
