package com.streamerhome.launcher

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.widget.Toast
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

// ---------- Weather (Open-Meteo, no API key) ----------

data class Weather(val temp: Int, val code: Int, val high: Int, val low: Int) {
    val emoji: String get() = describe(code).first
    val label: String get() = describe(code).second
}

private fun describe(code: Int): Pair<String, String> = when (code) {
    0 -> "☀️" to "Clear"
    1 -> "🌤️" to "Mostly clear"
    2 -> "⛅" to "Partly cloudy"
    3 -> "☁️" to "Overcast"
    45, 48 -> "🌫️" to "Fog"
    in 51..57 -> "🌦️" to "Drizzle"
    in 61..67 -> "🌧️" to "Rain"
    in 71..77 -> "🌨️" to "Snow"
    in 80..82 -> "🌧️" to "Showers"
    85, 86 -> "🌨️" to "Snow showers"
    95, 96, 99 -> "⛈️" to "Thunderstorm"
    else -> "🌡️" to "Weather"
}

object WeatherApi {
    fun fetch(): Weather? {
        return try {
            val url = URL(
                "https://api.open-meteo.com/v1/forecast" +
                    "?latitude=${Config.LATITUDE}&longitude=${Config.LONGITUDE}" +
                    "&current=temperature_2m,weather_code" +
                    "&daily=temperature_2m_max,temperature_2m_min" +
                    "&timezone=auto&forecast_days=1"
            )
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 10000
            conn.readTimeout = 10000
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val json = JSONObject(text)
            val cur = json.getJSONObject("current")
            val daily = json.getJSONObject("daily")
            Weather(
                temp = cur.getDouble("temperature_2m").roundToInt(),
                code = cur.getInt("weather_code"),
                high = daily.getJSONArray("temperature_2m_max").getDouble(0).roundToInt(),
                low = daily.getJSONArray("temperature_2m_min").getDouble(0).roundToInt()
            )
        } catch (e: Exception) {
            null
        }
    }
}

// ---------- Network / Wi-Fi ----------

data class NetInfo(
    val kind: String,
    val name: String,
    val detail: String,
    val level: Int, // -1 = none, 0..4 = signal strength
    val needsLocation: Boolean = false
)

object NetworkReader {
    @Suppress("DEPRECATION")
    fun read(context: Context): NetInfo {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
            ?: return NetInfo("none", "Not connected", "Check your network settings", -1)
        val caps = cm.getNetworkCapabilities(network)
            ?: return NetInfo("none", "Not connected", "Check your network settings", -1)

        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
            return NetInfo("ethernet", "Ethernet", "Wired connection", 4)
        }
        if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            return NetInfo("other", "Connected", "", 3)
        }

        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val raw = info?.ssid ?: ""
        val ssid = raw.trim('"')
        val hidden = ssid.isEmpty() || ssid == "<unknown ssid>"
        val hasPerm = context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

        val rssi = info?.rssi ?: -100
        val level = WifiManager.calculateSignalLevel(rssi, 5)
        val percent = ((rssi + 100) * 2).coerceIn(0, 100)
        val freq = info?.frequency ?: 0
        val band = when {
            freq >= 5925 -> "6 GHz"
            freq >= 4900 -> "5 GHz"
            freq > 0 -> "2.4 GHz"
            else -> ""
        }
        val speed = info?.linkSpeed ?: 0

        val parts = ArrayList<String>()
        if (band.isNotEmpty()) parts.add(band)
        if (speed > 0) parts.add("$speed Mbps")
        parts.add("Signal $percent%")

        return if (hidden) {
            NetInfo(
                "wifi",
                "Wi-Fi connected",
                if (hasPerm) "Name hidden. Make sure Location is switched on in system settings. " + parts.joinToString(" · ")
                else parts.joinToString(" · "),
                level,
                needsLocation = !hasPerm
            )
        } else {
            NetInfo("wifi", ssid, parts.joinToString(" · "), level)
        }
    }
}

// ---------- Apps ----------

data class AppEntry(val label: String, val pkg: String)

object Apps {
    fun launchIntent(pm: PackageManager, pkg: String): Intent? =
        pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)

    fun firstInstalled(pm: PackageManager, pkgs: List<String>): String? =
        pkgs.firstOrNull { launchIntent(pm, it) != null }

    fun launch(context: Context, pkg: String) {
        val intent = launchIntent(context.packageManager, pkg)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "Could not open app", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "App not installed", Toast.LENGTH_SHORT).show()
        }
    }

    fun installed(context: Context): List<AppEntry> {
        val pm = context.packageManager
        val categories = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val out = ArrayList<AppEntry>()
        for (category in categories) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == context.packageName) continue
                if (!seen.add(pkg)) continue
                out.add(AppEntry(ri.loadLabel(pm).toString(), pkg))
            }
        }
        return out.sortedBy { it.label.lowercase() }
    }

    fun icon(pm: PackageManager, pkg: String): ImageBitmap? {
        return try {
            pm.getApplicationIcon(pkg).toBitmap(144, 144).asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }
}

// ---------- Photos (local folder slideshow) ----------

object Photos {
    // /sdcard/Android/data/com.streamerhome.launcher/files/photos
    fun dir(context: Context): File {
        val base = context.getExternalFilesDir(null) ?: context.filesDir
        val d = File(base, "photos")
        d.mkdirs()
        return d
    }

    fun list(context: Context): List<File> {
        val all = dir(context).listFiles()?.toList() ?: emptyList()
        return all
            .filter { it.isFile && it.extension.lowercase() in setOf("jpg", "jpeg", "png", "webp") }
            .shuffled()
    }

    fun load(file: File, targetWidth: Int = 1600): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= targetWidth) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeFile(file.absolutePath, opts)
        } catch (e: Throwable) {
            null
        }
    }
}
