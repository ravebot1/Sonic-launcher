package com.streamerhome.launcher

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.widget.Toast
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

// ---------- Themes & saved settings ----------

data class ThemeSpec(val name: String, val accent: Color)

val Themes = listOf(
    ThemeSpec("Ice", Color(0xFF4FE3FF)),
    ThemeSpec("Violet", Color(0xFF9B8CFF)),
    ThemeSpec("Mint", Color(0xFF34D399)),
    ThemeSpec("Sunset", Color(0xFFFF8A4C)),
    ThemeSpec("Rose", Color(0xFFFF5C93)),
    ThemeSpec("Gold", Color(0xFFFFD166))
)

const val CAT_SPACE = 1
const val CAT_NATURE = 2
const val CAT_CITY = 4
const val CAT_ANIMALS = 8
const val CAT_ART = 16
const val CAT_ALL = 31

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("streamer_home", Context.MODE_PRIVATE)

    fun themeIndex(c: Context): Int = sp(c).getInt("theme", 0).coerceIn(0, Themes.size - 1)
    fun setThemeIndex(c: Context, v: Int) = sp(c).edit().putInt("theme", v).apply()

    fun intervalMin(c: Context): Int = sp(c).getInt("interval", 10).coerceIn(5, 60)
    fun setIntervalMin(c: Context, v: Int) = sp(c).edit().putInt("interval", v).apply()

    fun categories(c: Context): Int {
        val v = sp(c).getInt("cats", CAT_ALL) and CAT_ALL
        return if (v == 0) CAT_ALL else v
    }
    fun setCategories(c: Context, v: Int) = sp(c).edit().putInt("cats", v).apply()
}

// ---------- Weather (Open-Meteo, no API key) ----------

data class Weather(
    val temp: Int,
    val code: Int,
    val high: Int,
    val low: Int,
    val windMph: Int,
    val humidity: Int,
    val isDay: Boolean
) {
    val emoji: String get() = describe(code).first
    val label: String get() = describe(code).second

    // Used to pick matching photos: clear, cloud, rain, snow, fog, storm
    val group: String
        get() = when (code) {
            0, 1 -> "clear"
            2, 3 -> "cloud"
            45, 48 -> "fog"
            in 51..67, in 80..82 -> "rain"
            in 71..77, 85, 86 -> "snow"
            in 95..99 -> "storm"
            else -> "cloud"
        }
}

private fun describe(code: Int): Pair<String, String> = when (code) {
    0 -> "☀️" to "Clear"
    1 -> "🌤️" to "Mostly clear"
    2 -> "⛅" to "Partly cloudy"
    3 -> "☁️" to "Overcast"
    45, 48 -> "🌫️" to "Fog"
    in 51..57 -> "🌦️" to "Drizzle"
    in 61..67 -> "🌧️" to "Rain"
    in 71..77 -> "🌨️" to "Snow"
    in 80..82 -> "🌧️" to "Showers"
    85, 86 -> "🌨️" to "Snow showers"
    95, 96, 99 -> "⛈️" to "Thunderstorm"
    else -> "🌡️" to "Weather"
}

object WeatherApi {
    fun fetch(): Weather? {
        return try {
            val url = URL(
                "https://api.open-meteo.com/v1/forecast" +
                    "?latitude=${Config.LATITUDE}&longitude=${Config.LONGITUDE}" +
                    "&current=temperature_2m,weather_code,wind_speed_10m,relative_humidity_2m,is_day" +
                    "&daily=temperature_2m_max,temperature_2m_min" +
                    "&wind_speed_unit=mph&timezone=auto&forecast_days=1"
            )
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 10000
            conn.readTimeout = 10000
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val json = JSONObject(text)
            val cur = json.getJSONObject("current")
            val daily = json.getJSONObject("daily")
            Weather(
                temp = cur.getDouble("temperature_2m").roundToInt(),
                code = cur.getInt("weather_code"),
                high = daily.getJSONArray("temperature_2m_max").getDouble(0).roundToInt(),
                low = daily.getJSONArray("temperature_2m_min").getDouble(0).roundToInt(),
                windMph = cur.getDouble("wind_speed_10m").roundToInt(),
                humidity = cur.getDouble("relative_humidity_2m").roundToInt(),
                isDay = cur.optInt("is_day", 1) == 1
            )
        } catch (e: Exception) {
            null
        }
    }
}

// ---------- Online images (backgrounds + weather photos) ----------

object Remote {
    private const val UA =
        "StreamerHome/1.3 (https://github.com/ravebot1/launcher; personal Android TV launcher)"

    // Human-readable status of the last network calls, shown in Settings.
    @Volatile
    var status: String = "No image requests yet"
    private val notes = LinkedHashMap<String, String>()

    @Synchronized
    private fun note(key: String, value: String) {
        notes[key] = value
        status = notes.entries.joinToString("\n") { it.key + ": " + it.value }
    }

    private val cache = HashMap<String, Pair<Long, List<String>>>()

    @Synchronized
    private fun cached(key: String): List<String>? {
        val e = cache[key] ?: return null
        val fresh = System.currentTimeMillis() - e.first < 60L * 60L * 1000L
        return if (fresh && e.second.isNotEmpty()) e.second.shuffled() else null
    }

    @Synchronized
    private fun store(key: String, list: List<String>) {
        cache[key] = System.currentTimeMillis() to list
    }

    private fun httpGet(url: String, label: String): ByteArray? {
        return try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.setRequestProperty("User-Agent", UA)
            val code = conn.responseCode
            val bytes = if (code == 200) conn.inputStream.use { it.readBytes() } else null
            conn.disconnect()
            note(label, if (code == 200) "ok" else "HTTP $code")
            bytes
        } catch (e: Exception) {
            note(label, e.javaClass.simpleName)
            null
        }
    }

    private fun httpText(url: String, label: String): String? {
        val bytes = httpGet(url, label) ?: return null
        return String(bytes, Charsets.UTF_8)
    }

    private fun https(u: String): String = u.replaceFirst("http://", "https://")

    private fun nasaUrls(): List<String> {
        val out = ArrayList<String>()
        try {
            val text = httpText(
                "https://api.nasa.gov/planetary/apod?api_key=${Config.NASA_API_KEY}&count=12",
                "NASA space"
            )
            if (text != null) {
                val arr = JSONArray(text)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (o.optString("media_type") == "image") {
                        val u = o.optString("url")
                        if (u.isNotEmpty()) out.add(https(u))
                    }
                }
            }
        } catch (e: Exception) {
            note("NASA space", e.javaClass.simpleName)
        }
        return out
    }

    private fun bingUrls(): List<String> {
        val out = ArrayList<String>()
        try {
            val text = httpText(
                "https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=8&mkt=en-GB",
                "Bing nature"
            )
            if (text != null) {
                val arr = JSONObject(text).getJSONArray("images")
                for (i in 0 until arr.length()) {
                    val u = arr.getJSONObject(i).optString("url")
                    if (u.isNotEmpty()) {
                        out.add(if (u.startsWith("http")) https(u) else "https://www.bing.com" + u)
                    }
                }
            }
        } catch (e: Exception) {
            note("Bing nature", e.javaClass.simpleName)
        }
        return out
    }

    // Reads the image list out of a Wikimedia Commons API answer.
    private fun parseCommons(text: String, minWidth: Int): List<String> {
        val out = ArrayList<String>()
        val pages = JSONObject(text).optJSONObject("query")?.optJSONObject("pages") ?: return out
        val keys = pages.keys()
        while (keys.hasNext()) {
            val page = pages.optJSONObject(keys.next()) ?: continue
            val info = page.optJSONArray("imageinfo") ?: continue
            val first = info.optJSONObject(0) ?: continue
            val w = first.optInt("width", 0)
            val h = first.optInt("height", 0)
            if (minWidth > 0 && (w < minWidth || w <= h)) continue
            var u = first.optString("thumburl")
            if (u.isEmpty()) u = first.optString("url")
            val l = u.lowercase()
            if (l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".png")) out.add(https(u))
        }
        return out
    }

    private fun commonsCategory(title: String): List<String> {
        return try {
            val text = httpText(
                "https://commons.wikimedia.org/w/api.php?action=query&generator=categorymembers" +
                    "&gcmtitle=Category:" + title +
                    "&gcmtype=file&gcmlimit=80&prop=imageinfo&iiprop=url%7Csize&iiurlwidth=1280&format=json",
                "Commons London"
            )
            if (text != null) parseCommons(text, 0) else emptyList()
        } catch (e: Exception) {
            note("Commons London", e.javaClass.simpleName)
            emptyList()
        }
    }

    private fun commonsSearch(query: String, thumb: Int = 1280): List<String> {
        return try {
            val q = URLEncoder.encode("$query filetype:bitmap", "UTF-8")
            val text = httpText(
                "https://commons.wikimedia.org/w/api.php?action=query&generator=search" +
                    "&gsrsearch=" + q +
                    "&gsrnamespace=6&gsrlimit=40&prop=imageinfo&iiprop=url%7Csize&iiurlwidth=" + thumb + "&format=json",
                "Commons photos"
            )
            if (text != null) parseCommons(text, 1000) else emptyList()
        } catch (e: Exception) {
            note("Commons photos", e.javaClass.simpleName)
            emptyList()
        }
    }

    // High-quality Commons pictures for a keyword (featured pictures first, plain search as fallback)
    private fun commonsFeatured(words: String): List<String> {
        val fp = commonsSearch(words + " incategory:\"Featured pictures on Wikimedia Commons\"", 1920)
        if (fp.size >= 4) return fp
        val plain = commonsSearch(words, 1920)
        return if (plain.size > fp.size) plain else fp
    }

    // Wallpapers for the chosen types (space = NASA, nature = Bing, city = London pictures)
    fun backgroundUrls(cats: Int): List<String> {
        val key = "bg-$cats"
        val hit = cached(key)
        if (hit != null) return hit
        val out = ArrayList<String>()
        if ((cats and CAT_SPACE) != 0) out.addAll(nasaUrls())
        if ((cats and CAT_NATURE) != 0) out.addAll(bingUrls())
        if ((cats and CAT_CITY) != 0) out.addAll(commonsCategory(Config.LONDON_CATEGORY))
        if ((cats and CAT_ANIMALS) != 0) {
            out.addAll(commonsFeatured("wildlife"))
            out.addAll(commonsFeatured("bird"))
        }
        if ((cats and CAT_ART) != 0) {
            out.addAll(commonsFeatured("landscape painting"))
            out.addAll(commonsFeatured("seascape"))
        }
        if (out.isEmpty()) {
            out.addAll(bingUrls())
            out.addAll(nasaUrls())
        }
        store(key, out)
        return out.shuffled()
    }

    // London photos that match the time of day and the weather
    fun weatherPhotoUrls(isDay: Boolean, group: String): List<String> {
        val key = "wp-" + (if (isDay) "d" else "n") + group
        val hit = cached(key)
        if (hit != null) return hit

        val words = ArrayList<String>()
        if (!isDay) words.add("night")
        when (group) {
            "clear" -> {
                if (isDay) words.add("sunny")
            }
            "cloud" -> {
                words.add("cloudy")
            }
            "rain" -> {
                words.add("rain")
            }
            "snow" -> {
                words.add("snow")
            }
            "fog" -> {
                words.add("fog")
            }
            "storm" -> {
                words.add("storm")
            }
        }
        val queries = listOf(
            ("London " + words.joinToString(" ")).trim(),
            if (isDay) "London skyline" else "London night skyline"
        )
        var result: List<String> = emptyList()
        for (q in queries) {
            val r = commonsSearch(q)
            if (r.size >= 4) {
                result = r
                break
            }
            if (r.size > result.size) result = r
        }
        if (result.size < 4) {
            val c = commonsCategory(Config.LONDON_CATEGORY)
            if (c.size > result.size) result = c
        }
        store(key, result)
        return result.shuffled()
    }

    // Downloads (once, cached on disk) and decodes an image, keeping its longest side <= maxSide.
    fun loadBitmap(context: Context, url: String, maxSide: Int): Bitmap? {
        return try {
            val dir = File(context.cacheDir, "remote")
            dir.mkdirs()
            val file = File(dir, Integer.toHexString(url.hashCode()) + ".img")
            if (!file.exists() || file.length() == 0L) {
                val bytes = httpGet(url, "Image files") ?: return null
                file.writeBytes(bytes)
                trimCache(dir)
            }
            val bmp = decode(file, maxSide)
            if (bmp == null) file.delete()
            bmp
        } catch (e: Throwable) {
            null
        }
    }

    private fun trimCache(dir: File, keep: Int = 100) {
        val files = dir.listFiles()?.sortedByDescending { it.lastModified() } ?: return
        files.drop(keep).forEach { it.delete() }
    }

    private fun decode(file: File, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(file.absolutePath, opts)
    }
}

// ---------- Network / Wi-Fi ----------

data class NetInfo(
    val kind: String,
    val name: String,
    val detail: String,
    val level: Int, // -1 = none, 0..4 = signal strength
    val needsLocation: Boolean = false
)

object NetworkReader {
    @Suppress("DEPRECATION")
    fun read(context: Context): NetInfo {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
            ?: return NetInfo("none", "Not connected", "Check your network settings", -1)
        val caps = cm.getNetworkCapabilities(network)
            ?: return NetInfo("none", "Not connected", "Check your network settings", -1)

        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
            return NetInfo("ethernet", "Ethernet", "Wired connection", 4)
        }
        if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            return NetInfo("other", "Connected", "", 3)
        }

        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val raw = info?.ssid ?: ""
        val ssid = raw.trim('"')
        val hidden = ssid.isEmpty() || ssid == "<unknown ssid>"
        val hasPerm = context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

        val rssi = info?.rssi ?: -100
        val level = WifiManager.calculateSignalLevel(rssi, 5)
        val percent = ((rssi + 100) * 2).coerceIn(0, 100)
        val freq = info?.frequency ?: 0
        val band = when {
            freq >= 5925 -> "6 GHz"
            freq >= 4900 -> "5 GHz"
            freq > 0 -> "2.4 GHz"
            else -> ""
        }
        val speed = info?.linkSpeed ?: 0

        val parts = ArrayList<String>()
        if (band.isNotEmpty()) parts.add(band)
        if (speed > 0) parts.add("$speed Mbps")
        parts.add("Signal $percent%")

        return if (hidden) {
            NetInfo(
                "wifi",
                "Wi-Fi connected",
                if (hasPerm) "Name hidden. Make sure Location is switched on in system settings. " + parts.joinToString(" · ")
                else parts.joinToString(" · "),
                level,
                needsLocation = !hasPerm
            )
        } else {
            NetInfo("wifi", ssid, parts.joinToString(" · "), level)
        }
    }
}

// ---------- Apps ----------

data class AppEntry(val label: String, val pkg: String)

object Apps {
    fun launchIntent(pm: PackageManager, pkg: String): Intent? =
        pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)

    fun firstInstalled(pm: PackageManager, pkgs: List<String>): String? =
        pkgs.firstOrNull { launchIntent(pm, it) != null }

    fun launch(context: Context, pkg: String) {
        val intent = launchIntent(context.packageManager, pkg)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "Could not open app", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "App not installed", Toast.LENGTH_SHORT).show()
        }
    }

    fun installed(context: Context): List<AppEntry> {
        val pm = context.packageManager
        val categories = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val out = ArrayList<AppEntry>()
        for (category in categories) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == context.packageName) continue
                if (!seen.add(pkg)) continue
                out.add(AppEntry(ri.loadLabel(pm).toString(), pkg))
            }
        }
        return out.sortedBy { it.label.lowercase() }
    }

    fun icon(pm: PackageManager, pkg: String): ImageBitmap? {
        return try {
            pm.getApplicationIcon(pkg).toBitmap(256, 256).asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }
}
