package com.streamerhome.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// After an update Android kills the app and nothing reopens it, so Home falls back to the stock launcher.
// This receiver starts the launcher again as soon as the new version is installed.
class UpdateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        try {
            context.startActivity(
                Intent(context, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        } catch (e: Exception) {
            // blocked by Android: grant "Display over other apps" once (see Settings > System)
        }
    }
}
