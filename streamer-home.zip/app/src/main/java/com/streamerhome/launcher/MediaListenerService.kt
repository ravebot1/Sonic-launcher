package com.streamerhome.launcher

import android.service.notification.NotificationListenerService

// Does nothing by itself. Having "Notification access" enabled for this service is what lets
// the launcher read what is playing (Deezer, YouTube Music, Tidal, ...).
class MediaListenerService : NotificationListenerService()
