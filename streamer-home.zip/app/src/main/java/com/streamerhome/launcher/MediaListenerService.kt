package com.streamerhome.launcher

import android.os.Handler
import android.os.HandlerThread
import android.service.notification.NotificationListenerService

// Having "Notification access" enabled for this service is what lets the launcher read what is playing
// (Deezer, YouTube Music, Tidal, ...). While it is connected it also remembers what you played, so the
// "recent" tiles fill up even when another app is on screen.
class MediaListenerService : NotificationListenerService() {

    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var lastKey = ""

    private val tick = object : Runnable {
        override fun run() {
            try {
                val m = NowPlaying.read(this@MediaListenerService)
                if (m != null && m.title.isNotBlank()) {
                    NowPlaying.remember(applicationContext, m)
                    val k = m.pkg + "|" + m.title + "|" + m.artist + "|" + (m.art != null)
                    if (k != lastKey) {
                        lastKey = k
                        Recent.add(applicationContext, m.pkg, m.title, m.artist, m.art)
                    }
                }
            } catch (e: Exception) {
                // try again on the next tick
            }
            handler?.postDelayed(this, 3000L)
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        if (thread == null) {
            val t = HandlerThread("sonik-media")
            t.start()
            thread = t
            handler = Handler(t.looper)
        }
        handler?.removeCallbacks(tick)
        handler?.post(tick)
    }

    override fun onListenerDisconnected() {
        handler?.removeCallbacks(tick)
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        handler?.removeCallbacks(tick)
        thread?.quitSafely()
        thread = null
        handler = null
        super.onDestroy()
    }
}
