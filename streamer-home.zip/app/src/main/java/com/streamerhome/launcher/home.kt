package com.streamerhome.launcher

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

// ---------- Look & feel ----------

private val LocalAccent = compositionLocalOf { Color(0xFF4FE3FF) }

private val Ink = Color(0xFF060A14)
private val PanelDark = Color(0xFF0E1626)
private val TextHi = Color(0xFFF2F7FF)
private val TextLo = Color(0xFFA5B4CC)

// Compose has no built-in rounded font; SansSerif is the closest safe choice.
private val RoundedFont: FontFamily = FontFamily.SansSerif

private val glassBorder = Brush.linearGradient(listOf(Color(0x80FFFFFF), Color(0x14FFFFFF)))
private val glassFill = Brush.linearGradient(listOf(Color(0x3DFFFFFF), Color(0x0FFFFFFF)))
private val glassFillFocused = Brush.linearGradient(listOf(Color(0x70FFFFFF), Color(0x2AFFFFFF)))

private val timeFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")

private fun glow(color: Color, blur: Float = 16f) = TextStyle(
    shadow = Shadow(color = color.copy(alpha = 0.6f), offset = Offset.Zero, blurRadius = blur)
)

private fun Modifier.glass(shape: Shape): Modifier =
    this.clip(shape).background(glassFill).border(1.dp, glassBorder, shape)

// Sky colours used behind the weather photo (and while it loads)
private fun skyColors(isDay: Boolean, group: String): Pair<Color, Color> = when {
    !isDay && (group == "rain" || group == "storm") -> Pair(Color(0xFF0D1422), Color(0xFF2A3548))
    !isDay -> Pair(Color(0xFF0A1230), Color(0xFF22306A))
    group == "clear" -> Pair(Color(0xFF2F78C8), Color(0xFF8FC8F5))
    group == "rain" -> Pair(Color(0xFF34455A), Color(0xFF63778D))
    group == "storm" -> Pair(Color(0xFF2A2D44), Color(0xFF55506E))
    group == "snow" -> Pair(Color(0xFF8CA2B9), Color(0xFFDCE5EE))
    group == "fog" -> Pair(Color(0xFF7A858F), Color(0xFFB9C1C8))
    else -> Pair(Color(0xFF55697E), Color(0xFF9AAABA))
}

// ---------- Home screen ----------

@Composable
fun HomeScreen(
    permissionTick: Int,
    resumeTick: Int,
    onAskLocation: () -> Unit
) {
    val context = LocalContext.current

    var showApps by remember { mutableStateOf(false) }
    var showNet by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var weather by remember { mutableStateOf<Weather?>(null) }
    var net by remember { mutableStateOf(NetworkReader.read(context)) }

    var themeIdx by remember { mutableIntStateOf(Prefs.themeIndex(context)) }
    var intervalMin by remember { mutableIntStateOf(Prefs.intervalMin(context)) }
    var cats by remember { mutableIntStateOf(Prefs.categories(context)) }

    // A launcher should never "go back" to anything; Back only closes open panels.
    BackHandler {
        showSettings = false
        showApps = false
    }

    LaunchedEffect(Unit) {
        while (isActive) {
            now = LocalDateTime.now()
            delay(1000L)
        }
    }

    LaunchedEffect(Unit) {
        while (isActive) {
            val w = withContext(Dispatchers.IO) { WeatherApi.fetch() }
            if (w != null) weather = w
            delay(if (w != null) Config.WEATHER_REFRESH_MS else 60_000L)
        }
    }

    LaunchedEffect(permissionTick, resumeTick) {
        while (isActive) {
            net = NetworkReader.read(context)
            delay(4000L)
        }
    }

    val theme = Themes[themeIdx.coerceIn(0, Themes.size - 1)]

    CompositionLocalProvider(LocalAccent provides theme.accent) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Ink)
        ) {
            // Accent glow, visible until the first wallpaper loads
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            listOf(theme.accent.copy(alpha = 0.28f), Color.Transparent)
                        )
                    )
            )

            // Online wallpaper
            RotatingImage(
                modifier = Modifier.fillMaxSize(),
                maxSide = 2200,
                intervalMs = intervalMin * 60_000L,
                key = cats
            ) {
                Remote.backgroundUrls(cats)
            }

            // Darkening for readability
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0x99060A14), Color(0x40060A14), Color(0xB3060A14))
                        )
                    )
            )

            GridOverlay()

            Column(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 40.dp, vertical = 24.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    ClockText(now)

                    Spacer(Modifier.weight(1f))

                    WeatherPanel(weather)

                    Spacer(Modifier.width(16.dp))

                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        WifiButton(net) { showNet = true }
                        SettingsButton { showSettings = true }
                    }
                }

                Spacer(Modifier.weight(1f))

                AppRow(resumeTick) { showApps = true }

                Spacer(Modifier.height(10.dp))

                Text(
                    text = "Created by Claudiu",
                    color = TextLo.copy(alpha = 0.75f),
                    fontSize = 11.sp,
                    fontFamily = RoundedFont,
                    letterSpacing = 1.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }

            if (showApps) {
                AllApps(resumeTick) { showApps = false }
            }

            if (showSettings) {
                SettingsScreen(
                    themeIdx = themeIdx,
                    intervalMin = intervalMin,
                    cats = cats,
                    onTheme = { i ->
                        themeIdx = i
                        Prefs.setThemeIndex(context, i)
                    },
                    onInterval = { m ->
                        val v = m.coerceIn(5, 60)
                        intervalMin = v
                        Prefs.setIntervalMin(context, v)
                    },
                    onCats = { c ->
                        if (c != 0) {
                            cats = c
                            Prefs.setCategories(context, c)
                        }
                    },
                    onSystemSettings = { openSystemSettings(context) },
                    onClose = { showSettings = false }
                )
            }

            if (showNet) {
                NetDialog(
                    net = net,
                    onClose = { showNet = false },
                    onAskLocation = onAskLocation,
                    onSettings = { openWifiSettings(context) }
                )
            }
        }
    }
}

private fun openSystemSettings(context: Context) {
    try {
        context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        // nothing else to try
    }
}

private fun openWifiSettings(context: Context) {
    try {
        context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        openSystemSettings(context)
    }
}

@Composable
private fun GridOverlay() {
    Canvas(Modifier.fillMaxSize()) {
        val step = 56.dp.toPx()
        val c = Color(0x0EFFFFFF)
        var x = 0f
        while (x < size.width) {
            drawLine(c, Offset(x, 0f), Offset(x, size.height), 1f)
            x += step
        }
        var y = 0f
        while (y < size.height) {
            drawLine(c, Offset(0f, y), Offset(size.width, y), 1f)
            y += step
        }
    }
}

// Cross-fading slideshow of remote images. Restarts whenever `key` or the interval changes.
@Composable
private fun RotatingImage(
    modifier: Modifier,
    maxSide: Int,
    intervalMs: Long,
    key: Any,
    fetchUrls: () -> List<String>
) {
    val context = LocalContext.current
    var bitmap by remember { mutableStateOf<ImageBitmap?>(null) }

    LaunchedEffect(key, intervalMs) {
        var urls: List<String> = emptyList()
        var index = 0
        while (isActive) {
            if (urls.isEmpty()) {
                urls = withContext(Dispatchers.IO) { fetchUrls() }
                index = 0
                if (urls.isEmpty()) {
                    delay(60_000L)
                    continue
                }
            }
            val url = urls[index]
            val bmp = withContext(Dispatchers.IO) { Remote.loadBitmap(context, url, maxSide) }
            if (bmp != null) {
                bitmap = bmp.asImageBitmap()
                delay(intervalMs)
            } else {
                delay(2000L)
            }
            index++
            if (index >= urls.size) {
                urls = emptyList()
            }
        }
    }

    Crossfade(
        targetState = bitmap,
        modifier = modifier,
        animationSpec = tween(1500),
        label = "remoteImage"
    ) { bmp ->
        if (bmp != null) {
            Image(
                bitmap = bmp,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(Modifier.fillMaxSize())
        }
    }
}

// ---------- Top bar pieces ----------

@Composable
private fun ClockText(now: LocalDateTime) {
    // No panel behind it: just text with a soft dark shadow so it stays readable.
    Text(
        text = now.format(timeFmt),
        color = TextHi,
        fontSize = 36.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = RoundedFont,
        letterSpacing = 2.sp,
        style = TextStyle(
            shadow = Shadow(color = Color(0xCC000000), offset = Offset(0f, 2f), blurRadius = 10f)
        ),
        modifier = Modifier.padding(start = 6.dp, top = 6.dp)
    )
}

@Composable
private fun WeatherPanel(w: Weather?) {
    val accent = LocalAccent.current
    val shape = RoundedCornerShape(20.dp)
    val isDay = w?.isDay ?: true
    val group = w?.group ?: "cloud"
    val sky = skyColors(isDay, group)

    Box(
        Modifier
            .width(340.dp)
            .height(136.dp)
            .clip(shape)
            .background(PanelDark)
            .border(1.dp, glassBorder, shape)
    ) {
        // Sky colours that match the weather and time of day
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(sky.first, sky.second)))
        )

        // London photo matching the weather and time of day, changes every 30 minutes
        if (w != null) {
            RotatingImage(
                modifier = Modifier.fillMaxSize(),
                maxSide = 1400,
                intervalMs = Config.WEATHER_PHOTO_INTERVAL_MS,
                key = (if (isDay) "d" else "n") + group
            ) {
                Remote.weatherPhotoUrls(isDay, group)
            }
        }

        // Dark-to-clear scrim so the text on the left stays readable
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xE60A1020), Color(0x990A1020), Color(0x1A0A1020))
                    )
                )
        )

        Column(
            Modifier
                .align(Alignment.CenterStart)
                .padding(horizontal = 20.dp)
        ) {
            if (w == null) {
                Text(
                    text = "SYNCING...",
                    color = TextLo,
                    fontSize = 14.sp,
                    fontFamily = RoundedFont
                )
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = w.temp.toString() + "°",
                        color = TextHi,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont,
                        style = glow(accent, 18f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(text = w.emoji, fontSize = 28.sp)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(
                            text = Config.CITY,
                            color = TextHi,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = RoundedFont
                        )
                        Text(
                            text = w.label.uppercase(),
                            color = accent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = RoundedFont,
                            letterSpacing = 1.sp
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "H " + w.high + "°  L " + w.low + "°  ·  " + w.windMph + " MPH  ·  " + w.humidity + "%",
                    color = TextLo,
                    fontSize = 11.sp,
                    fontFamily = RoundedFont
                )
            }
        }
    }
}

@Composable
private fun WifiButton(net: NetInfo, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val active = if (net.level < 0) 0 else net.level.coerceAtLeast(1)
    Box(
        Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(if (focused) glassFillFocused else glassFill)
            .border(
                if (focused) 2.dp else 1.dp,
                if (focused) accent else Color(0x44FFFFFF),
                CircleShape
            )
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(24.dp)) {
            val barW = size.width / 7f
            for (i in 0 until 4) {
                val h = size.height * (0.3f + 0.7f * (i + 1) / 4f)
                drawRoundRect(
                    color = if (i < active) accent else Color(0x44FFFFFF),
                    topLeft = Offset(i * barW * 2f, size.height - h),
                    size = Size(barW, h),
                    cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                )
            }
        }
    }
}

@Composable
private fun SettingsButton(onClick: () -> Unit) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    Box(
        Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(if (focused) glassFillFocused else glassFill)
            .border(
                if (focused) 2.dp else 1.dp,
                if (focused) accent else Color(0x44FFFFFF),
                CircleShape
            )
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "⚙",
            color = if (focused) accent else TextHi,
            fontSize = 22.sp
        )
    }
}

// ---------- App tiles ----------

@Composable
private fun AppRow(resumeTick: Int, onAllApps: () -> Unit) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val pm = context.packageManager
    val first = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(300L)
        runCatching { first.requestFocus() }
    }

    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally)
    ) {
        Config.tiles.forEachIndexed { index, spec ->
            val pkg = remember(resumeTick, spec) { Apps.firstInstalled(pm, spec.packages) }

            var icon by remember(pkg) { mutableStateOf<ImageBitmap?>(null) }
            LaunchedEffect(pkg) {
                icon = withContext(Dispatchers.IO) {
                    pkg?.let { Apps.icon(pm, it) }
                }
            }

            AppTile(
                label = spec.label,
                accent = Color(spec.accent),
                icon = icon,
                modifier = Modifier.width(92.dp),
                installed = pkg != null,
                focusRequester = if (index == 0) first else null
            ) {
                val p = Apps.firstInstalled(pm, spec.packages)
                if (p != null) Apps.launch(context, p) else Apps.launch(context, spec.packages.first())
            }
        }

        AppTile(
            label = "All apps",
            accent = accent,
            icon = null,
            modifier = Modifier.width(92.dp),
            glyph = "☰"
        ) { onAllApps() }
    }
}

@Composable
private fun AppTile(
    label: String,
    accent: Color,
    icon: ImageBitmap?,
    modifier: Modifier = Modifier,
    glyph: String? = null,
    installed: Boolean = true,
    focusRequester: FocusRequester? = null,
    onClick: () -> Unit
) {
    val themeAccent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.12f else 1f,
        animationSpec = spring(),
        label = "tileScale"
    )
    val shape = RoundedCornerShape(16.dp)

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .scale(scale)
            .alpha(if (installed) 1f else 0.45f)
            .clip(shape)
            .background(if (focused) glassFillFocused else glassFill)
            .border(
                if (focused) 2.dp else 1.dp,
                if (focused) themeAccent else Color(0x44FFFFFF),
                shape
            )
            .then(
                if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier
            )
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(6.dp)
        ) {
            if (icon != null) {
                Image(
                    bitmap = icon,
                    contentDescription = label,
                    modifier = Modifier
                        .fillMaxWidth(0.66f)
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(14.dp))
                )
            } else {
                Box(
                    Modifier
                        .fillMaxWidth(0.66f)
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(accent.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = glyph ?: label.take(1).uppercase(),
                        color = accent,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = label,
                color = TextHi,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// ---------- All apps overlay ----------

@Composable
private fun AllApps(resumeTick: Int, onClose: () -> Unit) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val pm = context.packageManager
    val apps = remember(resumeTick) { Apps.installed(context) }
    val first = remember { FocusRequester() }

    LaunchedEffect(apps) {
        delay(250L)
        runCatching { first.requestFocus() }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF2060A14))
            .padding(horizontal = 40.dp, vertical = 28.dp)
    ) {
        Column {
            Text(
                text = "ALL APPS",
                color = accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 2.sp
            )
            Spacer(Modifier.height(16.dp))
            LazyVerticalGrid(
                columns = GridCells.Adaptive(104.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(8.dp)
            ) {
                itemsIndexed(apps) { index, app ->
                    var icon by remember(app.pkg) { mutableStateOf<ImageBitmap?>(null) }
                    LaunchedEffect(app.pkg) {
                        icon = withContext(Dispatchers.IO) { Apps.icon(pm, app.pkg) }
                    }
                    AppTile(
                        label = app.label,
                        accent = accent,
                        icon = icon,
                        modifier = Modifier.fillMaxWidth(),
                        focusRequester = if (index == 0) first else null
                    ) {
                        Apps.launch(context, app.pkg)
                        onClose()
                    }
                }
            }
        }
    }
}

// ---------- Launcher settings ----------

@Composable
private fun SettingsScreen(
    themeIdx: Int,
    intervalMin: Int,
    cats: Int,
    onTheme: (Int) -> Unit,
    onInterval: (Int) -> Unit,
    onCats: (Int) -> Unit,
    onSystemSettings: () -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    val first = remember { FocusRequester() }
    var status by remember { mutableStateOf(Remote.status) }

    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { first.requestFocus() }
    }
    LaunchedEffect(Unit) {
        while (isActive) {
            status = Remote.status
            delay(2000L)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF5060A14))
            .padding(horizontal = 40.dp, vertical = 24.dp)
    ) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Text(
                text = "LAUNCHER SETTINGS  ·  v" + Config.VERSION,
                color = accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 3.sp
            )

            Spacer(Modifier.height(16.dp))
            SectionLabel("COLOR THEME")
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Themes.forEachIndexed { i, t ->
                    ThemeSwatch(
                        theme = t,
                        selected = i == themeIdx,
                        focusRequester = if (i == themeIdx) first else null
                    ) { onTheme(i) }
                }
            }

            Spacer(Modifier.height(18.dp))
            SectionLabel("WALLPAPER CHANGES EVERY")
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                ChipButton("-", false) { onInterval(intervalMin - 5) }
                Text(
                    text = intervalMin.toString() + " min",
                    color = TextHi,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RoundedFont
                )
                ChipButton("+", false) { onInterval(intervalMin + 5) }
            }

            Spacer(Modifier.height(18.dp))
            SectionLabel("WALLPAPER TYPES")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ChipButton("Space", (cats and CAT_SPACE) != 0) { onCats(cats xor CAT_SPACE) }
                ChipButton("Nature", (cats and CAT_NATURE) != 0) { onCats(cats xor CAT_NATURE) }
                ChipButton("City", (cats and CAT_CITY) != 0) { onCats(cats xor CAT_CITY) }
                ChipButton("Animals", (cats and CAT_ANIMALS) != 0) { onCats(cats xor CAT_ANIMALS) }
                ChipButton("Art", (cats and CAT_ART) != 0) { onCats(cats xor CAT_ART) }
            }

            Spacer(Modifier.height(18.dp))
            SectionLabel("ONLINE IMAGE STATUS")
            Text(
                text = status,
                color = TextLo,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )

            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                ChipButton("System settings", false) { onSystemSettings() }
                ChipButton("Close", true) { onClose() }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        color = TextLo,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = RoundedFont,
        letterSpacing = 2.sp,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun ThemeSwatch(
    theme: ThemeSpec,
    selected: Boolean,
    focusRequester: FocusRequester?,
    onClick: () -> Unit
) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(44.dp)
                .scale(if (focused) 1.15f else 1f)
                .then(
                    if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier
                )
                .clip(CircleShape)
                .background(theme.accent)
                .border(
                    3.dp,
                    if (selected) Color.White else if (focused) Color(0xAAFFFFFF) else Color.Transparent,
                    CircleShape
                )
                .focusable(interactionSource = source)
                .clickable(interactionSource = source, indication = null, onClick = onClick)
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = theme.name,
            color = if (selected) TextHi else TextLo,
            fontSize = 11.sp,
            fontFamily = RoundedFont
        )
    }
}

@Composable
private fun ChipButton(
    text: String,
    selected: Boolean,
    focusRequester: FocusRequester? = null,
    onClick: () -> Unit
) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val shape = RoundedCornerShape(12.dp)
    val bg = if (focused) accent else if (selected) accent.copy(alpha = 0.35f) else Color(0xFF18223A)
    Box(
        Modifier
            .clip(shape)
            .background(bg)
            .border(1.dp, if (focused || selected) accent else Color(0x44FFFFFF), shape)
            .then(
                if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier
            )
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (focused) Ink else TextHi,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RoundedFont
        )
    }
}

// ---------- Network dialog ----------

@Composable
private fun NetDialog(
    net: NetInfo,
    onClose: () -> Unit,
    onAskLocation: () -> Unit,
    onSettings: () -> Unit
) {
    val accent = LocalAccent.current
    val closeFocus = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { closeFocus.requestFocus() }
    }

    val shape = RoundedCornerShape(20.dp)

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            Modifier
                .width(500.dp)
                .clip(shape)
                .background(PanelDark)
                .border(1.dp, glassBorder, shape)
                .padding(30.dp)
        ) {
            Text(
                text = "NETWORK",
                color = accent,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 2.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = net.name,
                color = TextHi,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                style = glow(accent, 18f)
            )
            if (net.detail.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = net.detail,
                    color = TextLo,
                    fontSize = 15.sp,
                    fontFamily = RoundedFont
                )
            }
            if (net.needsLocation) {
                Spacer(Modifier.height(14.dp))
                Text(
                    text = "Android only shows the Wi-Fi name after location access is allowed.",
                    color = TextLo,
                    fontSize = 14.sp,
                    fontFamily = RoundedFont
                )
                Spacer(Modifier.height(12.dp))
                ChipButton("Allow access", true) { onAskLocation() }
            }
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                ChipButton("Wi-Fi settings", false) { onSettings() }
                ChipButton("Close", true, closeFocus) { onClose() }
            }
        }
    }
}
