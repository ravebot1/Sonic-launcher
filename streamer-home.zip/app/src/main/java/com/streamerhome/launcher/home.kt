package com.streamerhome.launcher

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

private val AccentColor = Color(0xFF38BDF8)

// Compose has no built-in rounded font; SansSerif is the closest safe choice.
private val RoundedFont: FontFamily = FontFamily.SansSerif
private val Ink = Color(0xFF060A14)
private val PanelDark = Color(0xFF0E1626)
private val TextHi = Color(0xFFF2F7FF)
private val TextLo = Color(0xFFA5B4CC)

private val glassBorder =
    Brush.linearGradient(
        listOf(
            Color(0x50FFFFFF),
            Color(0x14FFFFFF)
        )
    )

private val glassFill =
    Brush.linearGradient(
        listOf(
            Color(0x3DFFFFFF),
            Color(0x0FFFFFFF)
        )
    )

private val glassFillFocused =
    Brush.linearGradient(
        listOf(
            Color(0x70FFFFFF),
            Color(0x2AFFFFFF)
        )
    )

private val timeFmt =
    DateTimeFormatter.ofPattern("HH:mm")

private fun glow(
    color: Color = AccentColor,
    blur: Float = 16f
) = TextStyle(
    shadow = Shadow(
        color = color.copy(alpha = 0.6f),
        offset = Offset.Zero,
        blurRadius = blur
    )
)

private fun Modifier.glass(
    shape: Shape
): Modifier =
    clip(shape)
        .background(glassFill)
        .border(
            1.dp,
            glassBorder,
            shape
        )

@Composable
fun HomeScreen(
    permissionTick: Int,
    resumeTick: Int,
    onAskLocation: () -> Unit
) {
    val context = LocalContext.current

    var showApps by remember { mutableStateOf(false) }
    var showNet by remember { mutableStateOf(false) }

    var now by remember {
        mutableStateOf(LocalDateTime.now())
    }

    var weather by remember {
        mutableStateOf<Weather?>(null)
    }

    var net by remember {
        mutableStateOf(NetworkReader.read(context))
    }

    BackHandler {
        showApps = false
    }

    LaunchedEffect(Unit) {
        while (isActive) {
            now = LocalDateTime.now()
            delay(1000)
        }
    }

    LaunchedEffect(Unit) {
        while (isActive) {

            val w =
                withContext(Dispatchers.IO) {
                    WeatherApi.fetch()
                }

            weather = w

            delay(
                if (w != null)
                    Config.WEATHER_REFRESH_MS
                else
                    60_000
            )
        }
    }

    LaunchedEffect(permissionTick, resumeTick) {
        net = NetworkReader.read(context)
    }

    LaunchedEffect(Unit) {
        while (isActive) {
            net = NetworkReader.read(context)
            delay(4000)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Ink)
    ) {

        RotatingImage(
            modifier = Modifier.fillMaxSize(),
            maxSide = 2200,
            intervalMs = Config.BG_INTERVAL_MS
        ) {
            Remote.backgroundUrls()
        }

        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0xB3060A14),
                            Color(0x59060A14),
                            Color(0xCC060A14)
                        )
                    )
                )
        )

        GridOverlay()

        Column(
            Modifier
                .fillMaxSize()
                .padding(
                    horizontal = 40.dp,
                    vertical = 28.dp
                )
        ) {

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {

                ClockPanel(now)

                Spacer(
                    Modifier.weight(1f)
                )

                WeatherPanel(weather)

                Spacer(
                    Modifier.width(16.dp)
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    WifiButton(net) {
                        showNet = true
                    }

                    SettingsButton {
                        openWifiSettings(context)
                    }
                }
            }

            Spacer(
                Modifier.weight(1f)
            )

            AppRow(resumeTick) {
                showApps = true
            }
        }

        if (showApps) {
            AllApps(resumeTick) {
                showApps = false
            }
        }

        if (showNet) {
            NetDialog(
                net = net,
                onClose = { showNet = false },
                onAskLocation = onAskLocation,
                onSettings = {
                    openWifiSettings(context)
                }
            )
        }
    }
}
private fun openWifiSettings(
    context: Context
) {
    try {
        context.startActivity(
            Intent(Settings.ACTION_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {

        try {
            context.startActivity(
                Intent(Settings.ACTION_WIFI_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
        }
    }
}

@Composable
private fun GridOverlay() {

    Canvas(
        Modifier.fillMaxSize()
    ) {

        val step = 56.dp.toPx()

        val c = Color(0x0EFFFFFF)

        var x = 0f

        while (x < size.width) {

            drawLine(
                c,
                Offset(x, 0f),
                Offset(x, size.height),
                1f
            )

            x += step
        }

        var y = 0f

        while (y < size.height) {

            drawLine(
                c,
                Offset(0f, y),
                Offset(size.width, y),
                1f
            )

            y += step
        }
    }
}

@Composable
private fun RotatingImage(
    modifier: Modifier,
    maxSide: Int,
    intervalMs: Long,
    fetchUrls: () -> List<String>
) {

    val context = LocalContext.current

    var bitmap by remember {
        mutableStateOf<ImageBitmap?>(null)
    }

    LaunchedEffect(Unit) {

        var urls: List<String> = emptyList()

        var index = 0

        while (isActive) {

            if (urls.isEmpty()) {

                urls =
                    withContext(Dispatchers.IO) {
                        fetchUrls()
                    }

                index = 0

                if (urls.isEmpty()) {

                    delay(15_000)

                    continue
                }
            }

            val bmp =
                withContext(Dispatchers.IO) {
                    Remote.loadBitmap(
                        context,
                        urls[index],
                        maxSide
                    )
                }

            if (bmp != null) {

                bitmap = bmp.asImageBitmap()

                delay(intervalMs)

            } else {
                delay(2000)
            }

            index++

            if (index >= urls.size) {
                index = 0
            }
        }
    }

    Crossfade(
        targetState = bitmap,
        animationSpec = tween(1500),
        modifier = modifier,
        label = "background"
    ) { bmp ->

        if (bmp != null) {

            Image(
                bitmap = bmp,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

        } else {

            Box(
                Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun ClockPanel(
    now: LocalDateTime
) {

    Box(
        Modifier
            .glass(
                RoundedCornerShape(20.dp)
            )
            .padding(
                horizontal = 20.dp,
                vertical = 10.dp
            )
            .width(IntrinsicSize.Max)
    ) {

        Text(
            text = now.format(timeFmt),
            color = TextHi,
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RoundedFont,
            style = glow(blur = 12f)
        )
    }
}

@Composable
private fun WeatherPanel(
    w: Weather?
) {

    val shape =
        RoundedCornerShape(20.dp)

    Box(
        Modifier
            .width(320.dp)
            .height(130.dp)
            .clip(shape)
            .background(PanelDark)
            .border(
                1.dp,
                glassBorder,
                shape
            )
    ) {

        RotatingImage(
            modifier = Modifier.fillMaxSize(),
            maxSide = 1400,
            intervalMs = Config.LONDON_INTERVAL_MS
        ) {
            Remote.londonUrls()
        }

        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            Color(0xEE0A1020),
                            Color(0xA10A1020),
                            Color(0x220A1020)
                        )
                    )
                )
        )

        Column(
            Modifier
                .align(Alignment.CenterStart)
                .padding(horizontal = 20.dp)
        ) {

            if (w == null) {

                Text(
                    text = "SYNCING...",
                    color = TextLo,
                    fontSize = 14.sp,
                    fontFamily = RoundedFont
                )

            } else {

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Text(
                        text = "${w.temp}°",
                        color = TextHi,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont,
                        style = glow(blur = 18f)
                    )

                    Spacer(
                        Modifier.width(10.dp)
                    )

                    Text(
                        text = w.emoji,
                        fontSize = 28.sp
                    )
                }

                Text(
                    text = w.label.uppercase(),
                    color = TextHi,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RoundedFont,
                    letterSpacing = 1.sp
                )

                Spacer(
                    Modifier.height(2.dp)
                )

                Text(
                    text =
                        "H ${w.high}°  " +
                        "L ${w.low}°  ·  " +
                        "${w.windMph} MPH  ·  " +
                        "${w.humidity}%",
                    color = TextLo,
                    fontSize = 11.sp,
                    fontFamily = RoundedFont
                )
            }
        }
    }
}

@Composable
private fun WifiButton(
    net: NetInfo,
    onClick: () -> Unit
) {

    val source = remember {
        MutableInteractionSource()
    }

    val focused by source.collectIsFocusedAsState()

    val active =
        if (net.level < 0)
            0
        else
            net.level.coerceAtLeast(1)

    Box(
        Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(
                if (focused)
                    glassFillFocused
                else
                    glassFill
            )
            .border(
                if (focused) 2.dp else 1.dp,
                if (focused)
                    AccentColor
                else
                    Color(0x44FFFFFF),
                CircleShape
            )
            .focusable(
                interactionSource = source
            )
            .clickable(
                interactionSource = source,
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {

        Canvas(
            Modifier.size(24.dp)
        ) {

            val barW = size.width / 7f

            for (i in 0 until 4) {

                val h =
                    size.height *
                    (0.3f + 0.7f * (i + 1) / 4f)

                drawRoundRect(
                    color =
                        if (i < active)
                            AccentColor
                        else
                            Color(0x44FFFFFF),
                    topLeft = Offset(
                        i * barW * 2f,
                        size.height - h
                    ),
                    size = Size(barW, h),
                    cornerRadius =
                        CornerRadius(
                            barW / 2f,
                            barW / 2f
                        )
                )
            }
        }
    }
}

@Composable
private fun SettingsButton(
    onClick: () -> Unit
) {

    val source = remember {
        MutableInteractionSource()
    }

    val focused by source.collectIsFocusedAsState()

    Box(
        Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(
                if (focused)
                    glassFillFocused
                else
                    glassFill
            )
            .border(
                if (focused) 2.dp else 1.dp,
                if (focused)
                    AccentColor
                else
                    Color(0x44FFFFFF),
                CircleShape
            )
            .focusable(
                interactionSource = source
            )
            .clickable(
                interactionSource = source,
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {

        Text(
            text = "⚙",
            color =
                if (focused)
                    AccentColor
                else
                    TextHi,
            fontSize = 22.sp
        )
    }
}

@Composable
private fun AppRow(
    resumeTick: Int,
    onAllApps: () -> Unit
) {

    val context = LocalContext.current
    val pm = context.packageManager

    val first =
        remember {
            FocusRequester()
        }

    LaunchedEffect(Unit) {

        delay(300)

        runCatching {
            first.requestFocus()
        }
    }

    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement =
            Arrangement.spacedBy(16.dp)
    ) {

        Config.tiles.forEachIndexed { index, spec ->

            val pkg =
                remember(resumeTick, spec) {
                    Apps.firstInstalled(
                        pm,
                        spec.packages
                    )
                }

            var icon by remember(pkg) {
                mutableStateOf<ImageBitmap?>(null)
            }

            LaunchedEffect(pkg) {
                icon =
                    withContext(Dispatchers.IO) {
                        pkg?.let {
                            Apps.icon(pm, it)
                        }
                    }
            }

            AppTile(
                label = spec.label,
                accent = Color(spec.accent),
                icon = icon,
                modifier = Modifier.weight(1f),
                installed = pkg != null,
                focusRequester =
                    if (index == 0)
                        first
                    else
                        null
            ) {

                val p =
                    Apps.firstInstalled(
                        pm,
                        spec.packages
                    )

                if (p != null)
                    Apps.launch(context, p)
                else
                    Apps.launch(
                        context,
                        spec.packages.first()
                    )
            }
        }

        AppTile(
            label = "All apps",
            accent = AccentColor,
            icon = null,
            modifier = Modifier.weight(1f),
            glyph = "☰"
        ) {
            onAllApps()
        }
    }
}

@Composable
private fun AppTile(
    label: String,
    accent: Color,
    icon: ImageBitmap?,
    modifier: Modifier = Modifier,
    glyph: String? = null,
    installed: Boolean = true,
    focusRequester: FocusRequester? = null,
    onClick: () -> Unit
) {

    val source =
        remember {
            MutableInteractionSource()
        }

    val focused by source.collectIsFocusedAsState()

    val scale by animateFloatAsState(
        targetValue =
            if (focused) 1.10f else 1f,
        animationSpec = spring(),
        label = "scale"
    )

    val offsetX by animateFloatAsState(
        targetValue =
            if (focused) -10f else 0f,
        label = "offsetX"
    )

    val offsetY by animateFloatAsState(
        targetValue =
            if (focused) -6f else 0f,
        label = "offsetY"
    )

    val shape =
        RoundedCornerShape(18.dp)

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationX = offsetX
                translationY = offsetY
            }
            .alpha(
                if (installed)
                    1f
                else
                    0.45f
            )
            .clip(shape)
            .background(
                if (focused)
                    glassFillFocused
                else
                    glassFill
            )
            .border(
                if (focused) 3.dp else 1.dp,
                if (focused)
                    AccentColor
                else
                    Color(0x44FFFFFF),
                shape
            )
            .then(
                if (focusRequester != null)
                    Modifier.focusRequester(
                        focusRequester
                    )
                else
                    Modifier
            )
            .focusable(
                interactionSource = source
            )
            .clickable(
                interactionSource = source,
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {

        Column(
            horizontalAlignment =
                Alignment.CenterHorizontally,
            verticalArrangement =
                Arrangement.Center,
            modifier =
                Modifier.padding(10.dp)
        ) {

            if (icon != null) {

                Image(
                    bitmap = icon,
                    contentDescription = label,
                    modifier = Modifier
                        .fillMaxWidth(0.7f)
                        .aspectRatio(1f)
                        .clip(
                            RoundedCornerShape(22.dp)
                        )
                )

            } else {

                Box(
                    Modifier
                        .fillMaxWidth(0.7f)
                        .aspectRatio(1f)
                        .clip(
                            RoundedCornerShape(22.dp)
                        )
                        .background(
                            accent.copy(alpha = 0.22f)
                        ),
                    contentAlignment =
                        Alignment.Center
                ) {

                    Text(
                        glyph
                            ?: label
                                .take(1)
                                .uppercase(),
                        color = accent,
                        fontSize = 40.sp,
                        fontWeight =
                            FontWeight.Bold,
                        fontFamily =
                            RoundedFont
                    )
                }
            }

            Spacer(
                Modifier.height(8.dp)
            )

            Text(
                text = label,
                color = TextHi,
                fontSize = 14.sp,
                fontWeight =
                    FontWeight.Bold,
                fontFamily =
                    RoundedFont,
                maxLines = 1,
                overflow =
                    TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun AllApps(
    resumeTick: Int,
    onClose: () -> Unit
) {

    val context = LocalContext.current

    val pm = context.packageManager

    val apps =
        remember(resumeTick) {
            Apps.installed(context)
        }

    val first =
        remember {
            FocusRequester()
        }

    LaunchedEffect(apps) {

        delay(250)

        runCatching {
            first.requestFocus()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Color(0xF2060A14)
            )
            .padding(
                horizontal = 40.dp,
                vertical = 28.dp
            )
    ) {

        Column {

            Text(
                text = "ALL APPS",
                color = AccentColor,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 2.sp
            )

            Spacer(
                Modifier.height(16.dp)
            )

            LazyVerticalGrid(
                columns =
                    GridCells.Adaptive(
                        132.dp
                    ),
                horizontalArrangement =
                    Arrangement.spacedBy(
                        14.dp
                    ),
                verticalArrangement =
                    Arrangement.spacedBy(
                        14.dp
                    ),
                contentPadding =
                    PaddingValues(8.dp)
            ) {

                itemsIndexed(apps) { index, app ->

                    var icon by remember(app.pkg) {
                        mutableStateOf<ImageBitmap?>(null)
                    }

                    LaunchedEffect(app.pkg) {

                        icon =
                            withContext(
                                Dispatchers.IO
                            ) {
                                Apps.icon(
                                    pm,
                                    app.pkg
                                )
                            }
                    }

                    AppTile(
                        label = app.label,
                        accent = AccentColor,
                        icon = icon,
                        modifier =
                            Modifier.fillMaxWidth(),
                        focusRequester =
                            if (index == 0)
                                first
                            else
                                null
                    ) {

                        Apps.launch(
                            context,
                            app.pkg
                        )

                        onClose()
                    }
                }
            }
        }
    }
}

@Composable
private fun NetDialog(
    net: NetInfo,
    onClose: () -> Unit,
    onAskLocation: () -> Unit,
    onSettings: () -> Unit
) {

    val closeFocus =
        remember {
            FocusRequester()
        }

    LaunchedEffect(Unit) {

        delay(250)

        runCatching {
            closeFocus.requestFocus()
        }
    }

    val shape =
        RoundedCornerShape(20.dp)

    Dialog(
        onDismissRequest = onClose,
        properties =
            DialogProperties(
                usePlatformDefaultWidth = false
            )
    ) {

        Column(
            Modifier
                .width(500.dp)
                .clip(shape)
                .background(PanelDark)
                .border(
                    1.dp,
                    glassBorder,
                    shape
                )
                .padding(30.dp)
        ) {

            Text(
                text = "NETWORK",
                color = AccentColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 2.sp
            )

            Spacer(
                Modifier.height(6.dp)
            )

            Text(
                text = net.name,
                color = TextHi,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                style = glow(blur = 18f)
            )

            if (net.detail.isNotEmpty()) {

                Spacer(
                    Modifier.height(8.dp)
                )

                Text(
                    text = net.detail,
                    color = TextLo,
                    fontSize = 15.sp,
                    fontFamily = RoundedFont
                )
            }

            if (net.needsLocation) {

                Spacer(
                    Modifier.height(14.dp)
                )

                Text(
                    text =
                        "Android only shows the Wi‑Fi name after location access is allowed.",
                    color = TextLo,
                    fontSize = 14.sp,
                    fontFamily = RoundedFont
                )

                Spacer(
                    Modifier.height(12.dp)
                )

                ActionButton(
                    text = "Allow access",
                    primary = true,
                    focusRequester = null,
                    onClick = onAskLocation
                )
            }

            Spacer(
                Modifier.height(24.dp)
            )

            Row(
                horizontalArrangement =
                    Arrangement.spacedBy(14.dp)
            ) {

                ActionButton(
                    text = "Wi‑Fi settings",
                    primary = false,
                    focusRequester = null,
                    onClick = onSettings
                )

                ActionButton(
                    text = "Close",
                    primary = true,
                    focusRequester = closeFocus,
                    onClick = onClose
                )
            }
        }
    }
}

@Composable
private fun ActionButton(
    text: String,
    primary: Boolean,
    focusRequester: FocusRequester?,
    onClick: () -> Unit
) {

    val source =
        remember {
            MutableInteractionSource()
        }

    val focused by source.collectIsFocusedAsState()

    val shape =
        RoundedCornerShape(12.dp)

    val bg =
        if (focused)
            AccentColor
        else if (primary)
            Color(0xFF1F2B45)
        else
            Color(0xFF18223A)

    Box(
        Modifier
            .clip(shape)
            .background(bg)
            .border(
                1.dp,
                if (focused)
                    AccentColor
                else
                    Color(0x44FFFFFF),
                shape
            )
            .then(
                if (focusRequester != null)
                    Modifier.focusRequester(
                        focusRequester
                    )
                else
                    Modifier
            )
            .focusable(
                interactionSource = source
            )
            .clickable(
                interactionSource = source,
                indication = null,
                onClick = onClick
            )
            .padding(
                horizontal = 26.dp,
                vertical = 12.dp
            ),
        contentAlignment =
            Alignment.Center
    ) {

        Text(
            text = text,
            color =
                if (focused)
                    Ink
                else
                    TextHi,
            fontSize = 16.sp,
            fontWeight =
                FontWeight.Bold,
            fontFamily =
                RoundedFont
        )
    }
}