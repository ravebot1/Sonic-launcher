package com.streamerhome.launcher

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import android.net.Uri
import android.widget.Toast
import kotlinx.coroutines.launch
import kotlinx.coroutines.CoroutineScope
import androidx.compose.ui.input.key.onPreviewKeyEvent
import java.time.LocalDate
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

// ---------- Look & feel ----------

private val LocalAccent = compositionLocalOf { Color(0xFF4FE3FF) }

private val Ink = Color(0xFF060A14)
private val PanelDark = Color(0xFF0E1626)
private val TextHi = Color(0xFFF2F7FF)
private val TextLo = Color(0xFFA5B4CC)

// Compose has no built-in rounded font; SansSerif is the closest safe choice.
private val RoundedFont: FontFamily = FontFamily.SansSerif

private val glassBorder = Brush.linearGradient(listOf(Color(0x80FFFFFF), Color(0x14FFFFFF)))
private val glassFill = Brush.linearGradient(listOf(Color(0x3DFFFFFF), Color(0x0FFFFFFF)))
private val glassFillFocused = Brush.linearGradient(listOf(Color(0x70FFFFFF), Color(0x2AFFFFFF)))

private val timeFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val time12Fmt: DateTimeFormatter = DateTimeFormatter.ofPattern("h:mm")
private val dateFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE, d MMMM")

private fun glow(color: Color, blur: Float = 16f) = TextStyle(
    shadow = Shadow(color = color.copy(alpha = 0.6f), offset = Offset.Zero, blurRadius = blur)
)

private fun Modifier.glass(shape: Shape): Modifier =
    this.clip(shape).background(glassFill).border(1.dp, glassBorder, shape)

// Focusable + click + long-press. Holding OK / Enter on the remote repeats the key: that is the long press.
// The long-press action runs when the button is RELEASED. If it ran during the hold, the menu window would
// take focus and receive the release, which could trigger "Open" by accident.
private fun Modifier.tvClickable(
    source: MutableInteractionSource,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
): Modifier = composed {
    var longPending by remember { mutableStateOf(false) }
    this
        .focusable(interactionSource = source)
        .onKeyEvent { ev ->
            val native = ev.nativeKeyEvent
            val code = native.keyCode
            val select = code == android.view.KeyEvent.KEYCODE_DPAD_CENTER ||
                code == android.view.KeyEvent.KEYCODE_ENTER ||
                code == android.view.KeyEvent.KEYCODE_NUMPAD_ENTER
            if (!select) {
                false
            } else if (ev.type == KeyEventType.KeyDown) {
                if (native.repeatCount == 0) {
                    longPending = false
                } else if (onLongClick != null) {
                    longPending = true
                }
                true
            } else if (ev.type == KeyEventType.KeyUp) {
                val wasLong = longPending
                longPending = false
                if (wasLong && onLongClick != null) onLongClick() else onClick()
                true
            } else {
                false
            }
        }
}

// anim: 0 = full, 1 = reduced, 2 = off
private fun panelEnter(anim: Int): EnterTransition =
    if (anim == 2) EnterTransition.None
    else fadeIn(tween(220)) + scaleIn(animationSpec = tween(220), initialScale = 0.94f)

private fun panelExit(anim: Int): ExitTransition =
    if (anim == 2) ExitTransition.None
    else fadeOut(tween(160)) + scaleOut(animationSpec = tween(160), targetScale = 0.96f)

// Staggered fade / slide-in when the launcher opens
@Composable
private fun Entrance(
    delayMs: Int,
    anim: Int,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    var shown by remember { mutableStateOf(anim == 2) }
    LaunchedEffect(Unit) {
        if (!shown) {
            delay(delayMs.toLong())
            shown = true
        }
    }
    val a by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = tween(if (anim == 0) 700 else 250),
        label = "enterAlpha"
    )
    val dy by animateFloatAsState(
        targetValue = if (shown || anim != 0) 0f else 28f,
        animationSpec = tween(700),
        label = "enterY"
    )
    Box(
        modifier.graphicsLayer {
            alpha = a
            translationY = dy * density
        }
    ) {
        content()
    }
}

// Sky colours used behind the weather photo (and while it loads)
private fun skyColors(isDay: Boolean, group: String): Pair<Color, Color> = when {
    !isDay && (group == "rain" || group == "storm") -> Pair(Color(0xFF0D1422), Color(0xFF2A3548))
    !isDay -> Pair(Color(0xFF0A1230), Color(0xFF22306A))
    group == "clear" -> Pair(Color(0xFF2F78C8), Color(0xFF8FC8F5))
    group == "rain" -> Pair(Color(0xFF34455A), Color(0xFF63778D))
    group == "storm" -> Pair(Color(0xFF2A2D44), Color(0xFF55506E))
    group == "snow" -> Pair(Color(0xFF8CA2B9), Color(0xFFDCE5EE))
    group == "fog" -> Pair(Color(0xFF7A858F), Color(0xFFB9C1C8))
    else -> Pair(Color(0xFF55697E), Color(0xFF9AAABA))
}

// ---------- Home screen ----------

@Composable
fun HomeScreen(
    permissionTick: Int,
    resumeTick: Int,
    onAskLocation: () -> Unit
) {
    val context = LocalContext.current
    val pm = context.packageManager

    var showApps by remember { mutableStateOf(false) }
    var showNet by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showForecast by remember { mutableStateOf(false) }
    var showClock by remember { mutableStateOf(false) }
    var showPicker by remember { mutableStateOf(false) }
    var showUpdate by remember { mutableStateOf(false) }
    var backToSettings by remember { mutableStateOf(false) }
    var menuPkg by remember { mutableStateOf<String?>(null) }

    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var weather by remember { mutableStateOf<Weather?>(null) }
    var net by remember { mutableStateOf(NetworkReader.read(context)) }

    var themeIdx by remember { mutableIntStateOf(Prefs.themeIndex(context)) }
    var intervalMin by remember { mutableIntStateOf(Prefs.intervalMin(context)) }
    var cats by remember { mutableIntStateOf(Prefs.categories(context)) }
    var anim by remember { mutableIntStateOf(Prefs.anim(context)) }
    var clockCfg by remember { mutableStateOf(Prefs.clock(context)) }
    var tilesPref by remember { mutableStateOf(Prefs.tiles(context)) }
    var testBuilds by remember { mutableStateOf(Prefs.testBuilds(context)) }
    var tileIdx by remember { mutableIntStateOf(Prefs.tileSize(context)) }
    var recentCount by remember { mutableIntStateOf(Prefs.recentCount(context)) }
    var recents by remember { mutableStateOf(Recent.list(context)) }
    val firstTile = remember { FocusRequester() }
    val playFocus = remember { FocusRequester() }

    var media by remember { mutableStateOf<MediaInfo?>(null) }
    var mediaArt by remember { mutableStateOf<ImageBitmap?>(null) }
    var mediaKey by remember { mutableStateOf("") }
    var mediaAccess by remember { mutableStateOf(false) }

    // Apps shown on the home row (saved order, only the ones that are installed)
    val tiles: List<String> = remember(resumeTick, tilesPref) {
        val base = tilesPref ?: Config.tiles.mapNotNull { Apps.firstInstalled(pm, it.packages) }
        base.filter { Apps.launchIntent(pm, it) != null }.distinct()
    }

    val saveTiles = { list: List<String> ->
        tilesPref = list
        Prefs.setTiles(context, list)
    }

    // Closes a sub-panel; returns to Settings when it was opened from there
    val closeSub: () -> Unit = {
        showForecast = false
        showClock = false
        showPicker = false
        showUpdate = false
        if (backToSettings) {
            backToSettings = false
            showSettings = true
        }
    }

    val overlayOpen = showApps || showSettings || showForecast || showClock ||
        showPicker || showUpdate || menuPkg != null

    // A launcher should never "go back" to anything; Back only closes open panels.
    BackHandler {
        if (menuPkg != null) {
            menuPkg = null
        } else if (showForecast || showClock || showPicker || showUpdate) {
            closeSub()
        } else {
            showSettings = false
            showApps = false
        }
    }

    LaunchedEffect(Unit) {
        while (isActive) {
            now = LocalDateTime.now()
            delay(15_000L)
        }
    }

    LaunchedEffect(Unit) {
        while (isActive) {
            val w = withContext(Dispatchers.IO) { WeatherApi.fetch() }
            if (w != null) weather = w
            delay(if (w != null) Config.WEATHER_REFRESH_MS else 60_000L)
        }
    }

    LaunchedEffect(permissionTick, resumeTick) {
        while (isActive) {
            net = withContext(Dispatchers.IO) { NetworkReader.read(context) }
            delay(4000L)
        }
    }

    // What is playing (needs notification access, see Settings)
    LaunchedEffect(resumeTick) {
        while (isActive) {
            val access = withContext(Dispatchers.IO) { NowPlaying.hasAccess(context) }
            mediaAccess = access
            val m = if (access) withContext(Dispatchers.IO) { NowPlaying.read(context) } else null
            val k = if (m == null) "" else m.pkg + "|" + m.title + "|" + m.artist + "|" + m.playing + "|" + (m.art != null)
            if (k != mediaKey) {
                mediaKey = k
                media = m
                mediaArt = m?.art?.asImageBitmap()
                if (m != null && m.playing && m.title.isNotBlank()) {
                    recents = withContext(Dispatchers.IO) {
                        Recent.add(context, m.pkg, m.title, m.artist, m.art)
                        Recent.list(context)
                    }
                }
            }
            delay(2000L)
        }
    }

    val theme = Themes[themeIdx.coerceIn(0, Themes.size - 1)]

    // London wallpapers follow the time of day and the weather
    val tod = timeOfDay(now.hour * 60 + now.minute, weather)
    val group = weather?.group ?: "cloud"
    val wallKey = if ((cats and CAT_LONDON) != 0) cats.toString() + "|" + tod + "|" + group else cats.toString()

    CompositionLocalProvider(LocalAccent provides theme.accent) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Ink)
        ) {
            // Accent glow, visible until the first wallpaper loads
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            listOf(theme.accent.copy(alpha = 0.28f), Color.Transparent)
                        )
                    )
            )

            // Online wallpaper (slow zoom when animations are on)
            RotatingImage(
                modifier = Modifier.fillMaxSize(),
                maxSide = 2200,
                intervalMs = intervalMin * 60_000L,
                key = wallKey,
                kenBurns = anim == 0,
                minSide = 1400
            ) {
                Remote.backgroundUrls(cats, tod, group)
            }

            // Darkening for readability
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0x99060A14), Color(0x40060A14), Color(0xB3060A14))
                        )
                    )
            )

            Column(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 40.dp, vertical = 24.dp)
                    .focusProperties { canFocus = !overlayOpen }
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Entrance(0, anim) {
                        ClockBlock(clockCfg, weather) { showClock = true }
                    }

                    Spacer(Modifier.weight(1f))

                    Entrance(120, anim) {
                        WeatherPanel(weather, anim) { showForecast = true }
                    }

                    Spacer(Modifier.width(16.dp))

                    Entrance(240, anim) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            WifiButton(net) { showNet = true }
                            SettingsButton { showSettings = true }
                        }
                    }
                }

                Spacer(Modifier.weight(1f))

                // "Now playing" card, only while something is playing or paused
                AnimatedVisibility(
                    visible = media != null,
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    enter = fadeIn(tween(300)) + slideInVertically(initialOffsetY = { it / 2 }),
                    exit = fadeOut(tween(200)) + slideOutVertically(targetOffsetY = { it / 2 })
                ) {
                    val mi = media
                    if (mi != null) {
                        Column {
                            NowPlayingCard(mi, mediaArt, playFocus, firstTile) { action ->
                                NowPlaying.control(context, mi.pkg, action)
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }

                Entrance(360, anim, Modifier.fillMaxWidth()) {
                    AppRow(
                        tiles = tiles,
                        recents = recents.take(recentCount),
                        tileDp = TILE_SIZES[tileIdx.coerceIn(0, TILE_SIZES.size - 1)],
                        overlayOpen = overlayOpen,
                        anim = anim,
                        firstTile = firstTile,
                        upTarget = if (media != null) playFocus else null,
                        onAllApps = { showApps = true },
                        onMenu = { pkg -> menuPkg = pkg }
                    )
                }

            }

            AnimatedVisibility(
                visible = showApps,
                enter = panelEnter(anim),
                exit = panelExit(anim)
            ) {
                AllApps(
                    resumeTick = resumeTick,
                    tiles = tiles,
                    onMenu = { pkg -> menuPkg = pkg },
                    onClose = { showApps = false }
                )
            }

            AnimatedVisibility(
                visible = showSettings,
                enter = panelEnter(anim),
                exit = panelExit(anim)
            ) {
                SettingsScreen(
                    themeIdx = themeIdx,
                    intervalMin = intervalMin,
                    cats = cats,
                    anim = anim,
                    tileSize = tileIdx,
                    recentCount = recentCount,
                    mediaAccess = mediaAccess,
                    onTheme = { i ->
                        themeIdx = i
                        Prefs.setThemeIndex(context, i)
                    },
                    onInterval = { m ->
                        val v = m.coerceIn(5, 60)
                        intervalMin = v
                        Prefs.setIntervalMin(context, v)
                    },
                    onCats = { c ->
                        if (c != 0) {
                            cats = c
                            Prefs.setCategories(context, c)
                        }
                    },
                    onAnim = { v ->
                        anim = v
                        Prefs.setAnim(context, v)
                    },
                    onTileSize = { v ->
                        tileIdx = v
                        Prefs.setTileSize(context, v)
                    },
                    onRecentCount = { v ->
                        recentCount = v
                        Prefs.setRecentCount(context, v)
                    },
                    onClearRecent = {
                        Recent.clear(context)
                        recents = emptyList()
                    },
                    onOpenClock = {
                        showSettings = false
                        backToSettings = true
                        showClock = true
                    },
                    onOpenPicker = {
                        showSettings = false
                        backToSettings = true
                        showPicker = true
                    },
                    onOpenUpdate = {
                        showSettings = false
                        backToSettings = true
                        showUpdate = true
                    },
                    onGrantMedia = { openNotificationAccess(context) },
                    onSystemSettings = { openSystemSettings(context) },
                    onClose = { showSettings = false }
                )
            }

            AnimatedVisibility(
                visible = showForecast,
                enter = panelEnter(anim),
                exit = panelExit(anim)
            ) {
                ForecastPanel(weather, anim) { closeSub() }
            }

            AnimatedVisibility(
                visible = showClock,
                enter = panelEnter(anim),
                exit = panelExit(anim)
            ) {
                ClockPanel(
                    cfg = clockCfg,
                    onChange = { c ->
                        clockCfg = c
                        Prefs.setClock(context, c)
                    },
                    onClose = { closeSub() }
                )
            }

            AnimatedVisibility(
                visible = showPicker,
                enter = panelEnter(anim),
                exit = panelExit(anim)
            ) {
                TilePicker(
                    tiles = tiles,
                    resumeTick = resumeTick,
                    onToggle = { pkg ->
                        if (tiles.contains(pkg)) saveTiles(tiles.filter { it != pkg })
                        else saveTiles(tiles + pkg)
                    },
                    onClose = { closeSub() }
                )
            }

            AnimatedVisibility(
                visible = showUpdate,
                enter = panelEnter(anim),
                exit = panelExit(anim)
            ) {
                UpdatePanel(
                    testBuilds = testBuilds,
                    onTestBuilds = { v ->
                        testBuilds = v
                        Prefs.setTestBuilds(context, v)
                    },
                    onClose = { closeSub() }
                )
            }

            val mp = menuPkg
            if (mp != null) {
                val idx = tiles.indexOf(mp)
                AppMenu(
                    pkg = mp,
                    onHome = idx >= 0,
                    canLeft = idx > 0,
                    canRight = idx >= 0 && idx < tiles.size - 1,
                    onOpen = {
                        menuPkg = null
                        Apps.launch(context, mp)
                    },
                    onInfo = {
                        menuPkg = null
                        openAppInfo(context, mp)
                    },
                    onUninstall = {
                        menuPkg = null
                        uninstallApp(context, mp)
                    },
                    onLeft = {
                        val l = tiles.toMutableList()
                        java.util.Collections.swap(l, idx, idx - 1)
                        saveTiles(l)
                    },
                    onRight = {
                        val l = tiles.toMutableList()
                        java.util.Collections.swap(l, idx, idx + 1)
                        saveTiles(l)
                    },
                    onToggleHome = {
                        menuPkg = null
                        if (idx >= 0) saveTiles(tiles.filter { it != mp }) else saveTiles(tiles + mp)
                    },
                    onClose = { menuPkg = null }
                )
            }

            if (showNet) {
                NetDialog(
                    net = net,
                    onClose = { showNet = false },
                    onAskLocation = onAskLocation,
                    onSettings = { openWifiSettings(context) }
                )
            }
        }
    }
}

private fun openNotificationAccess(context: Context) {
    try {
        context.startActivity(
            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        openSystemSettings(context)
    }
}

private fun openAppInfo(context: Context, pkg: String) {
    try {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        Toast.makeText(context, "Could not open app info", Toast.LENGTH_SHORT).show()
    }
}

private fun uninstallApp(context: Context, pkg: String) {
    try {
        context.startActivity(
            Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        Toast.makeText(context, "Could not start uninstall", Toast.LENGTH_SHORT).show()
    }
}

private fun openSystemSettings(context: Context) {
    try {
        context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        // nothing else to try
    }
}

private fun openWifiSettings(context: Context) {
    try {
        context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        openSystemSettings(context)
    }
}

@Composable
private fun GridOverlay() {
    Canvas(Modifier.fillMaxSize()) {
        val step = 56.dp.toPx()
        val c = Color(0x0EFFFFFF)
        var x = 0f
        while (x < size.width) {
            drawLine(c, Offset(x, 0f), Offset(x, size.height), 1f)
            x += step
        }
        var y = 0f
        while (y < size.height) {
            drawLine(c, Offset(0f, y), Offset(size.width, y), 1f)
            y += step
        }
    }
}

// Cross-fading slideshow of remote images. Restarts whenever `key` or the interval changes.
@Composable
private fun RotatingImage(
    modifier: Modifier,
    maxSide: Int,
    intervalMs: Long,
    key: Any,
    kenBurns: Boolean = false,
    minSide: Int = 0,
    fetchUrls: () -> List<String>
) {
    val context = LocalContext.current
    var bitmap by remember { mutableStateOf<ImageBitmap?>(null) }

    // Very slow zoom in and out (read in the graphics layer, so it never recomposes)
    val zoom: State<Float>? = if (kenBurns) {
        rememberInfiniteTransition(label = "zoom").animateFloat(
            initialValue = 1f,
            targetValue = 1.08f,
            animationSpec = infiniteRepeatable(
                animation = tween(40000, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "zoomValue"
        )
    } else {
        null
    }

    LaunchedEffect(key, intervalMs) {
        var urls: List<String> = emptyList()
        var index = 0
        while (isActive) {
            if (urls.isEmpty()) {
                urls = withContext(Dispatchers.IO) { fetchUrls() }
                index = 0
                if (urls.isEmpty()) {
                    delay(60_000L)
                    continue
                }
            }
            val url = urls[index]
            val bmp = withContext(Dispatchers.IO) { Remote.loadBitmap(context, url, maxSide, minSide) }
            if (bmp != null) {
                bitmap = bmp.asImageBitmap()
                delay(intervalMs)
            } else {
                delay(2000L)
            }
            index++
            if (index >= urls.size) {
                urls = emptyList()
            }
        }
    }

    Crossfade(
        targetState = bitmap,
        modifier = modifier,
        animationSpec = tween(1500),
        label = "remoteImage"
    ) { bmp ->
        if (bmp != null) {
            Image(
                bitmap = bmp,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val z = zoom?.value ?: 1f
                        scaleX = z
                        scaleY = z
                    }
            )
        } else {
            Box(Modifier.fillMaxSize())
        }
    }
}

// ---------- Top bar pieces ----------

@Composable
private fun ClockBlock(cfg: ClockCfg, w: Weather?, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val shape = RoundedCornerShape(18.dp)

    // The clock ticks on its own, so the rest of the home screen is not redrawn every second
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (isActive) {
            now = LocalDateTime.now()
            delay(1000L)
        }
    }

    val sizeSp = when (cfg.size) {
        0 -> 36
        1 -> 52
        else -> 72
    }
    val alphaValue = when (cfg.alpha) {
        0 -> 0.45f
        1 -> 0.65f
        2 -> 0.85f
        else -> 1f
    }
    val family = when (cfg.style) {
        2 -> FontFamily.Monospace
        3 -> FontFamily.Serif
        else -> FontFamily.SansSerif
    }
    val weight = when (cfg.style) {
        0 -> FontWeight.Thin
        1 -> FontWeight.Bold
        2 -> FontWeight.Normal
        3 -> FontWeight.Medium
        else -> FontWeight.Black
    }
    val textColor = (if (cfg.accentColor) accent else TextHi).copy(alpha = alphaValue)
    val shadowStyle = TextStyle(
        shadow = Shadow(color = Color(0xCC000000), offset = Offset(0f, 2f), blurRadius = 10f)
    )

    val timeText = if (cfg.h24) now.format(timeFmt) else now.format(time12Fmt)
    val secText = if (cfg.seconds) ":" + now.second.toString().padStart(2, '0') else ""
    val ampm = if (cfg.h24) "" else (if (now.hour < 12) " AM" else " PM")
    val small = secText + ampm

    // Lines under the clock
    val dateLine = if ((cfg.info and INFO_DATE) != 0) now.format(dateFmt) else ""
    val extras = ArrayList<String>()
    if (w != null) {
        if ((cfg.info and INFO_DAYLEN) != 0) {
            val m = w.sunsetMin - w.sunriseMin
            extras.add("Daylight " + (m / 60) + "h " + (m % 60) + "m")
        }
        if ((cfg.info and INFO_TOMORROW) != 0 && w.days.size > 1) {
            val d = w.days[1]
            extras.add("Tomorrow " + d.high + "° / " + d.low + "°")
        }
    }
    if ((cfg.info and INFO_MOON) != 0) {
        val mp = moonPhase(LocalDate.now())
        extras.add(mp.first + " " + mp.second)
    }
    val infoSp = when (cfg.size) {
        0 -> 12
        1 -> 14
        else -> 16
    }

    Column(
        Modifier
            .then(
                if (cfg.box == 1) Modifier.glass(shape)
                else if (cfg.box == 2) Modifier
                    .clip(shape)
                    .background(Color(0xCC0A1020))
                    .border(1.dp, Color(0x33FFFFFF), shape)
                else Modifier
            )
            .then(if (focused) Modifier.border(2.dp, accent, shape) else Modifier)
            .tvClickable(source, null, onClick)
            .padding(
                if (cfg.box == 0) PaddingValues(start = 6.dp, top = 6.dp, end = 10.dp, bottom = 6.dp)
                else PaddingValues(horizontal = 18.dp, vertical = 12.dp)
            )
    ) {
        if (cfg.style >= 5) {
            // Drawn digits: LED segments, neon tubes or a dot matrix
            Row(verticalAlignment = Alignment.Bottom) {
                DrawnClock(timeText, cfg.style, (sizeSp * 0.95f).dp, textColor)
                if (secText.isNotEmpty()) {
                    Spacer(Modifier.width(8.dp))
                    DrawnClock(secText, cfg.style, (sizeSp * 0.4f).dp, textColor.copy(alpha = alphaValue * 0.8f))
                }
                if (ampm.isNotEmpty()) {
                    Text(
                        text = ampm,
                        color = textColor,
                        fontSize = (sizeSp * 0.3f).sp,
                        fontFamily = RoundedFont,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }
            }
        } else {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = timeText,
                    color = textColor,
                    fontSize = sizeSp.sp,
                    fontWeight = weight,
                    fontFamily = family,
                    letterSpacing = 2.sp,
                    style = shadowStyle
                )
                if (small.isNotEmpty()) {
                    Text(
                        text = small,
                        color = textColor.copy(alpha = alphaValue * 0.8f),
                        fontSize = (sizeSp * 0.4f).sp,
                        fontWeight = weight,
                        fontFamily = family,
                        style = shadowStyle,
                        modifier = Modifier.padding(start = 6.dp, bottom = (sizeSp * 0.1f).dp)
                    )
                }
            }
        }
        if (dateLine.isNotEmpty()) {
            Text(
                text = dateLine,
                color = TextHi.copy(alpha = alphaValue * 0.9f),
                fontSize = infoSp.sp,
                fontFamily = RoundedFont,
                fontWeight = FontWeight.Medium,
                style = shadowStyle,
                modifier = Modifier.padding(start = 2.dp, top = 2.dp)
            )
        }
        if (w != null && (cfg.info and INFO_SUN) != 0) {
            Row(
                Modifier.padding(start = 2.dp, top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                SunEvent(true, formatMinutes(w.sunriseMin), TextHi.copy(alpha = alphaValue), infoSp)
                SunEvent(false, formatMinutes(w.sunsetMin), TextHi.copy(alpha = alphaValue), infoSp)
            }
        }
        if (extras.isNotEmpty()) {
            Text(
                text = extras.joinToString("   ·   "),
                color = TextHi.copy(alpha = alphaValue * 0.75f),
                fontSize = (infoSp - 1).sp,
                fontFamily = RoundedFont,
                style = shadowStyle,
                modifier = Modifier.padding(start = 2.dp, top = 4.dp)
            )
        }
    }
}

@Composable
private fun WeatherPanel(w: Weather?, anim: Int, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val shape = RoundedCornerShape(20.dp)
    val isDay = w?.isDay ?: true
    val group = w?.group ?: "cloud"
    val sky = skyColors(isDay, group)

    Box(
        Modifier
            .width(360.dp)
            .height(136.dp)
            .clip(shape)
            .background(PanelDark)
            .border(1.dp, glassBorder, shape)
            .then(if (focused) Modifier.border(2.dp, accent, shape) else Modifier)
            .tvClickable(source, null, onClick)
    ) {
        // Sky colours that match the weather and time of day
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(sky.first, sky.second)))
        )

        // Animated sky details (stars, sun glow, drifting clouds) in case no photo loads
        WeatherBackdrop(group, isDay, anim)

        // London photo matching the weather and time of day, changes every 30 minutes
        if (w != null) {
            RotatingImage(
                modifier = Modifier.fillMaxSize(),
                maxSide = 1400,
                intervalMs = Config.WEATHER_PHOTO_INTERVAL_MS,
                key = (if (isDay) "d" else "n") + group,
                minSide = 900
            ) {
                Remote.weatherPhotoUrls(isDay, group)
            }
        }

        // Dark-to-clear scrim so the text on the left stays readable
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xE60A1020), Color(0x990A1020), Color(0x1A0A1020))
                    )
                )
        )

        // Drawn weather artwork (sun, moon, clouds, rain, snow, lightning, fog)
        if (w != null) {
            WeatherArt(
                code = w.code,
                isDay = w.isDay,
                anim = anim,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 12.dp)
                    .size(108.dp)
            )
        }

        Column(
            Modifier
                .align(Alignment.CenterStart)
                .padding(horizontal = 20.dp)
        ) {
            if (w == null) {
                Text(
                    text = "SYNCING...",
                    color = TextLo,
                    fontSize = 14.sp,
                    fontFamily = RoundedFont
                )
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = w.temp.toString() + "°",
                        color = TextHi,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont,
                        style = glow(accent, 18f)
                    )
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(
                            text = Config.CITY,
                            color = TextHi,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = RoundedFont
                        )
                        Text(
                            text = w.label.uppercase(),
                            color = accent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = RoundedFont,
                            letterSpacing = 1.sp
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "H " + w.high + "°  L " + w.low + "°  ·  " + w.windMph + " MPH  ·  " + w.humidity + "%",
                    color = TextLo,
                    fontSize = 11.sp,
                    fontFamily = RoundedFont
                )
            }
        }
    }
}

@Composable
private fun WifiButton(net: NetInfo, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val active = if (net.level < 0) 0 else net.level.coerceAtLeast(1)
    Box(
        Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(if (focused) glassFillFocused else glassFill)
            .border(
                if (focused) 2.dp else 1.dp,
                if (focused) accent else Color(0x44FFFFFF),
                CircleShape
            )
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(24.dp)) {
            val barW = size.width / 7f
            for (i in 0 until 4) {
                val h = size.height * (0.3f + 0.7f * (i + 1) / 4f)
                drawRoundRect(
                    color = if (i < active) accent else Color(0x44FFFFFF),
                    topLeft = Offset(i * barW * 2f, size.height - h),
                    size = Size(barW, h),
                    cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                )
            }
        }
    }
}

@Composable
private fun SettingsButton(onClick: () -> Unit) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    Box(
        Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(if (focused) glassFillFocused else glassFill)
            .border(
                if (focused) 2.dp else 1.dp,
                if (focused) accent else Color(0x44FFFFFF),
                CircleShape
            )
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "⚙",
            color = if (focused) accent else TextHi,
            fontSize = 22.sp
        )
    }
}

// ---------- App tiles ----------

@Composable
private fun AppRow(
    tiles: List<String>,
    recents: List<RecentItem>,
    tileDp: Int,
    overlayOpen: Boolean,
    anim: Int,
    firstTile: FocusRequester,
    upTarget: FocusRequester?,
    onAllApps: () -> Unit,
    onMenu: (String) -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val pm = context.packageManager

    // Focus the first tile at start and again whenever a panel closes
    LaunchedEffect(overlayOpen) {
        if (!overlayOpen) {
            delay(300L)
            runCatching { firstTile.requestFocus() }
        }
    }

    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 14.dp)
    ) {
        itemsIndexed(tiles, key = { _, pkg -> pkg }) { index, pkg ->
            var icon by remember(pkg) { mutableStateOf<ImageBitmap?>(null) }
            LaunchedEffect(pkg) {
                icon = withContext(Dispatchers.IO) { Apps.icon(pm, pkg) }
            }
            AppTile(
                label = Apps.label(pm, pkg),
                accent = accent,
                icon = icon,
                modifier = Modifier.width(tileDp.dp),
                anim = anim,
                labelSp = tileDp / 9,
                upTarget = upTarget,
                focusRequester = if (index == 0) firstTile else null,
                onLongClick = { onMenu(pkg) }
            ) {
                Apps.launch(context, pkg)
            }
        }
        // What you last played or watched
        itemsIndexed(recents, key = { _, r -> "recent-" + r.id }) { _, r ->
            var art by remember(r.id) { mutableStateOf<ImageBitmap?>(null) }
            LaunchedEffect(r.id) {
                art = withContext(Dispatchers.IO) { Recent.art(context, r) ?: Apps.icon(pm, r.pkg) }
            }
            AppTile(
                label = r.title,
                accent = accent,
                icon = art,
                modifier = Modifier.width(tileDp.dp),
                anim = anim,
                labelSp = tileDp / 9,
                upTarget = upTarget
            ) {
                Recent.open(context, r)
            }
        }
        item {
            AppTile(
                label = "All apps",
                accent = accent,
                icon = null,
                modifier = Modifier.width(tileDp.dp),
                glyph = "☰",
                anim = anim,
                labelSp = tileDp / 9,
                upTarget = upTarget,
                focusRequester = if (tiles.isEmpty()) firstTile else null
            ) { onAllApps() }
        }
    }
}

@Composable
private fun AppTile(
    label: String,
    accent: Color,
    icon: ImageBitmap?,
    modifier: Modifier = Modifier,
    glyph: String? = null,
    installed: Boolean = true,
    badge: String? = null,
    anim: Int = 2,
    focusRequester: FocusRequester? = null,
    onLongClick: (() -> Unit)? = null,
    onFocused: (() -> Unit)? = null,
    labelSp: Int = 10,
    upTarget: FocusRequester? = null,
    onDpad: ((Int) -> Boolean)? = null,
    onClick: () -> Unit
) {
    val themeAccent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.12f else 1f,
        animationSpec = if (anim == 2) tween(0) else spring(dampingRatio = 0.55f, stiffness = 380f),
        label = "tileScale"
    )

    LaunchedEffect(focused) {
        if (focused) onFocused?.invoke()
    }

    // A light sweep that runs across the focused tile
    val sweep: Float = if (focused && anim == 0) {
        val t = rememberInfiniteTransition(label = "shine")
        val v by t.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(1800, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "shineX"
        )
        v
    } else {
        0f
    }

    val shape = RoundedCornerShape(16.dp)

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .scale(scale)
            .alpha(if (installed) 1f else 0.45f)
            .clip(shape)
            .background(if (focused) glassFillFocused else glassFill)
            .border(
                if (focused) 2.dp else 1.dp,
                if (focused) themeAccent else Color(0x44FFFFFF),
                shape
            )
            .then(if (upTarget != null) Modifier.focusProperties { up = upTarget } else Modifier)
            .then(
                if (onDpad != null) Modifier.onPreviewKeyEvent { ev ->
                    if (ev.type == KeyEventType.KeyDown) onDpad(ev.nativeKeyEvent.keyCode) else false
                } else Modifier
            )
            .then(
                if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier
            )
            .tvClickable(source, onLongClick, onClick)
            .drawWithContent {
                drawContent()
                if (focused && anim == 0) {
                    val w = size.width
                    val x = -0.4f * w + sweep * 1.8f * w
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(Color.Transparent, Color(0x40FFFFFF), Color.Transparent),
                            start = Offset(x, 0f),
                            end = Offset(x + 0.4f * w, size.height * 0.5f)
                        )
                    )
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(6.dp)
        ) {
            if (icon != null) {
                Image(
                    bitmap = icon,
                    contentDescription = label,
                    modifier = Modifier
                        .fillMaxWidth(0.66f)
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(14.dp))
                )
            } else {
                Box(
                    Modifier
                        .fillMaxWidth(0.66f)
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(accent.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = glyph ?: label.take(1).uppercase(),
                        color = accent,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = label,
                color = TextHi,
                fontSize = labelSp.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (badge != null) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(5.dp)
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(themeAccent),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = badge,
                    color = Ink,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ---------- All apps overlay ----------

@Composable
private fun AllApps(
    resumeTick: Int,
    tiles: List<String>,
    onMenu: (String) -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val pm = context.packageManager
    val apps = remember(resumeTick) { Apps.installed(context) }
    val requesters = remember(apps) { List(apps.size) { FocusRequester() } }
    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(apps) {
        delay(250L)
        runCatching { requesters.firstOrNull()?.requestFocus() }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF2060A14))
            .padding(horizontal = 40.dp, vertical = 28.dp)
    ) {
        Column {
            Text(
                text = "ALL APPS   ·   hold OK on an app for more",
                color = accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 2.sp
            )
            Spacer(Modifier.height(16.dp))
            LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Adaptive(104.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(8.dp)
            ) {
                itemsIndexed(apps) { index, app ->
                    var icon by remember(app.pkg) { mutableStateOf<ImageBitmap?>(null) }
                    LaunchedEffect(app.pkg) {
                        icon = withContext(Dispatchers.IO) { Apps.icon(pm, app.pkg) }
                    }
                    AppTile(
                        label = app.label,
                        accent = accent,
                        icon = icon,
                        modifier = Modifier.fillMaxWidth(),
                        badge = if (tiles.contains(app.pkg)) "✓" else null,
                        focusRequester = requesters[index],
                        onFocused = { scope.launch { revealGridItem(gridState, index) } },
                        onDpad = { code -> gridKey(code, scope, gridState, requesters, index) },
                        onLongClick = { onMenu(app.pkg) }
                    ) {
                        Apps.launch(context, app.pkg)
                        onClose()
                    }
                }
            }
        }
    }
}

// ---------- Launcher settings ----------

@Composable
private fun SettingsScreen(
    themeIdx: Int,
    intervalMin: Int,
    cats: Int,
    anim: Int,
    tileSize: Int,
    recentCount: Int,
    mediaAccess: Boolean,
    onTheme: (Int) -> Unit,
    onInterval: (Int) -> Unit,
    onCats: (Int) -> Unit,
    onAnim: (Int) -> Unit,
    onTileSize: (Int) -> Unit,
    onRecentCount: (Int) -> Unit,
    onClearRecent: () -> Unit,
    onOpenClock: () -> Unit,
    onOpenPicker: () -> Unit,
    onOpenUpdate: () -> Unit,
    onGrantMedia: () -> Unit,
    onSystemSettings: () -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    val first = remember { FocusRequester() }
    var status by remember { mutableStateOf(Remote.status) }

    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { first.requestFocus() }
    }
    LaunchedEffect(Unit) {
        while (isActive) {
            status = Remote.status
            delay(2000L)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF5060A14))
            .padding(horizontal = 40.dp, vertical = 24.dp)
    ) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Text(
                text = "SONIK LAUNCHER  ·  SETTINGS  ·  v" + Config.VERSION,
                color = accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 3.sp
            )

            Spacer(Modifier.height(16.dp))
            SectionLabel("COLOR THEME")
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Themes.forEachIndexed { i, t ->
                    ThemeSwatch(
                        theme = t,
                        selected = i == themeIdx,
                        focusRequester = if (i == themeIdx) first else null
                    ) { onTheme(i) }
                }
            }

            Spacer(Modifier.height(18.dp))
            SectionLabel("ANIMATIONS")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ChipButton("Full", anim == 0) { onAnim(0) }
                ChipButton("Reduced", anim == 1) { onAnim(1) }
                ChipButton("Off", anim == 2) { onAnim(2) }
            }

            Spacer(Modifier.height(18.dp))
            SectionLabel("HOME SCREEN")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ChipButton("Choose home apps...", false) { onOpenPicker() }
                ChipButton("Clock style...", false) { onOpenClock() }
            }

            Spacer(Modifier.height(18.dp))
            SectionLabel("TILE SIZE")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf("Small", "Medium", "Large", "Extra large").forEachIndexed { i, name ->
                    ChipButton(name, tileSize == i) { onTileSize(i) }
                }
            }

            Spacer(Modifier.height(18.dp))
            SectionLabel("RECENT TILES (WHAT YOU LAST PLAYED OR WATCHED)")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf(0, 2, 4, 6).forEach { n ->
                    ChipButton(if (n == 0) "Off" else n.toString(), recentCount == n) { onRecentCount(n) }
                }
                ChipButton("Clear history", false) { onClearRecent() }
            }
            Text(
                text = "Needs the playback card access below. Tap one to reopen the app; it resumes if it is still the active player.",
                color = TextLo,
                fontSize = 10.sp,
                fontFamily = RoundedFont,
                modifier = Modifier.padding(top = 6.dp)
            )

            Spacer(Modifier.height(18.dp))
            SectionLabel("WALLPAPER CHANGES EVERY")
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                ChipButton("-", false) { onInterval(intervalMin - 5) }
                Text(
                    text = intervalMin.toString() + " min",
                    color = TextHi,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RoundedFont
                )
                ChipButton("+", false) { onInterval(intervalMin + 5) }
            }

            Spacer(Modifier.height(18.dp))
            SectionLabel("WALLPAPER TYPES")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ChipButton("Space", (cats and CAT_SPACE) != 0) { onCats(cats xor CAT_SPACE) }
                ChipButton("Nature", (cats and CAT_NATURE) != 0) { onCats(cats xor CAT_NATURE) }
                ChipButton("City", (cats and CAT_CITY) != 0) { onCats(cats xor CAT_CITY) }
                ChipButton("Animals", (cats and CAT_ANIMALS) != 0) { onCats(cats xor CAT_ANIMALS) }
                ChipButton("Art", (cats and CAT_ART) != 0) { onCats(cats xor CAT_ART) }
                ChipButton("London (time of day)", (cats and CAT_LONDON) != 0) { onCats(cats xor CAT_LONDON) }
            }

            Spacer(Modifier.height(18.dp))
            SectionLabel("PLAYBACK CARD (DEEZER, YOUTUBE MUSIC, TIDAL...)")
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = if (mediaAccess) "Notification access: ON" else "Notification access: needed",
                    color = if (mediaAccess) accent else TextLo,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RoundedFont
                )
                if (!mediaAccess) {
                    ChipButton("Grant access", false) { onGrantMedia() }
                }
            }
            if (!mediaAccess) {
                Text(
                    text = "If the button does nothing, run on a computer: adb shell cmd notification allow_listener com.streamerhome.launcher/com.streamerhome.launcher.MediaListenerService",
                    color = TextLo,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            Spacer(Modifier.height(18.dp))
            SectionLabel("UPDATES (ONLY WHEN YOU ASK)")
            ChipButton("Check for updates...", false) { onOpenUpdate() }

            Spacer(Modifier.height(18.dp))
            SectionLabel("ONLINE IMAGE STATUS")
            Text(
                text = status,
                color = TextLo,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )

            Spacer(Modifier.height(18.dp))
            SectionLabel("ABOUT")
            Row(verticalAlignment = Alignment.CenterVertically) {
                SonicLogo(Modifier.size(72.dp))
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(
                        text = "Sonik Launcher",
                        color = TextHi,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont
                    )
                    Text(
                        text = "Version " + Config.VERSION,
                        color = accent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont
                    )
                    Text(
                        text = "An ad-free home screen for Google TV with live weather, wallpapers, a playback card and your own apps.",
                        color = TextLo,
                        fontSize = 12.sp,
                        fontFamily = RoundedFont,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                    Text(
                        text = "Created by Claudiu   ·   ravebot@gmail.com",
                        color = TextHi,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = RoundedFont,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
            Text(
                text = "Pictures and data: Open-Meteo (weather), NASA APOD, Bing and Wikimedia Commons.",
                color = TextLo,
                fontSize = 10.sp,
                fontFamily = RoundedFont,
                modifier = Modifier.padding(top = 8.dp)
            )

            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                ChipButton("System settings", false) { onSystemSettings() }
                ChipButton("Close", true) { onClose() }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        color = TextLo,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = RoundedFont,
        letterSpacing = 2.sp,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun ThemeSwatch(
    theme: ThemeSpec,
    selected: Boolean,
    focusRequester: FocusRequester?,
    onClick: () -> Unit
) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(44.dp)
                .scale(if (focused) 1.15f else 1f)
                .then(
                    if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier
                )
                .clip(CircleShape)
                .background(theme.accent)
                .border(
                    3.dp,
                    if (selected) Color.White else if (focused) Color(0xAAFFFFFF) else Color.Transparent,
                    CircleShape
                )
                .focusable(interactionSource = source)
                .clickable(interactionSource = source, indication = null, onClick = onClick)
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = theme.name,
            color = if (selected) TextHi else TextLo,
            fontSize = 11.sp,
            fontFamily = RoundedFont
        )
    }
}

@Composable
private fun ChipButton(
    text: String,
    selected: Boolean,
    focusRequester: FocusRequester? = null,
    compact: Boolean = false,
    wide: Boolean = false,
    onClick: () -> Unit
) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val shape = RoundedCornerShape(12.dp)
    val bg = if (focused) accent else if (selected) accent.copy(alpha = 0.35f) else Color(0xFF18223A)
    Box(
        (if (wide) Modifier.fillMaxWidth() else Modifier)
            .clip(shape)
            .background(bg)
            .border(1.dp, if (focused || selected) accent else Color(0x44FFFFFF), shape)
            .then(
                if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier
            )
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = onClick)
            .padding(horizontal = if (compact) 14.dp else 22.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (focused) Ink else TextHi,
            fontSize = if (compact) 14.sp else 15.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RoundedFont
        )
    }
}

// ---------- Network dialog ----------

@Composable
private fun NetDialog(
    net: NetInfo,
    onClose: () -> Unit,
    onAskLocation: () -> Unit,
    onSettings: () -> Unit
) {
    val accent = LocalAccent.current
    val closeFocus = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { closeFocus.requestFocus() }
    }

    val shape = RoundedCornerShape(20.dp)

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            Modifier
                .width(500.dp)
                .clip(shape)
                .background(PanelDark)
                .border(1.dp, glassBorder, shape)
                .padding(30.dp)
        ) {
            Text(
                text = "NETWORK",
                color = accent,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 2.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = net.name,
                color = TextHi,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                style = glow(accent, 18f)
            )
            if (net.detail.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = net.detail,
                    color = TextLo,
                    fontSize = 15.sp,
                    fontFamily = RoundedFont
                )
            }
            if (net.needsLocation) {
                Spacer(Modifier.height(14.dp))
                Text(
                    text = "Android only shows the Wi-Fi name after location access is allowed.",
                    color = TextLo,
                    fontSize = 14.sp,
                    fontFamily = RoundedFont
                )
                Spacer(Modifier.height(12.dp))
                ChipButton("Allow access", true) { onAskLocation() }
            }
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                ChipButton("Wi-Fi settings", false) { onSettings() }
                ChipButton("Close", true, closeFocus) { onClose() }
            }
        }
    }
}

// ---------- Rain / snow over the weather photo ----------

@Composable
private fun WeatherFx(group: String) {
    if (group != "rain" && group != "storm" && group != "snow") return
    val snow = group == "snow"
    val t = rememberInfiniteTransition(label = "fx")
    val p by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (snow) 6000 else 1100, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "fxProgress"
    )
    Canvas(Modifier.fillMaxSize()) {
        for (i in 0 until 16) {
            val seed = ((i * 37) % 100) / 100f
            val x = (((i * 53) % 100) / 100f) * size.width
            val y = ((p + seed) % 1f) * (size.height + 20f) - 10f
            if (snow) {
                drawCircle(
                    color = Color(0xCCFFFFFF),
                    radius = 2.2f + (i % 3),
                    center = Offset(x + kotlin.math.sin((p * 6.28f + i).toDouble()).toFloat() * 8f, y)
                )
            } else {
                drawLine(Color(0x88CFE8FF), Offset(x, y), Offset(x - 4f, y + 14f), 1.5f)
            }
        }
    }
}

// ---------- Now playing card ----------

@Composable
private fun NowPlayingCard(
    info: MediaInfo,
    art: ImageBitmap?,
    playFocus: FocusRequester,
    downTarget: FocusRequester,
    onControl: (Int) -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    var appIcon by remember(info.pkg) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(info.pkg) {
        appIcon = withContext(Dispatchers.IO) { Apps.icon(context.packageManager, info.pkg) }
    }
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .width(470.dp)
            .clip(shape)
            .background(glassFill)
            .border(1.dp, glassBorder, shape)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val cover = art ?: appIcon
        Box(
            Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0x33FFFFFF))
        ) {
            if (cover != null) {
                Image(
                    bitmap = cover,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = if (info.playing) "NOW PLAYING" else "PAUSED",
                color = accent,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 2.sp
            )
            Text(
                text = info.title,
                color = TextHi,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = info.artist,
                color = TextLo,
                fontSize = 12.sp,
                fontFamily = RoundedFont,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TransportButton(0, info.playing, null, downTarget) { onControl(0) }
            TransportButton(1, info.playing, playFocus, downTarget) { onControl(1) }
            TransportButton(2, info.playing, null, downTarget) { onControl(2) }
        }
    }
}

// kind: 0 = previous, 1 = play / pause, 2 = next
@Composable
private fun TransportButton(
    kind: Int,
    playing: Boolean,
    focusRequester: FocusRequester?,
    downTarget: FocusRequester?,
    onClick: () -> Unit
) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(if (focused) accent else Color(0x26FFFFFF))
            .then(if (downTarget != null) Modifier.focusProperties { down = downTarget } else Modifier)
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        val c = if (focused) Ink else TextHi
        Canvas(Modifier.size(16.dp)) {
            val w = size.width
            val h = size.height
            if (kind == 0) {
                drawRect(c, Offset(0f, 0f), Size(w * 0.16f, h))
                val tri = Path()
                tri.moveTo(w, 0f)
                tri.lineTo(w * 0.28f, h / 2f)
                tri.lineTo(w, h)
                tri.close()
                drawPath(tri, c)
            } else if (kind == 2) {
                drawRect(c, Offset(w * 0.84f, 0f), Size(w * 0.16f, h))
                val tri = Path()
                tri.moveTo(0f, 0f)
                tri.lineTo(w * 0.72f, h / 2f)
                tri.lineTo(0f, h)
                tri.close()
                drawPath(tri, c)
            } else if (playing) {
                drawRect(c, Offset(w * 0.12f, 0f), Size(w * 0.28f, h))
                drawRect(c, Offset(w * 0.60f, 0f), Size(w * 0.28f, h))
            } else {
                val tri = Path()
                tri.moveTo(w * 0.15f, 0f)
                tri.lineTo(w, h / 2f)
                tri.lineTo(w * 0.15f, h)
                tri.close()
                drawPath(tri, c)
            }
        }
    }
}

// ---------- Forecast (tap the weather card) ----------

@Composable
private fun ForecastPanel(w: Weather?, anim: Int, onClose: () -> Unit) {
    val accent = LocalAccent.current
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { first.requestFocus() }
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF0060A14))
            .padding(horizontal = 40.dp, vertical = 24.dp)
    ) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Text(
                text = "FORECAST  ·  " + Config.CITY.uppercase(),
                color = accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 3.sp
            )
            Spacer(Modifier.height(14.dp))
            if (w == null) {
                Text(
                    text = "No weather data yet. Try again in a moment.",
                    color = TextLo,
                    fontSize = 15.sp,
                    fontFamily = RoundedFont
                )
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = w.temp.toString() + "°",
                        color = TextHi,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont
                    )
                    Spacer(Modifier.width(10.dp))
                    WeatherArt(w.code, w.isDay, anim, Modifier.size(64.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = w.label,
                            color = TextHi,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = RoundedFont
                        )
                        Text(
                            text = "Wind " + w.windMph + " mph   ·   Humidity " + w.humidity + "%",
                            color = TextLo,
                            fontSize = 12.sp,
                            fontFamily = RoundedFont
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                SectionLabel("NEXT HOURS")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    w.hours.forEach { h -> HourCell(h) }
                }
                Spacer(Modifier.height(16.dp))
                SectionLabel("NEXT DAYS")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    w.days.forEach { d -> DayCell(d, Modifier.weight(1f)) }
                }
            }
            Spacer(Modifier.height(18.dp))
            ChipButton("Close", true, first) { onClose() }
        }
    }
}

@Composable
private fun HourCell(h: HourForecast) {
    val accent = LocalAccent.current
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier
            .width(70.dp)
            .clip(shape)
            .background(glassFill)
            .border(1.dp, glassBorder, shape)
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = h.label, color = TextLo, fontSize = 11.sp, fontFamily = RoundedFont)
        WeatherArt(h.code, hourIsDay(h.label), 2, Modifier.size(36.dp))
        Text(
            text = h.temp.toString() + "°",
            color = TextHi,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RoundedFont
        )
        Text(
            text = h.rain.toString() + "%",
            color = if (h.rain >= 40) accent else TextLo,
            fontSize = 10.sp,
            fontFamily = RoundedFont
        )
    }
}

@Composable
private fun DayCell(d: DayForecast, modifier: Modifier) {
    val accent = LocalAccent.current
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier
            .clip(shape)
            .background(glassFill)
            .border(1.dp, glassBorder, shape)
            .padding(vertical = 12.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = d.label,
            color = accent,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RoundedFont,
            letterSpacing = 1.sp
        )
        WeatherArt(d.code, true, 2, Modifier.size(44.dp))
        Text(
            text = d.text,
            color = TextLo,
            fontSize = 10.sp,
            fontFamily = RoundedFont,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = d.high.toString() + "° / " + d.low + "°",
            color = TextHi,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RoundedFont
        )
        Text(
            text = "Rain " + d.rain + "%",
            color = if (d.rain >= 40) accent else TextLo,
            fontSize = 10.sp,
            fontFamily = RoundedFont
        )
    }
}

// ---------- Clock style panel (click the clock) ----------

@Composable
private fun ClockPanel(cfg: ClockCfg, onChange: (ClockCfg) -> Unit, onClose: () -> Unit) {
    val accent = LocalAccent.current
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { first.requestFocus() }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0x66000000))
    ) {
        Column(
            Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .width(520.dp)
                .background(Color(0xF2080C18))
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            Text(
                text = "CLOCK STYLE",
                color = accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 3.sp
            )
            Text(
                text = "Changes show on the clock straight away.",
                color = TextLo,
                fontSize = 11.sp,
                fontFamily = RoundedFont,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(Modifier.height(14.dp))
            SectionLabel("FONT")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Thin", "Bold", "Mono", "Serif", "Black").forEachIndexed { i, name ->
                    ChipButton(name, cfg.style == i, if (i == cfg.style) first else null, compact = true) {
                        onChange(cfg.copy(style = i))
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("LED", "Neon", "Matrix").forEachIndexed { k, name ->
                    val i = 5 + k
                    ChipButton(name, cfg.style == i, if (i == cfg.style) first else null, compact = true) {
                        onChange(cfg.copy(style = i))
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            SectionLabel("SIZE")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Small", "Medium", "Large").forEachIndexed { i, name ->
                    ChipButton(name, cfg.size == i, compact = true) { onChange(cfg.copy(size = i)) }
                }
            }

            Spacer(Modifier.height(14.dp))
            SectionLabel("BACKGROUND BOX")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("None", "Glass", "Solid").forEachIndexed { i, name ->
                    ChipButton(name, cfg.box == i, compact = true) { onChange(cfg.copy(box = i)) }
                }
            }

            Spacer(Modifier.height(14.dp))
            SectionLabel("TEXT OPACITY")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("45%", "65%", "85%", "100%").forEachIndexed { i, name ->
                    ChipButton(name, cfg.alpha == i, compact = true) { onChange(cfg.copy(alpha = i)) }
                }
            }

            Spacer(Modifier.height(14.dp))
            SectionLabel("COLOR")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipButton("White", !cfg.accentColor, compact = true) { onChange(cfg.copy(accentColor = false)) }
                ChipButton("Theme color", cfg.accentColor, compact = true) { onChange(cfg.copy(accentColor = true)) }
            }

            Spacer(Modifier.height(14.dp))
            SectionLabel("FORMAT")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipButton("24-hour", cfg.h24, compact = true) { onChange(cfg.copy(h24 = !cfg.h24)) }
                ChipButton("Seconds", cfg.seconds, compact = true) { onChange(cfg.copy(seconds = !cfg.seconds)) }
            }

            Spacer(Modifier.height(14.dp))
            SectionLabel("SHOW UNDER THE CLOCK")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipButton("Date", (cfg.info and INFO_DATE) != 0, compact = true) {
                    onChange(cfg.copy(info = cfg.info xor INFO_DATE))
                }
                ChipButton("Sunrise & sunset", (cfg.info and INFO_SUN) != 0, compact = true) {
                    onChange(cfg.copy(info = cfg.info xor INFO_SUN))
                }
                ChipButton("Day length", (cfg.info and INFO_DAYLEN) != 0, compact = true) {
                    onChange(cfg.copy(info = cfg.info xor INFO_DAYLEN))
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipButton("Moon phase", (cfg.info and INFO_MOON) != 0, compact = true) {
                    onChange(cfg.copy(info = cfg.info xor INFO_MOON))
                }
                ChipButton("Tomorrow", (cfg.info and INFO_TOMORROW) != 0, compact = true) {
                    onChange(cfg.copy(info = cfg.info xor INFO_TOMORROW))
                }
            }

            Spacer(Modifier.height(20.dp))
            ChipButton("Done", true) { onClose() }
            Spacer(Modifier.height(12.dp))
        }
    }
}

// ---------- Choose which apps are on the home row ----------

@Composable
private fun TilePicker(
    tiles: List<String>,
    resumeTick: Int,
    onToggle: (String) -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val pm = context.packageManager
    val apps = remember(resumeTick) { Apps.installed(context) }
    val requesters = remember(apps) { List(apps.size) { FocusRequester() } }
    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(apps) {
        delay(250L)
        runCatching { requesters.firstOrNull()?.requestFocus() }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF5060A14))
            .padding(horizontal = 40.dp, vertical = 24.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = "CHOOSE HOME APPS",
                        color = accent,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont,
                        letterSpacing = 3.sp
                    )
                    Text(
                        text = "OK adds or removes an app (tick = on the home row). Hold OK on a home tile to move it.",
                        color = TextLo,
                        fontSize = 11.sp,
                        fontFamily = RoundedFont,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                ChipButton("Done", true) { onClose() }
            }
            Spacer(Modifier.height(12.dp))
            LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Adaptive(104.dp),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(8.dp)
            ) {
                itemsIndexed(apps) { index, app ->
                    var icon by remember(app.pkg) { mutableStateOf<ImageBitmap?>(null) }
                    LaunchedEffect(app.pkg) {
                        icon = withContext(Dispatchers.IO) { Apps.icon(pm, app.pkg) }
                    }
                    AppTile(
                        label = app.label,
                        accent = accent,
                        icon = icon,
                        modifier = Modifier.fillMaxWidth(),
                        badge = if (tiles.contains(app.pkg)) "✓" else null,
                        focusRequester = requesters[index],
                        onFocused = { scope.launch { revealGridItem(gridState, index) } },
                        onDpad = { code -> gridKey(code, scope, gridState, requesters, index) }
                    ) {
                        onToggle(app.pkg)
                    }
                }
            }
        }
    }
}

// ---------- Hold OK on an app: info, uninstall, reorder ----------

@Composable
private fun AppMenu(
    pkg: String,
    onHome: Boolean,
    canLeft: Boolean,
    canRight: Boolean,
    onOpen: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit,
    onLeft: () -> Unit,
    onRight: () -> Unit,
    onToggleHome: () -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val pm = context.packageManager
    val label = Apps.label(pm, pkg)
    val system = Apps.isSystem(pm, pkg)
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(200L)
        runCatching { first.requestFocus() }
    }
    val shape = RoundedCornerShape(20.dp)

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            Modifier
                .width(380.dp)
                .clip(shape)
                .background(PanelDark)
                .border(1.dp, glassBorder, shape)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = label.uppercase(),
                color = accent,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 2.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            ChipButton("Open", false, first, wide = true) { onOpen() }
            ChipButton("App info", false, wide = true) { onInfo() }
            if (!system) {
                ChipButton("Uninstall", false, wide = true) { onUninstall() }
            }
            if (onHome) {
                if (canLeft) {
                    ChipButton("Move left", false, wide = true) { onLeft() }
                }
                if (canRight) {
                    ChipButton("Move right", false, wide = true) { onRight() }
                }
                ChipButton("Remove from home", false, wide = true) { onToggleHome() }
            } else {
                ChipButton("Add to home", false, wide = true) { onToggleHome() }
            }
            ChipButton("Close", true, wide = true) { onClose() }
        }
    }
}

// ---------- Updates from GitHub (only when you press the button) ----------

@Composable
private fun UpdatePanel(
    testBuilds: Boolean,
    onTestBuilds: (Boolean) -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val installed = remember { Updater.installedBuild(context) }
    var release by remember { mutableStateOf<ReleaseInfo?>(null) }
    var message by remember {
        mutableStateOf("Press Check now. Nothing is downloaded or installed unless you confirm.")
    }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(-1) }
    val first = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { first.requestFocus() }
    }

    val doCheck: () -> Unit = {
        if (!busy) {
            scope.launch {
                busy = true
                release = null
                message = "Checking GitHub..."
                val res = withContext(Dispatchers.IO) { Updater.fetchLatest(testBuilds) }
                release = res.first
                message = if (res.first == null) res.second else ""
                busy = false
            }
        }
    }

    val doDownload: () -> Unit = {
        val rel = release
        if (rel != null && !busy) {
            if (!rel.apkUrl.startsWith("https://github.com/")) {
                message = "Unexpected download address, stopped."
            } else {
                scope.launch {
                    busy = true
                    progress = 0
                    message = "Downloading..."
                    val file = withContext(Dispatchers.IO) {
                        Updater.download(context, rel.apkUrl) { pct -> progress = pct }
                    }
                    progress = -1
                    if (file == null) {
                        message = "Download failed. Check the connection and try again."
                    } else if (!Updater.canInstall(context)) {
                        message = "Allow this app to install apps, then come back and press Download again."
                        Updater.openInstallPermission(context)
                    } else if (Updater.install(context, file)) {
                        message = "Installer opened. Confirm there to finish the update."
                    } else {
                        message = "Could not start the installer."
                    }
                    busy = false
                }
            }
        }
    }

    val r = release
    val newer = r != null && r.build > installed

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF5060A14))
            .padding(horizontal = 40.dp, vertical = 24.dp)
    ) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Text(
                text = "UPDATES",
                color = accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 3.sp
            )
            Spacer(Modifier.height(14.dp))
            Text(
                text = "Installed: build " + installed + "   ·   v" + Config.VERSION,
                color = TextHi,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Source: github.com/" + Config.GITHUB_REPO + ". Checked only when you press the button. Stable releases only, unless test builds are on.",
                color = TextLo,
                fontSize = 12.sp,
                fontFamily = RoundedFont
            )
            Spacer(Modifier.height(16.dp))
            if (message.isNotEmpty()) {
                Text(
                    text = message,
                    color = TextHi,
                    fontSize = 15.sp,
                    fontFamily = RoundedFont
                )
            }
            if (r != null) {
                if (newer) {
                    Text(
                        text = "New: " + r.name + "   (build " + r.build + ", " +
                            (Math.round(r.sizeMb * 10.0) / 10.0).toString() + " MB)",
                        color = accent,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont
                    )
                    if (r.notes.isNotEmpty()) {
                        Text(
                            text = r.notes,
                            color = TextLo,
                            fontSize = 12.sp,
                            fontFamily = RoundedFont
                        )
                    }
                } else {
                    Text(
                        text = "You are up to date (newest is " + r.name + ").",
                        color = TextHi,
                        fontSize = 15.sp,
                        fontFamily = RoundedFont
                    )
                }
            }
            if (progress >= 0) {
                Text(
                    text = "Downloading " + progress + "%",
                    color = accent,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RoundedFont
                )
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ChipButton("Check now", false, first) { doCheck() }
                if (newer) {
                    ChipButton("Download and install", true) { doDownload() }
                }
                ChipButton(if (testBuilds) "Test builds: ON" else "Test builds: OFF", testBuilds) {
                    onTestBuilds(!testBuilds)
                }
                ChipButton("Close", true) { onClose() }
            }
        }
    }
}

// ---------- Keep the focused grid item on screen ----------

private suspend fun revealGridItem(state: LazyGridState, index: Int) {
    val info = state.layoutInfo
    val item = info.visibleItemsInfo.firstOrNull { it.index == index }
    if (item == null) {
        state.animateScrollToItem(index)
        return
    }
    val pad = 28
    val top = item.offset.y
    val bottom = top + item.size.height
    if (bottom + pad > info.viewportEndOffset) {
        state.animateScrollBy((bottom + pad - info.viewportEndOffset).toFloat())
    } else if (top - pad < info.viewportStartOffset) {
        state.animateScrollBy((top - pad - info.viewportStartOffset).toFloat())
    }
}

private fun hourIsDay(label: String): Boolean {
    val hr = label.take(2).toIntOrNull() ?: 12
    return hr in 7..17
}

// ---------- Drawn weather artwork ----------

@Composable
private fun WeatherArt(code: Int, isDay: Boolean, anim: Int, modifier: Modifier = Modifier) {
    val phase: State<Float>? = if (anim != 2) {
        rememberInfiniteTransition(label = "art").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(8000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "artPhase"
        )
    } else {
        null
    }
    Canvas(modifier) {
        drawWeather(code, isDay, phase?.value ?: 0f)
    }
}

private fun DrawScope.drawWeather(code: Int, isDay: Boolean, p: Float) {
    val s = minOf(size.width, size.height)
    val kind = when (code) {
        0, 1 -> 0
        2 -> 1
        3 -> 2
        45, 48 -> 3
        in 51..67, in 80..82 -> 4
        in 71..77, 85, 86 -> 5
        in 95..99 -> 6
        else -> 2
    }
    when (kind) {
        0 -> {
            if (isDay) drawSun(s * 0.5f, s * 0.5f, s * 0.2f, p * 30f)
            else drawMoon(s * 0.5f, s * 0.5f, s * 0.22f, p)
        }
        1 -> {
            if (isDay) drawSun(s * 0.38f, s * 0.36f, s * 0.15f, p * 30f)
            else drawMoon(s * 0.38f, s * 0.36f, s * 0.16f, p)
            drawCloud(s * 0.56f, s * 0.6f, s * 0.82f, false, 1f)
        }
        2 -> {
            drawCloud(s * 0.38f, s * 0.42f, s * 0.6f, true, 0.85f)
            drawCloud(s * 0.58f, s * 0.58f, s * 0.82f, !isDay, 1f)
        }
        3 -> {
            drawCloud(s * 0.5f, s * 0.34f, s * 0.7f, false, 0.95f)
            for (i in 0 until 3) {
                val y = s * (0.62f + 0.12f * i)
                val dx = sin(p * 6.2832f + i * 1.7f) * s * 0.05f
                drawRoundRect(
                    color = Color(0x66FFFFFF),
                    topLeft = Offset(s * 0.16f + dx, y),
                    size = Size(s * 0.68f, s * 0.07f),
                    cornerRadius = CornerRadius(s * 0.035f, s * 0.035f)
                )
            }
        }
        4, 6 -> {
            drawCloud(s * 0.5f, s * 0.33f, s * 0.86f, true, 1f)
            drawRain(s, p)
            if (kind == 6) drawBolt(s, p)
        }
        else -> {
            drawCloud(s * 0.5f, s * 0.33f, s * 0.86f, true, 0.95f)
            drawSnow(s, p)
        }
    }
}

private fun DrawScope.drawSun(cx: Float, cy: Float, r: Float, rotDeg: Float) {
    val c = Offset(cx, cy)
    drawCircle(
        brush = Brush.radialGradient(
            listOf(Color(0x77FFD54A), Color.Transparent),
            center = c,
            radius = r * 2.7f
        ),
        radius = r * 2.7f,
        center = c
    )
    for (i in 0 until 12) {
        val a = (rotDeg + i * 30f) * 0.0174533f
        val inner = r * 1.3f
        val outer = r * (if (i % 2 == 0) 1.95f else 1.6f)
        drawLine(
            color = Color(0xDDFFD54A),
            start = Offset(cx + cos(a) * inner, cy + sin(a) * inner),
            end = Offset(cx + cos(a) * outer, cy + sin(a) * outer),
            strokeWidth = r * 0.13f,
            cap = StrokeCap.Round
        )
    }
    drawCircle(
        brush = Brush.radialGradient(
            listOf(Color(0xFFFFF6C2), Color(0xFFFFB93B)),
            center = Offset(cx - r * 0.3f, cy - r * 0.3f),
            radius = r * 1.6f
        ),
        radius = r,
        center = c
    )
}

private fun DrawScope.drawMoon(cx: Float, cy: Float, r: Float, p: Float) {
    val c = Offset(cx, cy)
    drawCircle(
        brush = Brush.radialGradient(
            listOf(Color(0x55BFD8FF), Color.Transparent),
            center = c,
            radius = r * 2.5f
        ),
        radius = r * 2.5f,
        center = c
    )
    drawCircle(
        brush = Brush.radialGradient(
            listOf(Color(0xFFFFFFFF), Color(0xFFD5DEEE)),
            center = Offset(cx - r * 0.3f, cy - r * 0.3f),
            radius = r * 1.6f
        ),
        radius = r,
        center = c
    )
    drawCircle(Color(0x22607090), r * 0.2f, Offset(cx - r * 0.32f, cy - r * 0.18f))
    drawCircle(Color(0x22607090), r * 0.13f, Offset(cx + r * 0.3f, cy + r * 0.12f))
    drawCircle(Color(0x22607090), r * 0.1f, Offset(cx - r * 0.02f, cy + r * 0.45f))
    val stars = listOf(
        Offset(-1.9f, -1.2f), Offset(1.7f, -1.5f), Offset(2.0f, 0.9f), Offset(-1.6f, 1.4f)
    )
    for (i in stars.indices) {
        val twinkle = 0.35f + 0.65f * abs(sin(p * 6.2832f + i * 1.3f))
        drawCircle(
            Color.White.copy(alpha = twinkle),
            r * 0.07f,
            Offset(cx + stars[i].x * r, cy + stars[i].y * r)
        )
    }
}

private fun DrawScope.drawCloud(cx: Float, cy: Float, w: Float, dark: Boolean, alpha: Float) {
    val top = if (dark) Color(0xFF9AA6BB) else Color(0xFFFFFFFF)
    val bottom = if (dark) Color(0xFF5E6B82) else Color(0xFFC3D2E8)
    val h = w * 0.55f
    val brush = Brush.verticalGradient(
        listOf(top, bottom),
        startY = cy - h * 0.5f,
        endY = cy + h * 0.4f
    )
    drawCircle(brush = brush, radius = w * 0.2f, center = Offset(cx - w * 0.22f, cy + h * 0.04f), alpha = alpha)
    drawCircle(brush = brush, radius = w * 0.28f, center = Offset(cx - w * 0.02f, cy - h * 0.1f), alpha = alpha)
    drawCircle(brush = brush, radius = w * 0.21f, center = Offset(cx + w * 0.23f, cy + h * 0.06f), alpha = alpha)
    drawRoundRect(
        brush = brush,
        topLeft = Offset(cx - w * 0.4f, cy + h * 0.02f),
        size = Size(w * 0.8f, h * 0.3f),
        cornerRadius = CornerRadius(h * 0.15f, h * 0.15f),
        alpha = alpha
    )
}

private fun DrawScope.drawRain(s: Float, p: Float) {
    for (i in 0 until 8) {
        val x = s * (0.24f + 0.075f * i)
        val t = (p * 5f + i * 0.137f) % 1f
        val y = s * (0.5f + 0.42f * t)
        drawLine(
            color = Color(0xFFBFE3FF).copy(alpha = 0.9f * (1f - t * 0.6f)),
            start = Offset(x, y),
            end = Offset(x - s * 0.025f, y + s * 0.07f),
            strokeWidth = s * 0.02f,
            cap = StrokeCap.Round
        )
    }
}

private fun DrawScope.drawSnow(s: Float, p: Float) {
    for (i in 0 until 8) {
        val t = (p * 2f + i * 0.131f) % 1f
        val x = s * (0.24f + 0.075f * i) + sin(p * 12.5664f + i) * s * 0.02f
        val y = s * (0.5f + 0.42f * t)
        drawCircle(
            Color.White.copy(alpha = 0.95f * (1f - t * 0.5f)),
            s * (0.018f + 0.004f * (i % 3)),
            Offset(x, y)
        )
    }
}

private fun DrawScope.drawBolt(s: Float, p: Float) {
    val flash = (p * 4f) % 1f
    val a = if (flash < 0.12f || (flash >= 0.2f && flash <= 0.3f)) 1f else 0.25f
    val bolt = Path()
    bolt.moveTo(s * 0.54f, s * 0.5f)
    bolt.lineTo(s * 0.42f, s * 0.7f)
    bolt.lineTo(s * 0.5f, s * 0.7f)
    bolt.lineTo(s * 0.44f, s * 0.92f)
    bolt.lineTo(s * 0.62f, s * 0.64f)
    bolt.lineTo(s * 0.54f, s * 0.64f)
    bolt.close()
    drawPath(bolt, Color(0xFFFFE066).copy(alpha = a))
}

// ---------- Drawn clock digits (styles 5 = LED, 6 = Neon, 7 = Matrix) ----------

private val SEGMENTS = intArrayOf(63, 6, 91, 79, 102, 109, 125, 7, 127, 111)

private val MATRIX = arrayOf(
    "01110 10001 10011 10101 11001 10001 01110",
    "00100 01100 00100 00100 00100 00100 01110",
    "01110 10001 00001 00010 00100 01000 11111",
    "11110 00001 00001 01110 00001 00001 11110",
    "00010 00110 01010 10010 11111 00010 00010",
    "11111 10000 11110 00001 00001 10001 01110",
    "00110 01000 10000 11110 10001 10001 01110",
    "11111 00001 00010 00100 01000 01000 01000",
    "01110 10001 10001 01110 10001 10001 01110",
    "01110 10001 10001 01111 00001 00010 01100"
)

private fun glyphAdvance(ch: Char, style: Int, h: Float): Float {
    return if (style == 7) {
        val cell = h / 7f
        if (ch == ':') cell * 3f else cell * 6f
    } else {
        if (ch == ':') h * 0.34f else h * 0.7f
    }
}

@Composable
private fun DrawnClock(text: String, style: Int, h: Dp, color: Color) {
    val hv = h.value
    var total = 0f
    for (ch in text) total += glyphAdvance(ch, style, hv)
    Canvas(Modifier.size(width = total.dp, height = h)) {
        val d = density
        var x = 0f
        for (ch in text) {
            drawGlyph(ch, style, x * d, hv * d, color)
            x += glyphAdvance(ch, style, hv)
        }
    }
}

private fun DrawScope.glowDot(cx: Float, cy: Float, r: Float, color: Color) {
    drawCircle(color.copy(alpha = 0.12f), r * 3f, Offset(cx, cy))
    drawCircle(color.copy(alpha = 0.25f), r * 1.9f, Offset(cx, cy))
    drawCircle(color, r, Offset(cx, cy))
}

private fun DrawScope.drawGlyph(ch: Char, style: Int, ox: Float, h: Float, color: Color) {
    if (style == 7) {
        drawMatrixGlyph(ch, ox, h, color)
        return
    }
    val w = h * 0.5f
    val t = if (style == 6) h * 0.07f else h * 0.115f
    val half = t / 2f
    if (ch == ':') {
        val r = t * 0.6f
        glowDot(ox + h * 0.12f, h * 0.33f, r, color)
        glowDot(ox + h * 0.12f, h * 0.67f, r, color)
        return
    }
    val digit = ch - '0'
    if (digit < 0 || digit > 9) return
    val mask = SEGMENTS[digit]
    val inset = t * 0.9f
    val mid = h / 2f
    val gap = inset * 0.55f
    val segs = arrayOf(
        floatArrayOf(inset, half, w - inset, half),
        floatArrayOf(w - half, inset, w - half, mid - gap),
        floatArrayOf(w - half, mid + gap, w - half, h - inset),
        floatArrayOf(inset, h - half, w - inset, h - half),
        floatArrayOf(half, mid + gap, half, h - inset),
        floatArrayOf(half, inset, half, mid - gap),
        floatArrayOf(inset, mid, w - inset, mid)
    )
    for (i in 0 until 7) {
        val lit = ((mask shr i) and 1) == 1
        val sg = segs[i]
        val p1 = Offset(ox + sg[0], sg[1])
        val p2 = Offset(ox + sg[2], sg[3])
        if (lit) {
            drawLine(color.copy(alpha = 0.10f), p1, p2, t * 3.2f, StrokeCap.Round)
            drawLine(color.copy(alpha = 0.22f), p1, p2, t * 2.0f, StrokeCap.Round)
            drawLine(color, p1, p2, t, StrokeCap.Round)
            if (style == 6) {
                drawLine(Color.White.copy(alpha = 0.85f), p1, p2, t * 0.35f, StrokeCap.Round)
            }
        } else {
            drawLine(color.copy(alpha = 0.07f), p1, p2, t, StrokeCap.Round)
        }
    }
}

private fun DrawScope.drawMatrixGlyph(ch: Char, ox: Float, h: Float, color: Color) {
    val cell = h / 7f
    val r = cell * 0.36f
    if (ch == ':') {
        glowDot(ox + cell * 0.5f, cell * 2.5f, r, color)
        glowDot(ox + cell * 0.5f, cell * 4.5f, r, color)
        return
    }
    val digit = ch - '0'
    if (digit < 0 || digit > 9) return
    val rows = MATRIX[digit].split(" ")
    for (row in 0 until 7) {
        for (col in 0 until 5) {
            val cx = ox + cell * (col + 0.5f)
            val cy = cell * (row + 0.5f)
            if (rows[row][col] == '1') {
                glowDot(cx, cy, r, color)
            } else {
                drawCircle(color.copy(alpha = 0.08f), r * 0.8f, Offset(cx, cy))
            }
        }
    }
}

// ---------- Sunrise / sunset with a drawn icon and a label ----------

@Composable
private fun SunEvent(rise: Boolean, time: String, color: Color, sp: Int) {
    val accent = LocalAccent.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size((sp * 2.2f).dp)) {
            drawSunIcon(rise, accent)
        }
        Spacer(Modifier.width(6.dp))
        Column {
            Text(
                text = if (rise) "SUNRISE" else "SUNSET",
                color = color.copy(alpha = 0.7f),
                fontSize = (sp - 4).coerceAtLeast(8).sp,
                fontFamily = RoundedFont,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Text(
                text = time,
                color = color,
                fontSize = sp.sp,
                fontFamily = RoundedFont,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private fun DrawScope.drawSunIcon(rise: Boolean, accent: Color) {
    val s = minOf(size.width, size.height)
    val horizon = s * 0.68f
    val sun = Color(0xFFFFC53D)
    val cx = s * 0.5f
    drawArc(
        color = sun,
        startAngle = 180f,
        sweepAngle = 180f,
        useCenter = true,
        topLeft = Offset(cx - s * 0.24f, horizon - s * 0.24f),
        size = Size(s * 0.48f, s * 0.48f)
    )
    for (i in 0 until 5) {
        val a = (180f + 22f + i * 34f) * 0.0174533f
        drawLine(
            color = sun,
            start = Offset(cx + cos(a) * s * 0.32f, horizon + sin(a) * s * 0.32f),
            end = Offset(cx + cos(a) * s * 0.44f, horizon + sin(a) * s * 0.44f),
            strokeWidth = s * 0.05f,
            cap = StrokeCap.Round
        )
    }
    drawLine(
        color = Color.White.copy(alpha = 0.85f),
        start = Offset(s * 0.04f, horizon),
        end = Offset(s * 0.96f, horizon),
        strokeWidth = s * 0.05f,
        cap = StrokeCap.Round
    )
    val arrow = Path()
    if (rise) {
        arrow.moveTo(cx, 0f)
        arrow.lineTo(s * 0.38f, s * 0.13f)
        arrow.lineTo(s * 0.62f, s * 0.13f)
    } else {
        arrow.moveTo(cx, s * 0.98f)
        arrow.lineTo(s * 0.38f, s * 0.85f)
        arrow.lineTo(s * 0.62f, s * 0.85f)
    }
    arrow.close()
    drawPath(arrow, accent)
}

// ---------- Animated sky behind the weather card ----------

@Composable
private fun WeatherBackdrop(group: String, isDay: Boolean, anim: Int) {
    val phase: State<Float>? = if (anim != 2) {
        rememberInfiniteTransition(label = "backdrop").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(60000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "backdropPhase"
        )
    } else {
        null
    }
    Canvas(Modifier.fillMaxSize()) {
        val p = phase?.value ?: 0f
        val w = size.width
        val h = size.height
        if (!isDay) {
            for (i in 0 until 16) {
                val x = w * (((i * 61) % 100) / 100f)
                val y = h * (((i * 37) % 70) / 100f)
                val tw = 0.3f + 0.7f * abs(sin(p * 62.832f + i))
                drawCircle(Color.White.copy(alpha = 0.55f * tw), 1.6f + (i % 3) * 0.5f, Offset(x, y))
            }
        } else if (group == "clear") {
            val c = Offset(w * 0.82f, h * 0.2f)
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0x66FFE9A0), Color.Transparent),
                    center = c,
                    radius = h * 1.1f
                ),
                radius = h * 1.1f,
                center = c
            )
        }
        if (group != "clear") {
            for (k in 0 until 3) {
                val x = ((p + k * 0.33f) % 1f) * (w + 240f) - 120f
                val y = h * (0.2f + 0.22f * k)
                drawCircle(Color(0x18FFFFFF), h * 0.30f, Offset(x, y))
                drawCircle(Color(0x18FFFFFF), h * 0.22f, Offset(x + h * 0.28f, y + h * 0.05f))
                drawCircle(Color(0x18FFFFFF), h * 0.25f, Offset(x - h * 0.26f, y + h * 0.06f))
            }
        }
    }
}

// ---------- Sonic logo: a purple S on a dark tile (same artwork as the app icon) ----------

@Composable
private fun SonicLogo(modifier: Modifier) {
    Canvas(modifier) {
        val k = size.minDimension / 96f
        val sPath = Path()
        sPath.moveTo(68f * k, 34f * k)
        sPath.cubicTo(64f * k, 24f * k, 56f * k, 20f * k, 48f * k, 20f * k)
        sPath.cubicTo(36f * k, 20f * k, 28f * k, 26f * k, 28f * k, 34f * k)
        sPath.cubicTo(28f * k, 43f * k, 38f * k, 46f * k, 48f * k, 49f * k)
        sPath.cubicTo(58f * k, 52f * k, 68f * k, 56f * k, 68f * k, 64f * k)
        sPath.cubicTo(68f * k, 72f * k, 59f * k, 77f * k, 48f * k, 77f * k)
        sPath.cubicTo(39f * k, 77f * k, 31f * k, 73f * k, 27f * k, 64f * k)

        drawRoundRect(
            brush = Brush.linearGradient(
                listOf(Color(0xFF2A0F5C), Color(0xFF0A0418)),
                start = Offset.Zero,
                end = Offset(size.width, size.height)
            ),
            cornerRadius = CornerRadius(20f * k, 20f * k)
        )
        // speed lines
        drawLine(Color(0x80B07CFF), Offset(6f * k, 30f * k), Offset(20f * k, 30f * k), 4f * k, StrokeCap.Round)
        drawLine(Color(0x59B07CFF), Offset(3f * k, 48f * k), Offset(17f * k, 48f * k), 4f * k, StrokeCap.Round)
        drawLine(Color(0x40B07CFF), Offset(6f * k, 66f * k), Offset(20f * k, 66f * k), 4f * k, StrokeCap.Round)
        // glow, then the S
        drawPath(
            sPath,
            Color(0x599B5CFF),
            style = Stroke(width = 16f * k, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        drawPath(
            sPath,
            brush = Brush.linearGradient(
                listOf(Color(0xFFD08BFF), Color(0xFF7C3BFF), Color(0xFF4A1FD6)),
                start = Offset(28f * k, 20f * k),
                end = Offset(68f * k, 77f * k)
            ),
            style = Stroke(width = 9f * k, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

private val TILE_SIZES = listOf(76, 92, 112, 136)

// Up / Down in a grid. A lazy grid only builds what is on screen, so scroll the next row in first,
// then move focus to it.
private fun gridKey(
    code: Int,
    scope: CoroutineScope,
    state: LazyGridState,
    requesters: List<FocusRequester>,
    index: Int
): Boolean {
    val down = code == android.view.KeyEvent.KEYCODE_DPAD_DOWN
    val up = code == android.view.KeyEvent.KEYCODE_DPAD_UP
    if (!down && !up) return false
    val columns = (state.layoutInfo.visibleItemsInfo.maxOfOrNull { it.column } ?: 0) + 1
    var target = if (down) index + columns else index - columns
    if (target < 0) return false
    if (target >= requesters.size) {
        val lastRowStart = ((requesters.size - 1) / columns) * columns
        if (down && index < lastRowStart) target = requesters.size - 1 else return down
    }
    val goTo = target
    scope.launch {
        revealGridItem(state, goTo)
        delay(60L)
        runCatching { requesters[goTo].requestFocus() }
    }
    return true
}
