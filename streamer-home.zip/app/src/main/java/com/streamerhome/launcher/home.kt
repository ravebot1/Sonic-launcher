package com.streamerhome.launcher

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import android.net.Uri
import android.widget.Toast
import kotlinx.coroutines.launch
import java.time.LocalDate
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

// ---------- Look & feel ----------

private val LocalAccent = compositionLocalOf { Color(0xFF4FE3FF) }

private val Ink = Color(0xFF060A14)
private val PanelDark = Color(0xFF0E1626)
private val TextHi = Color(0xFFF2F7FF)
private val TextLo = Color(0xFFA5B4CC)

// Compose has no built-in rounded font; SansSerif is the closest safe choice.
private val RoundedFont: FontFamily = FontFamily.SansSerif

private val glassBorder = Brush.linearGradient(listOf(Color(0x80FFFFFF), Color(0x14FFFFFF)))
private val glassFill = Brush.linearGradient(listOf(Color(0x3DFFFFFF), Color(0x0FFFFFFF)))
private val glassFillFocused = Brush.linearGradient(listOf(Color(0x70FFFFFF), Color(0x2AFFFFFF)))

private val timeFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val time12Fmt: DateTimeFormatter = DateTimeFormatter.ofPattern("h:mm")
private val dateFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE, d MMMM")

private fun glow(color: Color, blur: Float = 16f) = TextStyle(
    shadow = Shadow(color = color.copy(alpha = 0.6f), offset = Offset.Zero, blurRadius = blur)
)

private fun Modifier.glass(shape: Shape): Modifier =
    this.clip(shape).background(glassFill).border(1.dp, glassBorder, shape)

// Focusable + click + long-press. Holding OK / Enter on the remote repeats the key: that is the long press.
// The long-press action runs when the button is RELEASED. If it ran during the hold, the menu window would
// take focus and receive the release, which could trigger "Open" by accident.
private fun Modifier.tvClickable(
    source: MutableInteractionSource,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
): Modifier = composed {
    var longPending by remember { mutableStateOf(false) }
    this
        .focusable(interactionSource = source)
        .onKeyEvent { ev ->
            val native = ev.nativeKeyEvent
            val code = native.keyCode
            val select = code == android.view.KeyEvent.KEYCODE_DPAD_CENTER ||
                code == android.view.KeyEvent.KEYCODE_ENTER ||
                code == android.view.KeyEvent.KEYCODE_NUMPAD_ENTER
            if (!select) {
                false
            } else if (ev.type == KeyEventType.KeyDown) {
                if (native.repeatCount == 0) {
                    longPending = false
                } else if (onLongClick != null) {
                    longPending = true
                }
                true
            } else if (ev.type == KeyEventType.KeyUp) {
                val wasLong = longPending
                longPending = false
                if (wasLong && onLongClick != null) onLongClick() else onClick()
                true
            } else {
                false
            }
        }
}

// anim: 0 = full, 1 = reduced, 2 = off
private fun panelEnter(anim: Int): EnterTransition =
    if (anim == 2) EnterTransition.None
    else fadeIn(tween(220)) + scaleIn(animationSpec = tween(220), initialScale = 0.94f)

private fun panelExit(anim: Int): ExitTransition =
    if (anim == 2) ExitTransition.None
    else fadeOut(tween(160)) + scaleOut(animationSpec = tween(160), targetScale = 0.96f)

// Staggered fade / slide-in when the launcher opens
@Composable
private fun Entrance(
    delayMs: Int,
    anim: Int,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    var shown by remember { mutableStateOf(anim == 2) }
    LaunchedEffect(Unit) {
        if (!shown) {
            delay(delayMs.toLong())
            shown = true
        }
    }
    val a by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = tween(if (anim == 0) 700 else 250),
        label = "enterAlpha"
    )
    val dy by animateFloatAsState(
        targetValue = if (shown || anim != 0) 0f else 28f,
        animationSpec = tween(700),
        label = "enterY"
    )
    Box(
        modifier.graphicsLayer {
            alpha = a
            translationY = dy * density
        }
    ) {
        content()
    }
}

// Sky colours used behind the weather photo (and while it loads)
private fun skyColors(isDay: Boolean, group: String): Pair<Color, Color> = when {
    !isDay && (group == "rain" || group == "storm") -> Pair(Color(0xFF0D1422), Color(0xFF2A3548))
    !isDay -> Pair(Color(0xFF0A1230), Color(0xFF22306A))
    group == "clear" -> Pair(Color(0xFF2F78C8), Color(0xFF8FC8F5))
    group == "rain" -> Pair(Color(0xFF34455A), Color(0xFF63778D))
    group == "storm" -> Pair(Color(0xFF2A2D44), Color(0xFF55506E))
    group == "snow" -> Pair(Color(0xFF8CA2B9), Color(0xFFDCE5EE))
    group == "fog" -> Pair(Color(0xFF7A858F), Color(0xFFB9C1C8))
    else -> Pair(Color(0xFF55697E), Color(0xFF9AAABA))
}

// ---------- Home screen ----------

@Composable
fun HomeScreen(
    permissionTick: Int,
    resumeTick: Int,
    onAskLocation: () -> Unit
) {
    val context = LocalContext.current
    val pm = context.packageManager

    var showApps by remember { mutableStateOf(false) }
    var showNet by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showForecast by remember { mutableStateOf(false) }
    var showClock by remember { mutableStateOf(false) }
    var showPicker by remember { mutableStateOf(false) }
    var showUpdate by remember { mutableStateOf(false) }
    var backToSettings by remember { mutableStateOf(false) }
    var menuPkg by remember { mutableStateOf<String?>(null) }

    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var weather by remember { mutableStateOf<Weather?>(null) }
    var net by remember { mutableStateOf(NetworkReader.read(context)) }

    var themeIdx by remember { mutableIntStateOf(Prefs.themeIndex(context)) }
    var intervalMin by remember { mutableIntStateOf(Prefs.intervalMin(context)) }
    var cats by remember { mutableIntStateOf(Prefs.categories(context)) }
    var anim by remember { mutableIntStateOf(Prefs.anim(context)) }
    var clockCfg by remember { mutableStateOf(Prefs.clock(context)) }
    var tilesPref by remember { mutableStateOf(Prefs.tiles(context)) }
    var testBuilds by remember { mutableStateOf(Prefs.testBuilds(context)) }

    var media by remember { mutableStateOf<MediaInfo?>(null) }
    var mediaArt by remember { mutableStateOf<ImageBitmap?>(null) }
    var mediaKey by remember { mutableStateOf("") }
    var mediaAccess by remember { mutableStateOf(false) }

    // Apps shown on the home row (saved order, only the ones that are installed)
    val tiles: List<String> = remember(resumeTick, tilesPref) {
        val base = tilesPref ?: Config.tiles.mapNotNull { Apps.firstInstalled(pm, it.packages) }
        base.filter { Apps.launchIntent(pm, it) != null }.distinct()
    }

    val saveTiles = { list: List<String> ->
        tilesPref = list
        Prefs.setTiles(context, list)
    }

    // Closes a sub-panel; returns to Settings when it was opened from there
    val closeSub: () -> Unit = {
        showForecast = false
        showClock = false
        showPicker = false
        showUpdate = false
        if (backToSettings) {
            backToSettings = false
            showSettings = true
        }
    }

    val overlayOpen = showApps || showSettings || showForecast || showClock ||
        showPicker || showUpdate || menuPkg != null

    // A launcher should never "go back" to anything; Back only closes open panels.
    BackHandler {
        if (menuPkg != null) {
            menuPkg = null
        } else if (showForecast || showClock || showPicker || showUpdate) {
            closeSub()
        } else {
            showSettings = false
            showApps = false
        }
    }

    LaunchedEffect(Unit) {
        while (isActive) {
            now = LocalDateTime.now()
            delay(1000L)
        }
    }

    LaunchedEffect(Unit) {
        while (isActive) {
            val w = withContext(Dispatchers.IO) { WeatherApi.fetch() }
            if (w != null) weather = w
            delay(if (w != null) Config.WEATHER_REFRESH_MS else 60_000L)
        }
    }

    LaunchedEffect(permissionTick, resumeTick) {
        while (isActive) {
            net = NetworkReader.read(context)
            delay(4000L)
        }
    }

    // What is playing (needs notification access, see Settings)
    LaunchedEffect(resumeTick) {
        while (isActive) {
            val access = withContext(Dispatchers.IO) { NowPlaying.hasAccess(context) }
            mediaAccess = access
            val m = if (access) withContext(Dispatchers.IO) { NowPlaying.read(context) } else null
            val k = if (m == null) "" else m.pkg + "|" + m.title + "|" + m.artist + "|" + m.playing + "|" + (m.art != null)
            if (k != mediaKey) {
                mediaKey = k
                media = m
                mediaArt = m?.art?.asImageBitmap()
            }
            delay(2000L)
        }
    }

    val theme = Themes[themeIdx.coerceIn(0, Themes.size - 1)]

    // London wallpapers follow the time of day and the weather
    val tod = timeOfDay(now.hour * 60 + now.minute, weather)
    val group = weather?.group ?: "cloud"
    val wallKey = if ((cats and CAT_LONDON) != 0) cats.toString() + "|" + tod + "|" + group else cats.toString()

    CompositionLocalProvider(LocalAccent provides theme.accent) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Ink)
        ) {
            // Accent glow, visible until the first wallpaper loads
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            listOf(theme.accent.copy(alpha = 0.28f), Color.Transparent)
                        )
                    )
            )

            // Online wallpaper (slow zoom when animations are on)
            RotatingImage(
                modifier = Modifier.fillMaxSize(),
                maxSide = 2200,
                intervalMs = intervalMin * 60_000L,
                key = wallKey,
                kenBurns = anim == 0
            ) {
                Remote.backgroundUrls(cats, tod, group)
            }

            // Darkening for readability
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0x99060A14), Color(0x40060A14), Color(0xB3060A14))
                        )
                    )
            )

            GridOverlay()

            Column(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 40.dp, vertical = 24.dp)
                    .focusProperties { canFocus = !overlayOpen }
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Entrance(0, anim) {
                        ClockBlock(now, clockCfg, weather) { showClock = true }
                    }

                    Spacer(Modifier.weight(1f))

                    Entrance(120, anim) {
                        WeatherPanel(weather, anim) { showForecast = true }
                    }

                    Spacer(Modifier.width(16.dp))

                    Entrance(240, anim) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            WifiButton(net) { showNet = true }
                            SettingsButton { showSettings = true }
                        }
                    }
                }

                Spacer(Modifier.weight(1f))

                // "Now playing" card, only while something is playing or paused
                AnimatedVisibility(
                    visible = media != null,
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    enter = fadeIn(tween(300)) + slideInVertically(initialOffsetY = { it / 2 }),
                    exit = fadeOut(tween(200)) + slideOutVertically(targetOffsetY = { it / 2 })
                ) {
                    val mi = media
                    if (mi != null) {
                        Column {
                            NowPlayingCard(mi, mediaArt) { action ->
                                NowPlaying.control(context, mi.pkg, action)
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }

                Entrance(360, anim, Modifier.fillMaxWidth()) {
                    AppRow(
                        tiles = tiles,
                        overlayOpen = overlayOpen,
                        anim = anim,
                        onAllApps = { showApps = true },
                        onMenu = { pkg -> menuPkg = pkg }
                    )
                }

                Spacer(Modifier.height(6.dp))

                Text(
                    text = "Created by Claudiu",
                    color = TextLo.copy(alpha = 0.75f),
                    fontSize = 11.sp,
                    fontFamily = RoundedFont,
                    letterSpacing = 1.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }

            AnimatedVisibility(
                visible = showApps,
                enter = panelEnter(anim),
                exit = panelExit(anim)
            ) {
                AllApps(
                    resumeTick = resumeTick,
                    tiles = tiles,
                    onMenu = { pkg -> menuPkg = pkg },
                    onClose = { showApps = false }
                )
            }

            AnimatedVisibility(
                visible = showSettings,
                enter = panelEnter(anim),
                exit = panelExit(anim)
            ) {
                SettingsScreen(
                    themeIdx = themeIdx,
                    intervalMin = intervalMin,
                    cats = cats,
                    anim = anim,
                    mediaAccess = mediaAccess,
                    onTheme = { i ->
                        themeIdx = i
                        Prefs.setThemeIndex(context, i)
                    },
                    onInterval = { m ->
                        val v = m.coerceIn(5, 60)
                        intervalMin = v
                        Prefs.setIntervalMin(context, v)
                    },
                    onCats = { c ->
                        if (c != 0) {
                            cats = c
                            Prefs.setCategories(context, c)
                        }
                    },
                    onAnim = { v ->
                        anim = v
                        Prefs.setAnim(context, v)
                    },
                    onOpenClock = {
                        showSettings = false
                        backToSettings = true
                        showClock = true
                    },
                    onOpenPicker = {
                        showSettings = false
                        backToSettings = true
                        showPicker = true
                    },
                    onOpenUpdate = {
                        showSettings = false
                        backToSettings = true
                        showUpdate = true
                    },
                    onGrantMedia = { openNotificationAccess(context) },
                    onSystemSettings = { openSystemSettings(context) },
                    onClose = { showSettings = false }
                )
            }

            AnimatedVisibility(
                visible = showForecast,
                enter = panelEnter(anim),
                exit = panelExit(anim)
            ) {
                ForecastPanel(weather) { closeSub() }
            }

            AnimatedVisibility(
                visible = showClock,
                enter = panelEnter(anim),
                exit = panelExit(anim)
            ) {
                ClockPanel(
                    cfg = clockCfg,
                    onChange = { c ->
                        clockCfg = c
                        Prefs.setClock(context, c)
                    },
                    onClose = { closeSub() }
                )
            }

            AnimatedVisibility(
                visible = showPicker,
                enter = panelEnter(anim),
                exit = panelExit(anim)
            ) {
                TilePicker(
                    tiles = tiles,
                    resumeTick = resumeTick,
                    onToggle = { pkg ->
                        if (tiles.contains(pkg)) saveTiles(tiles.filter { it != pkg })
                        else saveTiles(tiles + pkg)
                    },
                    onClose = { closeSub() }
                )
            }

            AnimatedVisibility(
                visible = showUpdate,
                enter = panelEnter(anim),
                exit = panelExit(anim)
            ) {
                UpdatePanel(
                    testBuilds = testBuilds,
                    onTestBuilds = { v ->
                        testBuilds = v
                        Prefs.setTestBuilds(context, v)
                    },
                    onClose = { closeSub() }
                )
            }

            val mp = menuPkg
            if (mp != null) {
                val idx = tiles.indexOf(mp)
                AppMenu(
                    pkg = mp,
                    onHome = idx >= 0,
                    canLeft = idx > 0,
                    canRight = idx >= 0 && idx < tiles.size - 1,
                    onOpen = {
                        menuPkg = null
                        Apps.launch(context, mp)
                    },
                    onInfo = {
                        menuPkg = null
                        openAppInfo(context, mp)
                    },
                    onUninstall = {
                        menuPkg = null
                        uninstallApp(context, mp)
                    },
                    onLeft = {
                        val l = tiles.toMutableList()
                        java.util.Collections.swap(l, idx, idx - 1)
                        saveTiles(l)
                    },
                    onRight = {
                        val l = tiles.toMutableList()
                        java.util.Collections.swap(l, idx, idx + 1)
                        saveTiles(l)
                    },
                    onToggleHome = {
                        menuPkg = null
                        if (idx >= 0) saveTiles(tiles.filter { it != mp }) else saveTiles(tiles + mp)
                    },
                    onClose = { menuPkg = null }
                )
            }

            if (showNet) {
                NetDialog(
                    net = net,
                    onClose = { showNet = false },
                    onAskLocation = onAskLocation,
                    onSettings = { openWifiSettings(context) }
                )
            }
        }
    }
}

private fun openNotificationAccess(context: Context) {
    try {
        context.startActivity(
            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        openSystemSettings(context)
    }
}

private fun openAppInfo(context: Context, pkg: String) {
    try {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        Toast.makeText(context, "Could not open app info", Toast.LENGTH_SHORT).show()
    }
}

private fun uninstallApp(context: Context, pkg: String) {
    try {
        context.startActivity(
            Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        Toast.makeText(context, "Could not start uninstall", Toast.LENGTH_SHORT).show()
    }
}

private fun openSystemSettings(context: Context) {
    try {
        context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        // nothing else to try
    }
}

private fun openWifiSettings(context: Context) {
    try {
        context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        openSystemSettings(context)
    }
}

@Composable
private fun GridOverlay() {
    Canvas(Modifier.fillMaxSize()) {
        val step = 56.dp.toPx()
        val c = Color(0x0EFFFFFF)
        var x = 0f
        while (x < size.width) {
            drawLine(c, Offset(x, 0f), Offset(x, size.height), 1f)
            x += step
        }
        var y = 0f
        while (y < size.height) {
            drawLine(c, Offset(0f, y), Offset(size.width, y), 1f)
            y += step
        }
    }
}

// Cross-fading slideshow of remote images. Restarts whenever `key` or the interval changes.
@Composable
private fun RotatingImage(
    modifier: Modifier,
    maxSide: Int,
    intervalMs: Long,
    key: Any,
    kenBurns: Boolean = false,
    fetchUrls: () -> List<String>
) {
    val context = LocalContext.current
    var bitmap by remember { mutableStateOf<ImageBitmap?>(null) }

    // Very slow zoom in and out (read in the graphics layer, so it never recomposes)
    val zoom: State<Float>? = if (kenBurns) {
        rememberInfiniteTransition(label = "zoom").animateFloat(
            initialValue = 1f,
            targetValue = 1.08f,
            animationSpec = infiniteRepeatable(
                animation = tween(40000, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "zoomValue"
        )
    } else {
        null
    }

    LaunchedEffect(key, intervalMs) {
        var urls: List<String> = emptyList()
        var index = 0
        while (isActive) {
            if (urls.isEmpty()) {
                urls = withContext(Dispatchers.IO) { fetchUrls() }
                index = 0
                if (urls.isEmpty()) {
                    delay(60_000L)
                    continue
                }
            }
            val url = urls[index]
            val bmp = withContext(Dispatchers.IO) { Remote.loadBitmap(context, url, maxSide) }
            if (bmp != null) {
                bitmap = bmp.asImageBitmap()
                delay(intervalMs)
            } else {
                delay(2000L)
            }
            index++
            if (index >= urls.size) {
                urls = emptyList()
            }
        }
    }

    Crossfade(
        targetState = bitmap,
        modifier = modifier,
        animationSpec = tween(1500),
        label = "remoteImage"
    ) { bmp ->
        if (bmp != null) {
            Image(
                bitmap = bmp,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val z = zoom?.value ?: 1f
                        scaleX = z
                        scaleY = z
                    }
            )
        } else {
            Box(Modifier.fillMaxSize())
        }
    }
}

// ---------- Top bar pieces ----------

@Composable
private fun ClockBlock(now: LocalDateTime, cfg: ClockCfg, w: Weather?, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val shape = RoundedCornerShape(18.dp)

    val sizeSp = when (cfg.size) {
        0 -> 36
        1 -> 52
        else -> 72
    }
    val alphaValue = when (cfg.alpha) {
        0 -> 0.45f
        1 -> 0.65f
        2 -> 0.85f
        else -> 1f
    }
    val family = when (cfg.style) {
        2 -> FontFamily.Monospace
        3 -> FontFamily.Serif
        else -> FontFamily.SansSerif
    }
    val weight = when (cfg.style) {
        0 -> FontWeight.Thin
        1 -> FontWeight.Bold
        2 -> FontWeight.Normal
        3 -> FontWeight.Medium
        else -> FontWeight.Black
    }
    val textColor = (if (cfg.accentColor) accent else TextHi).copy(alpha = alphaValue)
    val shadowStyle = TextStyle(
        shadow = Shadow(color = Color(0xCC000000), offset = Offset(0f, 2f), blurRadius = 10f)
    )

    val timeText = if (cfg.h24) now.format(timeFmt) else now.format(time12Fmt)
    val small = (if (cfg.seconds) ":" + now.second.toString().padStart(2, '0') else "") +
        (if (cfg.h24) "" else (if (now.hour < 12) " AM" else " PM"))

    // Lines under the clock
    val dateLine = if ((cfg.info and INFO_DATE) != 0) now.format(dateFmt) else ""
    val extras = ArrayList<String>()
    if (w != null) {
        if ((cfg.info and INFO_SUN) != 0) {
            extras.add("↑ " + formatMinutes(w.sunriseMin) + "   ↓ " + formatMinutes(w.sunsetMin))
        }
        if ((cfg.info and INFO_DAYLEN) != 0) {
            val m = w.sunsetMin - w.sunriseMin
            extras.add("Day " + (m / 60) + "h " + (m % 60) + "m")
        }
        if ((cfg.info and INFO_TOMORROW) != 0 && w.days.size > 1) {
            val d = w.days[1]
            extras.add("Tomorrow " + d.high + "° / " + d.low + "°")
        }
    }
    if ((cfg.info and INFO_MOON) != 0) {
        val mp = moonPhase(LocalDate.now())
        extras.add(mp.first + " " + mp.second)
    }
    val infoSp = when (cfg.size) {
        0 -> 12
        1 -> 14
        else -> 16
    }

    Column(
        Modifier
            .then(
                if (cfg.box == 1) Modifier.glass(shape)
                else if (cfg.box == 2) Modifier
                    .clip(shape)
                    .background(Color(0xCC0A1020))
                    .border(1.dp, Color(0x33FFFFFF), shape)
                else Modifier
            )
            .then(if (focused) Modifier.border(2.dp, accent, shape) else Modifier)
            .tvClickable(source, null, onClick)
            .padding(
                if (cfg.box == 0) PaddingValues(start = 6.dp, top = 6.dp, end = 10.dp, bottom = 6.dp)
                else PaddingValues(horizontal = 18.dp, vertical = 12.dp)
            )
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = timeText,
                color = textColor,
                fontSize = sizeSp.sp,
                fontWeight = weight,
                fontFamily = family,
                letterSpacing = 2.sp,
                style = shadowStyle
            )
            if (small.isNotEmpty()) {
                Text(
                    text = small,
                    color = textColor.copy(alpha = alphaValue * 0.8f),
                    fontSize = (sizeSp * 0.4f).sp,
                    fontWeight = weight,
                    fontFamily = family,
                    style = shadowStyle,
                    modifier = Modifier.padding(start = 6.dp, bottom = (sizeSp * 0.1f).dp)
                )
            }
        }
        if (dateLine.isNotEmpty()) {
            Text(
                text = dateLine,
                color = TextHi.copy(alpha = alphaValue * 0.9f),
                fontSize = infoSp.sp,
                fontFamily = RoundedFont,
                fontWeight = FontWeight.Medium,
                style = shadowStyle,
                modifier = Modifier.padding(start = 2.dp)
            )
        }
        if (extras.isNotEmpty()) {
            Text(
                text = extras.joinToString("   ·   "),
                color = TextHi.copy(alpha = alphaValue * 0.75f),
                fontSize = (infoSp - 1).sp,
                fontFamily = RoundedFont,
                style = shadowStyle,
                modifier = Modifier.padding(start = 2.dp, top = 2.dp)
            )
        }
    }
}

@Composable
private fun WeatherPanel(w: Weather?, anim: Int, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val shape = RoundedCornerShape(20.dp)
    val isDay = w?.isDay ?: true
    val group = w?.group ?: "cloud"
    val sky = skyColors(isDay, group)

    Box(
        Modifier
            .width(340.dp)
            .height(136.dp)
            .clip(shape)
            .background(PanelDark)
            .border(1.dp, glassBorder, shape)
            .then(if (focused) Modifier.border(2.dp, accent, shape) else Modifier)
            .tvClickable(source, null, onClick)
    ) {
        // Sky colours that match the weather and time of day
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(sky.first, sky.second)))
        )

        // London photo matching the weather and time of day, changes every 30 minutes
        if (w != null) {
            RotatingImage(
                modifier = Modifier.fillMaxSize(),
                maxSide = 1400,
                intervalMs = Config.WEATHER_PHOTO_INTERVAL_MS,
                key = (if (isDay) "d" else "n") + group
            ) {
                Remote.weatherPhotoUrls(isDay, group)
            }
        }

        // Dark-to-clear scrim so the text on the left stays readable
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xE60A1020), Color(0x990A1020), Color(0x1A0A1020))
                    )
                )
        )

        // Rain / snow drifting over the photo
        if (anim == 0 && w != null) {
            WeatherFx(w.group)
        }

        Column(
            Modifier
                .align(Alignment.CenterStart)
                .padding(horizontal = 20.dp)
        ) {
            if (w == null) {
                Text(
                    text = "SYNCING...",
                    color = TextLo,
                    fontSize = 14.sp,
                    fontFamily = RoundedFont
                )
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = w.temp.toString() + "°",
                        color = TextHi,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont,
                        style = glow(accent, 18f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(text = w.emoji, fontSize = 28.sp)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(
                            text = Config.CITY,
                            color = TextHi,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = RoundedFont
                        )
                        Text(
                            text = w.label.uppercase(),
                            color = accent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = RoundedFont,
                            letterSpacing = 1.sp
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "H " + w.high + "°  L " + w.low + "°  ·  " + w.windMph + " MPH  ·  " + w.humidity + "%",
                    color = TextLo,
                    fontSize = 11.sp,
                    fontFamily = RoundedFont
                )
            }
        }
    }
}

@Composable
private fun WifiButton(net: NetInfo, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val active = if (net.level < 0) 0 else net.level.coerceAtLeast(1)
    Box(
        Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(if (focused) glassFillFocused else glassFill)
            .border(
                if (focused) 2.dp else 1.dp,
                if (focused) accent else Color(0x44FFFFFF),
                CircleShape
            )
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(24.dp)) {
            val barW = size.width / 7f
            for (i in 0 until 4) {
                val h = size.height * (0.3f + 0.7f * (i + 1) / 4f)
                drawRoundRect(
                    color = if (i < active) accent else Color(0x44FFFFFF),
                    topLeft = Offset(i * barW * 2f, size.height - h),
                    size = Size(barW, h),
                    cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                )
            }
        }
    }
}

@Composable
private fun SettingsButton(onClick: () -> Unit) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    Box(
        Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(if (focused) glassFillFocused else glassFill)
            .border(
                if (focused) 2.dp else 1.dp,
                if (focused) accent else Color(0x44FFFFFF),
                CircleShape
            )
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "⚙",
            color = if (focused) accent else TextHi,
            fontSize = 22.sp
        )
    }
}

// ---------- App tiles ----------

@Composable
private fun AppRow(
    tiles: List<String>,
    overlayOpen: Boolean,
    anim: Int,
    onAllApps: () -> Unit,
    onMenu: (String) -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val pm = context.packageManager
    val first = remember { FocusRequester() }

    // Focus the first tile at start and again whenever a panel closes
    LaunchedEffect(overlayOpen) {
        if (!overlayOpen) {
            delay(300L)
            runCatching { first.requestFocus() }
        }
    }

    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 14.dp)
    ) {
        itemsIndexed(tiles, key = { _, pkg -> pkg }) { index, pkg ->
            var icon by remember(pkg) { mutableStateOf<ImageBitmap?>(null) }
            LaunchedEffect(pkg) {
                icon = withContext(Dispatchers.IO) { Apps.icon(pm, pkg) }
            }
            AppTile(
                label = Apps.label(pm, pkg),
                accent = accent,
                icon = icon,
                modifier = Modifier.width(92.dp),
                anim = anim,
                focusRequester = if (index == 0) first else null,
                onLongClick = { onMenu(pkg) }
            ) {
                Apps.launch(context, pkg)
            }
        }
        item {
            AppTile(
                label = "All apps",
                accent = accent,
                icon = null,
                modifier = Modifier.width(92.dp),
                glyph = "☰",
                anim = anim,
                focusRequester = if (tiles.isEmpty()) first else null
            ) { onAllApps() }
        }
    }
}

@Composable
private fun AppTile(
    label: String,
    accent: Color,
    icon: ImageBitmap?,
    modifier: Modifier = Modifier,
    glyph: String? = null,
    installed: Boolean = true,
    badge: String? = null,
    anim: Int = 2,
    focusRequester: FocusRequester? = null,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    val themeAccent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.12f else 1f,
        animationSpec = if (anim == 2) tween(0) else spring(dampingRatio = 0.55f, stiffness = 380f),
        label = "tileScale"
    )

    // A light sweep that runs across the focused tile
    val sweep: Float = if (focused && anim == 0) {
        val t = rememberInfiniteTransition(label = "shine")
        val v by t.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(1800, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "shineX"
        )
        v
    } else {
        0f
    }

    val shape = RoundedCornerShape(16.dp)

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .scale(scale)
            .alpha(if (installed) 1f else 0.45f)
            .clip(shape)
            .background(if (focused) glassFillFocused else glassFill)
            .border(
                if (focused) 2.dp else 1.dp,
                if (focused) themeAccent else Color(0x44FFFFFF),
                shape
            )
            .then(
                if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier
            )
            .tvClickable(source, onLongClick, onClick)
            .drawWithContent {
                drawContent()
                if (focused && anim == 0) {
                    val w = size.width
                    val x = -0.4f * w + sweep * 1.8f * w
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(Color.Transparent, Color(0x40FFFFFF), Color.Transparent),
                            start = Offset(x, 0f),
                            end = Offset(x + 0.4f * w, size.height * 0.5f)
                        )
                    )
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(6.dp)
        ) {
            if (icon != null) {
                Image(
                    bitmap = icon,
                    contentDescription = label,
                    modifier = Modifier
                        .fillMaxWidth(0.66f)
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(14.dp))
                )
            } else {
                Box(
                    Modifier
                        .fillMaxWidth(0.66f)
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(accent.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = glyph ?: label.take(1).uppercase(),
                        color = accent,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = label,
                color = TextHi,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (badge != null) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(5.dp)
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(themeAccent),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = badge,
                    color = Ink,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ---------- All apps overlay ----------

@Composable
private fun AllApps(
    resumeTick: Int,
    tiles: List<String>,
    onMenu: (String) -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val pm = context.packageManager
    val apps = remember(resumeTick) { Apps.installed(context) }
    val first = remember { FocusRequester() }

    LaunchedEffect(apps) {
        delay(250L)
        runCatching { first.requestFocus() }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF2060A14))
            .padding(horizontal = 40.dp, vertical = 28.dp)
    ) {
        Column {
            Text(
                text = "ALL APPS   ·   hold OK on an app for more",
                color = accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 2.sp
            )
            Spacer(Modifier.height(16.dp))
            LazyVerticalGrid(
                columns = GridCells.Adaptive(104.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(8.dp)
            ) {
                itemsIndexed(apps) { index, app ->
                    var icon by remember(app.pkg) { mutableStateOf<ImageBitmap?>(null) }
                    LaunchedEffect(app.pkg) {
                        icon = withContext(Dispatchers.IO) { Apps.icon(pm, app.pkg) }
                    }
                    AppTile(
                        label = app.label,
                        accent = accent,
                        icon = icon,
                        modifier = Modifier.fillMaxWidth(),
                        badge = if (tiles.contains(app.pkg)) "✓" else null,
                        focusRequester = if (index == 0) first else null,
                        onLongClick = { onMenu(app.pkg) }
                    ) {
                        Apps.launch(context, app.pkg)
                        onClose()
                    }
                }
            }
        }
    }
}

// ---------- Launcher settings ----------

@Composable
private fun SettingsScreen(
    themeIdx: Int,
    intervalMin: Int,
    cats: Int,
    anim: Int,
    mediaAccess: Boolean,
    onTheme: (Int) -> Unit,
    onInterval: (Int) -> Unit,
    onCats: (Int) -> Unit,
    onAnim: (Int) -> Unit,
    onOpenClock: () -> Unit,
    onOpenPicker: () -> Unit,
    onOpenUpdate: () -> Unit,
    onGrantMedia: () -> Unit,
    onSystemSettings: () -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    val first = remember { FocusRequester() }
    var status by remember { mutableStateOf(Remote.status) }

    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { first.requestFocus() }
    }
    LaunchedEffect(Unit) {
        while (isActive) {
            status = Remote.status
            delay(2000L)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF5060A14))
            .padding(horizontal = 40.dp, vertical = 24.dp)
    ) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Text(
                text = "LAUNCHER SETTINGS  ·  v" + Config.VERSION,
                color = accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 3.sp
            )

            Spacer(Modifier.height(16.dp))
            SectionLabel("COLOR THEME")
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Themes.forEachIndexed { i, t ->
                    ThemeSwatch(
                        theme = t,
                        selected = i == themeIdx,
                        focusRequester = if (i == themeIdx) first else null
                    ) { onTheme(i) }
                }
            }

            Spacer(Modifier.height(18.dp))
            SectionLabel("ANIMATIONS")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ChipButton("Full", anim == 0) { onAnim(0) }
                ChipButton("Reduced", anim == 1) { onAnim(1) }
                ChipButton("Off", anim == 2) { onAnim(2) }
            }

            Spacer(Modifier.height(18.dp))
            SectionLabel("HOME SCREEN")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ChipButton("Choose home apps...", false) { onOpenPicker() }
                ChipButton("Clock style...", false) { onOpenClock() }
            }

            Spacer(Modifier.height(18.dp))
            SectionLabel("WALLPAPER CHANGES EVERY")
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                ChipButton("-", false) { onInterval(intervalMin - 5) }
                Text(
                    text = intervalMin.toString() + " min",
                    color = TextHi,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RoundedFont
                )
                ChipButton("+", false) { onInterval(intervalMin + 5) }
            }

            Spacer(Modifier.height(18.dp))
            SectionLabel("WALLPAPER TYPES")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ChipButton("Space", (cats and CAT_SPACE) != 0) { onCats(cats xor CAT_SPACE) }
                ChipButton("Nature", (cats and CAT_NATURE) != 0) { onCats(cats xor CAT_NATURE) }
                ChipButton("City", (cats and CAT_CITY) != 0) { onCats(cats xor CAT_CITY) }
                ChipButton("Animals", (cats and CAT_ANIMALS) != 0) { onCats(cats xor CAT_ANIMALS) }
                ChipButton("Art", (cats and CAT_ART) != 0) { onCats(cats xor CAT_ART) }
                ChipButton("London (time of day)", (cats and CAT_LONDON) != 0) { onCats(cats xor CAT_LONDON) }
            }

            Spacer(Modifier.height(18.dp))
            SectionLabel("PLAYBACK CARD (DEEZER, YOUTUBE MUSIC, TIDAL...)")
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = if (mediaAccess) "Notification access: ON" else "Notification access: needed",
                    color = if (mediaAccess) accent else TextLo,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RoundedFont
                )
                if (!mediaAccess) {
                    ChipButton("Grant access", false) { onGrantMedia() }
                }
            }
            if (!mediaAccess) {
                Text(
                    text = "If the button does nothing, run on a computer: adb shell cmd notification allow_listener com.streamerhome.launcher/com.streamerhome.launcher.MediaListenerService",
                    color = TextLo,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            Spacer(Modifier.height(18.dp))
            SectionLabel("UPDATES (ONLY WHEN YOU ASK)")
            ChipButton("Check for updates...", false) { onOpenUpdate() }

            Spacer(Modifier.height(18.dp))
            SectionLabel("ONLINE IMAGE STATUS")
            Text(
                text = status,
                color = TextLo,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )

            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                ChipButton("System settings", false) { onSystemSettings() }
                ChipButton("Close", true) { onClose() }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        color = TextLo,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = RoundedFont,
        letterSpacing = 2.sp,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun ThemeSwatch(
    theme: ThemeSpec,
    selected: Boolean,
    focusRequester: FocusRequester?,
    onClick: () -> Unit
) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(44.dp)
                .scale(if (focused) 1.15f else 1f)
                .then(
                    if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier
                )
                .clip(CircleShape)
                .background(theme.accent)
                .border(
                    3.dp,
                    if (selected) Color.White else if (focused) Color(0xAAFFFFFF) else Color.Transparent,
                    CircleShape
                )
                .focusable(interactionSource = source)
                .clickable(interactionSource = source, indication = null, onClick = onClick)
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = theme.name,
            color = if (selected) TextHi else TextLo,
            fontSize = 11.sp,
            fontFamily = RoundedFont
        )
    }
}

@Composable
private fun ChipButton(
    text: String,
    selected: Boolean,
    focusRequester: FocusRequester? = null,
    compact: Boolean = false,
    wide: Boolean = false,
    onClick: () -> Unit
) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val shape = RoundedCornerShape(12.dp)
    val bg = if (focused) accent else if (selected) accent.copy(alpha = 0.35f) else Color(0xFF18223A)
    Box(
        (if (wide) Modifier.fillMaxWidth() else Modifier)
            .clip(shape)
            .background(bg)
            .border(1.dp, if (focused || selected) accent else Color(0x44FFFFFF), shape)
            .then(
                if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier
            )
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = onClick)
            .padding(horizontal = if (compact) 14.dp else 22.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (focused) Ink else TextHi,
            fontSize = if (compact) 14.sp else 15.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RoundedFont
        )
    }
}

// ---------- Network dialog ----------

@Composable
private fun NetDialog(
    net: NetInfo,
    onClose: () -> Unit,
    onAskLocation: () -> Unit,
    onSettings: () -> Unit
) {
    val accent = LocalAccent.current
    val closeFocus = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { closeFocus.requestFocus() }
    }

    val shape = RoundedCornerShape(20.dp)

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            Modifier
                .width(500.dp)
                .clip(shape)
                .background(PanelDark)
                .border(1.dp, glassBorder, shape)
                .padding(30.dp)
        ) {
            Text(
                text = "NETWORK",
                color = accent,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 2.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = net.name,
                color = TextHi,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                style = glow(accent, 18f)
            )
            if (net.detail.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = net.detail,
                    color = TextLo,
                    fontSize = 15.sp,
                    fontFamily = RoundedFont
                )
            }
            if (net.needsLocation) {
                Spacer(Modifier.height(14.dp))
                Text(
                    text = "Android only shows the Wi-Fi name after location access is allowed.",
                    color = TextLo,
                    fontSize = 14.sp,
                    fontFamily = RoundedFont
                )
                Spacer(Modifier.height(12.dp))
                ChipButton("Allow access", true) { onAskLocation() }
            }
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                ChipButton("Wi-Fi settings", false) { onSettings() }
                ChipButton("Close", true, closeFocus) { onClose() }
            }
        }
    }
}

// ---------- Rain / snow over the weather photo ----------

@Composable
private fun WeatherFx(group: String) {
    if (group != "rain" && group != "storm" && group != "snow") return
    val snow = group == "snow"
    val t = rememberInfiniteTransition(label = "fx")
    val p by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (snow) 6000 else 1100, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "fxProgress"
    )
    Canvas(Modifier.fillMaxSize()) {
        for (i in 0 until 16) {
            val seed = ((i * 37) % 100) / 100f
            val x = (((i * 53) % 100) / 100f) * size.width
            val y = ((p + seed) % 1f) * (size.height + 20f) - 10f
            if (snow) {
                drawCircle(
                    color = Color(0xCCFFFFFF),
                    radius = 2.2f + (i % 3),
                    center = Offset(x + kotlin.math.sin((p * 6.28f + i).toDouble()).toFloat() * 8f, y)
                )
            } else {
                drawLine(Color(0x88CFE8FF), Offset(x, y), Offset(x - 4f, y + 14f), 1.5f)
            }
        }
    }
}

// ---------- Now playing card ----------

@Composable
private fun NowPlayingCard(info: MediaInfo, art: ImageBitmap?, onControl: (Int) -> Unit) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    var appIcon by remember(info.pkg) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(info.pkg) {
        appIcon = withContext(Dispatchers.IO) { Apps.icon(context.packageManager, info.pkg) }
    }
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .width(470.dp)
            .clip(shape)
            .background(glassFill)
            .border(1.dp, glassBorder, shape)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val cover = art ?: appIcon
        Box(
            Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0x33FFFFFF))
        ) {
            if (cover != null) {
                Image(
                    bitmap = cover,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = if (info.playing) "NOW PLAYING" else "PAUSED",
                color = accent,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 2.sp
            )
            Text(
                text = info.title,
                color = TextHi,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = info.artist,
                color = TextLo,
                fontSize = 12.sp,
                fontFamily = RoundedFont,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TransportButton(0, info.playing) { onControl(0) }
            TransportButton(1, info.playing) { onControl(1) }
            TransportButton(2, info.playing) { onControl(2) }
        }
    }
}

// kind: 0 = previous, 1 = play / pause, 2 = next
@Composable
private fun TransportButton(kind: Int, playing: Boolean, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(if (focused) accent else Color(0x26FFFFFF))
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        val c = if (focused) Ink else TextHi
        Canvas(Modifier.size(16.dp)) {
            val w = size.width
            val h = size.height
            if (kind == 0) {
                drawRect(c, Offset(0f, 0f), Size(w * 0.16f, h))
                val tri = Path()
                tri.moveTo(w, 0f)
                tri.lineTo(w * 0.28f, h / 2f)
                tri.lineTo(w, h)
                tri.close()
                drawPath(tri, c)
            } else if (kind == 2) {
                drawRect(c, Offset(w * 0.84f, 0f), Size(w * 0.16f, h))
                val tri = Path()
                tri.moveTo(0f, 0f)
                tri.lineTo(w * 0.72f, h / 2f)
                tri.lineTo(0f, h)
                tri.close()
                drawPath(tri, c)
            } else if (playing) {
                drawRect(c, Offset(w * 0.12f, 0f), Size(w * 0.28f, h))
                drawRect(c, Offset(w * 0.60f, 0f), Size(w * 0.28f, h))
            } else {
                val tri = Path()
                tri.moveTo(w * 0.15f, 0f)
                tri.lineTo(w, h / 2f)
                tri.lineTo(w * 0.15f, h)
                tri.close()
                drawPath(tri, c)
            }
        }
    }
}

// ---------- Forecast (tap the weather card) ----------

@Composable
private fun ForecastPanel(w: Weather?, onClose: () -> Unit) {
    val accent = LocalAccent.current
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { first.requestFocus() }
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF0060A14))
            .padding(horizontal = 40.dp, vertical = 24.dp)
    ) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Text(
                text = "FORECAST  ·  " + Config.CITY.uppercase(),
                color = accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 3.sp
            )
            Spacer(Modifier.height(14.dp))
            if (w == null) {
                Text(
                    text = "No weather data yet. Try again in a moment.",
                    color = TextLo,
                    fontSize = 15.sp,
                    fontFamily = RoundedFont
                )
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = w.temp.toString() + "°",
                        color = TextHi,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(text = w.emoji, fontSize = 32.sp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = w.label,
                            color = TextHi,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = RoundedFont
                        )
                        Text(
                            text = "Wind " + w.windMph + " mph   ·   Humidity " + w.humidity + "%",
                            color = TextLo,
                            fontSize = 12.sp,
                            fontFamily = RoundedFont
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                SectionLabel("NEXT HOURS")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    w.hours.forEach { h -> HourCell(h) }
                }
                Spacer(Modifier.height(16.dp))
                SectionLabel("NEXT DAYS")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    w.days.forEach { d -> DayCell(d, Modifier.weight(1f)) }
                }
            }
            Spacer(Modifier.height(18.dp))
            ChipButton("Close", true, first) { onClose() }
        }
    }
}

@Composable
private fun HourCell(h: HourForecast) {
    val accent = LocalAccent.current
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier
            .width(70.dp)
            .clip(shape)
            .background(glassFill)
            .border(1.dp, glassBorder, shape)
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = h.label, color = TextLo, fontSize = 11.sp, fontFamily = RoundedFont)
        Text(text = h.emoji, fontSize = 22.sp)
        Text(
            text = h.temp.toString() + "°",
            color = TextHi,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RoundedFont
        )
        Text(
            text = h.rain.toString() + "%",
            color = if (h.rain >= 40) accent else TextLo,
            fontSize = 10.sp,
            fontFamily = RoundedFont
        )
    }
}

@Composable
private fun DayCell(d: DayForecast, modifier: Modifier) {
    val accent = LocalAccent.current
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier
            .clip(shape)
            .background(glassFill)
            .border(1.dp, glassBorder, shape)
            .padding(vertical = 12.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = d.label,
            color = accent,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RoundedFont,
            letterSpacing = 1.sp
        )
        Text(text = d.emoji, fontSize = 26.sp)
        Text(
            text = d.text,
            color = TextLo,
            fontSize = 10.sp,
            fontFamily = RoundedFont,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = d.high.toString() + "° / " + d.low + "°",
            color = TextHi,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RoundedFont
        )
        Text(
            text = "Rain " + d.rain + "%",
            color = if (d.rain >= 40) accent else TextLo,
            fontSize = 10.sp,
            fontFamily = RoundedFont
        )
    }
}

// ---------- Clock style panel (click the clock) ----------

@Composable
private fun ClockPanel(cfg: ClockCfg, onChange: (ClockCfg) -> Unit, onClose: () -> Unit) {
    val accent = LocalAccent.current
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { first.requestFocus() }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0x66000000))
    ) {
        Column(
            Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .width(520.dp)
                .background(Color(0xF2080C18))
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            Text(
                text = "CLOCK STYLE",
                color = accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 3.sp
            )
            Text(
                text = "Changes show on the clock straight away.",
                color = TextLo,
                fontSize = 11.sp,
                fontFamily = RoundedFont,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(Modifier.height(14.dp))
            SectionLabel("FONT")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Thin", "Bold", "Mono", "Serif", "Black").forEachIndexed { i, name ->
                    ChipButton(name, cfg.style == i, if (i == cfg.style) first else null, compact = true) {
                        onChange(cfg.copy(style = i))
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            SectionLabel("SIZE")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Small", "Medium", "Large").forEachIndexed { i, name ->
                    ChipButton(name, cfg.size == i, compact = true) { onChange(cfg.copy(size = i)) }
                }
            }

            Spacer(Modifier.height(14.dp))
            SectionLabel("BACKGROUND BOX")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("None", "Glass", "Solid").forEachIndexed { i, name ->
                    ChipButton(name, cfg.box == i, compact = true) { onChange(cfg.copy(box = i)) }
                }
            }

            Spacer(Modifier.height(14.dp))
            SectionLabel("TEXT OPACITY")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("45%", "65%", "85%", "100%").forEachIndexed { i, name ->
                    ChipButton(name, cfg.alpha == i, compact = true) { onChange(cfg.copy(alpha = i)) }
                }
            }

            Spacer(Modifier.height(14.dp))
            SectionLabel("COLOR")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipButton("White", !cfg.accentColor, compact = true) { onChange(cfg.copy(accentColor = false)) }
                ChipButton("Theme color", cfg.accentColor, compact = true) { onChange(cfg.copy(accentColor = true)) }
            }

            Spacer(Modifier.height(14.dp))
            SectionLabel("FORMAT")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipButton("24-hour", cfg.h24, compact = true) { onChange(cfg.copy(h24 = !cfg.h24)) }
                ChipButton("Seconds", cfg.seconds, compact = true) { onChange(cfg.copy(seconds = !cfg.seconds)) }
            }

            Spacer(Modifier.height(14.dp))
            SectionLabel("SHOW UNDER THE CLOCK")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipButton("Date", (cfg.info and INFO_DATE) != 0, compact = true) {
                    onChange(cfg.copy(info = cfg.info xor INFO_DATE))
                }
                ChipButton("Sunrise & sunset", (cfg.info and INFO_SUN) != 0, compact = true) {
                    onChange(cfg.copy(info = cfg.info xor INFO_SUN))
                }
                ChipButton("Day length", (cfg.info and INFO_DAYLEN) != 0, compact = true) {
                    onChange(cfg.copy(info = cfg.info xor INFO_DAYLEN))
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipButton("Moon phase", (cfg.info and INFO_MOON) != 0, compact = true) {
                    onChange(cfg.copy(info = cfg.info xor INFO_MOON))
                }
                ChipButton("Tomorrow", (cfg.info and INFO_TOMORROW) != 0, compact = true) {
                    onChange(cfg.copy(info = cfg.info xor INFO_TOMORROW))
                }
            }

            Spacer(Modifier.height(20.dp))
            ChipButton("Done", true) { onClose() }
            Spacer(Modifier.height(12.dp))
        }
    }
}

// ---------- Choose which apps are on the home row ----------

@Composable
private fun TilePicker(
    tiles: List<String>,
    resumeTick: Int,
    onToggle: (String) -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val pm = context.packageManager
    val apps = remember(resumeTick) { Apps.installed(context) }
    val first = remember { FocusRequester() }

    LaunchedEffect(apps) {
        delay(250L)
        runCatching { first.requestFocus() }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF5060A14))
            .padding(horizontal = 40.dp, vertical = 24.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = "CHOOSE HOME APPS",
                        color = accent,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont,
                        letterSpacing = 3.sp
                    )
                    Text(
                        text = "OK adds or removes an app (tick = on the home row). Hold OK on a home tile to move it.",
                        color = TextLo,
                        fontSize = 11.sp,
                        fontFamily = RoundedFont,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                ChipButton("Done", true) { onClose() }
            }
            Spacer(Modifier.height(12.dp))
            LazyVerticalGrid(
                columns = GridCells.Adaptive(104.dp),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(8.dp)
            ) {
                itemsIndexed(apps) { index, app ->
                    var icon by remember(app.pkg) { mutableStateOf<ImageBitmap?>(null) }
                    LaunchedEffect(app.pkg) {
                        icon = withContext(Dispatchers.IO) { Apps.icon(pm, app.pkg) }
                    }
                    AppTile(
                        label = app.label,
                        accent = accent,
                        icon = icon,
                        modifier = Modifier.fillMaxWidth(),
                        badge = if (tiles.contains(app.pkg)) "✓" else null,
                        focusRequester = if (index == 0) first else null
                    ) {
                        onToggle(app.pkg)
                    }
                }
            }
        }
    }
}

// ---------- Hold OK on an app: info, uninstall, reorder ----------

@Composable
private fun AppMenu(
    pkg: String,
    onHome: Boolean,
    canLeft: Boolean,
    canRight: Boolean,
    onOpen: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit,
    onLeft: () -> Unit,
    onRight: () -> Unit,
    onToggleHome: () -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val pm = context.packageManager
    val label = Apps.label(pm, pkg)
    val system = Apps.isSystem(pm, pkg)
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(200L)
        runCatching { first.requestFocus() }
    }
    val shape = RoundedCornerShape(20.dp)

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            Modifier
                .width(380.dp)
                .clip(shape)
                .background(PanelDark)
                .border(1.dp, glassBorder, shape)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = label.uppercase(),
                color = accent,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 2.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            ChipButton("Open", false, first, wide = true) { onOpen() }
            ChipButton("App info", false, wide = true) { onInfo() }
            if (!system) {
                ChipButton("Uninstall", false, wide = true) { onUninstall() }
            }
            if (onHome) {
                if (canLeft) {
                    ChipButton("Move left", false, wide = true) { onLeft() }
                }
                if (canRight) {
                    ChipButton("Move right", false, wide = true) { onRight() }
                }
                ChipButton("Remove from home", false, wide = true) { onToggleHome() }
            } else {
                ChipButton("Add to home", false, wide = true) { onToggleHome() }
            }
            ChipButton("Close", true, wide = true) { onClose() }
        }
    }
}

// ---------- Updates from GitHub (only when you press the button) ----------

@Composable
private fun UpdatePanel(
    testBuilds: Boolean,
    onTestBuilds: (Boolean) -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val installed = remember { Updater.installedBuild(context) }
    var release by remember { mutableStateOf<ReleaseInfo?>(null) }
    var message by remember {
        mutableStateOf("Press Check now. Nothing is downloaded or installed unless you confirm.")
    }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(-1) }
    val first = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { first.requestFocus() }
    }

    val doCheck: () -> Unit = {
        if (!busy) {
            scope.launch {
                busy = true
                release = null
                message = "Checking GitHub..."
                val res = withContext(Dispatchers.IO) { Updater.fetchLatest(testBuilds) }
                release = res.first
                message = if (res.first == null) res.second else ""
                busy = false
            }
        }
    }

    val doDownload: () -> Unit = {
        val rel = release
        if (rel != null && !busy) {
            if (!rel.apkUrl.startsWith("https://github.com/")) {
                message = "Unexpected download address, stopped."
            } else {
                scope.launch {
                    busy = true
                    progress = 0
                    message = "Downloading..."
                    val file = withContext(Dispatchers.IO) {
                        Updater.download(context, rel.apkUrl) { pct -> progress = pct }
                    }
                    progress = -1
                    if (file == null) {
                        message = "Download failed. Check the connection and try again."
                    } else if (!Updater.canInstall(context)) {
                        message = "Allow this app to install apps, then come back and press Download again."
                        Updater.openInstallPermission(context)
                    } else if (Updater.install(context, file)) {
                        message = "Installer opened. Confirm there to finish the update."
                    } else {
                        message = "Could not start the installer."
                    }
                    busy = false
                }
            }
        }
    }

    val r = release
    val newer = r != null && r.build > installed

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF5060A14))
            .padding(horizontal = 40.dp, vertical = 24.dp)
    ) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Text(
                text = "UPDATES",
                color = accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                letterSpacing = 3.sp
            )
            Spacer(Modifier.height(14.dp))
            Text(
                text = "Installed: build " + installed + "   ·   v" + Config.VERSION,
                color = TextHi,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Source: github.com/" + Config.GITHUB_REPO + ". Checked only when you press the button. Stable releases only, unless test builds are on.",
                color = TextLo,
                fontSize = 12.sp,
                fontFamily = RoundedFont
            )
            Spacer(Modifier.height(16.dp))
            if (message.isNotEmpty()) {
                Text(
                    text = message,
                    color = TextHi,
                    fontSize = 15.sp,
                    fontFamily = RoundedFont
                )
            }
            if (r != null) {
                if (newer) {
                    Text(
                        text = "New: " + r.name + "   (build " + r.build + ", " +
                            (Math.round(r.sizeMb * 10.0) / 10.0).toString() + " MB)",
                        color = accent,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont
                    )
                    if (r.notes.isNotEmpty()) {
                        Text(
                            text = r.notes,
                            color = TextLo,
                            fontSize = 12.sp,
                            fontFamily = RoundedFont
                        )
                    }
                } else {
                    Text(
                        text = "You are up to date (newest is " + r.name + ").",
                        color = TextHi,
                        fontSize = 15.sp,
                        fontFamily = RoundedFont
                    )
                }
            }
            if (progress >= 0) {
                Text(
                    text = "Downloading " + progress + "%",
                    color = accent,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RoundedFont
                )
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ChipButton("Check now", false, first) { doCheck() }
                if (newer) {
                    ChipButton("Download and install", true) { doDownload() }
                }
                ChipButton(if (testBuilds) "Test builds: ON" else "Test builds: OFF", testBuilds) {
                    onTestBuilds(!testBuilds)
                }
                ChipButton("Close", true) { onClose() }
            }
        }
    }
}
