package com.streamerhome.launcher

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {

    private var permissionTick by mutableIntStateOf(0)
    private var resumeTick by mutableIntStateOf(0)
    private var wallpaperTick by mutableIntStateOf(0)
    private var mediaTick by mutableIntStateOf(0)
    private var audioTick by mutableIntStateOf(0)

    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            permissionTick++
        }

    private val mediaPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            mediaTick++
        }

    private val audioPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            audioTick++
        }

    private val homeRole =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            resumeTick++
        }

    // Android does not let an app make itself the default launcher silently: ask for the Home role,
    // fall back to the system "Home app" screen, then to the Home chooser.
    private fun requestDefaultHome() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    if (rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                        Toast.makeText(this, "Sonik Launcher is already the default", Toast.LENGTH_SHORT).show()
                    } else {
                        homeRole.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                    }
                    return
                }
            }
        } catch (e: Exception) {
            // try the next way
        }
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            return
        } catch (e: Exception) {
            // try the next way
        }
        try {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(this, "Not possible on this device. See the adb command in Settings > System.", Toast.LENGTH_LONG).show()
        }
    }

    // System file picker: the chosen picture is saved as the fixed wallpaper (1920 x 1080)
    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                val app = applicationContext
                Thread {
                    val ok = Wallpaper.saveFromUri(app, uri)
                    runOnUiThread {
                        if (ok) {
                            Prefs.setWallMode(app, 1)
                            wallpaperTick++
                        }
                        Toast.makeText(
                            app,
                            if (ok) "Wallpaper saved" else "Could not use that picture",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }.start()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            HomeScreen(
                permissionTick = permissionTick,
                resumeTick = resumeTick,
                wallpaperTick = wallpaperTick,
                mediaTick = mediaTick,
                audioTick = audioTick,
                onAskLocation = {
                    locationPermission.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                },
                onAskMedia = {
                    mediaPermission.launch(Wallpaper.mediaPermission())
                },
                onAskAudio = {
                    audioPermission.launch(Manifest.permission.RECORD_AUDIO)
                },
                onSetDefaultHome = { requestDefaultHome() },
                onPickFile = {
                    try {
                        pickImage.launch("image/*")
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "No file picker on this device", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }
}
