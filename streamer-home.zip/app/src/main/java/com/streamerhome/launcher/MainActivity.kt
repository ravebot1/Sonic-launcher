package com.streamerhome.launcher

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {

    private var permissionTick by
        mutableIntStateOf(0)

    private var resumeTick by
        mutableIntStateOf(0)

    private val locationPermission =
        registerForActivityResult(
            ActivityResultContracts
                .RequestPermission()
        ) {
            permissionTick++
        }

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {

        super.onCreate(savedInstanceState)

        setContent {

            HomeScreen(
                permissionTick = permissionTick,
                resumeTick = resumeTick,
                onAskLocation = {

                    locationPermission.launch(
                        Manifest.permission.ACCESS_FINE_LOCATION
                    )
                }
            )
        }
    }

    override fun onResume() {

        super.onResume()

        resumeTick++
    }
}