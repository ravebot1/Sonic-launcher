package com.streamerhome.launcher

data class TileSpec(
    val label: String,
    val packages: List<String>,
    val accent: Long
)

object Config {

    const val CITY = "London"

    const val LATITUDE = 51.55
    const val LONGITUDE = 0.05

    const val WEATHER_REFRESH_MS =
        30L * 60L * 1000L

    const val NASA_API_KEY = "DEMO_KEY"

    const val LONDON_CATEGORY =
        "Featured_pictures_of_London"

    const val BG_INTERVAL_MS =
        7L * 60L * 1000L

    const val LONDON_INTERVAL_MS =
        45_000L

    val tiles = listOf(

        TileSpec(
            "YouTube",
            listOf(
                "com.google.android.youtube.tv",
                "com.google.android.youtube"
            ),
            0xFFFF4B4BL
        ),

        TileSpec(
            "Stremio",
            listOf(
                "com.stremio.one"
            ),
            0xFF8B5CF6L
        ),

        TileSpec(
            "Deezer",
            listOf(
                "deezer.android.tv",
                "deezer.android.app"
            ),
            0xFFA238FFL
        ),

        TileSpec(
            "OTT Navigator",
            listOf(
                "studio.scillarium.ottnavigator"
            ),
            0xFF22C55EL
        )
    )
}