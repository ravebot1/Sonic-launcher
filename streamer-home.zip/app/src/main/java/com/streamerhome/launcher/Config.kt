package com.streamerhome.launcher

data class TileSpec(
    val label: String,
    // First package in the list that is installed on the device is used.
    val packages: List<String>,
    val accent: Long
)

object Config {
    const val VERSION = "1.9.10"
    // versionCode = BUILD_OFFSET + CI run number (keeps every new build above older ones)
    const val BUILD_OFFSET = 1000
    const val GITHUB_REPO = "ravebot1/launcher"

    // Weather location (change to your own coordinates).
    const val CITY = "London"
    const val LATITUDE = 51.55
    const val LONGITUDE = 0.05

    const val WEATHER_REFRESH_MS = 30L * 60L * 1000L
    // The photo on the weather card changes every 30 minutes.
    const val WEATHER_PHOTO_INTERVAL_MS = 30L * 60L * 1000L

    // Online images
    const val NASA_API_KEY = "DEMO_KEY"
    const val LONDON_CATEGORY = "Featured_pictures_of_London"

    // Home-screen tiles. Edit labels / package names here.
    val tiles = listOf(
        TileSpec("YouTube", listOf("com.google.android.youtube.tv", "com.google.android.youtube"), 0xFFFF4B4BL),
        TileSpec("Stremio", listOf("com.stremio.one"), 0xFF8B5CF6L),
        TileSpec("Deezer", listOf("deezer.android.tv", "deezer.android.app"), 0xFFA238FFL),
        TileSpec("OTT Navigator", listOf("studio.scillarium.ottnavigator"), 0xFF22C55EL)
    )
}
