package com.streamerhome.launcher

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.drawBehind
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.ScrollState
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import android.net.Uri
import android.widget.Toast
import kotlinx.coroutines.launch
import kotlinx.coroutines.CoroutineScope
import androidx.compose.ui.input.key.onPreviewKeyEvent
import java.time.LocalDate
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.animation.animateColorAsState
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.Constraints
import kotlin.math.roundToInt
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

// ---------- Look & feel ----------

private val LocalAccent = compositionLocalOf { Color(0xFF4FE3FF) }
private val LocalIconStyle = compositionLocalOf { 0 }

private val Ink = Color(0xFF060A14)
private val PanelDark = Color(0xFF0E1626)
private val TextHi = Color(0xFFF2F7FF)
private val TextLo = Color(0xFFA5B4CC)

// Compose has no built-in rounded font; SansSerif is the closest safe choice.
private val RoundedFont: FontFamily = FontFamily.SansSerif

private val glassBorder = Brush.linearGradient(listOf(Color(0x80FFFFFF), Color(0x14FFFFFF)))
private val glassFill = Brush.linearGradient(listOf(Color(0x3DFFFFFF), Color(0x0FFFFFFF)))
private val glassFillFocused = Brush.linearGradient(listOf(Color(0x70FFFFFF), Color(0x2AFFFFFF)))

private val timeFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val time12Fmt: DateTimeFormatter = DateTimeFormatter.ofPattern("h:mm")
private val dateFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE, d MMMM")

private fun glow(color: Color, blur: Float = 16f) = TextStyle(
    shadow = Shadow(color = color.copy(alpha = 0.6f), offset = Offset.Zero, blurRadius = blur)
)

// Down goes straight to the given focus target (the app tiles or the playback card)

// Where the focused button sits. Left at the start of a row goes back; anywhere else it moves along the row.
private object FocusTrack {
    @Volatile var left = 0f
    @Volatile var cardLeft = 0f
    fun atRowStart(): Boolean = left <= cardLeft + 4f
}

private fun Modifier.trackLeft(focused: Boolean): Modifier = composed {
    val l = remember { FloatArray(1) }
    this
        .onGloballyPositioned {
            l[0] = it.boundsInRoot().left
            if (focused) FocusTrack.left = l[0]
        }
        .onFocusChanged { if (it.isFocused) FocusTrack.left = l[0] }
}

// Soft tick on every D-pad press (Settings > Look > Sounds)
private fun Modifier.navSound(): Modifier = this.onPreviewKeyEvent { ev ->
    if (ev.type == KeyEventType.KeyDown) {
        when (ev.nativeKeyEvent.keyCode) {
            android.view.KeyEvent.KEYCODE_DPAD_UP, android.view.KeyEvent.KEYCODE_DPAD_DOWN, android.view.KeyEvent.KEYCODE_DPAD_LEFT, android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> Sfx.move()
        }
    }
    false
}

// Wi-Fi button at a screen edge: the key toward the tiles goes straight to them, the other way does nothing
private fun Modifier.edgeKeys(target: FocusRequester, atBottom: Boolean): Modifier = composed {
    val fm = LocalFocusManager.current
    this.onPreviewKeyEvent { ev ->
        if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
        val k = ev.nativeKeyEvent.keyCode
        val toward = if (atBottom) android.view.KeyEvent.KEYCODE_DPAD_UP else android.view.KeyEvent.KEYCODE_DPAD_DOWN
        val away = if (atBottom) android.view.KeyEvent.KEYCODE_DPAD_DOWN else android.view.KeyEvent.KEYCODE_DPAD_UP
        if (k == toward) {
            runCatching { target.requestFocus() }.isSuccess ||
                fm.moveFocus(if (atBottom) FocusDirection.Up else FocusDirection.Down)
        } else {
            k == away
        }
    }
}

// Lets the Settings dialog take Back one step (page -> category list) before it closes
private object SettingsBack {
    @Volatile var handler: (() -> Boolean)? = null
    fun handle(): Boolean = handler?.invoke() == true
}

// Settings reopens on the category you left
private object SettingsMemo { var cat = 0 }

private val BACK_LABELS = setOf("Close", "Done", "Cancel")

private fun Modifier.downTo(target: FocusRequester): Modifier = composed {
    val fm = LocalFocusManager.current
    this.onPreviewKeyEvent { ev ->
        if (ev.type == KeyEventType.KeyDown && ev.nativeKeyEvent.keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN) {
            runCatching { target.requestFocus() }.isSuccess || fm.moveFocus(FocusDirection.Down)
        } else {
            false
        }
    }
}

private fun Modifier.glass(shape: Shape): Modifier =
    this.clip(shape).background(glassFill).border(1.dp, glassBorder, shape)

// Focusable + click + long-press. Holding OK / Enter on the remote repeats the key: that is the long press.
// The long-press action runs when the button is RELEASED. If it ran during the hold, the menu window would
// take focus and receive the release, which could trigger "Open" by accident.
private fun Modifier.tvClickable(
    source: MutableInteractionSource,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
): Modifier = composed {
    var longPending by remember { mutableStateOf(false) }
    this
        .focusable(interactionSource = source)
        .onKeyEvent { ev ->
            val native = ev.nativeKeyEvent
            val code = native.keyCode
            val select = code == android.view.KeyEvent.KEYCODE_DPAD_CENTER ||
                code == android.view.KeyEvent.KEYCODE_ENTER ||
                code == android.view.KeyEvent.KEYCODE_NUMPAD_ENTER
            if (!select) {
                false
            } else if (ev.type == KeyEventType.KeyDown) {
                if (native.repeatCount == 0) {
                    longPending = false
                } else if (onLongClick != null) {
                    longPending = true
                }
                true
            } else if (ev.type == KeyEventType.KeyUp) {
                val wasLong = longPending
                longPending = false
                Sfx.click()
                if (wasLong && onLongClick != null) onLongClick() else onClick()
                true
            } else {
                false
            }
        }
}

// anim: 0 = full, 1 = reduced, 2 = off
private fun panelEnter(anim: Int): EnterTransition =
    if (anim == 2) EnterTransition.None
    else fadeIn(tween(220)) + scaleIn(animationSpec = tween(220), initialScale = 0.94f)

private fun panelExit(anim: Int): ExitTransition =
    if (anim == 2) ExitTransition.None
    else fadeOut(tween(160)) + scaleOut(animationSpec = tween(160), targetScale = 0.96f)

// Staggered fade / slide-in when the launcher opens
@Composable
private fun Entrance(
    delayMs: Int,
    anim: Int,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    var shown by remember { mutableStateOf(anim == 2) }
    LaunchedEffect(Unit) {
        if (!shown) {
            delay(delayMs.toLong())
            shown = true
        }
    }
    val a by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = tween(if (anim == 0) 700 else 250),
        label = "enterAlpha"
    )
    val dy by animateFloatAsState(
        targetValue = if (shown || anim != 0) 0f else 28f,
        animationSpec = tween(700),
        label = "enterY"
    )
    Box(
        modifier.graphicsLayer {
            alpha = a
            translationY = dy * density
        }
    ) {
        content()
    }
}

// Sky colours used behind the weather photo (and while it loads)
private fun skyColors(isDay: Boolean, group: String): Pair<Color, Color> = when {
    !isDay && (group == "rain" || group == "storm") -> Pair(Color(0xFF0D1422), Color(0xFF2A3548))
    !isDay -> Pair(Color(0xFF0A1230), Color(0xFF22306A))
    group == "clear" -> Pair(Color(0xFF2F78C8), Color(0xFF8FC8F5))
    group == "rain" -> Pair(Color(0xFF34455A), Color(0xFF63778D))
    group == "storm" -> Pair(Color(0xFF2A2D44), Color(0xFF55506E))
    group == "snow" -> Pair(Color(0xFF8CA2B9), Color(0xFFDCE5EE))
    group == "fog" -> Pair(Color(0xFF7A858F), Color(0xFFB9C1C8))
    else -> Pair(Color(0xFF55697E), Color(0xFF9AAABA))
}

// (kept as a pass-through so call sites stay simple)
@Composable
private fun WithBringSpec(marginDp: Int, ms: Int, content: @Composable () -> Unit) {
    content()
}

// ---------- Home screen ----------

@Composable
fun HomeScreen(
    permissionTick: Int,
    resumeTick: Int,
    wallpaperTick: Int,
    mediaTick: Int,
    audioTick: Int,
    onAskLocation: () -> Unit,
    onAskMedia: () -> Unit,
    onAskAudio: () -> Unit,
    onSetDefaultHome: () -> Unit,
    onPickFile: () -> Unit
) {
    val context = LocalContext.current
    val pm = context.packageManager

    var showApps by remember { mutableStateOf(false) }
    var showNet by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showForecast by remember { mutableStateOf(false) }
    var showClock by remember { mutableStateOf(false) }
    var showPicker by remember { mutableStateOf(false) }
    var showUpdate by remember { mutableStateOf(false) }
    var showGallery by remember { mutableStateOf(false) }
    var showWeatherCfg by remember { mutableStateOf(false) }
    var showLocal by remember { mutableStateOf(false) }
    var showChangelog by remember { mutableStateOf(false) }
    var backToForecast by remember { mutableStateOf(false) }
    var wxCfg by remember { mutableStateOf(Prefs.weather(context)) }
    var backToSettings by remember { mutableStateOf(false) }
    var menuPkg by remember { mutableStateOf<String?>(null) }

    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var weather by remember { mutableStateOf<Weather?>(null) }
    var net by remember { mutableStateOf(NetworkReader.read(context)) }

    var themeIdx by remember { mutableIntStateOf(Prefs.themeIndex(context)) }
    var intervalMin by remember { mutableIntStateOf(Prefs.intervalMin(context)) }
    var cats by remember { mutableIntStateOf(Prefs.categories(context)) }
    var anim by remember { mutableIntStateOf(Prefs.anim(context)) }
    var clockCfg by remember { mutableStateOf(Prefs.clock(context)) }
    var tilesPref by remember { mutableStateOf(Prefs.tiles(context)) }
    var testBuilds by remember { mutableStateOf(Prefs.testBuilds(context)) }
    var tileIdx by remember { mutableIntStateOf(Prefs.tileSize(context)) }
    var recentCount by remember { mutableIntStateOf(Prefs.recentCount(context)) }
    var recents by remember { mutableStateOf(Recent.list(context)) }
    var res4k by remember { mutableStateOf(Prefs.res4k(context)) }
    Remote.fourK = res4k
    var sounds by remember { mutableIntStateOf(Prefs.soundMode(context)) }
    Sfx.mode = sounds
    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { Sfx.init() } }
    Remote.tmdbKey = Prefs.tmdbKey(context)
    var autoAccent by remember { mutableStateOf(Prefs.autoAccent(context)) }
    var tileStyle by remember { mutableIntStateOf(Prefs.tileStyle(context)) }
    var wifiPos by remember { mutableIntStateOf(Prefs.wifiPos(context)) }
    var ambient by remember { mutableStateOf(Prefs.ambient(context)) }
    var nightMode by remember { mutableIntStateOf(Prefs.nightDim(context)) }
    var wallBmp by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var rootSize by remember { mutableStateOf(IntSize.Zero) }
    var clockPos by remember { mutableStateOf(Offset.Zero) }
    var contrast by remember { mutableStateOf<ContrastMap?>(null) }
    var wallUrl by remember { mutableStateOf<String?>(null) }
    var animStyle by remember { mutableIntStateOf(Prefs.animStyle(context)) }
    var wallTick by remember { mutableIntStateOf(0) }
    var vizStyle by remember { mutableIntStateOf(Prefs.vizStyle(context)) }
    val vizBands = remember { mutableStateOf(FloatArray(AudioViz.BANDS)) }
    val vizPeaks = remember { mutableStateOf(FloatArray(AudioViz.BANDS)) }
    var roomTemp by remember { mutableStateOf<String?>(null) }
    var roomTick by remember { mutableIntStateOf(0) }
    var textReq by remember { mutableStateOf<TextReq?>(null) }
    var pickReq by remember { mutableStateOf<PickReq?>(null) }
    val audioGranted = remember(audioTick) { AudioViz.hasPermission(context) }
    var glowRect by remember { mutableStateOf<Rect?>(null) }
    var glowKey by remember { mutableStateOf("") }
    var wallAccent by remember { mutableStateOf<Color?>(null) }
    var glowColor by remember { mutableStateOf<Color?>(null) }
    var isDefaultHome by remember { mutableStateOf(false) }
    LaunchedEffect(resumeTick) { isDefaultHome = withContext(Dispatchers.IO) { HomeRole.isDefault(context) } }
    val firstTile = remember { FocusRequester() }
    val playFocus = remember { FocusRequester() }
    val scope = rememberCoroutineScope()
    var wallMode by remember {
        mutableIntStateOf(Prefs.wallMode(context).let { if (it == 1 && !Wallpaper.exists(context)) 0 else it })
    }
    var fixedWall by remember { mutableStateOf<ImageBitmap?>(null) }
    var fixedVersion by remember { mutableIntStateOf(0) }

    var media by remember { mutableStateOf<MediaInfo?>(null) }
    var mediaArt by remember { mutableStateOf<ImageBitmap?>(null) }
    var mediaKey by remember { mutableStateOf("") }
    var mediaAccess by remember { mutableStateOf(false) }

    // Apps shown on the home row (saved order, only the ones that are installed)
    val tiles: List<String> = remember(resumeTick, tilesPref) {
        val base = tilesPref ?: Config.tiles.mapNotNull { Apps.firstInstalled(pm, it.packages) }
        base.filter { Apps.launchIntent(pm, it) != null }.distinct()
    }

    val saveTiles = { list: List<String> ->
        tilesPref = list
        Prefs.setTiles(context, list)
    }

    // Closes a sub-panel; returns to Settings when it was opened from there
    val closeSub: () -> Unit = {
        Sfx.back()
        showForecast = false
        showClock = false
        showPicker = false
        showUpdate = false
        showGallery = false
        showWeatherCfg = false
        showLocal = false
        showChangelog = false
        if (backToForecast) {
            backToForecast = false
            showForecast = true
        } else if (backToSettings) {
            backToSettings = false
            showSettings = true
        }
    }

    val overlayOpen = showApps || showSettings || showForecast || showClock ||
        showPicker || showUpdate || showGallery || showWeatherCfg || showLocal || showChangelog || menuPkg != null

    // Safety net: if focus is ever lost on the home screen (a focused card or tile left the screen), put it back
    var colFocus by remember { mutableStateOf(true) }
    var wifiFocus by remember { mutableStateOf(false) }
    val busyNow by rememberUpdatedState(overlayOpen || showNet || textReq != null || pickReq != null)
    val fmHome = LocalFocusManager.current
    LaunchedEffect(Unit) {
        var misses = 0
        while (isActive) {
            delay(400L)
            if (busyNow || colFocus || wifiFocus) {
                misses = 0
            } else if (++misses >= 2) {
                misses = 0
                if (runCatching { firstTile.requestFocus() }.isFailure) fmHome.moveFocus(FocusDirection.Next)
            }
        }
    }

    // A launcher should never "go back" to anything; Back only closes open panels.
    BackHandler {
        if (menuPkg != null) {
            menuPkg = null
        } else if (showForecast || showClock || showPicker || showUpdate || showGallery || showWeatherCfg || showLocal || showChangelog) {
            closeSub()
        } else if (showSettings && SettingsBack.handle()) {
            // handled inside Settings
        } else {
            if (showSettings || showApps) Sfx.back()
            showSettings = false
            showApps = false
        }
    }

    LaunchedEffect(Unit) {
        while (isActive) {
            now = LocalDateTime.now()
            delay(15_000L)
        }
    }

    LaunchedEffect(wxCfg.refreshMin) {
        while (isActive) {
            val w = withContext(Dispatchers.IO) { WeatherApi.fetch() }
            if (w != null) weather = w
            delay(if (w != null) wxCfg.refreshMin * 60_000L else 60_000L)
        }
    }

    LaunchedEffect(permissionTick, resumeTick) {
        while (isActive) {
            net = withContext(Dispatchers.IO) { NetworkReader.read(context) }
            delay(4000L)
        }
    }

    // What is playing (needs notification access, see Settings)
    LaunchedEffect(resumeTick) {
        while (isActive) {
            val access = withContext(Dispatchers.IO) { NowPlaying.hasAccess(context) }
            mediaAccess = access
            var m = if (access) withContext(Dispatchers.IO) { NowPlaying.read(context) } else null
            if (m != null) {
                NowPlaying.remember(context, m)
            } else if (access) {
                // the app dropped its session (e.g. after Back): keep the card for 10 minutes, play reopens the app
                m = withContext(Dispatchers.IO) { NowPlaying.last(context) }
            }
            val k = if (m == null) "" else m.pkg + "|" + m.title + "|" + m.artist + "|" + m.playing + "|" + (m.art != null)
            if (k != mediaKey) {
                mediaKey = k
                media = m
                mediaArt = m?.art?.asImageBitmap()
            }
            val saved = withContext(Dispatchers.IO) { Recent.list(context) }
            if (saved != recents) recents = saved
            delay(2000L)
        }
    }

    val vizOn = vizStyle != 0 && media?.playing == true
    LaunchedEffect(vizOn, audioTick) {
        if (vizOn) {
            withContext(Dispatchers.IO) { AudioViz.start(context) }
            val buf = FloatArray(AudioViz.BANDS)
            while (isActive) {
                withContext(Dispatchers.Default) { AudioViz.read(buf, android.os.SystemClock.uptimeMillis()) }
                vizBands.value = buf.copyOf()
                vizPeaks.value = AudioViz.peaks.copyOf()
                delay(40L)
            }
        } else {
            AudioViz.stop()
            vizBands.value = FloatArray(AudioViz.BANDS)
            vizPeaks.value = FloatArray(AudioViz.BANDS)
        }
    }
    DisposableEffect(Unit) { onDispose { AudioViz.stop() } }
    LaunchedEffect(roomTick, clockCfg.info) {
        if ((clockCfg.info and INFO_ROOM) != 0) {
            while (isActive) {
                roomTemp = withContext(Dispatchers.IO) { RoomTemp.fetch(context) }
                delay(if (roomTemp != null) 60_000L else 20_000L)
            }
        } else {
            roomTemp = null
        }
    }

    LaunchedEffect(wallMode, fixedVersion) {
        if (wallMode == 2) wallBmp = null
        fixedWall = if (wallMode == 1) withContext(Dispatchers.IO) { Wallpaper.loadFixed(context) } else null
        fixedWall?.let {
            wallAccent = Tint.vibrant(it.asAndroidBitmap())
            wallBmp = it.asAndroidBitmap()
        }
    }

    // A picture chosen with the system file picker was saved by the activity
    LaunchedEffect(wallpaperTick) {
        if (wallpaperTick > 0) {
            wallMode = Prefs.wallMode(context)
            fixedVersion++
        }
    }

    val theme = Themes[themeIdx.coerceIn(0, Themes.size - 1)]
    val accentTarget = if (autoAccent) (wallAccent ?: theme.accent) else theme.accent
    val accentColor by animateColorAsState(accentTarget, tween(if (anim == 2) 0 else 900), label = "accent")
    val glowTarget = (glowColor ?: accentColor).copy(alpha = if (ambient) 0.26f else 0f)
    val glowFill by animateColorAsState(glowTarget, tween(if (anim == 2) 0 else 500), label = "glow")

    // London wallpapers follow the time of day and the weather
    val tod = timeOfDay(now.hour * 60 + now.minute, weather)
    val group = weather?.group ?: "cloud"
    val homeDown = if (media != null) playFocus else firstTile
    val wallKey = (if ((cats and CAT_LONDON) != 0) cats.toString() + "|" + tod + "|" + group else cats.toString()) + (if (res4k) "|4k" else "") + "|" + wallTick

    CompositionLocalProvider(LocalAccent provides accentColor, LocalIconStyle provides wxCfg.icons) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Ink)
                .navSound()
                .onSizeChanged { rootSize = it }
        ) {
            // Accent glow, visible until the first wallpaper loads
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            listOf(accentColor.copy(alpha = 0.28f), Color.Transparent)
                        )
                    )
            )

            // Online wallpaper (slow zoom when animations are on)
            val fw = fixedWall
            if (wallMode == 2) {
                AnimatedWallpaper(animStyle, tod, accentColor, anim, Modifier.fillMaxSize())
            } else if (wallMode == 1 && fw != null) {
                Image(
                    bitmap = fw,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                RotatingImage(
                    modifier = Modifier.fillMaxSize(),
                    maxSide = if (res4k) 3840 else 2200,
                    onLoaded = { b ->
                        wallAccent = Tint.vibrant(b)
                        wallBmp = b
                    },
                    onShown = { wallUrl = it },
                    intervalMs = intervalMin * 60_000L,
                    key = wallKey,
                    kenBurns = anim == 0 && !clockCfg.blend,
                    minSide = if (res4k) 3000 else 1400
                ) {
                    Remote.backgroundUrls(cats, tod, group)
                }
            }

            // Darkening for readability
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0x99060A14), Color(0x40060A14), Color(0xB3060A14))
                        )
                    )
            )

            // Night mode: same wallpaper, darker and cooler after sunset
            val dimBase = when (nightMode) {
                1 -> 0.35f
                2 -> 0.55f
                else -> 0f
            }
            val dimTarget = dimBase * when (tod) {
                "night" -> 1f
                "sunrise", "sunset" -> 0.4f
                else -> 0f
            }
            val dimA by animateFloatAsState(dimTarget, tween(if (anim == 2) 0 else 3000), label = "nightDim")
            Box(Modifier.fillMaxSize().background(Color(0xFF040818).copy(alpha = dimA)))

            // Clock "Adapt to wallpaper": colours per area, worked out off the main thread
            LaunchedEffect(clockCfg.blend, wallBmp, rootSize, dimTarget) {
                val b = wallBmp
                contrast = if (clockCfg.blend && b != null && rootSize.width > 0) {
                    withContext(Dispatchers.Default) { Tint.contrast(b, rootSize.width, rootSize.height, dimTarget) }
                } else {
                    null
                }
            }

            // Ambient glow in the colour of the focused app
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(0.74f to Color.Transparent, 1f to glowFill))
            )

            // Music visualiser along the bottom while something plays
            val vizA by animateFloatAsState(if (vizOn) 1f else 0f, tween(500), label = "vizAlpha")
            if (vizStyle != 0 && vizA > 0.01f) {
                VizStrip(
                    style = vizStyle,
                    bands = vizBands,
                    peaks = vizPeaks,
                    color = accentColor,
                    modifier = (if (vizStyle == 6) Modifier.fillMaxSize() else Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .height(220.dp))
                        .alpha(vizA * 0.8f)
                )
            }

            // Glow around the focused tile, drawn on the whole screen so no list can cut it off
            if (!overlayOpen) {
                Canvas(Modifier.fillMaxSize()) {
                    val gr = glowRect ?: return@Canvas
                    val grow = gr.width * 0.06f
                    for (i in 1..6) {
                        val e = grow + i * 2.4f.dp.toPx()
                        drawRoundRect(
                            color = accentColor.copy(alpha = 0.15f - i * 0.022f),
                            topLeft = Offset(gr.left - e, gr.top - e),
                            size = Size(gr.width + 2 * e, gr.height + 2 * e),
                            cornerRadius = CornerRadius(16.dp.toPx() + e)
                        )
                    }
                }
            }

            Column(
                Modifier
                    .fillMaxSize()
                    .onFocusChanged { colFocus = it.hasFocus }
                    .focusProperties { canFocus = !overlayOpen }
                    .padding(horizontal = 40.dp, vertical = 24.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Entrance(0, anim) {
                        ClockBlock(clockCfg, weather, homeDown, contrast, clockPos, { clockPos = it }, roomTemp) { showClock = true }
                    }

                    Spacer(Modifier.weight(1f))

                    Entrance(120, anim) {
                        WeatherPanel(weather, wxCfg, anim, tod, homeDown) { showForecast = true }
                    }

                    if (wifiPos == 0) {
                        Spacer(Modifier.width(16.dp))
                        Entrance(240, anim) {
                            WifiButton(net, homeDown, false) { showNet = true }
                        }
                    }
                }

                Spacer(Modifier.weight(1f))

                // Cinema wallpaper: trailer button
                val movie = if (wallMode == 0) Remote.movieFor(wallUrl) else null
                if (movie != null) {
                    MovieChip(movie, homeDown, Modifier.align(Alignment.Start)) {
                        scope.launch {
                            Toast.makeText(context, "Finding the trailer...", Toast.LENGTH_SHORT).show()
                            val id = withContext(Dispatchers.IO) { Cinema.trailerId(movie.id) }
                            if (id == null || !Cinema.open(context, id)) {
                                Toast.makeText(context, "No trailer found", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }

                // "Now playing" card, only while something is playing or paused
                AnimatedVisibility(
                    visible = media != null,
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    enter = fadeIn(tween(300)) + slideInVertically(initialOffsetY = { it / 2 }),
                    exit = fadeOut(tween(200)) + slideOutVertically(targetOffsetY = { it / 2 })
                ) {
                    val mi = media
                    if (mi != null) {
                        Column {
                            NowPlayingCard(mi, mediaArt, playFocus, firstTile) { action ->
                                NowPlaying.control(context, mi.pkg, action)
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }

                Entrance(360, anim, Modifier.fillMaxWidth()) {
                    AppRow(
                        tiles = tiles,
                        recents = recents.take(recentCount),
                        tileDp = TILE_SIZES[tileIdx.coerceIn(0, TILE_SIZES.size - 1)],
                        bannerMode = tileStyle == 1,
                        onGlow = { glowColor = it },
                        onGlowRect = { k, rc ->
                            if (rc != null) {
                                glowKey = k
                                glowRect = rc
                            } else if (glowKey == k) {
                                glowRect = null
                            }
                        },
                        overlayOpen = overlayOpen,
                        anim = anim,
                        firstTile = firstTile,
                        onAllApps = { showApps = true },
                        onSettings = { showSettings = true },
                        onMenu = { pkg -> menuPkg = pkg }
                    )
                }

            }

            if (wifiPos in 1..3) {
                Box(
                    Modifier
                        .align(
                            when (wifiPos) {
                                1 -> Alignment.TopStart
                                2 -> Alignment.BottomStart
                                else -> Alignment.BottomEnd
                            }
                        )
                        .padding(10.dp)
                        .onFocusChanged { wifiFocus = it.hasFocus }
                        .focusProperties { canFocus = !overlayOpen }
                ) {
                    WifiButton(net, if (wifiPos >= 2) firstTile else homeDown, wifiPos >= 2) { showNet = true }
                }
            }

            if (showApps) PanelWindow(anim, onDismiss = { showApps = false }) {
                AllApps(
                    resumeTick = resumeTick,
                    tiles = tiles,
                    onMenu = { pkg -> menuPkg = pkg },
                    onClose = { showApps = false }
                )
            }

            if (showSettings) PanelWindow(anim, onDismiss = { if (!SettingsBack.handle()) showSettings = false }) {
                SettingsScreen(
                    themeIdx = themeIdx,
                    autoAccent = autoAccent,
                    tileStyle = tileStyle,
                    ambient = ambient,
                    wifiPos = wifiPos,
                    onWifiPos = { v ->
                        wifiPos = v
                        Prefs.setWifiPos(context, v)
                    },
                    isDefaultHome = isDefaultHome,
                    sounds = sounds,
                    modalOpen = textReq != null || pickReq != null,
                    onSounds = { v ->
                        sounds = v
                        Prefs.setSoundMode(context, v)
                    },
                    resumeTick = resumeTick,
                    vizStyle = vizStyle,
                    audioGranted = audioGranted,
                    onVizStyle = { v ->
                        vizStyle = v
                        Prefs.setVizStyle(context, v)
                    },
                    onAskAudio = onAskAudio,
                    onEditText = { t, h, i, cb -> textReq = TextReq(t, h, i, cb) },
                    onWallRefresh = { wallTick++ },
                    onRoomRefresh = { roomTick++ },
                    animStyle = animStyle,
                    onAnimStyle = { v ->
                        animStyle = v
                        Prefs.setAnimStyle(context, v)
                        wallMode = 2
                        Prefs.setWallMode(context, 2)
                    },
                    onPickList = { t, o, cb -> pickReq = PickReq(t, o, cb) },
                    onAutoAccent = { v ->
                        autoAccent = v
                        Prefs.setAutoAccent(context, v)
                    },
                    onTileStyle = { v ->
                        tileStyle = v
                        Prefs.setTileStyle(context, v)
                    },
                    onAmbient = { v ->
                        ambient = v
                        Prefs.setAmbient(context, v)
                    },
                    onSetDefaultHome = onSetDefaultHome,
                    intervalMin = intervalMin,
                    cats = cats,
                    anim = anim,
                    tileSize = tileIdx,
                    wallMode = wallMode,
                    recentCount = recentCount,
                    mediaAccess = mediaAccess,
                    res4k = res4k,
                    nightMode = nightMode,
                    onNightMode = { v ->
                        nightMode = v
                        Prefs.setNightDim(context, v)
                    },
                    onRes4k = { v ->
                        res4k = v
                        Prefs.setRes4k(context, v)
                    },
                    onTheme = { i ->
                        themeIdx = i
                        Prefs.setThemeIndex(context, i)
                    },
                    onInterval = { m ->
                        val v = m.coerceIn(0, 60)
                        intervalMin = v
                        Prefs.setIntervalMin(context, v)
                    },
                    onCats = { c ->
                        if (c != 0) {
                            cats = c
                            Prefs.setCategories(context, c)
                        }
                    },
                    onAnim = { v ->
                        anim = v
                        Prefs.setAnim(context, v)
                    },
                    onTileSize = { v ->
                        tileIdx = v
                        Prefs.setTileSize(context, v)
                    },
                    onRecentCount = { v ->
                        recentCount = v
                        Prefs.setRecentCount(context, v)
                    },
                    onClearRecent = {
                        Recent.clear(context)
                        recents = emptyList()
                    },
                    onWallMode = { v ->
                        if (v == 1 && !Wallpaper.exists(context)) {
                            showSettings = false
                            backToSettings = true
                            showGallery = true
                        } else {
                            wallMode = v
                            Prefs.setWallMode(context, v)
                        }
                    },
                    onOpenGallery = {
                        showSettings = false
                        backToSettings = true
                        showGallery = true
                    },
                    onOpenLocal = {
                        showSettings = false
                        backToSettings = true
                        showLocal = true
                    },
                    onOpenWeather = {
                        showSettings = false
                        backToSettings = true
                        showWeatherCfg = true
                    },
                    onOpenClock = {
                        showSettings = false
                        backToSettings = true
                        showClock = true
                    },
                    onOpenPicker = {
                        showSettings = false
                        backToSettings = true
                        showPicker = true
                    },
                    onOpenUpdate = {
                        showSettings = false
                        backToSettings = true
                        showUpdate = true
                    },
                    onOpenChangelog = {
                        showSettings = false
                        backToSettings = true
                        showChangelog = true
                    },
                    onGrantMedia = { openNotificationAccess(context) },
                    onSystemSettings = { openSystemSettings(context) },
                    onClose = { showSettings = false }
                )
            }

            if (showForecast) PanelWindow(anim, onDismiss = { closeSub() }) {
                ForecastPanel(
                    w = weather,
                    cfg = wxCfg,
                    anim = anim,
                    onSettings = {
                        showForecast = false
                        showWeatherCfg = true
                    },
                    onClose = { closeSub() }
                )
            }

            if (showWeatherCfg) PanelWindow(anim, onDismiss = { closeSub() }) {
                WeatherSettingsPanel(
                    cfg = wxCfg,
                    onChange = { c ->
                        wxCfg = c
                        Prefs.setWeather(context, c)
                    },
                    onClose = { closeSub() }
                )
            }

            if (showLocal) PanelWindow(anim, onDismiss = { closeSub() }) {
                LocalGallery(
                    mediaTick = mediaTick,
                    onAsk = onAskMedia,
                    onPickFile = {
                        closeSub()
                        onPickFile()
                    },
                    onPick = { uri ->
                        scope.launch {
                            val ok = withContext(Dispatchers.IO) { Wallpaper.saveFromUri(context, uri) }
                            if (ok) {
                                wallMode = 1
                                Prefs.setWallMode(context, 1)
                                fixedVersion++
                                Toast.makeText(context, "Wallpaper saved", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Could not use that picture", Toast.LENGTH_SHORT).show()
                            }
                            closeSub()
                        }
                    },
                    onClose = { closeSub() }
                )
            }

            if (showClock) PanelWindow(anim, onDismiss = { closeSub() }) {
                ClockPanel(
                    cfg = clockCfg,
                    onChange = { c ->
                        clockCfg = c
                        Prefs.setClock(context, c)
                    },
                    onClose = { closeSub() }
                )
            }

            if (showPicker) PanelWindow(anim, onDismiss = { closeSub() }) {
                TilePicker(
                    tiles = tiles,
                    resumeTick = resumeTick,
                    onToggle = { pkg ->
                        if (tiles.contains(pkg)) saveTiles(tiles.filter { it != pkg })
                        else saveTiles(tiles + pkg)
                    },
                    onClose = { closeSub() }
                )
            }

            if (showUpdate) PanelWindow(anim, onDismiss = { closeSub() }) {
                UpdatePanel(
                    testBuilds = testBuilds,
                    onTestBuilds = { v ->
                        testBuilds = v
                        Prefs.setTestBuilds(context, v)
                    },
                    onClose = { closeSub() }
                )
            }

            if (showChangelog) PanelWindow(anim, onDismiss = { closeSub() }) {
                ChangelogPanel(onClose = { closeSub() })
            }

            if (showGallery) PanelWindow(anim, onDismiss = { closeSub() }) {
                WallpaperGallery(
                    cats = cats,
                    tod = tod,
                    group = group,
                    onPick = { url ->
                        scope.launch {
                            val ok = withContext(Dispatchers.IO) { Wallpaper.saveFixed(context, url) }
                            if (ok) {
                                wallMode = 1
                                Prefs.setWallMode(context, 1)
                                fixedVersion++
                                Toast.makeText(context, "Wallpaper saved", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Could not save that picture", Toast.LENGTH_SHORT).show()
                            }
                            closeSub()
                        }
                    },
                    onClose = { closeSub() }
                )
            }

            val tr = textReq
            if (tr != null) {
                TextEntryDialog(
                    title = tr.title,
                    hint = tr.hint,
                    initial = tr.initial,
                    onSave = { v ->
                        tr.onSave(v)
                        textReq = null
                    },
                    onClose = { textReq = null }
                )
            }

            val pr = pickReq
            if (pr != null) {
                PickDialog(
                    title = pr.title,
                    options = pr.options,
                    onPick = { id -> pr.onPick(id) },
                    onClose = { pickReq = null }
                )
            }

            val mp = menuPkg
            if (mp != null) {
                val idx = tiles.indexOf(mp)
                AppMenu(
                    pkg = mp,
                    onHome = idx >= 0,
                    canLeft = idx > 0,
                    canRight = idx >= 0 && idx < tiles.size - 1,
                    onOpen = {
                        menuPkg = null
                        Apps.launch(context, mp)
                    },
                    onInfo = {
                        menuPkg = null
                        openAppInfo(context, mp)
                    },
                    onUninstall = {
                        menuPkg = null
                        uninstallApp(context, mp)
                    },
                    onLeft = {
                        val l = tiles.toMutableList()
                        java.util.Collections.swap(l, idx, idx - 1)
                        saveTiles(l)
                    },
                    onRight = {
                        val l = tiles.toMutableList()
                        java.util.Collections.swap(l, idx, idx + 1)
                        saveTiles(l)
                    },
                    onToggleHome = {
                        menuPkg = null
                        if (idx >= 0) saveTiles(tiles.filter { it != mp }) else saveTiles(tiles + mp)
                    },
                    onClose = { menuPkg = null }
                )
            }

            if (showNet) {
                NetDialog(
                    net = net,
                    onClose = { showNet = false },
                    onAskLocation = onAskLocation,
                    onSettings = { openWifiSettings(context) }
                )
            }
        }
    }
}

private fun openNotificationAccess(context: Context) {
    // Works without the system screen when WRITE_SECURE_SETTINGS was granted once with adb
    if (ListenerAccess.canWrite(context)) {
        val ok = ListenerAccess.enable(context)
        Toast.makeText(context, if (ok) "Notification access enabled" else "Could not enable it", Toast.LENGTH_SHORT).show()
        return
    }
    // The list screen (Special app access > Notification access) is the one where the switch stays on
    try {
        context.startActivity(
            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return
    } catch (e: Exception) {
        // try the detail screen
    }
    if (android.os.Build.VERSION.SDK_INT >= 30) {
        try {
            val cn = android.content.ComponentName(context, MediaListenerService::class.java).flattenToString()
            context.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
                    .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, cn)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        } catch (e: Exception) {
            // nothing else to try
        }
    }
    openSystemSettings(context)
}

private fun openAppInfo(context: Context, pkg: String) {
    try {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        Toast.makeText(context, "Could not open app info", Toast.LENGTH_SHORT).show()
    }
}

private fun uninstallApp(context: Context, pkg: String) {
    try {
        context.startActivity(
            Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        Toast.makeText(context, "Could not start uninstall", Toast.LENGTH_SHORT).show()
    }
}

private fun openSystemSettings(context: Context) {
    try {
        context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        // nothing else to try
    }
}

private fun openWifiSettings(context: Context) {
    try {
        context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        openSystemSettings(context)
    }
}


// Cross-fading slideshow of remote images. Restarts whenever `key` or the interval changes.
@Composable
private fun RotatingImage(
    modifier: Modifier,
    maxSide: Int,
    intervalMs: Long,
    key: Any,
    kenBurns: Boolean = false,
    minSide: Int = 0,
    onLoaded: ((android.graphics.Bitmap) -> Unit)? = null,
    onShown: ((String) -> Unit)? = null,
    fetchUrls: () -> List<String>
) {
    val context = LocalContext.current
    var bitmap by remember { mutableStateOf<ImageBitmap?>(null) }

    // Very slow zoom in and out (read in the graphics layer, so it never recomposes)
    val zoom: State<Float>? = if (kenBurns) {
        rememberInfiniteTransition(label = "zoom").animateFloat(
            initialValue = 1f,
            targetValue = 1.08f,
            animationSpec = infiniteRepeatable(
                animation = tween(40000, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "zoomValue"
        )
    } else {
        null
    }

    LaunchedEffect(key, intervalMs) {
        var urls: List<String> = emptyList()
        var index = 0
        while (isActive) {
            if (urls.isEmpty()) {
                urls = withContext(Dispatchers.IO) { fetchUrls() }
                index = 0
                if (urls.isEmpty()) {
                    delay(60_000L)
                    continue
                }
            }
            val url = urls[index]
            val bmp = withContext(Dispatchers.IO) { Remote.loadBitmap(context, url, maxSide, minSide) }
            if (bmp != null) {
                bitmap = bmp.asImageBitmap()
                onLoaded?.invoke(bmp)
                onShown?.invoke(url)
                if (intervalMs <= 0L) return@LaunchedEffect
                delay(intervalMs)
            } else {
                delay(2000L)
            }
            index++
            if (index >= urls.size) {
                urls = emptyList()
            }
        }
    }

    Crossfade(
        targetState = bitmap,
        modifier = modifier,
        animationSpec = tween(1500),
        label = "remoteImage"
    ) { bmp ->
        if (bmp != null) {
            Image(
                bitmap = bmp,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val z = zoom?.value ?: 1f
                        scaleX = z
                        scaleY = z
                    }
            )
        } else {
            Box(Modifier.fillMaxSize())
        }
    }
}

// ---------- Top bar pieces ----------

private fun clockFamily(style: Int): FontFamily = when (style) {
    2 -> FontFamily.Monospace
    3 -> FontFamily.Serif
    else -> FontFamily.SansSerif
}

private fun clockWeight(style: Int): FontWeight = when (style) {
    0 -> FontWeight.Thin
    1 -> FontWeight.Bold
    2 -> FontWeight.Normal
    3 -> FontWeight.Medium
    else -> FontWeight.Black
}

// size: 0 small, 1 medium, 2 large, 3 mini
private fun clockSizeSp(size: Int): Int = when (size) {
    3 -> 24
    0 -> 36
    1 -> 52
    else -> 72
}

private val CLOCK_FONTS = listOf(
    "Thin", "Bold", "Mono", "Serif", "Black", "LED", "Neon", "Matrix", "Slim", "Italic", "Outline", "Pixel"
)

// A small sample of a clock font (used by the font picker)
@Composable
private fun ClockSample(style: Int, color: Color, sp: Int = 22) {
    if (style >= 5) {
        DrawnClock("12:45", style, (sp * 0.95f).dp, color)
    } else {
        Text(
            text = "12:45",
            color = color,
            fontSize = sp.sp,
            fontWeight = clockWeight(style),
            fontFamily = clockFamily(style),
            letterSpacing = 1.sp
        )
    }
}

@Composable
private fun ClockBlock(
    cfg: ClockCfg,
    w: Weather?,
    downTarget: FocusRequester,
    contrast: ContrastMap?,
    pos: Offset,
    onPos: (Offset) -> Unit,
    room: String?,
    onClick: () -> Unit
) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val shape = RoundedCornerShape(18.dp)

    // The clock ticks on its own, so the rest of the home screen is not redrawn every second
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (isActive) {
            now = LocalDateTime.now()
            delay(1000L)
        }
    }

    val sizeSp = clockSizeSp(cfg.size)
    val family = clockFamily(cfg.style)
    val weight = clockWeight(cfg.style)

    // Adapt to wallpaper: the clock is drawn white, then each area is recoloured from the contrast map
    val adaptive = cfg.blend && contrast != null
    val mapImage = remember(contrast) { contrast?.bmp?.asImageBitmap() }
    val textColor = if (adaptive) Color.White else if (cfg.accentColor) accent else TextHi
    val infoColor = if (adaptive) Color.White else TextHi
    val shadowStyle = if (adaptive) TextStyle.Default else TextStyle(
        shadow = Shadow(color = Color(0xCC000000), offset = Offset(0f, 2f), blurRadius = 10f)
    )

    val timeText = if (cfg.h24) now.format(timeFmt) else now.format(time12Fmt)
    val secText = if (cfg.seconds) ":" + now.second.toString().padStart(2, '0') else ""
    val ampm = if (cfg.h24) "" else (if (now.hour < 12) " AM" else " PM")
    val small = secText + ampm

    // Lines under the clock
    val dateLine = if ((cfg.info and INFO_DATE) != 0) now.format(dateFmt) else ""
    val extras = ArrayList<String>()
    if (w != null) {
        if ((cfg.info and INFO_DAYLEN) != 0) {
            val m = w.sunsetMin - w.sunriseMin
            extras.add("Daylight " + (m / 60) + "h " + (m % 60) + "m")
        }
        if ((cfg.info and INFO_TOMORROW) != 0 && w.days.size > 1) {
            val d = w.days[1]
            extras.add("Tomorrow " + d.high + "° / " + d.low + "°")
        }
    }
    if ((cfg.info and INFO_MOON) != 0) {
        val mp = moonPhase(LocalDate.now())
        extras.add(mp.first + " " + mp.second)
    }
    val infoSp = when (cfg.size) {
        3 -> 10
        0 -> 12
        1 -> 14
        else -> 16
    }

    val boxMod = when (cfg.box) {
        1 -> Modifier.glass(shape)
        2 -> Modifier
            .clip(shape)
            .background(Color(0xCC0A1020))
            .border(1.dp, Color(0x33FFFFFF), shape)
        else -> Modifier
    }

    Box(
        Modifier
            .then(if (focused) Modifier.border(2.dp, accent, shape) else Modifier)
            .downTo(downTarget)
            .tvClickable(source, null, onClick)
    ) {
        // Opacity applies to the whole clock: digits, lines under it and the box
        Column(
            Modifier
                .graphicsLayer { alpha = cfg.opacity / 100f }
                .then(boxMod)
                .padding(
                    if (cfg.box == 0) PaddingValues(start = 6.dp, top = 6.dp, end = 10.dp, bottom = 6.dp)
                    else PaddingValues(horizontal = 18.dp, vertical = 12.dp)
                )
        ) {
            Column(
                Modifier
                    .onGloballyPositioned { c ->
                        val p = c.positionInRoot()
                        if (abs(p.x - pos.x) > 1f || abs(p.y - pos.y) > 1f) onPos(p)
                    }
                    .graphicsLayer { if (adaptive) compositingStrategy = CompositingStrategy.Offscreen }
                    .drawWithContent {
                        drawContent()
                        val img = mapImage
                        val m = contrast
                        if (adaptive && img != null && m != null) {
                            drawImage(
                                image = img,
                                dstOffset = IntOffset((-pos.x).roundToInt(), (-pos.y).roundToInt()),
                                dstSize = IntSize(m.w, m.h),
                                blendMode = BlendMode.SrcIn
                            )
                        }
                    }
            ) {
                if (cfg.style >= 5) {
                    // Drawn digits: LED segments, neon tubes or a dot matrix
                    Row(verticalAlignment = Alignment.Bottom) {
                        DrawnClock(timeText, cfg.style, (sizeSp * 0.95f).dp, textColor)
                        if (secText.isNotEmpty()) {
                            Spacer(Modifier.width(8.dp))
                            DrawnClock(secText, cfg.style, (sizeSp * 0.4f).dp, textColor.copy(alpha = 0.8f))
                        }
                        if (ampm.isNotEmpty()) {
                            Text(
                                text = ampm,
                                color = textColor,
                                fontSize = (sizeSp * 0.3f).sp,
                                fontFamily = RoundedFont,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 6.dp)
                            )
                        }
                        RoomReading(room, textColor, sizeSp)
                    }
                } else {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = timeText,
                            color = textColor,
                            fontSize = sizeSp.sp,
                            fontWeight = weight,
                            fontFamily = family,
                            letterSpacing = 2.sp,
                            style = shadowStyle
                        )
                        if (small.isNotEmpty()) {
                            Text(
                                text = small,
                                color = textColor.copy(alpha = 0.8f),
                                fontSize = (sizeSp * 0.4f).sp,
                                fontWeight = weight,
                                fontFamily = family,
                                style = shadowStyle,
                                modifier = Modifier.padding(start = 6.dp, bottom = (sizeSp * 0.1f).dp)
                            )
                        }
                        RoomReading(room, textColor, sizeSp)
                    }
                }
                if (dateLine.isNotEmpty()) {
                    Text(
                        text = dateLine,
                        color = infoColor.copy(alpha = 0.9f),
                        fontSize = infoSp.sp,
                        fontFamily = RoundedFont,
                        fontWeight = FontWeight.Medium,
                        style = shadowStyle,
                        modifier = Modifier.padding(start = 2.dp, top = 2.dp)
                    )
                }
                if (w != null && (cfg.info and INFO_SUN) != 0) {
                    Row(
                        Modifier.padding(start = 2.dp, top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        SunEvent(true, formatMinutes(w.sunriseMin), infoColor, infoSp)
                        SunEvent(false, formatMinutes(w.sunsetMin), infoColor, infoSp)
                    }
                }
                if (extras.isNotEmpty()) {
                    Text(
                        text = extras.joinToString("   ·   "),
                        color = infoColor.copy(alpha = 0.75f),
                        fontSize = (infoSp - 1).sp,
                        fontFamily = RoundedFont,
                        style = shadowStyle,
                        modifier = Modifier.padding(start = 2.dp, top = 4.dp)
                    )
                }
            }
        }
    }
}

private fun wxFamily(i: Int): FontFamily = when (i) {
    3 -> FontFamily.Serif
    4 -> FontFamily.Monospace
    5 -> FontFamily.Cursive
    else -> FontFamily.SansSerif
}

private fun wxWeight(i: Int): FontWeight = when (i) {
    1 -> FontWeight.Black
    2 -> FontWeight.Thin
    else -> FontWeight.Bold
}

private val WX_SCALES = floatArrayOf(0.6f, 0.8f, 1.0f, 1.2f)

// Lays the content out at baseW x baseH dp and draws it scaled by f; the layout takes the scaled size
private fun Modifier.scaledBox(baseW: Int, baseH: Int, f: Float): Modifier = this.layout { measurable, _ ->
    val p = measurable.measure(Constraints.fixed(baseW.dp.roundToPx(), baseH.dp.roundToPx()))
    layout((p.width * f).roundToInt(), (p.height * f).roundToInt()) {
        p.placeWithLayer(0, 0) {
            scaleX = f
            scaleY = f
            transformOrigin = TransformOrigin(0f, 0f)
        }
    }
}

@Composable
private fun WeatherPanel(w: Weather?, cfg: WeatherCfg, anim: Int, tod: String, downTarget: FocusRequester, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val shape = RoundedCornerShape(20.dp)
    val isDay = w?.isDay ?: true
    val group = w?.group ?: "cloud"
    val sky = skyColors(isDay, group)
    val family = wxFamily(cfg.font)
    val weight = wxWeight(cfg.font)
    val tempColor = if (cfg.color == 1) accent else TextHi
    val clear = cfg.photo == 2
    val f = WX_SCALES[cfg.size.coerceIn(0, 3)]

    Box(
        Modifier
            .clip(shape)
            .background(if (clear) Color(0x2E0A1020) else PanelDark)
            .then(if (focused) Modifier.border(2.dp, accent, shape) else Modifier)
            .downTo(downTarget)
            .tvClickable(source, null, onClick)
    ) {
        // The card is laid out at 360 x 172 and scaled to the chosen size
        Box(Modifier.scaledBox(360, 172, f)) {
            if (clear) {
                // See-through: only a light shade so the text stays readable on the wallpaper
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Brush.horizontalGradient(listOf(Color(0x66060A14), Color(0x1A060A14))))
                )
            } else {
                // Sky colours that match the weather and time of day
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(listOf(sky.first, sky.second)))
                )

                // Animated sky details (stars, sun glow, drifting clouds) in case no photo loads
                WeatherBackdrop(group, isDay, anim)

                // London photo matching the weather and time of day (switch off in the weather settings)
                if (w != null && cfg.photo == 0) {
                    RotatingImage(
                        modifier = Modifier.fillMaxSize(),
                        maxSide = 1400,
                        intervalMs = cfg.photoMin * 60_000L,
                        key = tod + (if (isDay) "d" else "n") + group,
                        minSide = 500
                    ) {
                        Remote.weatherPhotoUrls(isDay, group, tod)
                    }
                }

                // Scrims so the text stays readable: left side and the forecast strip at the bottom
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color(0xB30A1020), Color(0x590A1020), Color(0x0D0A1020))
                            )
                        )
                )
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .height(78.dp)
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x990A1020))))
                )
            }

            Column(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                if (w == null) {
                    Text(text = "Syncing...", color = TextLo, fontSize = 14.sp, fontFamily = family)
                } else {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = w.temp.toString() + "°",
                            color = tempColor,
                            fontSize = 46.sp,
                            fontWeight = weight,
                            fontFamily = family,
                            style = glow(accent, 18f)
                        )
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = Config.CITY,
                                color = TextHi,
                                fontSize = 22.sp,
                                fontWeight = weight,
                                fontFamily = family
                            )
                            if ((cfg.info and WX_COND) != 0) {
                                Text(
                                    text = w.label,
                                    color = accent,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = family,
                                )
                            }
                            if (cfg.cardWind) {
                                Text(
                                    text = "Wind " + compass(w.windDir) + " " + w.windMph + " mph" +
                                        (if (w.gustMph > w.windMph) "  ·  gusts " + w.gustMph else ""),
                                    color = TextHi,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = family
                                )
                            }
                        }
                        if ((cfg.info and WX_ICON) != 0) {
                            WeatherArt(w.code, w.isDay, anim, Modifier.size(64.dp))
                        }
                    }
                    // Next 5 days (Weather settings > Show on the card)
                    if (cfg.strip) {
                        Row(Modifier.fillMaxWidth()) {
                            w.days.drop(1).take(5).forEach { d -> MiniDay(d, family, Modifier.weight(1f)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniDay(d: DayForecast, family: FontFamily, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = d.label,
            color = TextLo,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = family,
        )
        WeatherArt(d.code, true, 2, Modifier.size(28.dp))
        Row {
            Text(text = d.high.toString() + "°", color = TextHi, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = family)
            Spacer(Modifier.width(3.dp))
            Text(text = d.low.toString() + "°", color = TextLo, fontSize = 10.sp, fontFamily = family)
        }
    }
}

// Wi-Fi and Settings: small, no background; the focused one gets a ring
@Composable
private fun WifiButton(net: NetInfo, target: FocusRequester, atBottom: Boolean, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val active = if (net.level < 0) 0 else net.level.coerceAtLeast(1)
    Box(
        Modifier
            .size(38.dp)
            .scale(if (focused) 1.2f else 1f)
            .clip(CircleShape)
            .then(if (focused) Modifier.border(2.dp, accent, CircleShape) else Modifier)
            .edgeKeys(target, atBottom)
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = { Sfx.click(); onClick() }),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(20.dp)) {
            val barW = size.width / 7f
            for (i in 0 until 4) {
                val h = size.height * (0.3f + 0.7f * (i + 1) / 4f)
                drawRoundRect(
                    color = if (i < active) accent else Color(0x66FFFFFF),
                    topLeft = Offset(i * barW * 2f, size.height - h),
                    size = Size(barW, h),
                    cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                )
            }
        }
    }
}


// ---------- App tiles ----------

@OptIn(ExperimentalComposeUiApi::class)
@Composable
private fun AppRow(
    tiles: List<String>,
    recents: List<RecentItem>,
    tileDp: Int,
    bannerMode: Boolean,
    overlayOpen: Boolean,
    anim: Int,
    firstTile: FocusRequester,
    onAllApps: () -> Unit,
    onSettings: () -> Unit,
    onMenu: (String) -> Unit,
    onGlow: (Color?) -> Unit,
    onGlowRect: (String, Rect?) -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val pm = context.packageManager
    val tileW = (if (bannerMode) tileDp * 16 / 9 else tileDp).dp
    val ratio = if (bannerMode) 16f / 9f else 1f

    // Focus the first tile at start and again whenever a panel closes
    LaunchedEffect(overlayOpen) {
        if (!overlayOpen) {
            delay(300L)
            runCatching { firstTile.requestFocus() }
        }
    }

    val rowState = rememberLazyListState()
    val rowScope = rememberCoroutineScope()
    val rowMargin = with(androidx.compose.ui.platform.LocalDensity.current) { 20.dp.roundToPx() }
    var focusIdx by remember { mutableIntStateOf(0) }
    // Down from the top row lands on the tile you were on last
    val entry = focusIdx.coerceIn(0, tiles.size + recents.size + 1)
    val reveal: (Int) -> Unit = { i ->
        focusIdx = i
        rowScope.launch { revealRowItem(rowState, i, rowMargin) }
    }
    WithBringSpec(72, 320) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            // once on the tile row, Left at the first tile and Right at the last tile do nothing
            .onPreviewKeyEvent { ev ->
                if (ev.type == KeyEventType.KeyDown) {
                    val k = ev.nativeKeyEvent.keyCode
                    val last = tiles.size + recents.size + 1
                    (k == android.view.KeyEvent.KEYCODE_DPAD_LEFT && focusIdx <= 0) ||
                        (k == android.view.KeyEvent.KEYCODE_DPAD_RIGHT && focusIdx >= last)
                } else {
                    false
                }
            },
        state = rowState,
        horizontalArrangement = Arrangement.spacedBy(0.dp, Alignment.CenterHorizontally),
        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 26.dp)
    ) {
        itemsIndexed(tiles, key = { _, pkg -> pkg }) { index, pkg ->
            var icon by remember(pkg) { mutableStateOf<ImageBitmap?>(null) }
            var banner by remember(pkg, bannerMode) { mutableStateOf<ImageBitmap?>(null) }
            LaunchedEffect(pkg) {
                icon = withContext(Dispatchers.IO) { Apps.icon(pm, pkg) }
            }
            LaunchedEffect(pkg, bannerMode) {
                banner = if (bannerMode) withContext(Dispatchers.IO) { Apps.banner(pm, pkg) } else null
            }
            AppTile(
                label = Apps.label(pm, pkg),
                accent = accent,
                icon = icon,
                modifier = Modifier.width(tileW + 14.dp),
                outerPad = 7.dp,
                onBounds = { rc -> onGlowRect(pkg, rc) },
                ratio = ratio,
                banner = banner,
                anim = anim,
                labelSp = tileDp / 9,
                focusRequester = if (index == entry) firstTile else null,
                onFocused = {
                    reveal(index)
                    (banner ?: icon)?.let { onGlow(Tint.vibrant(it.asAndroidBitmap())) }
                },
                onLongClick = { onMenu(pkg) }
            ) {
                Apps.launch(context, pkg)
            }
        }
        // What you last played or watched
        itemsIndexed(recents, key = { _, r -> "recent-" + r.id }) { rIdx, r ->
            var art by remember(r.id) { mutableStateOf<ImageBitmap?>(null) }
            LaunchedEffect(r.id) {
                art = withContext(Dispatchers.IO) { Recent.art(context, r) ?: Apps.icon(pm, r.pkg) }
            }
            AppTile(
                label = r.title,
                accent = accent,
                icon = art,
                modifier = Modifier.width(tileW + 14.dp),
                outerPad = 7.dp,
                onBounds = { rc -> onGlowRect("recent-" + r.id, rc) },
                focusRequester = if (tiles.size + rIdx == entry) firstTile else null,
                ratio = ratio,
                anim = anim,
                labelSp = tileDp / 9,
                onFocused = {
                    reveal(tiles.size + rIdx)
                    art?.let { onGlow(Tint.vibrant(it.asAndroidBitmap())) }
                }
            ) {
                Recent.open(context, r)
            }
        }
        item {
            AppTile(
                label = "All apps",
                accent = accent,
                icon = null,
                modifier = Modifier.width(tileW + 14.dp),
                outerPad = 7.dp,
                onBounds = { rc -> onGlowRect("all", rc) },
                ratio = ratio,
                glyph = "☰",
                anim = anim,
                labelSp = tileDp / 9,
                focusRequester = if (tiles.size + recents.size == entry) firstTile else null,
                onFocused = {
                    reveal(tiles.size + recents.size)
                    onGlow(null)
                }
            ) { onAllApps() }
        }
        item {
            AppTile(
                label = "Settings",
                accent = accent,
                icon = null,
                modifier = Modifier.width(tileW + 14.dp),
                outerPad = 7.dp,
                onBounds = { rc -> onGlowRect("settings", rc) },
                focusRequester = if (tiles.size + recents.size + 1 == entry) firstTile else null,
                ratio = ratio,
                glyph = "⚙",
                anim = anim,
                labelSp = tileDp / 9,
                onFocused = {
                    reveal(tiles.size + recents.size + 1)
                    onGlow(null)
                }
            ) { onSettings() }
        }
    }
    }
}

@Composable
private fun AppTile(
    label: String,
    accent: Color,
    icon: ImageBitmap?,
    modifier: Modifier = Modifier,
    ratio: Float = 1f,
    banner: ImageBitmap? = null,
    glyph: String? = null,
    installed: Boolean = true,
    badge: String? = null,
    anim: Int = 2,
    focusRequester: FocusRequester? = null,
    onLongClick: (() -> Unit)? = null,
    onFocused: (() -> Unit)? = null,
    labelSp: Int = 10,
    outerPad: Dp = 0.dp,
    onBounds: ((Rect?) -> Unit)? = null,
    onDpad: ((Int) -> Boolean)? = null,
    onClick: () -> Unit
) {
    val themeAccent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.12f else 1f,
        animationSpec = if (anim == 2) tween(0) else spring(dampingRatio = 0.55f, stiffness = 380f),
        label = "tileScale"
    )

    val coords = remember { arrayOfNulls<LayoutCoordinates>(1) }
    val focusedNow = rememberUpdatedState(focused)
    LaunchedEffect(focused) {
        if (focused) {
            onFocused?.invoke()
            coords[0]?.let { onBounds?.invoke(it.boundsInRoot()) }
        } else {
            onBounds?.invoke(null)
        }
    }

    // A light sweep that runs across the focused tile
    val sweep: Float = if (focused && anim == 0) {
        val t = rememberInfiniteTransition(label = "shine")
        val v by t.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(1800, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "shineX"
        )
        v
    } else {
        0f
    }

    val shape = RoundedCornerShape(16.dp)
    val iconMod = if (ratio > 1.2f) Modifier.fillMaxHeight(0.58f).aspectRatio(1f)
    else Modifier.fillMaxWidth(0.66f).aspectRatio(1f)

    Box(
        modifier = modifier
            .padding(outerPad)
            .aspectRatio(ratio)
            .onGloballyPositioned {
                coords[0] = it
                if (focusedNow.value) onBounds?.invoke(it.boundsInRoot())
            }
            .scale(scale)
            .alpha(if (installed) 1f else 0.45f)
            .clip(shape)
            .background(if (focused) glassFillFocused else glassFill)
            .border(
                if (focused) 2.dp else 1.dp,
                if (focused) themeAccent else Color(0x44FFFFFF),
                shape
            )
            .then(
                if (onDpad != null) Modifier.onPreviewKeyEvent { ev ->
                    if (ev.type == KeyEventType.KeyDown) onDpad(ev.nativeKeyEvent.keyCode) else false
                } else Modifier
            )
            .then(
                if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier
            )
            .tvClickable(source, onLongClick, onClick)
            .drawWithContent {
                drawContent()
                if (focused && anim == 0) {
                    val w = size.width
                    val x = -0.4f * w + sweep * 1.8f * w
                    drawRect(
                        brush = Brush.linearGradient(
                            colors = listOf(Color.Transparent, Color(0x40FFFFFF), Color.Transparent),
                            start = Offset(x, 0f),
                            end = Offset(x + 0.4f * w, size.height * 0.5f)
                        )
                    )
                }
            },
        contentAlignment = Alignment.Center
    ) {
        if (banner != null) {
            Image(
                bitmap = banner,
                contentDescription = label,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
        if (banner == null) Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(6.dp)
        ) {
            if (icon != null) {
                Image(
                    bitmap = icon,
                    contentDescription = label,
                    modifier = iconMod
                        .clip(RoundedCornerShape(14.dp))
                )
            } else {
                Box(
                    iconMod
                        .clip(RoundedCornerShape(14.dp))
                        .background(accent.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = glyph ?: label.take(1).uppercase(),
                        color = accent,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = label,
                color = TextHi,
                fontSize = labelSp.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (badge != null) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(5.dp)
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(themeAccent),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = badge,
                    color = Ink,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ---------- Shared pieces ----------

private class TextReq(val title: String, val hint: String, val initial: String, val onSave: (String) -> Unit)

@Composable
private fun ScreenTitle(title: String, sub: String? = null) {
    val accent = LocalAccent.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .width(5.dp)
                .height(if (sub != null) 38.dp else 28.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(accent)
        )
        Spacer(Modifier.width(12.dp))
        Column {
            Text(text = title, color = TextHi, fontSize = 24.sp, fontWeight = FontWeight.Bold, fontFamily = RoundedFont)
            if (sub != null) {
                Text(text = sub, color = TextLo, fontSize = 12.sp, fontFamily = RoundedFont)
            }
        }
    }
}

// Small text entry window (API keys, addresses): the on-screen keyboard opens when the field is selected
@Composable
private fun TextEntryDialog(title: String, hint: String, initial: String, onSave: (String) -> Unit, onClose: () -> Unit) {
    val accent = LocalAccent.current
    var text by remember { mutableStateOf(initial) }
    val field = remember { FocusRequester() }
    val fs = remember { MutableInteractionSource() }
    val fieldFocused by fs.collectIsFocusedAsState()
    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { field.requestFocus() }
    }
    val shape = RoundedCornerShape(22.dp)
    val fieldShape = RoundedCornerShape(12.dp)
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            Modifier
                .width(580.dp)
                .navSound()
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xFF131C34), Color(0xFF0A1020))))
                .border(1.dp, accent.copy(alpha = 0.4f), shape)
                .padding(26.dp)
        ) {
            ScreenTitle(title)
            Spacer(Modifier.height(8.dp))
            Text(text = hint, color = TextLo, fontSize = 12.sp, fontFamily = RoundedFont)
            Spacer(Modifier.height(14.dp))
            BasicTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                textStyle = TextStyle(color = TextHi, fontSize = 16.sp, fontFamily = FontFamily.Monospace),
                cursorBrush = SolidColor(accent),
                interactionSource = fs,
                modifier = Modifier
                    .fillMaxWidth()
                    .focusRequester(field)
                    .clip(fieldShape)
                    .background(Color(0xFF18223A))
                    .border(if (fieldFocused) 2.dp else 1.dp, if (fieldFocused) accent else Color(0x44FFFFFF), fieldShape)
                    .padding(14.dp)
            )
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ChipButton("Save", true) { onSave(text) }
                ChipButton("Cancel", false) { onClose() }
            }
        }
    }
}

// "Watch trailer" button shown while a cinema wallpaper is on screen
@Composable
private fun MovieChip(m: Movie, down: FocusRequester, modifier: Modifier, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .padding(start = 12.dp)
            .clip(shape)
            .background(if (focused) accent else Color(0x99060A14))
            .border(1.dp, if (focused) accent else Color(0x55FFFFFF), shape)
            .downTo(down)
            .tvClickable(source, null, onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val c = if (focused) Ink else TextHi
        Canvas(Modifier.size(14.dp)) {
            val tri = Path()
            tri.moveTo(size.width * 0.15f, 0f)
            tri.lineTo(size.width, size.height / 2f)
            tri.lineTo(size.width * 0.15f, size.height)
            tri.close()
            drawPath(tri, c)
        }
        Spacer(Modifier.width(9.dp))
        Text(text = "Watch trailer", color = c, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = RoundedFont)
        Text(
            text = "   " + m.title + (if (m.year.isNotEmpty()) " (" + m.year + ")" else ""),
            color = c.copy(alpha = 0.75f),
            fontSize = 12.sp,
            fontFamily = RoundedFont,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// Room temperature next to the clock digits
@Composable
private fun RoomReading(room: String?, color: Color, sizeSp: Int) {
    if (room == null) return
    Row(Modifier.padding(start = 14.dp, bottom = (sizeSp * 0.06f).dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .width(1.dp)
                .height((sizeSp * 0.9f).dp)
                .background(color.copy(alpha = 0.3f))
        )
        Column(Modifier.padding(start = 12.dp)) {
            Text(
                text = "Room",
                color = color.copy(alpha = 0.7f),
                fontSize = (sizeSp * 0.28f).coerceAtLeast(9f).sp,
                fontFamily = RoundedFont,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = room,
                color = color,
                fontSize = (sizeSp * 0.5f).sp,
                fontFamily = RoundedFont,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// ---------- Music visualiser: 1 bars, 2 mirror, 3 pills, 4 LED, 5 wave, 6 radial ----------

@Composable
private fun VizStrip(style: Int, bands: State<FloatArray>, peaks: State<FloatArray>, color: Color, modifier: Modifier) {
    val hsv = remember(color) {
        val a = FloatArray(3)
        android.graphics.Color.colorToHSV(color.toArgb(), a)
        a
    }
    Canvas(modifier) {
        val b = bands.value
        val pk = peaks.value
        val n = b.size
        val w = size.width
        val h = size.height
        // colour shifts a little from the low to the high end of the spectrum
        fun tone(i: Int, alpha: Float, v: Float = 1f): Color =
            Color.hsv((hsv[0] + 55f * i / n) % 360f, (hsv[1] * 0.85f).coerceIn(0.35f, 1f), v, alpha)
        when (style) {
            1 -> {
                val y0 = h * 0.78f
                val slot = w / n
                val bw = slot * 0.72f
                for (i in 0 until n) {
                    val x = i * slot + slot * 0.14f
                    val bh = (y0 * b[i]).coerceAtLeast(3f)
                    drawRect(tone(i, 0.12f), Offset(x - 3f, y0 - bh - 3f), Size(bw + 6f, bh + 3f))
                    drawRect(
                        Brush.verticalGradient(listOf(tone(i, 0.95f), tone(i, 0.35f, 0.7f)), startY = y0 - bh, endY = y0),
                        Offset(x, y0 - bh), Size(bw, bh)
                    )
                    drawRect(tone(i, 1f), Offset(x, y0 - y0 * pk[i] - 6f), Size(bw, 3f))
                    // reflection on the "floor"
                    val rh = bh * 0.32f
                    drawRect(
                        Brush.verticalGradient(listOf(tone(i, 0.25f), Color.Transparent), startY = y0 + 3f, endY = y0 + 3f + rh),
                        Offset(x, y0 + 3f), Size(bw, rh)
                    )
                }
                drawRect(Color.White.copy(alpha = 0.12f), Offset(0f, y0), Size(w, 1.5f))
            }
            2 -> {
                val cy = h * 0.5f
                val slot = w / n
                val bw = slot * 0.7f
                for (i in 0 until n) {
                    val x = i * slot + slot * 0.15f
                    val half = (cy * b[i]).coerceAtLeast(2f)
                    drawRect(
                        Brush.verticalGradient(
                            0f to tone(i, 0.15f), 0.5f to tone(i, 1f), 1f to tone(i, 0.15f),
                            startY = cy - half, endY = cy + half
                        ),
                        Offset(x, cy - half), Size(bw, half * 2f)
                    )
                    val pe = cy * pk[i]
                    drawRect(tone(i, 0.9f), Offset(x, cy - pe - 5f), Size(bw, 2.5f))
                    drawRect(tone(i, 0.9f), Offset(x, cy + pe + 2.5f), Size(bw, 2.5f))
                }
                drawRect(Color.White.copy(alpha = 0.18f), Offset(0f, cy - 0.75f), Size(w, 1.5f))
            }
            3 -> {
                val y0 = h * 0.8f
                val slot = w / n
                val bw = slot * 0.58f
                for (i in 0 until n) {
                    val x = i * slot + (slot - bw) / 2f
                    val bh = (y0 * b[i]).coerceAtLeast(bw)
                    val cr = CornerRadius(bw / 2f, bw / 2f)
                    drawRoundRect(tone(i, 0.14f), Offset(x - 3f, y0 - bh - 3f), Size(bw + 6f, bh + 6f), CornerRadius(bw / 2f + 3f, bw / 2f + 3f))
                    drawRoundRect(
                        Brush.verticalGradient(listOf(tone(i, 1f), tone(i, 0.4f, 0.75f)), startY = y0 - bh, endY = y0),
                        Offset(x, y0 - bh), Size(bw, bh), cr
                    )
                    drawCircle(tone(i, 1f), bw * 0.3f, Offset(x + bw / 2f, y0 - y0 * pk[i] - bw))
                    val rh = bh * 0.28f
                    drawRoundRect(
                        Brush.verticalGradient(listOf(tone(i, 0.22f), Color.Transparent), startY = y0 + 4f, endY = y0 + 4f + rh),
                        Offset(x, y0 + 4f), Size(bw, rh), cr
                    )
                }
            }
            4 -> {
                // classic LED meter: green, yellow, red, with a held peak segment
                val segs = 22
                val sh = h * 0.9f / segs
                val slot = w / n
                val bw = slot * 0.72f
                for (i in 0 until n) {
                    val x = i * slot + slot * 0.14f
                    val lit = (b[i] * segs).toInt()
                    val peakSeg = (pk[i] * segs).toInt().coerceIn(0, segs - 1)
                    for (k in 0 until segs) {
                        val f = k / segs.toFloat()
                        val c = if (f < 0.6f) Color(0xFF3DDC84) else if (f < 0.85f) Color(0xFFFFD54A) else Color(0xFFFF4B3E)
                        val y = h * 0.95f - (k + 1) * sh
                        val a = if (k < lit) 0.95f else if (k == peakSeg) 0.95f else 0.07f
                        if (k < lit) drawRect(c.copy(alpha = 0.16f), Offset(x - 2f, y - 1f), Size(bw + 4f, sh))
                        drawRoundRect(c.copy(alpha = a), Offset(x, y + 1f), Size(bw, sh - 3f), CornerRadius(2f, 2f))
                    }
                }
            }
            5 -> {
                // three layered waves: slow and wide at the back, quick and sharp in front
                val y0 = h * 0.86f
                for (layer in 0 until 3) {
                    val amp = y0 * (0.55f + 0.2f * layer)
                    val path = Path()
                    path.moveTo(0f, y0)
                    fun v(i: Int): Float {
                        var s = 0f
                        var c = 0
                        for (d in -(2 - layer)..(2 - layer)) {
                            val j = i + d
                            if (j in 0 until n) {
                                s += b[j]
                                c++
                            }
                        }
                        return s / c
                    }
                    path.lineTo(0f, y0 - amp * v(0))
                    for (i in 1 until n) {
                        val x0 = (i - 1) * (w / (n - 1))
                        val x1 = i * (w / (n - 1))
                        path.cubicTo((x0 + x1) / 2f, y0 - amp * v(i - 1), (x0 + x1) / 2f, y0 - amp * v(i), x1, y0 - amp * v(i))
                    }
                    val line = Path()
                    line.addPath(path)
                    path.lineTo(w, y0)
                    path.close()
                    drawPath(
                        path,
                        Brush.verticalGradient(listOf(tone(layer * 14, 0.5f - 0.1f * layer), Color.Transparent), startY = y0 - amp, endY = y0)
                    )
                    drawPath(line, tone(layer * 14, 0.22f), style = Stroke(9f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                    drawPath(line, tone(layer * 14, 0.95f), style = Stroke(2.5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
            else -> {
                // radial spectrum: bars around a ring that pulses with the bass
                val c = Offset(w / 2f, h * 0.46f)
                var bass = 0f
                for (i in 0 until 4) bass += b[i] / 4f
                val r0 = minOf(w, h) * (0.2f + 0.025f * bass)
                val len = minOf(w, h) * 0.2f
                val m = n * 2
                drawCircle(Brush.radialGradient(listOf(tone(0, 0.18f * (0.5f + bass)), Color.Transparent), center = c, radius = r0 * 2f), r0 * 2f, c)
                drawCircle(tone(n / 2, 0.35f), r0 * 0.94f, c, style = Stroke(2f))
                for (i in 0 until m) {
                    val idx = if (i < n) i else m - 1 - i
                    val ang = (i.toFloat() / m) * 6.2832f - 1.5708f
                    val dx = cos(ang)
                    val dy = sin(ang)
                    val l = len * b[idx] + 3f
                    drawLine(
                        tone(idx, 0.95f),
                        Offset(c.x + dx * r0, c.y + dy * r0), Offset(c.x + dx * (r0 + l), c.y + dy * (r0 + l)),
                        6f, StrokeCap.Round
                    )
                    val pr = r0 + len * pk[idx] + 10f
                    drawCircle(tone(idx, 0.9f), 2.2f, Offset(c.x + dx * pr, c.y + dy * pr))
                }
            }
        }
    }
}

// ---------- All apps: recently used on top, the rest A to Z ----------

@Composable
private fun DrawerTile(
    label: String,
    icon: ImageBitmap?,
    ticked: Boolean,
    modifier: Modifier,
    focusRequester: FocusRequester?,
    onFocused: (() -> Unit)?,
    onDpad: ((Int) -> Boolean)?,
    onLongClick: () -> Unit,
    onClick: () -> Unit
) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.08f else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "drawerScale"
    )
    LaunchedEffect(focused) {
        if (focused) onFocused?.invoke()
    }
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .aspectRatio(0.95f)
            .scale(scale)
            .clip(shape)
            .background(
                if (focused) Brush.verticalGradient(listOf(accent.copy(alpha = 0.42f), accent.copy(alpha = 0.12f)))
                else Brush.verticalGradient(listOf(Color(0x26FFFFFF), Color(0x0AFFFFFF)))
            )
            .border(if (focused) 2.dp else 1.dp, if (focused) accent else Color(0x2EFFFFFF), shape)
            .then(
                if (onDpad != null) Modifier.onPreviewKeyEvent { ev ->
                    if (ev.type == KeyEventType.KeyDown) onDpad(ev.nativeKeyEvent.keyCode) else false
                } else Modifier
            )
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .tvClickable(source, onLongClick, onClick)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            if (icon != null) {
                Image(bitmap = icon, contentDescription = label, modifier = Modifier.size(56.dp).clip(RoundedCornerShape(15.dp)))
            } else {
                Box(
                    Modifier.size(56.dp).clip(RoundedCornerShape(15.dp)).background(accent.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = label.take(1).uppercase(), color = accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }
            if (ticked) {
                Box(
                    Modifier.size(18.dp).clip(CircleShape).background(accent),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "✓", color = Ink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text = label,
            color = if (focused) TextHi else TextHi.copy(alpha = 0.85f),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RoundedFont,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun DrawerApp(
    app: AppEntry,
    onHome: Boolean,
    modifier: Modifier,
    focusRequester: FocusRequester?,
    onFocused: (() -> Unit)?,
    onDpad: ((Int) -> Boolean)?,
    onMenu: (String) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val pm = context.packageManager
    var icon by remember(app.pkg) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(app.pkg) {
        icon = withContext(Dispatchers.IO) { Apps.icon(pm, app.pkg) }
    }
    DrawerTile(
        label = app.label,
        icon = icon,
        ticked = onHome,
        modifier = modifier,
        focusRequester = focusRequester,
        onFocused = onFocused,
        onDpad = onDpad,
        onLongClick = { onMenu(app.pkg) }
    ) {
        Apps.launch(context, app.pkg)
        onClose()
    }
}

@Composable
private fun AllApps(
    resumeTick: Int,
    tiles: List<String>,
    onMenu: (String) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val apps = remember(resumeTick) { Apps.installed(context) }
    val recent = remember(apps) {
        val known = apps.associateBy { it.pkg }
        AppUse.list(context).mapNotNull { known[it] }.take(6)
    }
    val rest = remember(apps, recent) {
        val r = recent.map { it.pkg }.toSet()
        apps.filter { it.pkg !in r }
    }
    val recentReq = remember(recent) { List(recent.size) { FocusRequester() } }
    val requesters = remember(rest) { List(rest.size) { FocusRequester() } }
    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(apps) {
        delay(250L)
        runCatching { (recentReq.firstOrNull() ?: requesters.firstOrNull())?.requestFocus() }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xF70A1226), Color(0xF7050810))))
            .padding(horizontal = 44.dp, vertical = 26.dp)
    ) {
        Column {
            ScreenTitle("All apps", apps.size.toString() + " apps  ·  hold OK on an app for more")
            Spacer(Modifier.height(16.dp))
            if (recent.isNotEmpty()) {
                SectionLabel("Recently used")
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    recent.forEachIndexed { i, app ->
                        DrawerApp(app, tiles.contains(app.pkg), Modifier.width(104.dp), recentReq[i], null, null, onMenu, onClose)
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
            SectionLabel("A to Z")
            LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Adaptive(104.dp),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(8.dp)
            ) {
                itemsIndexed(rest) { index, app ->
                    DrawerApp(
                        app, tiles.contains(app.pkg), Modifier.fillMaxWidth(), requesters[index],
                        { scope.launch { revealGridItem(gridState, index) } },
                        { code -> gridKey(code, scope, gridState, requesters, index) },
                        onMenu, onClose
                    )
                }
            }
        }
    }
}

private class PickReq(val title: String, val options: List<Pair<String, String>>, val onPick: (String) -> Unit)

// A list to choose from (e.g. the temperature sensors found in Home Assistant)
@Composable
private fun PickDialog(title: String, options: List<Pair<String, String>>, onPick: (String) -> Unit, onClose: () -> Unit) {
    val accent = LocalAccent.current
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { first.requestFocus() }
    }
    val shape = RoundedCornerShape(22.dp)
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            Modifier
                .width(620.dp)
                .navSound()
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xFF131C34), Color(0xFF0A1020))))
                .border(1.dp, accent.copy(alpha = 0.4f), shape)
                .padding(26.dp)
        ) {
            ScreenTitle(title)
            Spacer(Modifier.height(14.dp))
            Column(
                Modifier
                    .heightIn(max = 360.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                options.forEachIndexed { i, o ->
                    ChipButton(o.second, false, if (i == 0) first else null, compact = true, wide = true) {
                        onPick(o.first)
                        onClose()
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            ChipButton("Cancel", false) { onClose() }
        }
    }
}

// ---------- Launcher settings: categories on the left, cards on the right ----------

private fun DrawScope.drawCatIcon(kind: Int, c: Color) {
    val s = size.minDimension
    val sw = s * 0.09f
    when (kind) {
        0 -> {
            drawCircle(c, s * 0.42f, Offset(s / 2f, s / 2f), style = Stroke(sw))
            drawArc(c, -90f, 180f, true, Offset(s * 0.08f, s * 0.08f), Size(s * 0.84f, s * 0.84f))
        }
        1 -> {
            val p = Path()
            p.moveTo(s * 0.5f, s * 0.08f)
            p.lineTo(s * 0.94f, s * 0.48f)
            p.lineTo(s * 0.8f, s * 0.48f)
            p.lineTo(s * 0.8f, s * 0.9f)
            p.lineTo(s * 0.2f, s * 0.9f)
            p.lineTo(s * 0.2f, s * 0.48f)
            p.lineTo(s * 0.06f, s * 0.48f)
            p.close()
            drawPath(p, c)
        }
        2 -> {
            drawRoundRect(c, Offset(s * 0.08f, s * 0.16f), Size(s * 0.84f, s * 0.68f), CornerRadius(s * 0.1f), style = Stroke(sw))
            val m = Path()
            m.moveTo(s * 0.16f, s * 0.76f)
            m.lineTo(s * 0.42f, s * 0.46f)
            m.lineTo(s * 0.6f, s * 0.66f)
            m.lineTo(s * 0.72f, s * 0.54f)
            m.lineTo(s * 0.86f, s * 0.76f)
            m.close()
            drawPath(m, c)
            drawCircle(c, s * 0.07f, Offset(s * 0.72f, s * 0.34f))
        }
        3 -> {
            drawCircle(c, s * 0.42f, Offset(s / 2f, s / 2f), style = Stroke(sw))
            val t = Path()
            t.moveTo(s * 0.42f, s * 0.32f)
            t.lineTo(s * 0.7f, s * 0.5f)
            t.lineTo(s * 0.42f, s * 0.68f)
            t.close()
            drawPath(t, c)
        }
        4 -> drawGear(c)
        else -> {
            drawLine(c, Offset(s * 0.2f, s * 0.2f), Offset(s * 0.8f, s * 0.8f), sw, StrokeCap.Round)
            drawLine(c, Offset(s * 0.8f, s * 0.2f), Offset(s * 0.2f, s * 0.8f), sw, StrokeCap.Round)
        }
    }
}

private val SETTINGS_CATS = listOf("Look", "Home", "Wallpaper", "Playback", "System")
private val SETTINGS_HINTS = listOf(
    "Colours, tile style and focus effects",
    "Apps, clock, weather and recent tiles",
    "Pictures, quality and how often they change",
    "The now-playing card",
    "Default launcher, updates and about"
)

@Composable
private fun SideItem(
    text: String,
    icon: Int,
    selected: Boolean,
    req: FocusRequester,
    locked: Boolean,
    onFocus: () -> Unit,
    onKey: (Int) -> Boolean,
    onClick: () -> Unit
) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val shape = RoundedCornerShape(14.dp)
    LaunchedEffect(focused) {
        if (focused) onFocus()
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                if (focused) Brush.horizontalGradient(listOf(Color.White, Color(0xFFDDE6FF)))
                else if (selected) Brush.horizontalGradient(listOf(accent.copy(alpha = 0.32f), accent.copy(alpha = 0.04f)))
                else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
            )
            .onPreviewKeyEvent { ev ->
                if (ev.type == KeyEventType.KeyDown) onKey(ev.nativeKeyEvent.keyCode) else false
            }
            .focusProperties { canFocus = !locked }
            .focusRequester(req)
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = { if (text in BACK_LABELS) Sfx.back() else Sfx.click(); onClick() })
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(if (focused) Color(0x33000000) else if (selected) accent.copy(alpha = 0.5f) else Color(0x1FFFFFFF)),
            contentAlignment = Alignment.Center
        ) {
            val ic = if (focused) Ink else TextHi
            Canvas(Modifier.size(20.dp)) { drawCatIcon(icon, ic) }
        }
        Spacer(Modifier.width(12.dp))
        Text(
            text = text,
            color = if (focused) Ink else if (selected) TextHi else TextLo,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RoundedFont
        )
    }
}

@Composable
private fun SettingCard(title: String, hint: String? = null, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val accent = LocalAccent.current
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.10f), Color(0x14FFFFFF))))
            .border(1.dp, accent.copy(alpha = 0.22f), shape)
            .padding(18.dp)
            .onGloballyPositioned { FocusTrack.cardLeft = it.boundsInRoot().left }
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .width(4.dp)
                    .height(16.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(accent)
            )
            Spacer(Modifier.width(9.dp))
            Text(
                text = title,
                color = TextHi,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont
            )
        }
        if (hint != null) {
            Text(
                text = hint,
                color = TextLo,
                fontSize = 11.sp,
                fontFamily = RoundedFont,
                modifier = Modifier.padding(top = 3.dp, start = 13.dp)
            )
        }
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ChipRow(content: @Composable () -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) { content() }
}

// Right-hand panel with the same look as the Settings pages (clock style, weather card)
@Composable
private fun SidePanel(title: String, hint: String, scroll: ScrollState, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val accent = LocalAccent.current
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0x66000000))
    ) {
        Column(
            Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .width(540.dp)
                .onPreviewKeyEvent { ev ->
                    if (ev.type == KeyEventType.KeyDown && ev.nativeKeyEvent.keyCode == android.view.KeyEvent.KEYCODE_DPAD_LEFT && FocusTrack.atRowStart()) {
                        onBack()
                        true
                    } else {
                        false
                    }
                }
                .background(Brush.verticalGradient(listOf(Color(0xFA0B1226), Color(0xFA060914))))
                .verticalScroll(scroll)
                .padding(horizontal = 24.dp, vertical = 22.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .width(5.dp)
                        .height(36.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(accent)
                )
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(
                        text = title,
                        color = TextHi,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont
                    )
                    Text(
                        text = hint,
                        color = TextLo,
                        fontSize = 12.sp,
                        fontFamily = RoundedFont
                    )
                }
            }
            content()
            Spacer(Modifier.height(160.dp))
        }
    }
}

// A selectable tile with a preview on top (font picker, weather icon sets)
@Composable
private fun ChoiceTile(
    name: String,
    selected: Boolean,
    focusRequester: FocusRequester? = null,
    onClick: () -> Unit,
    previewH: Dp = 46.dp,
    preview: @Composable (Color) -> Unit
) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier
            .width(140.dp)
            .trackLeft(focused)
            .clip(shape)
            .background(if (focused) Color.White else if (selected) accent.copy(alpha = 0.45f) else Color(0xFF18223A))
            .border(if (focused) 3.dp else 1.dp, if (focused || selected) accent else Color(0x44FFFFFF), shape)
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = { Sfx.click(); onClick() })
            .padding(horizontal = 8.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.height(previewH).fillMaxWidth(), contentAlignment = Alignment.Center) {
            preview(if (focused) Ink else TextHi)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = name,
            color = if (focused) Ink else TextLo,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RoundedFont
        )
    }
}

@OptIn(ExperimentalLayoutApi::class, androidx.compose.ui.ExperimentalComposeUiApi::class)
@Composable
private fun SettingsScreen(
    themeIdx: Int,
    autoAccent: Boolean,
    tileStyle: Int,
    ambient: Boolean,
    wifiPos: Int,
    onWifiPos: (Int) -> Unit,
    sounds: Int,
    onSounds: (Int) -> Unit,
    modalOpen: Boolean,
    isDefaultHome: Boolean,
    resumeTick: Int,
    vizStyle: Int,
    audioGranted: Boolean,
    onVizStyle: (Int) -> Unit,
    onAskAudio: () -> Unit,
    onEditText: (String, String, String, (String) -> Unit) -> Unit,
    onWallRefresh: () -> Unit,
    onRoomRefresh: () -> Unit,
    animStyle: Int,
    onAnimStyle: (Int) -> Unit,
    onPickList: (String, List<Pair<String, String>>, (String) -> Unit) -> Unit,
    onAutoAccent: (Boolean) -> Unit,
    onTileStyle: (Int) -> Unit,
    onAmbient: (Boolean) -> Unit,
    onSetDefaultHome: () -> Unit,
    intervalMin: Int,
    cats: Int,
    anim: Int,
    tileSize: Int,
    wallMode: Int,
    recentCount: Int,
    mediaAccess: Boolean,
    res4k: Boolean,
    onRes4k: (Boolean) -> Unit,
    nightMode: Int,
    onNightMode: (Int) -> Unit,
    onTheme: (Int) -> Unit,
    onInterval: (Int) -> Unit,
    onCats: (Int) -> Unit,
    onAnim: (Int) -> Unit,
    onTileSize: (Int) -> Unit,
    onRecentCount: (Int) -> Unit,
    onClearRecent: () -> Unit,
    onWallMode: (Int) -> Unit,
    onOpenGallery: () -> Unit,
    onOpenLocal: () -> Unit,
    onOpenWeather: () -> Unit,
    onOpenClock: () -> Unit,
    onOpenPicker: () -> Unit,
    onOpenUpdate: () -> Unit,
    onOpenChangelog: () -> Unit,
    onGrantMedia: () -> Unit,
    onSystemSettings: () -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var cat by remember { mutableIntStateOf(SettingsMemo.cat) }
    var closeFocused by remember { mutableStateOf(false) }
    val side = remember { List(6) { FocusRequester() } }   // 0..4 categories, 5 = Close
    val paneFirst = remember { FocusRequester() }
    var inPane by remember { mutableStateOf(false) }
    var sideFocus by remember { mutableStateOf(true) }
    var sideLocked by remember { mutableStateOf(false) }   // while the page has focus, the list cannot grab focus
    var movieMsg by remember { mutableStateOf("") }
    var typeTip by remember { mutableStateOf("") }
    val goSide: () -> Unit = {
        Sfx.back()
        inPane = false
        sideLocked = false
        scope.launch {
            delay(80L)
            runCatching { side[cat].requestFocus() }
        }
    }
    val goPane: () -> Unit = {
        inPane = true
        closeFocused = false
        runCatching { paneFirst.requestFocus() }
    }
    // Back inside a page returns to the category list; Back on the list closes Settings
    val inPaneNow by rememberUpdatedState(inPane || !sideFocus)
    DisposableEffect(Unit) {
        SettingsBack.handler = { if (inPaneNow) { goSide(); true } else false }
        onDispose { SettingsBack.handler = null }
    }
    // Coming back from another screen (system Notification access) Compose can lose focus: put it back
    LaunchedEffect(resumeTick) {
        delay(400L)
        if (inPane) {
            runCatching { paneFirst.requestFocus() }
        } else {
            sideLocked = false
            delay(80L)
            runCatching { side[cat].requestFocus() }
        }
    }
    var status by remember { mutableStateOf(Remote.status) }
    var mediaDbg by remember { mutableStateOf("") }
    var roomDbg by remember { mutableStateOf("") }
    var vizDbg by remember { mutableStateOf("") }
    val previewBands = remember { mutableStateOf(FloatArray(16) { i -> (0.18f + 0.78f * abs(sin(i * 0.85f + 0.6f))) * (1f - i * 0.025f) }) }
    val previewPeaks = remember { mutableStateOf(FloatArray(16) { i -> (previewBands.value[i] + 0.1f).coerceAtMost(1f) }) }

    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { side[cat].requestFocus() }
    }
    LaunchedEffect(Unit) {
        while (isActive) {
            status = Remote.status
            mediaDbg = withContext(Dispatchers.IO) { NowPlaying.debug(ctx) }
            roomDbg = RoomTemp.status
            vizDbg = AudioViz.status
            delay(2000L)
        }
    }

    // Up / Down move through the list and switch the page; Right jumps into the page
    val sideKey: (Int, Int) -> Boolean = { i, code ->
        when (code) {
            android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (i < 5) {
                    if (i + 1 <= 4) cat = i + 1
                    runCatching { side[i + 1].requestFocus() }
                }
                true
            }
            android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                if (i > 0) {
                    cat = i - 1
                    runCatching { side[i - 1].requestFocus() }
                }
                true
            }
            android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (i < 5) goPane()
                true
            }
            android.view.KeyEvent.KEYCODE_DPAD_LEFT -> true
            else -> false
        }
    }

    // Safety net: if focus is ever lost inside Settings, put it back
    var rootFocus by remember { mutableStateOf(true) }
    val modalNow by rememberUpdatedState(modalOpen)
    val backPending = remember { BooleanArray(1) }
    LaunchedEffect(Unit) {
        var misses = 0
        while (isActive) {
            delay(400L)
            if (rootFocus || modalNow) {
                misses = 0
            } else if (++misses >= 2) {
                misses = 0
                if (inPaneNow) {
                    if (runCatching { paneFirst.requestFocus() }.isFailure) goSide()
                } else {
                    sideLocked = false
                    runCatching { side[cat].requestFocus() }
                }
            }
        }
    }

    Row(
        Modifier
            .fillMaxSize()
            .onFocusChanged { rootFocus = it.hasFocus }
            // Back and Left (at the start of a row) inside a page return to the category list
            .onPreviewKeyEvent { ev ->
                val k = ev.nativeKeyEvent.keyCode
                if (k == android.view.KeyEvent.KEYCODE_BACK) {
                    if (ev.type == KeyEventType.KeyDown) {
                        if (inPaneNow) {
                            backPending[0] = true
                            goSide()
                            true
                        } else {
                            false
                        }
                    } else if (backPending[0]) {
                        backPending[0] = false
                        true
                    } else {
                        false
                    }
                } else if (inPaneNow && k == android.view.KeyEvent.KEYCODE_DPAD_LEFT &&
                    ev.type == KeyEventType.KeyDown && FocusTrack.atRowStart()
                ) {
                    goSide()
                    true
                } else {
                    false
                }
            }
            .background(Brush.horizontalGradient(listOf(Color(0xFA050913), Color(0xF50A1222))))
    ) {
        Column(
            Modifier
                .width(270.dp)
                .fillMaxHeight()
                .onFocusChanged { sideFocus = it.hasFocus }
                .background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.34f), Color(0xFF0B1124), Color(0xFF060914))))
                .padding(horizontal = 18.dp, vertical = 24.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SonicLogo(Modifier.size(44.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Sonik Launcher",
                        color = TextHi,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont
                    )
                    Text(
                        text = "Settings  ·  v" + Config.VERSION,
                        color = accent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont
                    )
                }
            }
            Spacer(Modifier.height(22.dp))
            SETTINGS_CATS.forEachIndexed { i, name ->
                SideItem(
                    text = name,
                    icon = i,
                    selected = cat == i && !closeFocused,
                    req = side[i],
                    locked = sideLocked,
                    onFocus = {
                        cat = i
                        closeFocused = false
                        SettingsMemo.cat = i
                    },
                    onKey = { code -> sideKey(i, code) },
                    onClick = { goPane() }
                )
                Spacer(Modifier.height(4.dp))
            }
            Spacer(Modifier.weight(1f))
            SideItem(
                text = "Close",
                icon = 5,
                selected = false,
                req = side[5],
                locked = sideLocked,
                onFocus = { closeFocused = true },
                onKey = { code -> sideKey(5, code) },
                onClick = onClose
            )
        }

        Box(Modifier.width(1.dp).fillMaxHeight().background(accent.copy(alpha = 0.35f)))

        Box(Modifier.weight(1f).fillMaxHeight()) {
            WithBringSpec(110, 380) {
            key(cat) {
                val scroll = rememberScrollState()
                Column(
                    Modifier
                        .fillMaxSize()
                        .onPreviewKeyEvent { ev ->
                            if (ev.type == KeyEventType.KeyDown) {
                                when (ev.nativeKeyEvent.keyCode) {
                                    // Left at the start of a row goes back to the category you came from
                                    android.view.KeyEvent.KEYCODE_DPAD_LEFT -> {
                                        if (FocusTrack.atRowStart()) goSide() else return@onPreviewKeyEvent false
                                        true
                                    }
                                    android.view.KeyEvent.KEYCODE_BACK -> {
                                        goSide()
                                        true
                                    }
                                    else -> false
                                }
                            } else {
                                // swallow the Back release too, so the dialog never sees half a Back press
                                ev.nativeKeyEvent.keyCode == android.view.KeyEvent.KEYCODE_BACK
                            }
                        }
                        // Up / Down / Right can never leave the page; Left is handled above
                        .focusProperties {
                            exit = { FocusRequester.Cancel }
                        }
                        .focusGroup()
                        .verticalScroll(scroll)
                        .padding(horizontal = 32.dp, vertical = 26.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = SETTINGS_CATS[cat],
                        color = TextHi,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont
                    )
                    Text(
                        text = SETTINGS_HINTS[cat],
                        color = TextLo,
                        fontSize = 13.sp,
                        fontFamily = RoundedFont
                    )

                    when (cat) {
                        0 -> {
                            SettingCard("Colour theme", "Auto picks the most colourful tone of the current wallpaper.") {
                                Row(
                                    Modifier.scrollTopOnFocus(scroll, scope),
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Themes.forEachIndexed { i, t ->
                                        ThemeSwatch(
                                            theme = t,
                                            selected = !autoAccent && i == themeIdx,
                                            focusRequester = if (i == themeIdx) paneFirst else null
                                        ) {
                                            onTheme(i)
                                            onAutoAccent(false)
                                        }
                                    }
                                }
                                Spacer(Modifier.height(12.dp))
                                ChipButton("Auto (from wallpaper)", autoAccent, compact = true) { onAutoAccent(!autoAccent) }
                            }
                            SettingCard("Tile style", "Banners use the 16:9 artwork TV apps ship; apps without one show their icon.") {
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ChipButton("Icons", tileStyle == 0, compact = true) { onTileStyle(0) }
                                    ChipButton("Banners (16:9)", tileStyle == 1, compact = true) { onTileStyle(1) }
                                }
                            }
                            SettingCard("Tile size") {
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    listOf("Small", "Medium", "Large", "Extra large").forEachIndexed { i, name ->
                                        ChipButton(name, tileSize == i, compact = true) { onTileSize(i) }
                                    }
                                }
                            }
                            SettingCard("Wi-Fi icon", "Where the Wi-Fi button sits on the home screen.") {
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    listOf("Top right", "Top left", "Bottom left", "Bottom right", "Hidden").forEachIndexed { i, n ->
                                        ChipButton(n, wifiPos == i, compact = true) { onWifiPos(i) }
                                    }
                                }
                            }
                            SettingCard("Sounds", "A click for OK, a lower tone for Back and a soft tick when you move.") {
                                ChipRow {
                                    ChipButton("Off", sounds == 0, compact = true) { onSounds(0) }
                                    ChipButton("Clicks only", sounds == 1, compact = true) { onSounds(1) }
                                    ChipButton("Clicks and movement", sounds == 2, compact = true) { onSounds(2) }
                                }
                            }
                            SettingCard("Effects", "Ambient glow tints the bottom of the screen with the colour of the focused app.", modifier = Modifier.scrollBottomOnFocus(scroll, scope)) {
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ChipButton("Ambient glow", ambient, compact = true) { onAmbient(!ambient) }
                                }
                                Spacer(Modifier.height(10.dp))
                                SectionLabel("Animations")
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ChipButton("Full", anim == 0, compact = true) { onAnim(0) }
                                    ChipButton("Reduced", anim == 1, compact = true) { onAnim(1) }
                                    ChipButton("Off", anim == 2, compact = true) { onAnim(2) }
                                }
                            }
                        }

                        1 -> {
                            SettingCard("Home screen", "Hold OK on a tile for more: move, remove, app info.") {
                                FlowRow(
                                    Modifier.scrollTopOnFocus(scroll, scope),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ChipButton("Choose home apps...", false, paneFirst, compact = true) { onOpenPicker() }
                                    ChipButton("Clock style...", false, compact = true) { onOpenClock() }
                                    ChipButton("Weather card...", false, compact = true) { onOpenWeather() }
                                }
                            }
                            SettingCard(
                                "Room temperature",
                                "Shown next to the clock once Clock style > Room temperature is on. Echo Dot has no public API, so this reads the sensor from Home Assistant. Steps: 1 address, 2 token, 3 Find sensors, pick yours. Tip: the Google TV phone app has a keyboard that makes typing the token easy."
                            ) {
                                Text(text = roomDbg, color = TextLo, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                Spacer(Modifier.height(10.dp))
                                ChipRow {
                                    ChipButton("Home Assistant address...", false, compact = true) {
                                        onEditText("Home Assistant address", "Include http:// and the port, e.g. http://192.168.1.20:8123", Prefs.haUrl(ctx).ifBlank { "http://homeassistant.local:8123" }) { v ->
                                            Prefs.setHaUrl(ctx, v.trim())
                                            onRoomRefresh()
                                        }
                                    }
                                    ChipButton("Access token...", false, compact = true) {
                                        onEditText("Access token", "Home Assistant > your profile > Long-lived access tokens", Prefs.haToken(ctx)) { v ->
                                            Prefs.setHaToken(ctx, v.trim())
                                            onRoomRefresh()
                                        }
                                    }
                                    ChipButton("Find sensors...", false, compact = true) {
                                        scope.launch {
                                            val found = withContext(Dispatchers.IO) { RoomTemp.discover(ctx) }
                                            if (found.isEmpty()) {
                                                Toast.makeText(ctx, "No temperature sensors found. " + RoomTemp.status, Toast.LENGTH_LONG).show()
                                            } else {
                                                onPickList("Pick the temperature sensor", found) { id ->
                                                    Prefs.setHaEntity(ctx, id)
                                                    onRoomRefresh()
                                                }
                                            }
                                        }
                                    }
                                    ChipButton("Sensor name...", false, compact = true) {
                                        onEditText("Sensor name", "e.g. sensor.living_room_echo_temperature", Prefs.haEntity(ctx)) { v ->
                                            Prefs.setHaEntity(ctx, v.trim())
                                            onRoomRefresh()
                                        }
                                    }
                                    ChipButton("Test now", false, compact = true) { onRoomRefresh() }
                                }
                            }
                            SettingCard(
                                "Recent tiles",
                                "What you last played or watched. Needs the playback card access. Tap one to reopen the app.",
                                modifier = Modifier.scrollBottomOnFocus(scroll, scope)
                            ) {
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    listOf(0, 2, 4, 6).forEach { n ->
                                        ChipButton(if (n == 0) "Off" else n.toString(), recentCount == n, compact = true) { onRecentCount(n) }
                                    }
                                    ChipButton("Clear history", false, compact = true) { onClearRecent() }
                                }
                            }
                        }

                        2 -> {
                            SettingCard(
                                "Wallpaper type",
                                if (wallMode == 2) "A live animation instead of pictures."
                                else if (wallMode == 1) "One picture you picked stays on screen."
                                else "A new picture every few minutes from the online sources you choose.",
                                modifier = Modifier.scrollTopOnFocus(scroll, scope)
                            ) {
                                DropdownChip(
                                    options = listOf("Rotating pictures (online)", "Fixed picture (my pick)", "Animated (drawn live)"),
                                    selected = wallMode,
                                    focusRequester = paneFirst
                                ) { onWallMode(it) }
                            }
                            if (wallMode == 2) {
                                SettingCard("Animation", "Drawn live in the app, no downloads. It follows the time of day: sunrise, day, sunset and night.") {
                                    DropdownChip(
                                        options = listOf("Abstract (colour and light)", "Nature (mountains and lake)", "London (skyline, Thames, traffic)"),
                                        selected = animStyle
                                    ) { onAnimStyle(it) }
                                    Text(
                                        text = "The clock colour Adapt to wallpaper shows white on animated wallpapers.",
                                        color = TextLo,
                                        fontSize = 11.sp,
                                        fontFamily = RoundedFont,
                                        modifier = Modifier.padding(top = 10.dp)
                                    )
                                }
                            } else if (wallMode == 1) {
                                SettingCard("Fixed picture", "Pick a picture; it is saved as your wallpaper, cropped to the screen.") {
                                    ChipRow {
                                        ChipButton("Wallpaper gallery...", false, compact = true) { onOpenGallery() }
                                        ChipButton("From this device...", false, compact = true) { onOpenLocal() }
                                    }
                                }
                            } else {
                                SettingCard("Types", "Tap a type to use only that one, tap more to mix them.") {
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        val pick = { bit: Int -> onCats(if (cats == CAT_ALL) bit else cats xor bit) }
                                        ChipButton("All", cats == CAT_ALL, compact = true, onFocus = { typeTip = "Mixes every type below. Movies are included when a TMDB key is set." }) { onCats(CAT_ALL) }
                                        ChipButton("Space", (cats and CAT_SPACE) != 0 && cats != CAT_ALL, compact = true, onFocus = { typeTip = "NASA pictures: nebulae, galaxies, planets." }) { pick(CAT_SPACE) }
                                        ChipButton("Nature", (cats and CAT_NATURE) != 0 && cats != CAT_ALL, compact = true, onFocus = { typeTip = "Bing daily pictures and landscape photos." }) { pick(CAT_NATURE) }
                                        ChipButton("City", (cats and CAT_CITY) != 0 && cats != CAT_ALL, compact = true, onFocus = { typeTip = "Featured photos of London and other cities." }) { pick(CAT_CITY) }
                                        ChipButton("Animals", (cats and CAT_ANIMALS) != 0 && cats != CAT_ALL, compact = true, onFocus = { typeTip = "Featured wildlife photos from Wikimedia Commons." }) { pick(CAT_ANIMALS) }
                                        ChipButton("Art", (cats and CAT_ART) != 0 && cats != CAT_ALL, compact = true, onFocus = { typeTip = "Landscape and seascape paintings." }) { pick(CAT_ART) }
                                        ChipButton("London (time of day)", (cats and CAT_LONDON) != 0 && cats != CAT_ALL, compact = true, onFocus = { typeTip = "London photos that follow the time of day and the weather." }) { pick(CAT_LONDON) }
                                    }
                                    Text(
                                        text = if (typeTip.isEmpty()) "Move over a type to see what it does." else typeTip,
                                        color = accent,
                                        fontSize = 12.sp,
                                        fontFamily = RoundedFont,
                                        modifier = Modifier.padding(top = 12.dp).heightIn(min = 36.dp)
                                    )
                                }
                                SettingCard(
                                    "Movies in cinema",
                                    "Posters of films now showing, with a Watch trailer button above the tiles. Needs the free key below."
                                ) {
                                    val movieMode = if ((cats and CAT_MOVIES) == 0) 2 else if (cats == CAT_MOVIES) 0 else 1
                                    ChipRow {
                                        ChipButton("Movies only", movieMode == 0, compact = true) { onCats(CAT_MOVIES) }
                                        ChipButton("Mix with other types", movieMode == 1, compact = true) {
                                            onCats(if (cats == CAT_MOVIES) CAT_ALL else cats or CAT_MOVIES)
                                        }
                                        ChipButton("No movies", movieMode == 2, compact = true) {
                                            val r = cats and CAT_MOVIES.inv() and CAT_ALL
                                            onCats(if (r == 0) CAT_ALL and CAT_MOVIES.inv() else r)
                                        }
                                    }
                                    Text(
                                        text = "Movies only: every picture is a film poster. Mix: film posters appear now and then between the pictures of the types above. No movies: films are left out.",
                                        color = TextLo,
                                        fontSize = 11.sp,
                                        fontFamily = RoundedFont,
                                        modifier = Modifier.padding(top = 10.dp)
                                    )
                                }
                                SettingCard(
                                    "Movies in cinema key",
                                    "The Movies type needs a free TMDB v3 API key (themoviedb.org > Settings > API)."
                                ) {
                                    Text(
                                        text = if (Remote.tmdb().isBlank()) "TMDB key: not set" else "TMDB key: set",
                                        color = if (Remote.tmdb().isBlank()) TextLo else accent,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = RoundedFont
                                    )
                                    Spacer(Modifier.height(10.dp))
                                    ChipRow {
                                        ChipButton("Set TMDB key...", false, compact = true) {
                                            onEditText("TMDB API key", "Paste the v3 API key", Prefs.tmdbKey(ctx)) { v ->
                                                Prefs.setTmdbKey(ctx, v.trim())
                                                Remote.tmdbKey = v.trim()
                                                onWallRefresh()
                                            }
                                        }
                                        ChipButton("Check the key", false, compact = true) {
                                            scope.launch {
                                                movieMsg = "Checking..."
                                                movieMsg = withContext(Dispatchers.IO) { Remote.movieCheck() }
                                                onWallRefresh()
                                            }
                                        }
                                    }
                                    if (movieMsg.isNotEmpty()) {
                                        Text(text = movieMsg, color = TextLo, fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 8.dp))
                                    }
                                }
                                SettingCard("Changes every") {
                                    val steps = listOf(0, 5, 10, 15, 20, 30, 45, 60)
                                    Box(Modifier.width(340.dp)) {
                                        DropdownChip(
                                            options = steps.map { if (it == 0) "Never (stay on one picture)" else it.toString() + " min" },
                                            selected = steps.indexOfFirst { it >= intervalMin }.let { if (it < 0) steps.size - 1 else it }
                                        ) { onInterval(steps[it]) }
                                    }
                                }
                            }
                            if (wallMode != 2) {
                                SettingCard("Quality", "Resolution of downloaded and saved pictures.") {
                                    ChipRow {
                                        ChipButton("1080p", !res4k, compact = true) { onRes4k(false) }
                                        ChipButton("4K (3840 x 2160)", res4k, compact = true) { onRes4k(true) }
                                    }
                                }
                            }
                            SettingCard(
                                "Night mode",
                                "Same wallpaper, darker and cooler after sunset (sunrise and sunset ease in).",
                                modifier = Modifier.scrollBottomOnFocus(scroll, scope)
                            ) {
                                ChipRow {
                                    listOf("Off", "Soft", "Deep").forEachIndexed { i, n ->
                                        ChipButton(n, nightMode == i, compact = true) { onNightMode(i) }
                                    }
                                }
                            }
                        }

                        3 -> {
                            SettingCard("Now playing card", "Shows Deezer, YouTube Music, Tidal and any media app. Android needs notification access for it.", modifier = Modifier.scrollTopOnFocus(scroll, scope)) {
                                Text(
                                    text = if (mediaAccess) "Notification access: on" else "Notification access: needed",
                                    color = if (mediaAccess) accent else TextLo,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = RoundedFont
                                )
                                Spacer(Modifier.height(10.dp))
                                ChipButton(
                                    if (mediaAccess) "Notification access settings..." else "Grant access",
                                    false, paneFirst, compact = true
                                ) { onGrantMedia() }
                                ChipButton("Open app info (allow restricted settings)", false, compact = true) {
                                    openAppInfo(ctx, ctx.packageName)
                                }
                                Text(
                                    text = "If the switch turns itself off again: Settings > Apps > Special app access > Notification access > Sonik Launcher, or in App info open the menu and choose Allow restricted settings.",
                                    color = TextLo,
                                    fontSize = 11.sp,
                                    fontFamily = RoundedFont,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                                if (!mediaAccess) {
                                    Text(
                                        text = "If the system screen will not switch it on, run once on a computer: adb shell pm grant com.streamerhome.launcher android.permission.WRITE_SECURE_SETTINGS   then press Grant access again.\nOr: adb shell appops set com.streamerhome.launcher ACCESS_RESTRICTED_SETTINGS allow   and retry the system screen.",
                                        color = TextLo,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.padding(top = 8.dp)
                                    )
                                }
                            }
                            SettingCard("Media sessions Android reports", "State 3 = playing, 2 = paused, 1 = stopped.") {
                                Text(
                                    text = mediaDbg,
                                    color = TextLo,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            SettingCard(
                                "Music visualiser",
                                "Bars along the bottom while music plays. It listens to the audio output; apps that block capture get a simulated animation instead.",
                                modifier = Modifier.scrollBottomOnFocus(scroll, scope)
                            ) {
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    listOf("Off", "Bars", "Mirror", "Pills", "LED", "Wave", "Radial").forEachIndexed { i, n ->
                                        ChoiceTile(n, vizStyle == i, onClick = { onVizStyle(i) }, previewH = 64.dp) { _ ->
                                            if (i == 0) {
                                                Text(text = "Off", color = TextLo, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = RoundedFont)
                                            } else {
                                                VizStrip(i, previewBands, previewPeaks, accent, Modifier.fillMaxWidth().height(64.dp))
                                            }
                                        }
                                    }
                                }
                                if (!audioGranted) {
                                    Spacer(Modifier.height(10.dp))
                                    ChipButton("Allow audio access", false, compact = true) { onAskAudio() }
                                }
                                Text(
                                    text = vizDbg,
                                    color = TextLo,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                            }
                        }

                        else -> {
                            SettingCard(
                                "Default launcher",
                                if (isDefaultHome) "Sonik Launcher is the default home app." else "Another launcher may open when you press Home.",
                                modifier = Modifier.scrollTopOnFocus(scroll, scope)
                            ) {
                                ChipButton("Set as default launcher", isDefaultHome, paneFirst, compact = true) { onSetDefaultHome() }
                                Text(
                                    text = "If no dialog appears, run on a computer: adb shell cmd package set-home-activity com.streamerhome.launcher/.MainActivity",
                                    color = TextLo,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                            }
                            SettingCard("Updates", "Checked only when you ask.") {
                                ChipButton("Check for updates...", false, compact = true) { onOpenUpdate() }
                                Spacer(Modifier.height(10.dp))
                                ChipButton("What's new (changelog)...", false, compact = true) { onOpenChangelog() }
                            }
                            SettingCard("Online image status") {
                                Text(
                                    text = status,
                                    color = TextLo,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            SettingCard("About", modifier = Modifier.scrollBottomOnFocus(scroll, scope)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    SonicLogo(Modifier.size(64.dp))
                                    Spacer(Modifier.width(16.dp))
                                    Column {
                                        Text(
                                            text = "Sonik Launcher  ·  v" + Config.VERSION,
                                            color = TextHi,
                                            fontSize = 17.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = RoundedFont
                                        )
                                        Text(
                                            text = "An ad-free home screen for Google TV with live weather, wallpapers, a playback card and your own apps.",
                                            color = TextLo,
                                            fontSize = 12.sp,
                                            fontFamily = RoundedFont,
                                            modifier = Modifier.padding(top = 2.dp)
                                        )
                                        Text(
                                            text = "Created by Claudiu   ·   ravebot@gmail.com",
                                            color = TextHi,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium,
                                            fontFamily = RoundedFont,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "Data and pictures: Open-Meteo, NASA APOD, Bing, Wikimedia Commons, Flickr, Openverse. Weather icons: Meteocons (MIT).",
                                    color = TextLo,
                                    fontSize = 10.sp,
                                    fontFamily = RoundedFont,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                                Spacer(Modifier.height(10.dp))
                                ChipButton("System settings", false, compact = true) { onSystemSettings() }
                            }
                        }
                    }
                    Spacer(Modifier.height(160.dp))
                }
            }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        color = LocalAccent.current.copy(alpha = 0.95f),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = RoundedFont,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun ThemeSwatch(
    theme: ThemeSpec,
    selected: Boolean,
    focusRequester: FocusRequester?,
    onClick: () -> Unit
) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(44.dp)
                .trackLeft(focused)
                .scale(if (focused) 1.15f else 1f)
                .then(
                    if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier
                )
                .clip(CircleShape)
                .background(theme.accent)
                .border(
                    3.dp,
                    if (selected) Color.White else if (focused) Color(0xAAFFFFFF) else Color.Transparent,
                    CircleShape
                )
                .focusable(interactionSource = source)
                .clickable(interactionSource = source, indication = null, onClick = { Sfx.click(); onClick() })
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = theme.name,
            color = if (selected) TextHi else TextLo,
            fontSize = 11.sp,
            fontFamily = RoundedFont
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChipButton(
    text: String,
    selected: Boolean,
    focusRequester: FocusRequester? = null,
    compact: Boolean = false,
    wide: Boolean = false,
    onFocus: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val bir = remember { BringIntoViewRequester() }
    var chipSize by remember { mutableStateOf(IntSize.Zero) }
    val marginPx = with(LocalDensity.current) { 110.dp.toPx() }
    LaunchedEffect(focused) {
        if (focused) {
            onFocus?.invoke()
            delay(30L)
            runCatching {
                bir.bringIntoView(Rect(0f, -marginPx, chipSize.width.toFloat(), chipSize.height + marginPx))
            }
        }
    }
    val shape = RoundedCornerShape(50)
    val bg: Brush = if (focused) Brush.horizontalGradient(listOf(Color.White, Color(0xFFDDE6FF)))
    else if (selected) Brush.horizontalGradient(listOf(accent.copy(alpha = 0.7f), accent.copy(alpha = 0.4f)))
    else Brush.horizontalGradient(listOf(Color(0xFF1E2848), Color(0xFF151D36)))
    Box(
        (if (wide) Modifier.fillMaxWidth() else Modifier)
            .onSizeChanged { chipSize = it }
            .trackLeft(focused)
            .bringIntoViewRequester(bir)
            .scale(if (focused) 1.06f else 1f)
            .clip(shape)
            .background(bg)
            .border(if (focused) 3.dp else 1.dp, if (focused || selected) accent else Color(0x44FFFFFF), shape)
            .then(
                if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier
            )
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = { if (text in BACK_LABELS) Sfx.back() else Sfx.click(); onClick() })
            .padding(horizontal = if (compact) 14.dp else 22.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (focused) Ink else TextHi,
            fontSize = if (compact) 14.sp else 15.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RoundedFont
        )
    }
}

// ---------- Network dialog ----------

@Composable
private fun NetDialog(
    net: NetInfo,
    onClose: () -> Unit,
    onAskLocation: () -> Unit,
    onSettings: () -> Unit
) {
    val accent = LocalAccent.current
    val closeFocus = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { closeFocus.requestFocus() }
    }

    val shape = RoundedCornerShape(20.dp)

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            Modifier
                .width(500.dp)
                .navSound()
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xFF131C34), Color(0xFF0A1020))))
                .border(1.dp, LocalAccent.current.copy(alpha = 0.35f), shape)
                .padding(30.dp)
        ) {
            Text(
                text = "Network",
                color = accent,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = net.name,
                color = TextHi,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                style = glow(accent, 18f)
            )
            if (net.detail.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = net.detail,
                    color = TextLo,
                    fontSize = 15.sp,
                    fontFamily = RoundedFont
                )
            }
            if (net.needsLocation) {
                Spacer(Modifier.height(14.dp))
                Text(
                    text = "Android only shows the Wi-Fi name after location access is allowed.",
                    color = TextLo,
                    fontSize = 14.sp,
                    fontFamily = RoundedFont
                )
                Spacer(Modifier.height(12.dp))
                ChipButton("Allow access", true) { onAskLocation() }
            }
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                ChipButton("Wi-Fi settings", false) { onSettings() }
                ChipButton("Close", true, closeFocus) { onClose() }
            }
        }
    }
}


// ---------- Now playing card ----------

@Composable
private fun NowPlayingCard(
    info: MediaInfo,
    art: ImageBitmap?,
    playFocus: FocusRequester,
    downTarget: FocusRequester,
    onControl: (Int) -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    var appIcon by remember(info.pkg) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(info.pkg) {
        appIcon = withContext(Dispatchers.IO) { Apps.icon(context.packageManager, info.pkg) }
    }
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .width(470.dp)
            .clip(shape)
            .background(glassFill)
            .border(1.dp, glassBorder, shape)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val cover = art ?: appIcon
        Box(
            Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0x33FFFFFF))
        ) {
            if (cover != null) {
                Image(
                    bitmap = cover,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = if (info.playing) "Now playing" else "Paused",
                color = accent,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
            )
            Text(
                text = info.title,
                color = TextHi,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = info.artist,
                color = TextLo,
                fontSize = 12.sp,
                fontFamily = RoundedFont,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TransportButton(0, info.playing, null, downTarget) { onControl(0) }
            TransportButton(1, info.playing, playFocus, downTarget) { onControl(1) }
            TransportButton(2, info.playing, null, downTarget) { onControl(2) }
        }
    }
}

// kind: 0 = previous, 1 = play / pause, 2 = next
@Composable
private fun TransportButton(
    kind: Int,
    playing: Boolean,
    focusRequester: FocusRequester?,
    downTarget: FocusRequester?,
    onClick: () -> Unit
) {
    val accent = LocalAccent.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(if (focused) accent else Color(0x26FFFFFF))
            .then(if (downTarget != null) Modifier.downTo(downTarget) else Modifier)
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .focusable(interactionSource = source)
            .clickable(interactionSource = source, indication = null, onClick = { Sfx.click(); onClick() }),
        contentAlignment = Alignment.Center
    ) {
        val c = if (focused) Ink else TextHi
        Canvas(Modifier.size(16.dp)) {
            val w = size.width
            val h = size.height
            if (kind == 0) {
                drawRect(c, Offset(0f, 0f), Size(w * 0.16f, h))
                val tri = Path()
                tri.moveTo(w, 0f)
                tri.lineTo(w * 0.28f, h / 2f)
                tri.lineTo(w, h)
                tri.close()
                drawPath(tri, c)
            } else if (kind == 2) {
                drawRect(c, Offset(w * 0.84f, 0f), Size(w * 0.16f, h))
                val tri = Path()
                tri.moveTo(0f, 0f)
                tri.lineTo(w * 0.72f, h / 2f)
                tri.lineTo(0f, h)
                tri.close()
                drawPath(tri, c)
            } else if (playing) {
                drawRect(c, Offset(w * 0.12f, 0f), Size(w * 0.28f, h))
                drawRect(c, Offset(w * 0.60f, 0f), Size(w * 0.28f, h))
            } else {
                val tri = Path()
                tri.moveTo(w * 0.15f, 0f)
                tri.lineTo(w, h / 2f)
                tri.lineTo(w * 0.15f, h)
                tri.close()
                drawPath(tri, c)
            }
        }
    }
}

// ---------- Forecast (tap the weather card) ----------

// Soft tones (no strong greens) for temperatures
private fun tempTone(t: Int): Color = when {
    t <= 0 -> Color(0xFFA5D0FF)
    t <= 8 -> Color(0xFF86BCFF)
    t <= 15 -> Color(0xFFB9C4FF)
    t <= 22 -> Color(0xFFFFDB8E)
    t <= 28 -> Color(0xFFFFB46B)
    else -> Color(0xFFFF7E6E)
}

private val RainBlue = Color(0xFF8FD0FF)
private val CellFill = Color(0xCC080D1C)
private val CellBorder = Color(0x40FFFFFF)

private fun cap(t: String): String = t.lowercase().replaceFirstChar { it.uppercase() }

@Composable
private fun FcLabel(text: String) {
    Text(
        text = text,
        color = Color.White.copy(alpha = 0.9f),
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(bottom = 6.dp)
    )
}

@Composable
private fun InfoChip(text: String, color: Color) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier
            .clip(shape)
            .background(Color(0xB3050914))
            .border(1.dp, color.copy(alpha = 0.7f), shape)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text = text, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ForecastPanel(w: Weather?, cfg: WeatherCfg, anim: Int, onSettings: () -> Unit, onClose: () -> Unit) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { first.requestFocus() }
    }
    val isDay = w?.isDay ?: true
    val group = w?.group ?: "cloud"
    val sky = skyColors(isDay, group)
    Box(Modifier.fillMaxSize().background(Ink)) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(sky.first.copy(alpha = 0.7f), sky.second.copy(alpha = 0.35f), Color.Transparent)))
        )
        WeatherBackdrop(group, isDay, anim)
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 32.dp, vertical = 14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Forecast  ·  " + Config.CITY,
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                ChipButton("Weather settings...", false, compact = true) { onSettings() }
                Spacer(Modifier.width(8.dp))
                ChipButton("Close", true, first, compact = true) { onClose() }
            }
            Spacer(Modifier.height(10.dp))
            if (w == null) {
                Text(text = "No weather data yet. Try again in a moment.", color = TextHi, fontSize = 15.sp)
            } else {
                val heroShape = RoundedCornerShape(22.dp)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(heroShape)
                        .background(CellFill)
                        .border(1.dp, CellBorder, heroShape)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    WeatherArt(w.code, w.isDay, anim, Modifier.size(84.dp))
                    Spacer(Modifier.width(14.dp))
                    Text(
                        text = w.temp.toString() + "°",
                        color = tempTone(w.temp),
                        fontSize = 56.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.width(18.dp))
                    Column {
                        Text(text = w.label, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if ((cfg.info and WX_HL) != 0) {
                                InfoChip("High " + w.high + "°", tempTone(w.high))
                                InfoChip("Low " + w.low + "°", tempTone(w.low))
                            }
                            if ((cfg.info and WX_HUM) != 0) InfoChip("Humidity " + w.humidity + "%", RainBlue)
                        }
                        if ((cfg.info and WX_WIND) != 0) {
                            Spacer(Modifier.height(6.dp))
                            InfoChip("Wind " + compass(w.windDir) + " " + w.windMph + " mph" + (if (w.gustMph > w.windMph) ", gusts " + w.gustMph else ""), Color(0xFFC9BFFF))
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                FcLabel("Next hours")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    w.hours.take(cfg.hours).forEach { h -> HourCell(h, Modifier.weight(1f)) }
                }
                Spacer(Modifier.height(10.dp))
                FcLabel("Next days")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    w.days.take(cfg.days).forEach { d -> DayCell(d, Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun HourCell(h: HourForecast, modifier: Modifier) {
    val shape = RoundedCornerShape(14.dp)
    val tone = tempTone(h.temp)
    Column(
        modifier
            .clip(shape)
            .background(CellFill)
            .border(1.dp, CellBorder, shape),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.fillMaxWidth().height(3.dp).background(tone))
        Spacer(Modifier.height(4.dp))
        Text(text = h.label, color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
        WeatherArt(h.code, hourIsDay(h.label), 2, Modifier.size(34.dp))
        Text(text = h.temp.toString() + "°", color = tone, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(text = h.rain.toString() + "%", color = if (h.rain >= 40) RainBlue else Color(0xFFB5C2D9), fontSize = 10.sp)
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun DayCell(d: DayForecast, modifier: Modifier) {
    val shape = RoundedCornerShape(14.dp)
    val hi = tempTone(d.high)
    val lo = tempTone(d.low)
    Column(
        modifier
            .clip(shape)
            .background(CellFill)
            .border(1.dp, CellBorder, shape),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.fillMaxWidth().height(3.dp).background(Brush.horizontalGradient(listOf(lo, hi))))
        Spacer(Modifier.height(4.dp))
        Text(text = cap(d.label), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        WeatherArt(d.code, true, 2, Modifier.size(40.dp))
        Row {
            Text(text = d.high.toString() + "°", color = hi, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(5.dp))
            Text(text = d.low.toString() + "°", color = lo, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Text(text = "Rain " + d.rain + "%", color = if (d.rain >= 40) RainBlue else Color(0xFFB5C2D9), fontSize = 10.sp)
        Spacer(Modifier.height(4.dp))
    }
}

// ---------- Changelog (Settings > System) ----------

@Composable
private fun ChangelogPanel(onClose: () -> Unit) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val text = remember {
        try {
            context.assets.open("CHANGELOG.md").bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            "Changelog not available."
        }
    }
    val scroll = rememberScrollState()
    val scope = rememberCoroutineScope()
    val body = remember { FocusRequester() }
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { body.requestFocus() }
    }
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF5060A14))
            .padding(horizontal = 40.dp, vertical = 24.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = "What's new  ·  v" + Config.VERSION,
                        color = accent,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont,
                    )
                    Text(
                        text = "Up / Down scrolls. Up at the top reaches Close.",
                        color = TextLo,
                        fontSize = 11.sp,
                        fontFamily = RoundedFont,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                ChipButton("Close", true, compact = true) { onClose() }
            }
            Spacer(Modifier.height(12.dp))
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(shape)
                    .background(Color(0x14FFFFFF))
                    .border(if (focused) 2.dp else 1.dp, if (focused) accent else Color(0x22FFFFFF), shape)
                    .focusRequester(body)
                    .onPreviewKeyEvent { ev ->
                        if (ev.type == KeyEventType.KeyDown) {
                            when (ev.nativeKeyEvent.keyCode) {
                                android.view.KeyEvent.KEYCODE_DPAD_DOWN ->
                                    if (scroll.value < scroll.maxValue) {
                                        scope.launch { scroll.animateScrollBy(260f) }
                                        true
                                    } else true
                                android.view.KeyEvent.KEYCODE_DPAD_UP ->
                                    if (scroll.value > 0) {
                                        scope.launch { scroll.animateScrollBy(-260f) }
                                        true
                                    } else false
                                else -> false
                            }
                        } else {
                            false
                        }
                    }
                    .focusable(interactionSource = source)
                    .verticalScroll(scroll)
                    .padding(20.dp)
            ) {
                Column {
                    text.lines().forEach { line ->
                        when {
                            line.startsWith("## ") -> Text(
                                text = "v" + line.removePrefix("## "),
                                color = accent,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = RoundedFont,
                                modifier = Modifier.padding(top = 14.dp, bottom = 4.dp)
                            )
                            line.startsWith("- ") -> Text(
                                text = "•  " + line.removePrefix("- "),
                                color = TextHi,
                                fontSize = 13.sp,
                                fontFamily = RoundedFont,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                            else -> {}
                        }
                    }
                }
            }
        }
    }
}

// ---------- Clock style panel (click the clock) ----------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ClockPanel(cfg: ClockCfg, onChange: (ClockCfg) -> Unit, onClose: () -> Unit) {
    val scroll = rememberScrollState()
    val scope = rememberCoroutineScope()
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { first.requestFocus() }
    }

    SidePanel("Clock style", "Changes show on the clock straight away.", scroll, onClose) {
        SettingCard("Font", "Each style is shown as it will look.", modifier = Modifier.scrollTopOnFocus(scroll, scope)) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                maxItemsInEachRow = 3
            ) {
                CLOCK_FONTS.forEachIndexed { i, name ->
                    ChoiceTile(name, cfg.style == i, if (i == cfg.style) first else null, onClick = { onChange(cfg.copy(style = i)) }) { c ->
                        ClockSample(i, c)
                    }
                }
            }
        }

        SettingCard("Size") {
            ChipRow {
                listOf("Mini" to 3, "Small" to 0, "Medium" to 1, "Large" to 2).forEach { (n, v) ->
                    ChipButton(n, cfg.size == v, compact = true) { onChange(cfg.copy(size = v)) }
                }
            }
        }

        SettingCard("Background box") {
            ChipRow {
                listOf("None", "Glass", "Solid").forEachIndexed { i, name ->
                    ChipButton(name, cfg.box == i, compact = true) { onChange(cfg.copy(box = i)) }
                }
            }
        }

        SettingCard("Opacity", "Applies to the whole clock: digits, lines under it and the box.") {
            ChipRow {
                listOf(5, 10, 20, 30, 45, 60, 80, 100).forEach { o ->
                    ChipButton(o.toString() + "%", cfg.opacity == o, compact = true) { onChange(cfg.copy(opacity = o)) }
                }
            }
        }

        SettingCard(
            "Colour",
            "Adapt to wallpaper recolours each part of the clock against the picture behind it: light on dark areas, dark on bright ones. It pauses the slow wallpaper zoom."
        ) {
            ChipRow {
                ChipButton("White", !cfg.accentColor && !cfg.blend, compact = true) { onChange(cfg.copy(accentColor = false, blend = false)) }
                ChipButton("Theme colour", cfg.accentColor && !cfg.blend, compact = true) { onChange(cfg.copy(accentColor = true, blend = false)) }
                ChipButton("Adapt to wallpaper", cfg.blend, compact = true) { onChange(cfg.copy(blend = true)) }
            }
        }

        SettingCard("Format") {
            ChipRow {
                ChipButton("24-hour", cfg.h24, compact = true) { onChange(cfg.copy(h24 = !cfg.h24)) }
                ChipButton("Seconds", cfg.seconds, compact = true) { onChange(cfg.copy(seconds = !cfg.seconds)) }
            }
        }

        SettingCard("Show under the clock") {
            ChipRow {
                ChipButton("Date", (cfg.info and INFO_DATE) != 0, compact = true) { onChange(cfg.copy(info = cfg.info xor INFO_DATE)) }
                ChipButton("Sunrise & sunset", (cfg.info and INFO_SUN) != 0, compact = true) { onChange(cfg.copy(info = cfg.info xor INFO_SUN)) }
                ChipButton("Day length", (cfg.info and INFO_DAYLEN) != 0, compact = true) { onChange(cfg.copy(info = cfg.info xor INFO_DAYLEN)) }
                ChipButton("Moon phase", (cfg.info and INFO_MOON) != 0, compact = true) { onChange(cfg.copy(info = cfg.info xor INFO_MOON)) }
                ChipButton("Tomorrow", (cfg.info and INFO_TOMORROW) != 0, compact = true) { onChange(cfg.copy(info = cfg.info xor INFO_TOMORROW)) }
                ChipButton("Room temperature", (cfg.info and INFO_ROOM) != 0, compact = true) { onChange(cfg.copy(info = cfg.info xor INFO_ROOM)) }
            }
        }

        ChipButton("Done", true) { onClose() }
    }
}

// ---------- Choose which apps are on the home row ----------

@Composable
private fun TilePicker(
    tiles: List<String>,
    resumeTick: Int,
    onToggle: (String) -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val pm = context.packageManager
    val apps = remember(resumeTick) { Apps.installed(context) }
    val requesters = remember(apps) { List(apps.size) { FocusRequester() } }
    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(apps) {
        delay(250L)
        runCatching { requesters.firstOrNull()?.requestFocus() }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF5060A14))
            .padding(horizontal = 40.dp, vertical = 24.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    ScreenTitle("Choose home apps")
                    Text(
                        text = "OK adds or removes an app (tick = on the home row). Hold OK on a home tile to move it.",
                        color = TextLo,
                        fontSize = 11.sp,
                        fontFamily = RoundedFont,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                ChipButton("Done", true) { onClose() }
            }
            Spacer(Modifier.height(12.dp))
            LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Adaptive(104.dp),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(8.dp)
            ) {
                itemsIndexed(apps) { index, app ->
                    var icon by remember(app.pkg) { mutableStateOf<ImageBitmap?>(null) }
                    LaunchedEffect(app.pkg) {
                        icon = withContext(Dispatchers.IO) { Apps.icon(pm, app.pkg) }
                    }
                    AppTile(
                        label = app.label,
                        accent = accent,
                        icon = icon,
                        modifier = Modifier.fillMaxWidth(),
                        badge = if (tiles.contains(app.pkg)) "✓" else null,
                        focusRequester = requesters[index],
                        onFocused = { scope.launch { revealGridItem(gridState, index) } },
                        onDpad = { code -> gridKey(code, scope, gridState, requesters, index) }
                    ) {
                        onToggle(app.pkg)
                    }
                }
            }
        }
    }
}

// ---------- Hold OK on an app: info, uninstall, reorder ----------

@Composable
private fun AppMenu(
    pkg: String,
    onHome: Boolean,
    canLeft: Boolean,
    canRight: Boolean,
    onOpen: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit,
    onLeft: () -> Unit,
    onRight: () -> Unit,
    onToggleHome: () -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val pm = context.packageManager
    val label = Apps.label(pm, pkg)
    val system = Apps.isSystem(pm, pkg)
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(200L)
        runCatching { first.requestFocus() }
    }
    val shape = RoundedCornerShape(20.dp)

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            Modifier
                .width(380.dp)
                .navSound()
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xFF131C34), Color(0xFF0A1020))))
                .border(1.dp, LocalAccent.current.copy(alpha = 0.35f), shape)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = label,
                color = accent,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            ChipButton("Open", false, first, wide = true) { onOpen() }
            ChipButton("App info", false, wide = true) { onInfo() }
            if (!system) {
                ChipButton("Uninstall", false, wide = true) { onUninstall() }
            }
            if (onHome) {
                if (canLeft) {
                    ChipButton("Move left", false, wide = true) { onLeft() }
                }
                if (canRight) {
                    ChipButton("Move right", false, wide = true) { onRight() }
                }
                ChipButton("Remove from home", false, wide = true) { onToggleHome() }
            } else {
                ChipButton("Add to home", false, wide = true) { onToggleHome() }
            }
            ChipButton("Close", true, wide = true) { onClose() }
        }
    }
}

// ---------- Updates from GitHub (only when you press the button) ----------

@Composable
private fun UpdatePanel(
    testBuilds: Boolean,
    onTestBuilds: (Boolean) -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val installed = remember { Updater.installedBuild(context) }
    var release by remember { mutableStateOf<ReleaseInfo?>(null) }
    var message by remember {
        mutableStateOf("Press Check now. Nothing is downloaded or installed unless you confirm.")
    }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(-1) }
    var ready by remember { mutableStateOf<java.io.File?>(null) }
    val first = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { first.requestFocus() }
    }

    val doCheck: () -> Unit = {
        if (!busy) {
            scope.launch {
                busy = true
                release = null
                message = "Checking GitHub..."
                val res = withContext(Dispatchers.IO) { Updater.fetchLatest(testBuilds) }
                release = res.first
                message = if (res.first == null) res.second else ""
                busy = false
            }
        }
    }

    val doInstall: (java.io.File) -> Unit = { file ->
        if (!Updater.canInstall(context)) {
            message = "Allow this app to install apps, then come back and press Install again."
            Updater.openInstallPermission(context)
        } else if (Updater.install(context, file)) {
            message = "Installer opened. Confirm there to finish the update."
        } else {
            message = "Could not start the installer."
        }
    }

    val doDownload: () -> Unit = {
        val rel = release
        if (rel != null && !busy) {
            if (!rel.apkUrl.startsWith("https://github.com/")) {
                message = "Unexpected download address, stopped."
            } else {
                scope.launch {
                    busy = true
                    progress = 0
                    message = "Downloading..."
                    val file = withContext(Dispatchers.IO) {
                        Updater.download(context, rel.apkUrl) { pct -> progress = pct }
                    }
                    progress = -1
                    if (file == null) {
                        message = "Download failed. Check the connection and try again."
                    } else {
                        ready = file
                        message = "Downloaded. Opening the installer..."
                        delay(700L)
                        doInstall(file)
                    }
                    busy = false
                }
            }
        }
    }

    val r = release
    val newer = r != null && Updater.isNewer(r.version)

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF5060A14))
            .padding(horizontal = 40.dp, vertical = 24.dp)
    ) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            ScreenTitle("Updates")
            Spacer(Modifier.height(14.dp))
            Text(
                text = "Installed: v" + Config.VERSION + " (code " + installed + ")" + "",
                color = TextHi,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RoundedFont
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Source: github.com/" + Config.GITHUB_REPO + ". Checked only when you press the button. Stable releases only, unless test builds are on.",
                color = TextLo,
                fontSize = 12.sp,
                fontFamily = RoundedFont
            )
            Spacer(Modifier.height(16.dp))
            if (message.isNotEmpty()) {
                Text(
                    text = message,
                    color = TextHi,
                    fontSize = 15.sp,
                    fontFamily = RoundedFont
                )
            }
            if (r != null) {
                if (newer) {
                    Text(
                        text = "New: " + r.name + "   (v" + r.version + ", " +
                            (Math.round(r.sizeMb * 10.0) / 10.0).toString() + " MB)",
                        color = accent,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RoundedFont
                    )
                    if (r.notes.isNotEmpty()) {
                        Text(
                            text = r.notes,
                            color = TextLo,
                            fontSize = 12.sp,
                            fontFamily = RoundedFont
                        )
                    }
                } else {
                    Text(
                        text = "You are up to date (newest is " + r.name + ").",
                        color = TextHi,
                        fontSize = 15.sp,
                        fontFamily = RoundedFont
                    )
                }
            }
            if (progress >= 0) {
                Text(
                    text = "Downloading " + progress + "%",
                    color = accent,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RoundedFont
                )
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ChipButton("Check now", false, first) { doCheck() }
                if (newer) {
                    ChipButton("Download and install", true) { doDownload() }
                }
                val rf = ready
                if (rf != null) {
                    ChipButton("Install downloaded update", true) { doInstall(rf) }
                }
                ChipButton(if (testBuilds) "Test builds: on" else "Test builds: off", testBuilds) {
                    onTestBuilds(!testBuilds)
                }
                ChipButton("Close", true) { onClose() }
            }
        }
    }
}

// Keeps the focused home tile fully on screen, with a small margin
private suspend fun revealRowItem(state: LazyListState, index: Int, margin: Int) {
    val info = state.layoutInfo
    val item = info.visibleItemsInfo.firstOrNull { it.index == index }
    if (item == null) {
        state.animateScrollToItem(index)
        return
    }
    val start = item.offset
    val end = start + item.size
    val vs = info.viewportStartOffset + margin
    val ve = info.viewportEndOffset - margin
    if (end > ve) state.animateScrollBy((end - ve).toFloat())
    else if (start < vs) state.animateScrollBy((start - vs).toFloat())
}

// ---------- Keep the focused grid item on screen ----------

private suspend fun revealGridItem(state: LazyGridState, index: Int) {
    val info = state.layoutInfo
    val item = info.visibleItemsInfo.firstOrNull { it.index == index }
    if (item == null) {
        state.animateScrollToItem(index)
        return
    }
    val pad = 28
    val top = item.offset.y
    val bottom = top + item.size.height
    if (bottom + pad > info.viewportEndOffset) {
        state.animateScrollBy((bottom + pad - info.viewportEndOffset).toFloat())
    } else if (top - pad < info.viewportStartOffset) {
        state.animateScrollBy((top - pad - info.viewportStartOffset).toFloat())
    }
}

private fun hourIsDay(label: String): Boolean {
    val hr = label.take(2).toIntOrNull() ?: 12
    return hr in 7..17
}

// ---------- Drawn weather artwork ----------

@Composable
private fun WeatherArt(code: Int, isDay: Boolean, anim: Int, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val style = LocalIconStyle.current
    val online = style < 2
    var icon by remember(code, isDay, style) { mutableStateOf<ImageBitmap?>(null) }
    if (online) {
        LaunchedEffect(code, isDay, style) {
            icon = withContext(Dispatchers.IO) { Remote.loadIcon(context, if (style == 1) owmIcon(code, isDay) else iconName(code, isDay), 256, style) }?.asImageBitmap()
        }
    }
    val ic = icon
    if (ic != null) Image(bitmap = ic, contentDescription = null, modifier = modifier)
    else DrawnWeatherArt(code, isDay, anim, style, modifier)
}

private fun owmIcon(code: Int, isDay: Boolean): String {
    val d = if (isDay) "d" else "n"
    return when (code) {
        0, 1 -> "01$d"
        2 -> "02$d"
        3 -> "04$d"
        45, 48 -> "50$d"
        in 51..57 -> "09$d"
        in 61..67, in 80..82 -> "10$d"
        in 71..77, 85, 86 -> "13$d"
        95, 96, 99 -> "11$d"
        else -> "03$d"
    }
}

private fun iconName(code: Int, isDay: Boolean): String = when (code) {
    0, 1 -> if (isDay) "clear-day" else "clear-night"
    2 -> if (isDay) "partly-cloudy-day" else "partly-cloudy-night"
    3 -> "overcast"
    45, 48 -> "fog"
    in 51..57 -> "drizzle"
    66, 67 -> "sleet"
    in 61..65, in 80..82 -> "rain"
    in 71..77, 85, 86 -> "snow"
    95 -> "thunderstorms"
    96, 99 -> "thunderstorms-rain"
    else -> "cloudy"
}

@Composable
private fun DrawnWeatherArt(code: Int, isDay: Boolean, anim: Int, style: Int, modifier: Modifier = Modifier) {
    val phase: State<Float>? = if (anim != 2) {
        rememberInfiniteTransition(label = "art").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(8000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "artPhase"
        )
    } else {
        null
    }
    Canvas(modifier) {
        drawWeather(code, isDay, phase?.value ?: 0f, style)
    }
}

private fun DrawScope.drawWeather(code: Int, isDay: Boolean, p: Float, style: Int = 2) {
    if (style == 3) {
        drawWeatherDeluxe(code, isDay, p)
        return
    }
    if (style == 4) {
        drawWeatherNeon(code, isDay, p)
        return
    }
    val s = minOf(size.width, size.height)
    val kind = when (code) {
        0, 1 -> 0
        2 -> 1
        3 -> 2
        45, 48 -> 3
        in 51..67, in 80..82 -> 4
        in 71..77, 85, 86 -> 5
        in 95..99 -> 6
        else -> 2
    }
    when (kind) {
        0 -> {
            if (isDay) drawSun(s * 0.5f, s * 0.5f, s * 0.2f, p * 30f)
            else drawMoon(s * 0.5f, s * 0.5f, s * 0.22f, p)
        }
        1 -> {
            if (isDay) drawSun(s * 0.38f, s * 0.36f, s * 0.15f, p * 30f)
            else drawMoon(s * 0.38f, s * 0.36f, s * 0.16f, p)
            drawCloud(s * 0.56f, s * 0.6f, s * 0.82f, false, 1f)
        }
        2 -> {
            drawCloud(s * 0.38f, s * 0.42f, s * 0.6f, true, 0.85f)
            drawCloud(s * 0.58f, s * 0.58f, s * 0.82f, !isDay, 1f)
        }
        3 -> {
            drawCloud(s * 0.5f, s * 0.34f, s * 0.7f, false, 0.95f)
            for (i in 0 until 3) {
                val y = s * (0.62f + 0.12f * i)
                val dx = sin(p * 6.2832f + i * 1.7f) * s * 0.05f
                drawRoundRect(
                    brush = Brush.horizontalGradient(
                        listOf(Color.Transparent, Color(0xBBFFFFFF), Color.Transparent),
                        startX = s * 0.14f + dx,
                        endX = s * 0.86f + dx
                    ),
                    topLeft = Offset(s * 0.16f + dx, y),
                    size = Size(s * 0.68f, s * 0.07f),
                    cornerRadius = CornerRadius(s * 0.035f, s * 0.035f)
                )
            }
        }
        4, 6 -> {
            drawCloud(s * 0.5f, s * 0.33f, s * 0.86f, true, 1f)
            drawRain(s, p)
            if (kind == 6) drawBolt(s, p)
        }
        else -> {
            drawCloud(s * 0.5f, s * 0.33f, s * 0.86f, true, 0.95f)
            drawSnow(s, p)
        }
    }
}

private fun DrawScope.drawSun(cx: Float, cy: Float, r: Float, rotDeg: Float) {
    val c = Offset(cx, cy)
    drawCircle(
        brush = Brush.radialGradient(listOf(Color(0x99FFE9A0), Color(0x33FFC247), Color.Transparent), center = c, radius = r * 3.2f),
        radius = r * 3.2f,
        center = c
    )
    drawCircle(Color(0x55FFE9A0), r * 1.14f, c, style = Stroke(r * 0.05f))
    // tapered rays, long and short
    for (i in 0 until 16) {
        val a = (rotDeg + i * 22.5f) * 0.0174533f
        val long = i % 2 == 0
        val inner = r * 1.25f
        val outer = r * (if (long) 2.15f else 1.7f)
        val half = r * (if (long) 0.13f else 0.09f)
        val dx = cos(a)
        val dy = sin(a)
        val ray = Path()
        ray.moveTo(cx + dx * inner - dy * half, cy + dy * inner + dx * half)
        ray.lineTo(cx + dx * outer, cy + dy * outer)
        ray.lineTo(cx + dx * inner + dy * half, cy + dy * inner - dx * half)
        ray.close()
        drawPath(ray, Color(if (long) 0xCCFFDA70 else 0x99FFDA70))
    }
    drawCircle(
        brush = Brush.radialGradient(
            listOf(Color(0xFFFFFCE6), Color(0xFFFFD54A), Color(0xFFF29A1F)),
            center = Offset(cx - r * 0.35f, cy - r * 0.35f),
            radius = r * 1.7f
        ),
        radius = r,
        center = c
    )
    drawCircle(Color(0x66FFFFFF), r * 0.28f, Offset(cx - r * 0.35f, cy - r * 0.38f))
}

private fun DrawScope.drawMoon(cx: Float, cy: Float, r: Float, p: Float) {
    val c = Offset(cx, cy)
    drawCircle(
        brush = Brush.radialGradient(
            listOf(Color(0x55BFD8FF), Color.Transparent),
            center = c,
            radius = r * 2.5f
        ),
        radius = r * 2.5f,
        center = c
    )
    drawCircle(
        brush = Brush.radialGradient(
            listOf(Color(0xFFFFFFFF), Color(0xFFD5DEEE)),
            center = Offset(cx - r * 0.3f, cy - r * 0.3f),
            radius = r * 1.6f
        ),
        radius = r,
        center = c
    )
    drawCircle(Color(0x22607090), r * 0.2f, Offset(cx - r * 0.32f, cy - r * 0.18f))
    drawCircle(Color(0x22607090), r * 0.13f, Offset(cx + r * 0.3f, cy + r * 0.12f))
    drawCircle(Color(0x22607090), r * 0.1f, Offset(cx - r * 0.02f, cy + r * 0.45f))
    val stars = listOf(
        Offset(-1.9f, -1.2f), Offset(1.7f, -1.5f), Offset(2.0f, 0.9f), Offset(-1.6f, 1.4f)
    )
    for (i in stars.indices) {
        val twinkle = 0.35f + 0.65f * abs(sin(p * 6.2832f + i * 1.3f))
        drawCircle(
            Color.White.copy(alpha = twinkle),
            r * 0.07f,
            Offset(cx + stars[i].x * r, cy + stars[i].y * r)
        )
    }
}

private fun DrawScope.drawCloud(cx: Float, cy: Float, w: Float, dark: Boolean, alpha: Float) {
    val top = if (dark) Color(0xFFD9DFEA) else Color(0xFFFFFFFF)
    val mid = if (dark) Color(0xFF9AA6BA) else Color(0xFFE9F1FB)
    val low = if (dark) Color(0xFF59667E) else Color(0xFFAFC3DE)
    val deep = if (dark) Color(0xFF3B465B) else Color(0xFF8DA6C8)
    drawOval(Color(0x30000000), Offset(cx - w * 0.38f, cy + w * 0.23f), Size(w * 0.76f, w * 0.08f), alpha = alpha)
    // x, y, radius (fractions of the width)
    val puffs = arrayOf(
        floatArrayOf(-0.27f, 0.09f, 0.15f),
        floatArrayOf(0.28f, 0.10f, 0.14f),
        floatArrayOf(-0.13f, -0.04f, 0.22f),
        floatArrayOf(0.12f, -0.08f, 0.25f),
        floatArrayOf(0.02f, 0.10f, 0.19f),
        floatArrayOf(-0.36f, 0.14f, 0.10f),
        floatArrayOf(0.37f, 0.15f, 0.095f),
        floatArrayOf(0.27f, -0.03f, 0.15f),
        floatArrayOf(-0.26f, 0.0f, 0.14f)
    )
    // flat base with a shaded underside
    drawRoundRect(
        brush = Brush.verticalGradient(listOf(mid, low, deep), startY = cy + w * 0.02f, endY = cy + w * 0.29f),
        topLeft = Offset(cx - w * 0.40f, cy + w * 0.06f),
        size = Size(w * 0.80f, w * 0.21f),
        cornerRadius = CornerRadius(w * 0.105f, w * 0.105f),
        alpha = alpha
    )
    // shaded puffs, then lit puffs with soft edges on top: gives the cloud volume
    for (q in puffs) {
        val r = q[2] * w
        val p = Offset(cx + q[0] * w, cy + q[1] * w)
        drawCircle(
            brush = Brush.radialGradient(listOf(mid, low, deep), center = Offset(p.x, p.y + r * 0.2f), radius = r * 1.25f),
            radius = r, center = p, alpha = alpha
        )
    }
    for (q in puffs) {
        val r = q[2] * w
        val p = Offset(cx + q[0] * w, cy + q[1] * w - r * 0.1f)
        drawCircle(
            brush = Brush.radialGradient(
                listOf(top, mid, mid.copy(alpha = 0f)),
                center = Offset(p.x - r * 0.25f, p.y - r * 0.35f),
                radius = r * 1.1f
            ),
            radius = r, center = p, alpha = alpha
        )
    }
    // thin lit rim on the top of the two biggest puffs
    for (k in 2..3) {
        val q = puffs[k]
        val r = q[2] * w
        val c = Offset(cx + q[0] * w, cy + q[1] * w - r * 0.1f)
        drawArc(
            Color.White.copy(alpha = 0.55f * alpha), 205f, 80f, false,
            Offset(c.x - r * 0.96f, c.y - r * 0.96f), Size(r * 1.92f, r * 1.92f),
            style = Stroke(w * 0.014f, cap = StrokeCap.Round)
        )
    }
}

private fun DrawScope.drawRain(s: Float, p: Float) {
    for (i in 0 until 14) {
        val near = i % 2 == 0
        val x = s * (0.18f + 0.05f * i)
        val t = (p * (if (near) 5f else 3.5f) + i * 0.137f) % 1f
        val y = s * (0.5f + 0.4f * t)
        val len = s * (if (near) 0.12f else 0.08f)
        val hw = s * (if (near) 0.026f else 0.017f)
        val a = 1f - t * 0.6f
        val drop = Path()
        drop.moveTo(x, y)
        drop.cubicTo(x - hw * 0.4f, y + len * 0.35f, x - hw, y + len * 0.7f, x, y + len)
        drop.cubicTo(x + hw, y + len * 0.7f, x + hw * 0.4f, y + len * 0.35f, x, y)
        drop.close()
        drawPath(
            drop,
            Brush.verticalGradient(
                listOf(Color(0x669CC8F0), if (near) Color(0xFFCFE8FF) else Color(0xCC8FBDEB)),
                startY = y,
                endY = y + len
            ),
            a
        )
        drawLine(Color.White.copy(alpha = 0.7f * a), Offset(x - hw * 0.3f, y + len * 0.55f), Offset(x - hw * 0.3f, y + len * 0.8f), s * 0.006f, StrokeCap.Round)
        if (t > 0.86f) {
            drawOval(Color(0x55CFE8FF), Offset(x - hw * 2f, s * 0.93f), Size(hw * 4f, hw * 1.2f), style = Stroke(s * 0.005f))
        }
    }
}

private fun DrawScope.drawSnow(s: Float, p: Float) {
    for (i in 0 until 8) {
        val t = (p * 2f + i * 0.131f) % 1f
        val x = s * (0.2f + 0.08f * i) + sin(p * 12.5664f + i) * s * 0.02f
        val y = s * (0.5f + 0.42f * t)
        val r = s * (0.03f + 0.01f * (i % 3))
        val c = Color.White.copy(alpha = 0.95f * (1f - t * 0.5f))
        val rot = p * 3f + i
        for (k in 0 until 6) {
            val a = k * 1.0472f + rot
            val ex = x + cos(a) * r
            val ey = y + sin(a) * r
            drawLine(c, Offset(x, y), Offset(ex, ey), s * 0.009f, StrokeCap.Round)
            // small side branches
            val bx = x + cos(a) * r * 0.6f
            val by = y + sin(a) * r * 0.6f
            for (sgn in intArrayOf(-1, 1)) {
                val ba = a + sgn * 0.8f
                drawLine(c, Offset(bx, by), Offset(bx + cos(ba) * r * 0.35f, by + sin(ba) * r * 0.35f), s * 0.007f, StrokeCap.Round)
            }
        }
    }
}

private fun DrawScope.drawBolt(s: Float, p: Float) {
    val flash = (p * 4f) % 1f
    val a = if (flash < 0.12f || (flash >= 0.2f && flash <= 0.3f)) 1f else 0.25f
    val bolt = Path()
    bolt.moveTo(s * 0.54f, s * 0.5f)
    bolt.lineTo(s * 0.42f, s * 0.7f)
    bolt.lineTo(s * 0.5f, s * 0.7f)
    bolt.lineTo(s * 0.44f, s * 0.92f)
    bolt.lineTo(s * 0.62f, s * 0.64f)
    bolt.lineTo(s * 0.54f, s * 0.64f)
    bolt.close()
    drawPath(bolt, Color(0xFFFFE066).copy(alpha = a * 0.35f), style = Stroke(width = s * 0.07f, join = StrokeJoin.Round))
    drawPath(
        bolt,
        Brush.verticalGradient(listOf(Color(0xFFFFF3B0), Color(0xFFFFB300)), startY = s * 0.5f, endY = s * 0.92f),
        alpha = a
    )
}

// Settings icon: a proper cog
private fun DrawScope.drawGear(color: Color) {
    val c = Offset(size.width / 2f, size.height / 2f)
    val s = minOf(size.width, size.height)
    val rOut = s * 0.48f
    val rIn = s * 0.36f
    val teeth = 8
    val step = 6.2832f / teeth
    val path = Path()
    path.fillType = PathFillType.EvenOdd
    for (i in 0 until teeth) {
        val a = i * step
        val pts = listOf(
            Pair(a - step * 0.34f, rIn), Pair(a - step * 0.2f, rOut),
            Pair(a + step * 0.2f, rOut), Pair(a + step * 0.34f, rIn)
        )
        pts.forEachIndexed { k, pr ->
            val x = c.x + cos(pr.first) * pr.second
            val y = c.y + sin(pr.first) * pr.second
            if (i == 0 && k == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
    }
    path.close()
    path.addOval(androidx.compose.ui.geometry.Rect(c, s * 0.16f))
    drawPath(path, color)
}

// ---------- Animated wallpapers drawn in the app: 0 abstract, 1 nature, 2 city ----------

private fun hash01(i: Int): Float {
    var x = i * 374761393 + 668265263
    x = (x xor (x ushr 13)) * 1274126177
    x = x xor (x ushr 16)
    return (x and 0xFFFFFF) / 16777215f
}

private fun smooth01(t: Float): Float = t * t * (3f - 2f * t)

// smooth 1-D value noise, 0..1
private fun noise1(x: Float, seed: Int): Float {
    val i = kotlin.math.floor(x).toInt()
    val f = x - i
    val s = smooth01(f)
    return hash01(i * 7919 + seed) * (1f - s) + hash01((i + 1) * 7919 + seed) * s
}

// four octaves, about 0..1
private fun fbm(x: Float, seed: Int): Float {
    var sum = 0f
    var a = 0.5f
    var f = 1f
    for (o in 0 until 4) {
        sum += a * noise1(x * f, seed + o * 13)
        a *= 0.5f
        f *= 2.1f
    }
    return sum / 0.9375f
}

// top, middle, horizon
private fun skyOf(tod: String): List<Color> = when (tod) {
    "night" -> listOf(Color(0xFF030614), Color(0xFF0A1332), Color(0xFF1B2A5C))
    "sunrise" -> listOf(Color(0xFF1B2A5C), Color(0xFFB0577A), Color(0xFFFFB27A))
    "sunset" -> listOf(Color(0xFF1A1F4D), Color(0xFFC2506B), Color(0xFFFF9A5A))
    else -> listOf(Color(0xFF1F5FA8), Color(0xFF5FA6E0), Color(0xFFBFE3F7))
}

@Composable
private fun AnimatedWallpaper(style: Int, tod: String, accent: Color, anim: Int, modifier: Modifier) {
    // one slow loop; every movement uses whole numbers of cycles, so the loop never jumps
    val t: State<Float> = if (anim == 2) {
        remember { mutableStateOf(0.3f) }
    } else {
        rememberInfiniteTransition(label = "wall").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(240000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "wallT"
        )
    }
    Canvas(modifier) {
        val p = t.value
        when (style) {
            0 -> drawAbstract(p, accent)
            1 -> drawNature(p, tod)
            else -> drawCity(p, tod)
        }
    }
}

private fun DrawScope.drawStars(p: Float, count: Int, maxY: Float, milky: Boolean) {
    val w = size.width
    if (milky) {
        // soft diagonal band of the Milky Way
        for (k in 0 until 14) {
            val f = k / 13f
            val c = Offset(w * (0.08f + 0.84f * f), maxY * (0.95f - 0.8f * f))
            val r = maxY * 0.36f
            drawCircle(Brush.radialGradient(listOf(Color(0x14C8D6FF), Color.Transparent), center = c, radius = r), r, c)
        }
    }
    for (i in 0 until count) {
        var x = hash01(i * 5) * w
        var y = hash01(i * 5 + 1) * maxY
        if (milky && i % 3 == 0) {
            // denser stars along the band
            val f = x / w
            y = maxY * (0.95f - 0.8f * f) + (hash01(i * 5 + 3) - 0.5f) * maxY * 0.28f
        }
        val tw = 0.3f + 0.7f * abs(sin(6.2832f * (8 + i % 9) * p + i))
        val col = lerp(Color(0xFFBFD4FF), Color(0xFFFFE2B0), hash01(i * 5 + 4))
        val r = 0.9f + hash01(i * 5 + 2) * 1.9f
        drawCircle(col.copy(alpha = tw * 0.9f), r, Offset(x, y))
        if (r > 2.3f) drawCircle(col.copy(alpha = tw * 0.18f), r * 3.2f, Offset(x, y))
    }
}

// Clouds made of soft, lit puffs: bright on top, shaded underneath
private fun DrawScope.drawSkyClouds(p: Float, tod: String, count: Int, y0: Float, yr: Float) {
    val w = size.width
    val lit = when (tod) {
        "night" -> Color(0xFF7C8FC4)
        "sunrise", "sunset" -> Color(0xFFFFD2B0)
        else -> Color.White
    }
    val shade = when (tod) {
        "night" -> Color(0xFF2A3560)
        "sunrise", "sunset" -> Color(0xFFB0627A)
        else -> Color(0xFFB7C4D8)
    }
    val a = if (tod == "night") 0.5f else 0.75f
    for (i in 0 until count) {
        val sz = 200f + hash01(i * 7 + 3) * 320f
        val x = ((p * (2 + i % 3) + hash01(i * 7)) % 1f) * (w + sz * 2f) - sz
        val y = y0 + yr * hash01(i * 7 + 1)
        for (j in 0 until 8) {
            val f = j / 7f
            val pr = sz * (0.09f + 0.1f * hash01(i * 13 + j)) * (1f - abs(f - 0.5f) * 0.8f)
            val c = Offset(x + sz * f, y + sz * 0.05f * sin(j * 1.7f + i) - pr * 0.2f)
            drawCircle(
                Brush.radialGradient(
                    listOf(lit.copy(alpha = a), shade.copy(alpha = a * 0.55f), Color.Transparent),
                    center = Offset(c.x - pr * 0.25f, c.y - pr * 0.35f),
                    radius = pr * 1.5f
                ),
                pr * 1.5f, c
            )
        }
    }
}

private fun DrawScope.drawAbstract(p: Float, accent: Color) {
    val w = size.width
    val h = size.height
    drawRect(Brush.verticalGradient(listOf(Color(0xFF05071A), Color(0xFF0B0F2E))))
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(accent.toArgb(), hsv)
    val hues = floatArrayOf(0f, 35f, -40f, 90f, 190f, 140f, -90f)
    // big soft colour blobs that add up where they meet
    for (i in 0 until 7) {
        val k = 3 + i % 5
        val a = 6.2832f * (k * p + i * 0.19f)
        val b = 6.2832f * ((k + 1) * p + i * 0.37f)
        val c = Offset(w * (0.5f + 0.4f * sin(a)), h * (0.5f + 0.34f * cos(b)))
        val r = h * (0.5f + 0.14f * sin(a * 2f))
        val col = Color.hsv(((hsv[0] + hues[i]) % 360f + 360f) % 360f, 0.75f, 1f)
        drawCircle(
            Brush.radialGradient(listOf(col.copy(alpha = 0.36f), col.copy(alpha = 0.1f), Color.Transparent), center = c, radius = r),
            r, c, blendMode = BlendMode.Plus
        )
    }
    // slow light beams
    for (k in 0 until 3) {
        val x0 = w * (0.2f + 0.3f * k) + w * 0.08f * sin(6.2832f * (2 + k) * p + k)
        val beam = Path()
        beam.moveTo(x0 - 40f, 0f)
        beam.lineTo(x0 + 40f, 0f)
        beam.lineTo(x0 + 240f + k * 60f, h)
        beam.lineTo(x0 - 160f, h)
        beam.close()
        drawPath(beam, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.07f), Color.Transparent)), blendMode = BlendMode.Plus)
    }
    // flowing ribbons with a glow
    for (k in 0 until 4) {
        val path = Path()
        val base = h * (0.3f + 0.12f * k)
        path.moveTo(0f, base)
        var x = 0f
        while (x <= w) {
            val u = x / w
            val y = base +
                h * 0.07f * sin(u * 6.2832f * (1.2f + k * 0.45f) + 6.2832f * p * (2 + k)) +
                h * 0.03f * sin(u * 6.2832f * 3.1f - 6.2832f * p * (3 + k))
            path.lineTo(x, y)
            x += 20f
        }
        val c1 = Color.hsv(((hsv[0] + hues[k]) % 360f + 360f) % 360f, 0.5f, 1f)
        val rib = Brush.horizontalGradient(listOf(Color.Transparent, c1.copy(alpha = 0.55f), Color.Transparent))
        drawPath(path, rib, style = Stroke(10f + k * 2f), alpha = 0.18f)
        drawPath(path, rib, style = Stroke(2.5f))
    }
    // bokeh discs and rising sparks
    for (i in 0 until 14) {
        val x = w * ((hash01(i * 3) + 0.04f * sin(6.2832f * 3f * p + i)) % 1f)
        val y = h * (1f - ((p * (1 + i % 2) + hash01(i * 3 + 1)) % 1f))
        val r = 18f + hash01(i * 3 + 2) * 60f
        val col = Color.hsv(((hsv[0] + hues[i % 7]) % 360f + 360f) % 360f, 0.4f, 1f)
        drawCircle(col.copy(alpha = 0.05f), r, Offset(x, y))
        drawCircle(col.copy(alpha = 0.12f), r, Offset(x, y), style = Stroke(1.5f))
    }
    for (i in 0 until 70) {
        val x = w * ((hash01(i * 2 + 900) + 0.03f * sin(6.2832f * 4f * p + i)) % 1f)
        val y = h * (1f - ((p * (1 + i % 3) + hash01(i * 2 + 901)) % 1f))
        val tw = 0.3f + 0.7f * abs(sin(6.2832f * (6 + i % 7) * p + i))
        drawCircle(Color.White.copy(alpha = 0.7f * tw), 1.2f + hash01(i + 950) * 2.2f, Offset(x, y))
    }
    drawRect(Brush.radialGradient(listOf(Color.Transparent, Color(0x77000000)), center = Offset(w / 2f, h / 2f), radius = w * 0.7f))
}

private fun DrawScope.drawNature(p: Float, tod: String) {
    val w = size.width
    val h = size.height
    val sky = skyOf(tod)
    val night = tod == "night"
    val dusk = tod == "sunrise" || tod == "sunset"
    val horizon = h * 0.62f
    drawRect(Brush.verticalGradient(listOf(sky[0], sky[1], sky[2]), startY = 0f, endY = horizon))
    if (night) drawStars(p, 130, horizon * 0.95f, true)
    val sc = Offset(
        w * (if (tod == "sunrise") 0.3f else if (tod == "sunset") 0.72f else 0.66f),
        horizon * (if (tod == "day") 0.34f else if (night) 0.3f else 0.9f)
    )
    val pulse = 1f + 0.03f * sin(6.2832f * 20f * p)
    // horizon glow
    drawRect(
        Brush.verticalGradient(listOf(Color.Transparent, if (dusk) Color(0x77FFB070) else Color(0x22FFFFFF)), startY = horizon * 0.6f, endY = horizon),
        Offset(0f, horizon * 0.6f), Size(w, horizon * 0.4f)
    )
    if (night) {
        drawCircle(Brush.radialGradient(listOf(Color(0x66BFD8FF), Color.Transparent), center = sc, radius = h * 0.3f * pulse), h * 0.3f * pulse, sc)
        drawCircle(
            Brush.radialGradient(listOf(Color.White, Color(0xFFD5DEEE)), center = Offset(sc.x - 12f, sc.y - 12f), radius = h * 0.07f),
            h * 0.05f, sc
        )
        drawCircle(Color(0x225A6C90), h * 0.012f, Offset(sc.x - h * 0.016f, sc.y - h * 0.01f))
        drawCircle(Color(0x225A6C90), h * 0.008f, Offset(sc.x + h * 0.015f, sc.y + h * 0.012f))
    } else {
        val glow = if (tod == "day") Color(0x88FFF3B0) else Color(0x99FFC070)
        drawCircle(Brush.radialGradient(listOf(glow, Color.Transparent), center = sc, radius = h * 0.55f * pulse), h * 0.55f * pulse, sc)
        if (dusk) {
            // light shafts fanning out from the sun
            for (k in 0 until 7) {
                val ang = -2.6f + k * 0.35f + 0.05f * sin(6.2832f * 3f * p + k)
                val d1 = Offset(cos(ang - 0.06f), sin(ang - 0.06f))
                val d2 = Offset(cos(ang + 0.06f), sin(ang + 0.06f))
                val ray = Path()
                ray.moveTo(sc.x, sc.y)
                ray.lineTo(sc.x + d1.x * h, sc.y + d1.y * h)
                ray.lineTo(sc.x + d2.x * h, sc.y + d2.y * h)
                ray.close()
                drawPath(ray, Brush.radialGradient(listOf(Color(0x33FFD9A0), Color.Transparent), center = sc, radius = h * 0.9f))
            }
        }
        drawCircle(Color(0xFFFFF6D0), h * 0.048f, sc)
    }
    drawSkyClouds(p, tod, 7, h * 0.06f, horizon * 0.42f)

    // four mountain ridges built from layered noise, snow on the far ones, forest on the near ones
    val dark = if (night) Color(0xFF050B16) else Color(0xFF0E2230)
    val snow = if (night) Color(0xFF9FB0D8) else if (dusk) Color(0xFFFFD8C0) else Color(0xFFF4F8FF)
    for (l in 0 until 4) {
        val base = horizon + h * (0.03f + 0.045f * l)
        val amp = h * (0.2f - 0.035f * l)
        val path = Path()
        val pts = ArrayList<Offset>()
        path.moveTo(0f, h * 0.9f)
        var x = 0f
        while (x <= w + 16f) {
            val u = x / w
            val n = fbm(u * (2.2f + l * 0.9f) + l * 5.3f, 100 + l * 17)
            val rg = 1f - abs(2f * fbm(u * (3f + l) + l * 2.1f, 200 + l) - 1f)
            val y = base - amp * (0.55f * n + 0.45f * rg * rg)
            pts.add(Offset(x, y))
            path.lineTo(x, y)
            x += 16f
        }
        path.lineTo(w + 16f, h * 0.9f)
        path.close()
        val c1 = lerp(sky[2], dark, 0.3f + 0.18f * l)
        val c2 = lerp(sky[2], dark, 0.5f + 0.15f * l)
        val top = if (l < 2) snow else c1
        drawPath(path, Brush.verticalGradient(0f to top, 0.22f to c1, 1f to c2, startY = base - amp * 1.05f, endY = base + h * 0.1f))
        if (l >= 2) {
            val tree = lerp(c2, Color.Black, 0.4f)
            for (i in pts.indices) {
                val th = h * (0.012f + 0.02f * hash01(i * 3 + l * 90))
                val q = pts[i]
                val tri = Path()
                tri.moveTo(q.x, q.y - th)
                tri.lineTo(q.x - th * 0.4f, q.y + 2f)
                tri.lineTo(q.x + th * 0.4f, q.y + 2f)
                tri.close()
                drawPath(tri, tree)
            }
        }
        // haze that fades the ridge into the distance
        val hz = base - amp * 0.35f
        drawRect(
            Brush.verticalGradient(listOf(Color.Transparent, sky[2].copy(alpha = if (night) 0.12f else 0.28f)), startY = hz, endY = base + h * 0.05f),
            Offset(0f, hz), Size(w, base + h * 0.05f - hz)
        )
        if (l == 1 || l == 2) {
            val bx = ((p * 3 + l * 0.3f) % 1f) * (w * 1.6f) - w * 0.6f
            drawOval(
                Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.11f), Color.Transparent), startX = bx, endX = bx + w * 0.6f),
                Offset(bx, base - amp * 0.15f), Size(w * 0.6f, h * 0.07f)
            )
        }
    }

    // a lake that mirrors the sky, with glitter under the sun or moon and ripples
    val lakeY = h * 0.8f
    drawRect(
        Brush.verticalGradient(listOf(lerp(sky[2], dark, 0.5f), lerp(sky[1], dark, 0.75f)), startY = lakeY, endY = h),
        Offset(0f, lakeY), Size(w, h - lakeY)
    )
    val gl = if (night) Color(0xFFDCE6FF) else Color(0xFFFFF0C0)
    for (k in 0 until 26) {
        val yy = lakeY + (h - lakeY) * (k / 26f)
        val wob = sin(6.2832f * (10 + k % 7) * p + k * 1.3f)
        val len = (18f + 30f * abs(wob)) * (1f + k * 0.05f)
        val cx = sc.x + wob * (8f + k * 5f)
        drawLine(
            gl.copy(alpha = (0.55f - k * 0.018f).coerceAtLeast(0f)),
            Offset(cx - len / 2f, yy), Offset(cx + len / 2f, yy), 2f + k * 0.1f, StrokeCap.Round
        )
    }
    for (k in 0 until 40) {
        val yy = lakeY + (h - lakeY) * hash01(k + 500)
        val xx = ((hash01(k + 520) + p * (2 + k % 3)) % 1f) * w
        val len = 40f + 60f * hash01(k + 540)
        drawLine(Color.White.copy(alpha = 0.07f), Offset(xx, yy), Offset(xx + len, yy), 1.5f)
    }

    // banks and tall pines framing the lake
    val ground = if (night) Color(0xFF03080F) else Color(0xFF07161A)
    val left = Path()
    left.moveTo(0f, h * 0.84f)
    left.quadraticBezierTo(w * 0.2f, h * 0.86f, w * 0.36f, h)
    left.lineTo(0f, h)
    left.close()
    drawPath(left, ground)
    val right = Path()
    right.moveTo(w, h * 0.85f)
    right.quadraticBezierTo(w * 0.82f, h * 0.87f, w * 0.66f, h)
    right.lineTo(w, h)
    right.close()
    drawPath(right, ground)
    for (i in 0 until 16) {
        val onLeft = i % 2 == 0
        val f = hash01(i + 60)
        val x = (if (onLeft) f * 0.3f else 1f - f * 0.28f) * w + sin(6.2832f * 6f * p + i) * 2.5f
        val th = h * (0.16f + 0.2f * hash01(i + 80))
        val tw = th * 0.4f
        val by = h * (if (onLeft) 0.9f else 0.92f) + h * 0.08f * hash01(i + 100)
        for (tier in 0 until 6) {
            val ty = by - th * (0.14f * tier)
            val half = tw * (1f - 0.15f * tier)
            val tri = Path()
            tri.moveTo(x, ty - th * 0.4f)
            tri.lineTo(x - half, ty)
            tri.lineTo(x + half, ty)
            tri.close()
            drawPath(tri, ground)
        }
    }

    if (night) {
        for (i in 0 until 34) {
            val x = w * (hash01(i + 120) + 0.03f * sin(6.2832f * 5f * p + i * 1.7f))
            val y = h * (0.7f + 0.26f * hash01(i + 160)) + 14f * cos(6.2832f * 7f * p + i)
            val a = 0.2f + 0.8f * abs(sin(6.2832f * (9 + i % 5) * p + i))
            drawCircle(Color(0xFFD9FF7A).copy(alpha = 0.18f * a), 12f, Offset(x, y))
            drawCircle(Color(0xFFF2FFA8).copy(alpha = a), 2.6f, Offset(x, y))
        }
    } else {
        for (i in 0 until 5) {
            val x = ((p * 2 + hash01(i + 400)) % 1f) * (w + 120f) - 60f
            val y = h * (0.14f + 0.14f * hash01(i + 410)) + 10f * sin(6.2832f * 5f * p + i)
            val flap = sin(6.2832f * 40f * p + i) * 7f
            drawLine(Color(0xAA0B1A24), Offset(x - 12f, y - flap), Offset(x, y), 2.2f, StrokeCap.Round)
            drawLine(Color(0xAA0B1A24), Offset(x + 12f, y - flap), Offset(x, y), 2.2f, StrokeCap.Round)
        }
    }
}

// London at night and by day: the Thames with boats, Big Ben, the London Eye, Tower Bridge, the Shard,
// the Walkie Talkie, the Gherkin and Canary Wharf. Windows switch on and off, aircraft blink and leave
// contrails, buses and cars drive along the Embankment.
private fun DrawScope.drawCity(p: Float, tod: String) {
    val w = size.width
    val h = size.height
    val tau = 6.2832f
    val sky = skyOf(tod)
    val night = tod == "night"
    val gy = h * 0.70f
    val road = h * 0.93f
    val lightP = when (tod) {
        "night" -> 0.55f
        "sunset" -> 0.35f
        "sunrise" -> 0.2f
        else -> 0.04f
    }
    val dark = if (night) Color(0xFF050914) else Color(0xFF16202E)
    val far = lerp(sky[2], dark, 0.35f)
    val mid = lerp(sky[2], dark, 0.55f)
    val glass = lerp(sky[2], dark, 0.72f)
    val glassTop = lerp(sky[1], dark, 0.5f)
    val red = Color(0xFFFF3B30)
    val warm = Color(0xFFFFD98A)
    val cool = Color(0xFFCFE6FF)

    // lit windows; some of them switch on and off while you watch
    fun windows(x: Float, top: Float, bw: Float, bh: Float, seed: Int, lp: Float) {
        var iy = 0
        var wy = top + 10f
        while (wy < top + bh - 12f) {
            var ix = 0
            var wx = x + 6f
            while (wx < x + bw - 10f) {
                val hv = hash01(seed * 131 + ix * 17 + iy * 5)
                val on = if (hv > 0.88f) sin(tau * (6 + (ix + iy) % 8) * p + seed + ix) > 1f - 2f * lp else hv < lp
                if (on) {
                    val c = if (hash01(seed * 7 + ix + iy * 3) > 0.7f) cool else warm
                    drawRect(c.copy(alpha = 0.85f), Offset(wx, wy), Size(7f, 10f))
                }
                wx += 15f
                ix++
            }
            wy += 22f
            iy++
        }
    }

    // sky, sun or moon, clouds
    drawRect(Brush.verticalGradient(listOf(sky[0], sky[1], sky[2]), startY = 0f, endY = gy))
    if (night) drawStars(p, 90, gy * 0.55f, false)
    val sc = Offset(w * 0.52f, h * (if (tod == "day") 0.16f else if (night) 0.14f else 0.46f))
    if (night) {
        drawCircle(Brush.radialGradient(listOf(Color(0x66BFD8FF), Color.Transparent), center = sc, radius = h * 0.26f), h * 0.26f, sc)
        drawCircle(Color(0xFFE8EEF9), h * 0.04f, sc)
    } else {
        val g = if (tod == "day") Color(0x88FFF3B0) else Color(0x99FFC070)
        drawCircle(Brush.radialGradient(listOf(g, Color.Transparent), center = sc, radius = h * 0.5f), h * 0.5f, sc)
        drawCircle(Color(0xFFFFF6D0), h * 0.04f, sc)
    }
    drawSkyClouds(p, tod, 5, h * 0.04f, h * 0.22f)
    drawRect(
        Brush.verticalGradient(listOf(Color.Transparent, if (night) Color(0x44FF9A4A) else Color(0x22FFD9A0)), startY = h * 0.4f, endY = gy),
        Offset(0f, h * 0.4f), Size(w, gy - h * 0.4f)
    )

    // aircraft: strobes, wing lights and (by day) contrails
    for (j in 0 until 3) {
        val dir = if (j % 2 == 0) 1f else -1f
        val t = (p * (2 + j) + hash01(j + 300)) % 1f
        val px = (if (dir > 0f) t else 1f - t) * (w + 300f) - 150f
        val py = h * (0.07f + 0.06f * j) + t * h * 0.03f
        drawLine(if (night) Color.White else Color(0xFF223046), Offset(px - 9f * dir, py), Offset(px + 9f * dir, py), 3f, StrokeCap.Round)
        if (!night) drawLine(Color.White.copy(alpha = 0.35f), Offset(px - 9f * dir, py), Offset(px - 160f * dir, py), 2f, StrokeCap.Round)
        if (sin(tau * (28f + j) * p) > 0.2f) {
            drawCircle(Color.White.copy(alpha = 0.95f), 3f, Offset(px, py - 3f))
            drawCircle(Color.White.copy(alpha = 0.2f), 10f, Offset(px, py - 3f))
        }
        drawCircle(red, 2f, Offset(px - 4f, py + 2f))
        drawCircle(Color(0xFF34D17A), 2f, Offset(px + 4f, py + 2f))
    }

    // far and middle skyline
    var x = -20f
    var idx = 0
    while (x < w) {
        val bw = 26f + hash01(idx) * 46f
        val bh = h * (0.03f + 0.11f * hash01(idx + 1))
        drawRect(far, Offset(x, gy - bh), Size(bw, bh))
        x += bw + 2f
        idx += 3
    }
    x = -10f
    idx = 500
    while (x < w) {
        val bw = 34f + hash01(idx) * 60f
        val bh = h * (0.05f + 0.12f * hash01(idx + 1))
        val top = gy - bh
        drawRect(Brush.verticalGradient(listOf(glassTop, mid), startY = top, endY = gy), Offset(x, top), Size(bw, bh))
        windows(x, top, bw, bh, idx, lightP)
        x += bw + 3f + hash01(idx + 2) * 8f
        idx += 3
    }
    drawRect(
        Brush.verticalGradient(listOf(Color.Transparent, sky[2].copy(alpha = if (night) 0.14f else 0.25f)), startY = gy - h * 0.2f, endY = gy),
        Offset(0f, gy - h * 0.2f), Size(w, h * 0.2f)
    )

    // Big Ben and the Houses of Parliament
    run {
        val bx = w * 0.07f
        val bw = w * 0.02f
        val bh = h * 0.36f
        drawRect(Brush.verticalGradient(listOf(glassTop, glass), startY = gy - bh, endY = gy), Offset(bx, gy - bh), Size(bw, bh))
        val spire = Path()
        spire.moveTo(bx - bw * 0.1f, gy - bh)
        spire.lineTo(bx + bw / 2f, gy - bh - bw * 1.6f)
        spire.lineTo(bx + bw * 1.1f, gy - bh)
        spire.close()
        drawPath(spire, glass)
        val fc = Offset(bx + bw / 2f, gy - bh * 0.84f)
        val r = bw * 0.34f
        drawCircle(Brush.radialGradient(listOf(warm.copy(alpha = if (night) 0.5f else 0.1f), Color.Transparent), center = fc, radius = r * 3f), r * 3f, fc)
        drawCircle(if (night) Color(0xFFFFF2C0) else Color(0xFFE8E4D8), r, fc)
        val px = bx + bw
        val pw = w * 0.09f
        val ph = h * 0.07f
        drawRect(glass, Offset(px, gy - ph), Size(pw, ph))
        windows(px, gy - ph, pw, ph, 41, lightP + 0.2f)
        for (k in 0 until 6) drawRect(glass, Offset(px + pw * (k + 0.5f) / 6f, gy - ph - 10f), Size(3f, 10f))
    }

    // the London Eye turns slowly
    run {
        val cx = w * 0.27f
        val r = h * 0.15f
        val cy = gy - r * 1.12f
        val ring = if (night) cool else Color(0xFFE6EEF7)
        val a0 = p * tau * 2f
        if (night) drawCircle(cool.copy(alpha = 0.1f), r * 1.05f, Offset(cx, cy), style = Stroke(10f))
        drawCircle(ring.copy(alpha = 0.85f), r, Offset(cx, cy), style = Stroke(3f))
        drawCircle(ring.copy(alpha = 0.5f), r * 0.94f, Offset(cx, cy), style = Stroke(1.5f))
        drawLine(glass, Offset(cx - r * 0.02f, cy), Offset(cx - r * 0.4f, gy), 5f)
        drawLine(glass, Offset(cx + r * 0.02f, cy), Offset(cx + r * 0.4f, gy), 5f)
        for (k in 0 until 16) {
            val a = a0 + k * tau / 16f
            val e = Offset(cx + cos(a) * r, cy + sin(a) * r)
            drawLine(ring.copy(alpha = 0.35f), Offset(cx, cy), e, 1.2f)
            drawCircle(if (night) warm else Color.White, 4.5f, e)
        }
        drawCircle(ring, 5f, Offset(cx, cy))
    }

    // the Shard
    run {
        val cx = w * 0.42f
        val bw = w * 0.05f
        val bh = h * 0.46f
        val body = Path()
        body.moveTo(cx - bw / 2f, gy)
        body.lineTo(cx - bw * 0.04f, gy - bh)
        body.lineTo(cx + bw * 0.04f, gy - bh)
        body.lineTo(cx + bw / 2f, gy)
        body.close()
        drawPath(body, Brush.verticalGradient(listOf(glassTop, glass), startY = gy - bh, endY = gy))
        for (k in 1..12) {
            val f = k / 13f
            val half = bw / 2f * (1f - f) + bw * 0.04f
            val lit = night && hash01(k + 700) < 0.7f
            drawLine((if (lit) warm else Color.White).copy(alpha = if (lit) 0.55f else 0.07f), Offset(cx - half, gy - bh * f), Offset(cx + half, gy - bh * f), 2f)
        }
        drawCircle(red.copy(alpha = if (sin(tau * 24f * p) > 0f) 0.9f else 0.2f), 3.5f, Offset(cx, gy - bh - 4f))
    }

    // Walkie Talkie
    run {
        val cx = w * 0.70f
        val bw = w * 0.034f
        val bh = h * 0.26f
        val body = Path()
        body.moveTo(cx - bw * 0.38f, gy)
        body.lineTo(cx - bw * 0.6f, gy - bh * 0.8f)
        body.lineTo(cx - bw * 0.5f, gy - bh)
        body.lineTo(cx + bw * 0.5f, gy - bh)
        body.lineTo(cx + bw * 0.6f, gy - bh * 0.8f)
        body.lineTo(cx + bw * 0.38f, gy)
        body.close()
        drawPath(body, Brush.verticalGradient(listOf(glassTop, glass), startY = gy - bh, endY = gy))
        windows(cx - bw * 0.4f, gy - bh * 0.8f, bw * 0.8f, bh * 0.8f, 30, lightP)
    }

    // the Gherkin
    run {
        val cx = w * 0.78f
        val bw = w * 0.04f
        val bh = h * 0.30f
        drawRoundRect(
            Brush.verticalGradient(listOf(glassTop, glass), startY = gy - bh, endY = gy),
            Offset(cx - bw / 2f, gy - bh), Size(bw, bh), CornerRadius(bw / 2f, bw * 0.8f)
        )
        for (k in 1..9) {
            val lit = night && hash01(k + 760) < 0.6f
            drawLine((if (lit) cool else Color.White).copy(alpha = if (lit) 0.5f else 0.08f), Offset(cx - bw * 0.42f, gy - bh * k / 10f), Offset(cx + bw * 0.42f, gy - bh * k / 10f), 2f)
        }
    }

    // Canary Wharf: One Canada Square with its blinking aviation light
    run {
        val bx = w * 0.91f
        val bw = w * 0.026f
        val bh = h * 0.40f
        for ((dx, k) in listOf(-0.045f to 0.28f, 0.04f to 0.22f)) {
            val tx = w * (0.91f + dx)
            val th = h * k
            drawRect(Brush.verticalGradient(listOf(glassTop, glass), startY = gy - th, endY = gy), Offset(tx, gy - th), Size(bw * 0.9f, th))
            windows(tx, gy - th, bw * 0.9f, th, 80 + (dx * 100f).toInt(), lightP)
        }
        drawRect(Brush.verticalGradient(listOf(glassTop, glass), startY = gy - bh, endY = gy), Offset(bx, gy - bh), Size(bw, bh))
        val cap = Path()
        cap.moveTo(bx, gy - bh)
        cap.lineTo(bx + bw / 2f, gy - bh - bw * 0.9f)
        cap.lineTo(bx + bw, gy - bh)
        cap.close()
        drawPath(cap, glass)
        windows(bx, gy - bh, bw, bh, 11, lightP)
        val on = sin(tau * 30f * p) > 0f
        val tip = Offset(bx + bw / 2f, gy - bh - bw * 0.9f - 3f)
        drawCircle(red.copy(alpha = if (on) 1f else 0.2f), 4f, tip)
        if (on) drawCircle(red.copy(alpha = 0.25f), 14f, tip)
    }

    // the Thames: reflections of the sun or moon and of the city lights
    drawRect(
        Brush.verticalGradient(listOf(lerp(sky[2], dark, 0.45f), lerp(sky[1], dark, 0.78f)), startY = gy, endY = road),
        Offset(0f, gy), Size(w, road - gy)
    )
    for (k in 0 until 30) {
        val yy = gy + (road - gy) * (k / 30f)
        val wob = sin(tau * (9 + k % 6) * p + k * 1.3f)
        val len = (14f + 26f * abs(wob)) * (1f + k * 0.05f)
        val gx = sc.x + wob * (8f + k * 4f)
        drawLine(
            (if (night) cool else Color(0xFFFFF0C0)).copy(alpha = (0.5f - k * 0.016f).coerceAtLeast(0f)),
            Offset(gx - len / 2f, yy), Offset(gx + len / 2f, yy), 2f + k * 0.1f, StrokeCap.Round
        )
    }
    if (night) {
        for (k in 0 until 40) {
            val xx = w * hash01(k + 900)
            val yy = gy + (road - gy) * (0.05f + 0.6f * hash01(k + 940))
            val wob = sin(tau * (7 + k % 5) * p + k)
            drawLine((if (k % 3 == 0) cool else warm).copy(alpha = 0.22f), Offset(xx + wob * 4f, yy), Offset(xx + wob * 4f, yy + 16f + 10f * abs(wob)), 2f, StrokeCap.Round)
        }
    }
    for (b in 0 until 3) {
        val dir = if (b % 2 == 0) 1f else -1f
        val t = (p * (3 + b) + hash01(b + 950)) % 1f
        val bx = (if (dir > 0f) t else 1f - t) * (w + 200f) - 100f
        val by = gy + (road - gy) * (0.35f + 0.22f * b)
        drawRoundRect(dark, Offset(bx, by), Size(46f, 8f), CornerRadius(4f, 4f))
        drawRect(dark, Offset(bx + 12f, by - 8f), Size(20f, 8f))
        drawCircle(if (dir > 0f) Color(0xFF34D17A) else red, 2.5f, Offset(bx + (if (dir > 0f) 46f else 0f), by + 2f))
        drawLine(Color.White.copy(alpha = 0.18f), Offset(bx - dir * 10f, by + 9f), Offset(bx - dir * 70f, by + 11f), 2f, StrokeCap.Round)
    }

    // Tower Bridge
    run {
        val cx = w * 0.58f
        val by = gy + h * 0.045f
        val tw = w * 0.022f
        val th = h * 0.20f
        val span = w * 0.17f
        val steel = if (night) Color(0xFF1B2F5C) else Color(0xFF5F86B8)
        val txs = floatArrayOf(cx - w * 0.05f, cx + w * 0.05f)
        drawLine(steel, Offset(txs[0] + tw / 2f, by - th * 0.9f), Offset(cx - span, by), 3f)
        drawLine(steel, Offset(txs[1] + tw / 2f, by - th * 0.9f), Offset(cx + span, by), 3f)
        drawRect(glass, Offset(cx - span, by), Size(span * 2f, 7f))
        drawRect(steel, Offset(txs[0] + tw, by - th * 0.78f), Size(txs[1] - txs[0] - tw, 6f))
        for (tx in txs) {
            drawRect(steel, Offset(tx, by - th), Size(tw, th + 7f))
            val cap = Path()
            cap.moveTo(tx - 2f, by - th)
            cap.lineTo(tx + tw / 2f, by - th - tw * 1.2f)
            cap.lineTo(tx + tw + 2f, by - th)
            cap.close()
            drawPath(cap, steel)
            windows(tx, by - th, tw, th, 60 + tx.toInt() % 7, lightP + 0.2f)
        }
        if (tod != "day") {
            for (k in 0 until 16) drawCircle(warm.copy(alpha = 0.8f), 2.2f, Offset(cx - span + span * 2f * k / 15f, by - 2f))
        }
        drawRect(steel.copy(alpha = 0.2f), Offset(cx - span, by + 7f), Size(span * 2f, 10f))
    }

    // the Embankment: lamps, buses and cars
    drawRect(Brush.verticalGradient(listOf(Color(0xFF0A0F1A), Color(0xFF03060C)), startY = road, endY = h), Offset(0f, road), Size(w, h - road))
    drawRect(Color.White.copy(alpha = 0.08f), Offset(0f, road), Size(w, 2f))
    for (i in 0 until 10) {
        val lx = w * (0.04f + 0.105f * i)
        val lamp = Offset(lx, road - h * 0.05f)
        drawLine(Color(0xFF05080F), Offset(lx, road), lamp, 3f)
        if (tod != "day") {
            drawCircle(Brush.radialGradient(listOf(Color(0x66FFD98A), Color.Transparent), center = lamp, radius = 40f), 40f, lamp)
            drawCircle(Color(0xFFFFE9B0), 3.5f, lamp)
        }
    }
    for (i in 0 until 14) {
        val dir = if (i % 2 == 0) 1f else -1f
        val t = (p * (3 + i % 4) + hash01(i + 300)) % 1f
        val cx = (if (dir > 0f) t else 1f - t) * (w + 200f) - 100f
        val cy = h * (if (dir > 0f) 0.955f else 0.975f)
        val bus = i % 5 == 0
        val len = if (bus) 54f else 24f
        val lamps = if (dir > 0f) Color(0xFFFFF2C0) else red
        drawRoundRect(
            if (bus) Color(0xFFC8102E) else Color(0xFF111827),
            Offset(cx, cy - (if (bus) 14f else 8f)), Size(len, if (bus) 16f else 9f), CornerRadius(3f, 3f)
        )
        if (bus) for (k in 0 until 6) drawRect(warm.copy(alpha = 0.8f), Offset(cx + 4f + k * 8f, cy - 11f), Size(5f, 5f))
        val head = Offset(cx + (if (dir > 0f) len else 0f), cy - 2f)
        if (dir > 0f && tod != "day") {
            val beam = Path()
            beam.moveTo(head.x, head.y)
            beam.lineTo(head.x + 70f, head.y - 8f)
            beam.lineTo(head.x + 70f, head.y + 8f)
            beam.close()
            drawPath(beam, Color(0x22FFF2C0))
        }
        drawCircle(lamps, 2.5f, head)
        drawRoundRect(lamps.copy(alpha = 0.12f), Offset(cx, cy + 6f), Size(len, 14f), CornerRadius(4f, 4f))
    }
}

// ---------- Drawn weather sets: Deluxe (3) and Neon (4) ----------

private fun weatherKind(code: Int): Int = when (code) {
    0, 1 -> 0
    2 -> 1
    3 -> 2
    45, 48 -> 3
    in 51..67, in 80..82 -> 4
    in 71..77, 85, 86 -> 5
    in 95..99 -> 6
    else -> 2
}

// x, y, radius (fractions of the cloud width)
private val DX_PUFFS = arrayOf(
    floatArrayOf(-0.34f, 0.12f, 0.11f),
    floatArrayOf(-0.25f, 0.04f, 0.15f),
    floatArrayOf(-0.12f, -0.07f, 0.20f),
    floatArrayOf(0.02f, -0.12f, 0.22f),
    floatArrayOf(0.17f, -0.07f, 0.19f),
    floatArrayOf(0.29f, 0.03f, 0.15f),
    floatArrayOf(0.36f, 0.12f, 0.11f),
    floatArrayOf(-0.06f, 0.10f, 0.18f),
    floatArrayOf(0.12f, 0.10f, 0.17f),
    floatArrayOf(-0.20f, 0.12f, 0.13f),
    floatArrayOf(0.26f, 0.13f, 0.12f)
)

// tone: 0 white, 1 grey, 2 storm
private fun DrawScope.drawCloudDeluxe(cx: Float, cy: Float, w: Float, tone: Int, alpha: Float) {
    val pal = when (tone) {
        0 -> listOf(Color(0xFFFFFFFF), Color(0xFFEEF5FF), Color(0xFFB9CDE8), Color(0xFF8AA3C8))
        1 -> listOf(Color(0xFFE3E8F1), Color(0xFFB4BFD1), Color(0xFF76839C), Color(0xFF4E5A71))
        else -> listOf(Color(0xFFB9BFD0), Color(0xFF7B849C), Color(0xFF454E66), Color(0xFF2A3146))
    }
    val top = pal[0]
    val mid = pal[1]
    val low = pal[2]
    val deep = pal[3]
    // contact shadow and the flat, shaded base
    drawOval(Color(0x38000000), Offset(cx - w * 0.36f, cy + w * 0.245f), Size(w * 0.72f, w * 0.07f), alpha = alpha)
    drawRoundRect(
        brush = Brush.verticalGradient(listOf(mid, low, deep), startY = cy, endY = cy + w * 0.27f),
        topLeft = Offset(cx - w * 0.40f, cy + w * 0.05f),
        size = Size(w * 0.80f, w * 0.21f),
        cornerRadius = CornerRadius(w * 0.105f, w * 0.105f),
        alpha = alpha
    )
    // shaded puffs (the body of the cloud)
    for (q in DX_PUFFS) {
        val r = q[2] * w
        val c = Offset(cx + q[0] * w, cy + q[1] * w)
        drawCircle(
            Brush.radialGradient(listOf(mid, low, deep), center = Offset(c.x, c.y + r * 0.25f), radius = r * 1.3f),
            r, c, alpha
        )
    }
    // lit puffs on top, soft towards the edge
    for (q in DX_PUFFS) {
        val r = q[2] * w
        val c = Offset(cx + q[0] * w, cy + q[1] * w - r * 0.12f)
        drawCircle(
            Brush.radialGradient(
                listOf(top, mid, mid.copy(alpha = 0f)),
                center = Offset(c.x - r * 0.28f, c.y - r * 0.38f),
                radius = r * 1.15f
            ),
            r, c, alpha
        )
    }
    // thin lit rim on top and a thin shade at the lower right of the bigger puffs
    for (q in DX_PUFFS) {
        if (q[2] < 0.15f) continue
        val r = q[2] * w
        val c = Offset(cx + q[0] * w, cy + q[1] * w - r * 0.12f)
        drawArc(
            Color.White.copy(alpha = 0.6f * alpha), 200f, 85f, false,
            Offset(c.x - r * 0.96f, c.y - r * 0.96f), Size(r * 1.92f, r * 1.92f),
            style = Stroke(w * 0.012f, cap = StrokeCap.Round)
        )
        drawArc(
            deep.copy(alpha = 0.28f * alpha), 15f, 70f, false,
            Offset(c.x - r * 0.96f, c.y - r * 0.96f), Size(r * 1.92f, r * 1.92f),
            style = Stroke(w * 0.01f, cap = StrokeCap.Round)
        )
    }
    // light bouncing under the base and a few specular dots
    drawRoundRect(
        Color.White.copy(alpha = 0.12f * alpha), Offset(cx - w * 0.30f, cy + w * 0.2f),
        Size(w * 0.6f, w * 0.03f), CornerRadius(w * 0.015f, w * 0.015f)
    )
    drawCircle(Color.White.copy(alpha = 0.55f * alpha), w * 0.012f, Offset(cx - w * 0.19f, cy - w * 0.1f))
    drawCircle(Color.White.copy(alpha = 0.5f * alpha), w * 0.015f, Offset(cx - w * 0.02f, cy - w * 0.17f))
    drawCircle(Color.White.copy(alpha = 0.45f * alpha), w * 0.01f, Offset(cx + w * 0.14f, cy - w * 0.12f))
}

private fun DrawScope.drawSunDeluxe(cx: Float, cy: Float, r: Float, rot: Float) {
    val c = Offset(cx, cy)
    drawCircle(
        Brush.radialGradient(listOf(Color(0xAAFFF3B0), Color(0x44FFB74D), Color.Transparent), center = c, radius = r * 4f),
        r * 4f, c
    )
    drawCircle(Color(0x33FFE082), r * 1.55f, c, style = Stroke(r * 0.04f))
    drawCircle(Color(0x22FFE082), r * 1.9f, c, style = Stroke(r * 0.03f))
    // 24 tapered rays in three lengths
    for (i in 0 until 24) {
        val a = (rot + i * 15f) * 0.0174533f
        val kind = i % 3
        val inner = r * 1.22f
        val outer = r * (if (kind == 0) 2.3f else if (kind == 1) 1.85f else 1.5f)
        val half = r * (if (kind == 0) 0.12f else if (kind == 1) 0.09f else 0.06f)
        val dx = cos(a)
        val dy = sin(a)
        val ray = Path()
        ray.moveTo(cx + dx * inner - dy * half, cy + dy * inner + dx * half)
        ray.lineTo(cx + dx * outer, cy + dy * outer)
        ray.lineTo(cx + dx * inner + dy * half, cy + dy * inner - dx * half)
        ray.close()
        drawPath(
            ray,
            Brush.linearGradient(
                listOf(Color(0xFFFFE27A), Color(0x00FF9800)),
                start = Offset(cx + dx * inner, cy + dy * inner),
                end = Offset(cx + dx * outer, cy + dy * outer)
            )
        )
    }
    // the sun body with surface texture, rim light and a highlight
    drawCircle(
        Brush.radialGradient(
            listOf(Color(0xFFFFFDE7), Color(0xFFFFE066), Color(0xFFFFA726), Color(0xFFE65100)),
            center = Offset(cx - r * 0.3f, cy - r * 0.32f),
            radius = r * 1.6f
        ),
        r, c
    )
    drawCircle(Color(0x1AE65100), r * 0.2f, Offset(cx + r * 0.38f, cy + r * 0.2f))
    drawCircle(Color(0x16E65100), r * 0.14f, Offset(cx - r * 0.1f, cy + r * 0.5f))
    drawCircle(Color(0x14E65100), r * 0.12f, Offset(cx + r * 0.1f, cy - r * 0.45f))
    drawCircle(Color(0x55FFFFFF), r, c, style = Stroke(r * 0.05f))
    drawOval(Color(0x88FFFFFF), Offset(cx - r * 0.62f, cy - r * 0.7f), Size(r * 0.5f, r * 0.28f))
}

private fun DrawScope.drawMoonDeluxe(cx: Float, cy: Float, r: Float, p: Float) {
    val c = Offset(cx, cy)
    drawCircle(
        Brush.radialGradient(listOf(Color(0x66BFD8FF), Color(0x22BFD8FF), Color.Transparent), center = c, radius = r * 3f),
        r * 3f, c
    )
    val disc = Path()
    disc.addOval(androidx.compose.ui.geometry.Rect(c, r))
    val cut = Path()
    cut.addOval(androidx.compose.ui.geometry.Rect(Offset(cx + r * 0.55f, cy - r * 0.2f), r * 0.92f))
    val cres = Path()
    cres.op(disc, cut, PathOperation.Difference)
    // earthshine on the dark part, then the lit crescent
    drawCircle(Color(0x22AFC4E8), r, c)
    drawPath(
        cres,
        Brush.linearGradient(
            listOf(Color(0xFFFFFFFF), Color(0xFFDCE6F7), Color(0xFFAFC0DD)),
            start = Offset(cx - r, cy - r),
            end = Offset(cx + r * 0.4f, cy + r)
        )
    )
    clipPath(cres) {
        drawCircle(Color(0x2A5A6C90), r * 0.17f, Offset(cx - r * 0.5f, cy - r * 0.15f))
        drawCircle(Color(0x2A5A6C90), r * 0.11f, Offset(cx - r * 0.25f, cy + r * 0.45f))
        drawCircle(Color(0x2A5A6C90), r * 0.08f, Offset(cx - r * 0.7f, cy + r * 0.35f))
        drawCircle(Color(0x2A5A6C90), r * 0.07f, Offset(cx - r * 0.1f, cy - r * 0.6f))
    }
    drawPath(cres, Color(0x66FFFFFF), style = Stroke(r * 0.03f))
    val st = arrayOf(
        floatArrayOf(-1.7f, -1.2f), floatArrayOf(1.6f, -1.4f), floatArrayOf(1.8f, 0.8f), floatArrayOf(-1.5f, 1.3f)
    )
    for (i in st.indices) {
        val tw = 0.35f + 0.65f * abs(sin(p * 6.2832f + i * 1.3f))
        val sx = cx + st[i][0] * r
        val sy = cy + st[i][1] * r
        val sr = r * 0.1f
        drawLine(Color.White.copy(alpha = tw), Offset(sx - sr * 1.8f, sy), Offset(sx + sr * 1.8f, sy), sr * 0.35f, StrokeCap.Round)
        drawLine(Color.White.copy(alpha = tw), Offset(sx, sy - sr * 1.8f), Offset(sx, sy + sr * 1.8f), sr * 0.35f, StrokeCap.Round)
        drawCircle(Color.White.copy(alpha = tw), sr * 0.55f, Offset(sx, sy))
    }
}

private fun DrawScope.drawRainDeluxe(s: Float, p: Float) {
    for (i in 0 until 18) {
        val near = i % 2 == 0
        val x = s * (0.15f + 0.037f * i)
        val t = (p * (if (near) 5f else 3.5f) + i * 0.173f) % 1f
        val y = s * (0.5f + 0.4f * t)
        val len = s * (if (near) 0.12f else 0.08f)
        val hw = s * (if (near) 0.026f else 0.017f)
        val a = 1f - t * 0.55f
        // motion streak above the drop
        drawLine(
            Brush.verticalGradient(listOf(Color.Transparent, Color(0x669CC8F0)), startY = y - len * 1.3f, endY = y),
            Offset(x, y - len * 1.3f), Offset(x, y), s * 0.008f, StrokeCap.Round, alpha = a
        )
        val drop = Path()
        drop.moveTo(x, y)
        drop.cubicTo(x - hw * 0.4f, y + len * 0.35f, x - hw, y + len * 0.7f, x, y + len)
        drop.cubicTo(x + hw, y + len * 0.7f, x + hw * 0.4f, y + len * 0.35f, x, y)
        drop.close()
        drawPath(
            drop,
            Brush.verticalGradient(
                listOf(Color(0x669CC8F0), if (near) Color(0xFFCFE8FF) else Color(0xCC8FBDEB)),
                startY = y,
                endY = y + len
            ),
            a
        )
        drawLine(Color.White.copy(alpha = 0.75f * a), Offset(x - hw * 0.3f, y + len * 0.55f), Offset(x - hw * 0.3f, y + len * 0.8f), s * 0.006f, StrokeCap.Round)
        if (t > 0.86f) {
            drawOval(Color(0x66CFE8FF), Offset(x - hw * 2.2f, s * 0.93f), Size(hw * 4.4f, hw * 1.3f), style = Stroke(s * 0.005f))
            drawOval(Color(0x33CFE8FF), Offset(x - hw * 3.4f, s * 0.925f), Size(hw * 6.8f, hw * 2f), style = Stroke(s * 0.004f))
        }
    }
    drawOval(
        Brush.horizontalGradient(listOf(Color.Transparent, Color(0x33CFE8FF), Color.Transparent), startX = s * 0.1f, endX = s * 0.9f),
        Offset(s * 0.1f, s * 0.9f), Size(s * 0.8f, s * 0.08f)
    )
}

private fun DrawScope.drawSnowDeluxe(s: Float, p: Float) {
    for (i in 0 until 9) {
        val t = (p * 2f + i * 0.117f) % 1f
        val x = s * (0.16f + 0.085f * i) + sin(p * 12.5664f + i) * s * 0.02f
        val y = s * (0.5f + 0.42f * t)
        val big = i % 3 == 0
        val r = s * (if (big) 0.06f else 0.04f)
        val col = Color.White.copy(alpha = 0.95f * (1f - t * 0.5f))
        drawCircle(Color(0x22BFE0FF), r * 1.5f, Offset(x, y))
        val rot = p * 3f + i
        for (k in 0 until 6) {
            val a = k * 1.0472f + rot
            val dx = cos(a)
            val dy = sin(a)
            drawLine(col, Offset(x, y), Offset(x + dx * r, y + dy * r), s * 0.009f, StrokeCap.Round)
            for (lv in 0 until 2) {
                val f = 0.45f + 0.3f * lv
                val bx = x + dx * r * f
                val by = y + dy * r * f
                val bl = r * (0.34f - 0.1f * lv)
                for (sg in intArrayOf(-1, 1)) {
                    val ba = a + sg * 0.85f
                    drawLine(col, Offset(bx, by), Offset(bx + cos(ba) * bl, by + sin(ba) * bl), s * 0.006f, StrokeCap.Round)
                }
            }
        }
        drawCircle(col, r * 0.1f, Offset(x, y))
    }
}

private fun DrawScope.boltPath(s: Float): Path {
    val bolt = Path()
    bolt.moveTo(s * 0.54f, s * 0.5f)
    bolt.lineTo(s * 0.42f, s * 0.7f)
    bolt.lineTo(s * 0.5f, s * 0.7f)
    bolt.lineTo(s * 0.44f, s * 0.92f)
    bolt.lineTo(s * 0.62f, s * 0.64f)
    bolt.lineTo(s * 0.54f, s * 0.64f)
    bolt.close()
    return bolt
}

private fun DrawScope.drawBoltDeluxe(s: Float, p: Float) {
    val flash = (p * 4f) % 1f
    val on = flash < 0.12f || (flash >= 0.2f && flash <= 0.3f)
    val a = if (on) 1f else 0.3f
    val bolt = boltPath(s)
    val mid = Offset(s * 0.52f, s * 0.72f)
    drawCircle(Brush.radialGradient(listOf(Color(0x66FFE066), Color.Transparent), center = mid, radius = s * 0.34f), s * 0.34f, mid, a)
    drawPath(bolt, Color(0xFFFFE066).copy(alpha = a * 0.3f), style = Stroke(width = s * 0.09f, join = StrokeJoin.Round))
    drawPath(bolt, Color(0xFFFFB300).copy(alpha = a * 0.5f), style = Stroke(width = s * 0.035f, join = StrokeJoin.Round))
    drawPath(
        bolt,
        Brush.verticalGradient(listOf(Color(0xFFFFFBE0), Color(0xFFFFC107), Color(0xFFFF8F00)), startY = s * 0.5f, endY = s * 0.92f),
        alpha = a
    )
    drawLine(Color.White.copy(alpha = 0.8f * a), Offset(s * 0.52f, s * 0.55f), Offset(s * 0.46f, s * 0.68f), s * 0.012f, StrokeCap.Round)
    if (on) {
        drawLine(Color(0xFFFFF3B0).copy(alpha = 0.8f), Offset(s * 0.66f, s * 0.6f), Offset(s * 0.72f, s * 0.56f), s * 0.01f, StrokeCap.Round)
        drawLine(Color(0xFFFFF3B0).copy(alpha = 0.8f), Offset(s * 0.38f, s * 0.8f), Offset(s * 0.32f, s * 0.84f), s * 0.01f, StrokeCap.Round)
    }
}

private fun DrawScope.drawFogDeluxe(s: Float, p: Float) {
    for (i in 0 until 4) {
        val y = s * (0.62f + 0.09f * i)
        val dx = sin(p * 6.2832f + i * 1.6f) * s * 0.04f
        val band = Path()
        band.moveTo(s * 0.12f + dx, y)
        band.cubicTo(s * 0.3f + dx, y - s * 0.04f, s * 0.5f + dx, y + s * 0.04f, s * 0.7f + dx, y)
        band.cubicTo(s * 0.78f + dx, y - s * 0.015f, s * 0.84f + dx, y, s * 0.88f + dx, y)
        drawPath(
            band,
            Brush.horizontalGradient(listOf(Color.Transparent, Color(0xCCFFFFFF), Color.Transparent), startX = s * 0.1f, endX = s * 0.9f),
            style = Stroke(width = s * 0.035f, cap = StrokeCap.Round)
        )
    }
}

private fun DrawScope.drawWeatherDeluxe(code: Int, isDay: Boolean, p: Float) {
    val s = minOf(size.width, size.height)
    val kind = weatherKind(code)
    when (kind) {
        0 -> {
            if (isDay) drawSunDeluxe(s * 0.5f, s * 0.5f, s * 0.19f, p * 30f)
            else drawMoonDeluxe(s * 0.5f, s * 0.5f, s * 0.24f, p)
        }
        1 -> {
            if (isDay) drawSunDeluxe(s * 0.36f, s * 0.34f, s * 0.14f, p * 30f)
            else drawMoonDeluxe(s * 0.36f, s * 0.34f, s * 0.16f, p)
            drawCloudDeluxe(s * 0.57f, s * 0.6f, s * 0.84f, 0, 1f)
        }
        2 -> {
            drawCloudDeluxe(s * 0.38f, s * 0.4f, s * 0.6f, 1, 0.9f)
            drawCloudDeluxe(s * 0.58f, s * 0.58f, s * 0.84f, if (isDay) 0 else 1, 1f)
        }
        3 -> {
            drawCloudDeluxe(s * 0.5f, s * 0.3f, s * 0.72f, 1, 0.95f)
            drawFogDeluxe(s, p)
        }
        4, 6 -> {
            drawCloudDeluxe(s * 0.5f, s * 0.3f, s * 0.88f, if (kind == 6) 2 else 1, 1f)
            drawRainDeluxe(s, p)
            if (kind == 6) drawBoltDeluxe(s, p)
        }
        else -> {
            drawCloudDeluxe(s * 0.5f, s * 0.3f, s * 0.88f, 1, 0.97f)
            drawSnowDeluxe(s, p)
        }
    }
}

// ----- Neon: glowing line art -----

private fun DrawScope.neon(path: Path, color: Color, w: Float) {
    drawPath(path, color.copy(alpha = 0.10f), style = Stroke(w * 3.4f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    drawPath(path, color.copy(alpha = 0.24f), style = Stroke(w * 2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    drawPath(path, color, style = Stroke(w, cap = StrokeCap.Round, join = StrokeJoin.Round))
    drawPath(path, Color.White.copy(alpha = 0.55f), style = Stroke(w * 0.3f, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

private fun DrawScope.neonLine(a: Offset, b: Offset, color: Color, w: Float) {
    val l = Path()
    l.moveTo(a.x, a.y)
    l.lineTo(b.x, b.y)
    neon(l, color, w)
}

private fun neonCloudPath(cx: Float, cy: Float, w: Float): Path {
    val parts = ArrayList<Path>()
    for (q in arrayOf(floatArrayOf(-0.19f, 0.04f, 0.16f), floatArrayOf(0.0f, -0.07f, 0.21f), floatArrayOf(0.2f, 0.02f, 0.16f))) {
        val o = Path()
        o.addOval(androidx.compose.ui.geometry.Rect(Offset(cx + q[0] * w, cy + q[1] * w), q[2] * w))
        parts.add(o)
    }
    val base = Path()
    base.addRoundRect(
        androidx.compose.ui.geometry.RoundRect(cx - 0.36f * w, cy + 0.02f * w, cx + 0.36f * w, cy + 0.2f * w, 0.09f * w, 0.09f * w)
    )
    parts.add(base)
    var acc = parts[0]
    for (i in 1 until parts.size) {
        val n = Path()
        n.op(acc, parts[i], PathOperation.Union)
        acc = n
    }
    return acc
}

private fun DrawScope.neonCloud(cx: Float, cy: Float, w: Float, color: Color, lw: Float) {
    val path = neonCloudPath(cx, cy, w)
    drawPath(path, Color(0xAA0A1426))
    neon(path, color, lw)
}

private fun DrawScope.neonSun(cx: Float, cy: Float, r: Float, rot: Float, color: Color, lw: Float) {
    val ring = Path()
    ring.addOval(androidx.compose.ui.geometry.Rect(Offset(cx, cy), r))
    neon(ring, color, lw)
    for (i in 0 until 12) {
        val a = (rot + i * 30f) * 0.0174533f
        val l = if (i % 2 == 0) 1.9f else 1.6f
        neonLine(
            Offset(cx + cos(a) * r * 1.35f, cy + sin(a) * r * 1.35f),
            Offset(cx + cos(a) * r * l, cy + sin(a) * r * l),
            color, lw * 0.8f
        )
    }
}

private fun DrawScope.neonMoon(cx: Float, cy: Float, r: Float, color: Color, lw: Float, p: Float) {
    val disc = Path()
    disc.addOval(androidx.compose.ui.geometry.Rect(Offset(cx, cy), r))
    val cut = Path()
    cut.addOval(androidx.compose.ui.geometry.Rect(Offset(cx + r * 0.55f, cy - r * 0.2f), r * 0.92f))
    val cres = Path()
    cres.op(disc, cut, PathOperation.Difference)
    neon(cres, color, lw)
    val st = arrayOf(floatArrayOf(-1.6f, -1.1f), floatArrayOf(1.5f, -1.3f), floatArrayOf(1.7f, 0.8f))
    for (i in st.indices) {
        val tw = 0.4f + 0.6f * abs(sin(p * 6.2832f + i * 1.3f))
        drawCircle(color.copy(alpha = tw), r * 0.07f, Offset(cx + st[i][0] * r, cy + st[i][1] * r))
    }
}

private fun DrawScope.drawWeatherNeon(code: Int, isDay: Boolean, p: Float) {
    val s = minOf(size.width, size.height)
    val sunC = Color(0xFFFFD54A)
    val cloudC = Color(0xFF7FE9FF)
    val rainC = Color(0xFF6BB8FF)
    val snowC = Color(0xFFDDE6FF)
    val boltC = Color(0xFFFFE066)
    val moonC = Color(0xFFC9B8FF)
    val lw = s * 0.035f
    when (val kind = weatherKind(code)) {
        0 -> {
            if (isDay) neonSun(s * 0.5f, s * 0.5f, s * 0.2f, p * 30f, sunC, lw)
            else neonMoon(s * 0.5f, s * 0.5f, s * 0.24f, moonC, lw, p)
        }
        1 -> {
            if (isDay) neonSun(s * 0.36f, s * 0.34f, s * 0.13f, p * 30f, sunC, lw)
            else neonMoon(s * 0.36f, s * 0.34f, s * 0.16f, moonC, lw, p)
            neonCloud(s * 0.57f, s * 0.6f, s * 0.8f, cloudC, lw)
        }
        2 -> {
            neonCloud(s * 0.38f, s * 0.4f, s * 0.58f, Color(0xFF9AB4D6), lw * 0.9f)
            neonCloud(s * 0.58f, s * 0.58f, s * 0.8f, cloudC, lw)
        }
        3 -> {
            neonCloud(s * 0.5f, s * 0.3f, s * 0.7f, cloudC, lw)
            for (i in 0 until 3) {
                val y = s * (0.66f + 0.1f * i)
                val dx = sin(p * 6.2832f + i * 1.7f) * s * 0.04f
                neonLine(Offset(s * 0.2f + dx, y), Offset(s * 0.8f + dx, y), Color(0xFF9BB1C8), lw * 0.8f)
            }
        }
        4, 6 -> {
            neonCloud(s * 0.5f, s * 0.3f, s * 0.84f, if (kind == 6) Color(0xFFB59BFF) else cloudC, lw)
            for (i in 0 until 6) {
                val t = (p * 4f + i * 0.17f) % 1f
                val x = s * (0.26f + 0.09f * i) - t * s * 0.04f
                val y = s * (0.55f + 0.3f * t)
                neonLine(Offset(x, y), Offset(x - s * 0.03f, y + s * 0.09f), rainC, lw * 0.75f)
            }
            if (kind == 6) {
                val bolt = boltPath(s)
                neon(bolt, boltC, lw * 0.6f)
            }
        }
        else -> {
            neonCloud(s * 0.5f, s * 0.3f, s * 0.84f, cloudC, lw)
            for (i in 0 until 4) {
                val t = (p * 2f + i * 0.23f) % 1f
                val x = s * (0.3f + 0.13f * i)
                val y = s * (0.58f + 0.3f * t)
                val r = s * 0.045f
                for (k in 0 until 3) {
                    val a = k * 1.0472f + p * 2f + i
                    neonLine(
                        Offset(x - cos(a) * r, y - sin(a) * r),
                        Offset(x + cos(a) * r, y + sin(a) * r),
                        snowC, lw * 0.5f
                    )
                }
            }
        }
    }
}

// ---------- Drawn clock digits (styles 5 = LED, 6 = Neon, 7 = Matrix) ----------

private val SEGMENTS = intArrayOf(63, 6, 91, 79, 102, 109, 125, 7, 127, 111)

private val MATRIX = arrayOf(
    "01110 10001 10011 10101 11001 10001 01110",
    "00100 01100 00100 00100 00100 00100 01110",
    "01110 10001 00001 00010 00100 01000 11111",
    "11110 00001 00001 01110 00001 00001 11110",
    "00010 00110 01010 10010 11111 00010 00010",
    "11111 10000 11110 00001 00001 10001 01110",
    "00110 01000 10000 11110 10001 10001 01110",
    "11111 00001 00010 00100 01000 01000 01000",
    "01110 10001 10001 01110 10001 10001 01110",
    "01110 10001 10001 01111 00001 00010 01100"
)

private fun glyphAdvance(ch: Char, style: Int, h: Float): Float {
    return if (style == 7 || style == 11) {
        val cell = h / 7f
        if (ch == ':') cell * 3f else cell * 6f
    } else {
        val extra = if (style == 9) 0.1f else 0f
        if (ch == ':') h * (0.34f + extra) else h * (0.7f + extra)
    }
}

@Composable
private fun DrawnClock(text: String, style: Int, h: Dp, color: Color) {
    val hv = h.value
    var total = 0f
    for (ch in text) total += glyphAdvance(ch, style, hv)
    Canvas(Modifier.size(width = total.dp, height = h)) {
        val d = density
        var x = 0f
        for (ch in text) {
            drawGlyph(ch, style, x * d, hv * d, color)
            x += glyphAdvance(ch, style, hv)
        }
    }
}

private fun DrawScope.glowDot(cx: Float, cy: Float, r: Float, color: Color) {
    drawCircle(color.copy(alpha = 0.12f), r * 3f, Offset(cx, cy))
    drawCircle(color.copy(alpha = 0.25f), r * 1.9f, Offset(cx, cy))
    drawCircle(color, r, Offset(cx, cy))
}

private fun DrawScope.glowSquare(cx: Float, cy: Float, r: Float, color: Color) {
    drawRect(color.copy(alpha = 0.14f), Offset(cx - r * 1.9f, cy - r * 1.9f), Size(r * 3.8f, r * 3.8f))
    drawRect(color, Offset(cx - r, cy - r), Size(r * 2f, r * 2f))
}

// Styles: 5 LED, 6 Neon, 7 Matrix, 8 Slim, 9 Italic, 10 Outline, 11 Pixel
private fun DrawScope.drawGlyph(ch: Char, style: Int, ox: Float, h: Float, color: Color) {
    if (style == 7 || style == 11) {
        drawMatrixGlyph(ch, ox, h, color, style == 11)
        return
    }
    val w = h * 0.5f
    val t = when (style) {
        6 -> h * 0.07f
        8 -> h * 0.05f
        else -> h * 0.115f
    }
    val slant = if (style == 9) 0.18f else 0f
    val half = t / 2f
    if (ch == ':') {
        val r = t * 0.6f
        glowDot(ox + h * 0.12f + (h - h * 0.33f) * slant, h * 0.33f, r, color)
        glowDot(ox + h * 0.12f + (h - h * 0.67f) * slant, h * 0.67f, r, color)
        return
    }
    val digit = ch - '0'
    if (digit < 0 || digit > 9) return
    val mask = SEGMENTS[digit]
    val inset = t * 0.9f
    val mid = h / 2f
    val gap = inset * 0.55f
    val segs = arrayOf(
        floatArrayOf(inset, half, w - inset, half),
        floatArrayOf(w - half, inset, w - half, mid - gap),
        floatArrayOf(w - half, mid + gap, w - half, h - inset),
        floatArrayOf(inset, h - half, w - inset, h - half),
        floatArrayOf(half, mid + gap, half, h - inset),
        floatArrayOf(half, inset, half, mid - gap),
        floatArrayOf(inset, mid, w - inset, mid)
    )
    for (i in 0 until 7) {
        val lit = ((mask shr i) and 1) == 1
        val sg = segs[i]
        val p1 = Offset(ox + sg[0] + (h - sg[1]) * slant, sg[1])
        val p2 = Offset(ox + sg[2] + (h - sg[3]) * slant, sg[3])
        if (style == 10) {
            // hollow tubes
            val l = minOf(p1.x, p2.x) - t * 0.5f
            val r = maxOf(p1.x, p2.x) + t * 0.5f
            val tp = minOf(p1.y, p2.y) - t * 0.5f
            val bt = maxOf(p1.y, p2.y) + t * 0.5f
            val topLeft = Offset(l, tp)
            val box = Size(r - l, bt - tp)
            val corner = CornerRadius(t * 0.5f, t * 0.5f)
            if (lit) {
                drawRoundRect(color.copy(alpha = 0.18f), topLeft, box, corner, style = Stroke(width = t * 0.55f))
                drawRoundRect(color, topLeft, box, corner, style = Stroke(width = t * 0.16f))
            } else {
                drawRoundRect(color.copy(alpha = 0.08f), topLeft, box, corner, style = Stroke(width = t * 0.1f))
            }
            continue
        }
        if (lit) {
            drawLine(color.copy(alpha = 0.10f), p1, p2, t * 3.2f, StrokeCap.Round)
            drawLine(color.copy(alpha = 0.22f), p1, p2, t * 2.0f, StrokeCap.Round)
            drawLine(color, p1, p2, t, StrokeCap.Round)
            if (style == 6 || style == 8) {
                drawLine(Color.White.copy(alpha = 0.85f), p1, p2, t * 0.35f, StrokeCap.Round)
            }
        } else {
            drawLine(color.copy(alpha = 0.07f), p1, p2, t, StrokeCap.Round)
        }
    }
}

private fun DrawScope.drawMatrixGlyph(ch: Char, ox: Float, h: Float, color: Color, square: Boolean) {
    val cell = h / 7f
    val r = cell * (if (square) 0.42f else 0.36f)
    if (ch == ':') {
        if (square) {
            glowSquare(ox + cell * 0.5f, cell * 2.5f, r, color)
            glowSquare(ox + cell * 0.5f, cell * 4.5f, r, color)
        } else {
            glowDot(ox + cell * 0.5f, cell * 2.5f, r, color)
            glowDot(ox + cell * 0.5f, cell * 4.5f, r, color)
        }
        return
    }
    val digit = ch - '0'
    if (digit < 0 || digit > 9) return
    val rows = MATRIX[digit].split(" ")
    for (row in 0 until 7) {
        for (col in 0 until 5) {
            val cx = ox + cell * (col + 0.5f)
            val cy = cell * (row + 0.5f)
            if (rows[row][col] == '1') {
                if (square) glowSquare(cx, cy, r, color) else glowDot(cx, cy, r, color)
            } else if (square) {
                drawRect(color.copy(alpha = 0.08f), Offset(cx - r * 0.8f, cy - r * 0.8f), Size(r * 1.6f, r * 1.6f))
            } else {
                drawCircle(color.copy(alpha = 0.08f), r * 0.8f, Offset(cx, cy))
            }
        }
    }
}

// ---------- Sunrise / sunset with a drawn icon and a label ----------

@Composable
private fun SunEvent(rise: Boolean, time: String, color: Color, sp: Int) {
    val accent = LocalAccent.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size((sp * 2.2f).dp)) {
            drawSunIcon(rise, accent)
        }
        Spacer(Modifier.width(6.dp))
        Column {
            Text(
                text = if (rise) "Sunrise" else "Sunset",
                color = color.copy(alpha = 0.7f),
                fontSize = (sp - 4).coerceAtLeast(8).sp,
                fontFamily = RoundedFont,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = time,
                color = color,
                fontSize = sp.sp,
                fontFamily = RoundedFont,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private fun DrawScope.drawSunIcon(rise: Boolean, accent: Color) {
    val s = minOf(size.width, size.height)
    val horizon = s * 0.68f
    val sun = Color(0xFFFFC53D)
    val cx = s * 0.5f
    drawArc(
        color = sun,
        startAngle = 180f,
        sweepAngle = 180f,
        useCenter = true,
        topLeft = Offset(cx - s * 0.24f, horizon - s * 0.24f),
        size = Size(s * 0.48f, s * 0.48f)
    )
    for (i in 0 until 5) {
        val a = (180f + 22f + i * 34f) * 0.0174533f
        drawLine(
            color = sun,
            start = Offset(cx + cos(a) * s * 0.32f, horizon + sin(a) * s * 0.32f),
            end = Offset(cx + cos(a) * s * 0.44f, horizon + sin(a) * s * 0.44f),
            strokeWidth = s * 0.05f,
            cap = StrokeCap.Round
        )
    }
    drawLine(
        color = Color.White.copy(alpha = 0.85f),
        start = Offset(s * 0.04f, horizon),
        end = Offset(s * 0.96f, horizon),
        strokeWidth = s * 0.05f,
        cap = StrokeCap.Round
    )
    val arrow = Path()
    if (rise) {
        arrow.moveTo(cx, 0f)
        arrow.lineTo(s * 0.38f, s * 0.13f)
        arrow.lineTo(s * 0.62f, s * 0.13f)
    } else {
        arrow.moveTo(cx, s * 0.98f)
        arrow.lineTo(s * 0.38f, s * 0.85f)
        arrow.lineTo(s * 0.62f, s * 0.85f)
    }
    arrow.close()
    drawPath(arrow, accent)
}

// ---------- Animated sky behind the weather card ----------

@Composable
private fun WeatherBackdrop(group: String, isDay: Boolean, anim: Int) {
    val phase: State<Float>? = if (anim != 2) {
        rememberInfiniteTransition(label = "backdrop").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(60000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "backdropPhase"
        )
    } else {
        null
    }
    Canvas(Modifier.fillMaxSize()) {
        val p = phase?.value ?: 0f
        val w = size.width
        val h = size.height
        if (!isDay) {
            for (i in 0 until 16) {
                val x = w * (((i * 61) % 100) / 100f)
                val y = h * (((i * 37) % 70) / 100f)
                val tw = 0.3f + 0.7f * abs(sin(p * 62.832f + i))
                drawCircle(Color.White.copy(alpha = 0.55f * tw), 1.6f + (i % 3) * 0.5f, Offset(x, y))
            }
        } else if (group == "clear") {
            val c = Offset(w * 0.82f, h * 0.2f)
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0x66FFE9A0), Color.Transparent),
                    center = c,
                    radius = h * 1.1f
                ),
                radius = h * 1.1f,
                center = c
            )
        }
        if (group != "clear") {
            for (k in 0 until 3) {
                val x = ((p + k * 0.33f) % 1f) * (w + 240f) - 120f
                val y = h * (0.2f + 0.22f * k)
                drawCircle(Color(0x18FFFFFF), h * 0.30f, Offset(x, y))
                drawCircle(Color(0x18FFFFFF), h * 0.22f, Offset(x + h * 0.28f, y + h * 0.05f))
                drawCircle(Color(0x18FFFFFF), h * 0.25f, Offset(x - h * 0.26f, y + h * 0.06f))
            }
        }
    }
}

// ---------- Sonic logo: a purple S on a dark tile (same artwork as the app icon) ----------

@Composable
private fun SonicLogo(modifier: Modifier) {
    Canvas(modifier) {
        val k = size.minDimension / 96f
        val sPath = Path()
        sPath.moveTo(68f * k, 34f * k)
        sPath.cubicTo(64f * k, 24f * k, 56f * k, 20f * k, 48f * k, 20f * k)
        sPath.cubicTo(36f * k, 20f * k, 28f * k, 26f * k, 28f * k, 34f * k)
        sPath.cubicTo(28f * k, 43f * k, 38f * k, 46f * k, 48f * k, 49f * k)
        sPath.cubicTo(58f * k, 52f * k, 68f * k, 56f * k, 68f * k, 64f * k)
        sPath.cubicTo(68f * k, 72f * k, 59f * k, 77f * k, 48f * k, 77f * k)
        sPath.cubicTo(39f * k, 77f * k, 31f * k, 73f * k, 27f * k, 64f * k)

        drawRoundRect(
            brush = Brush.linearGradient(
                listOf(Color(0xFF2A0F5C), Color(0xFF0A0418)),
                start = Offset.Zero,
                end = Offset(size.width, size.height)
            ),
            cornerRadius = CornerRadius(20f * k, 20f * k)
        )
        // speed lines
        drawLine(Color(0x80B07CFF), Offset(6f * k, 30f * k), Offset(20f * k, 30f * k), 4f * k, StrokeCap.Round)
        drawLine(Color(0x59B07CFF), Offset(3f * k, 48f * k), Offset(17f * k, 48f * k), 4f * k, StrokeCap.Round)
        drawLine(Color(0x40B07CFF), Offset(6f * k, 66f * k), Offset(20f * k, 66f * k), 4f * k, StrokeCap.Round)
        // glow, then the S
        drawPath(
            sPath,
            Color(0x599B5CFF),
            style = Stroke(width = 16f * k, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        drawPath(
            sPath,
            brush = Brush.linearGradient(
                listOf(Color(0xFFD08BFF), Color(0xFF7C3BFF), Color(0xFF4A1FD6)),
                start = Offset(28f * k, 20f * k),
                end = Offset(68f * k, 77f * k)
            ),
            style = Stroke(width = 9f * k, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

private val TILE_SIZES = listOf(76, 92, 112, 136)

// Up / Down in a grid. A lazy grid only builds what is on screen, so scroll the next row in first,
// then move focus to it.
private fun gridKey(
    code: Int,
    scope: CoroutineScope,
    state: LazyGridState,
    requesters: List<FocusRequester>,
    index: Int
): Boolean {
    val down = code == android.view.KeyEvent.KEYCODE_DPAD_DOWN
    val up = code == android.view.KeyEvent.KEYCODE_DPAD_UP
    if (!down && !up) return false
    val columns = (state.layoutInfo.visibleItemsInfo.maxOfOrNull { it.column } ?: 0) + 1
    var target = if (down) index + columns else index - columns
    if (target < 0) return false
    if (target >= requesters.size) {
        val lastRowStart = ((requesters.size - 1) / columns) * columns
        if (down && index < lastRowStart) target = requesters.size - 1 else return down
    }
    val goTo = target
    scope.launch {
        revealGridItem(state, goTo)
        delay(60L)
        runCatching { requesters[goTo].requestFocus() }
    }
    return true
}

// ---------- A full-screen panel in its own window: the remote can never reach the home screen behind it ----------

@Composable
private fun PanelWindow(anim: Int, onDismiss: () -> Unit, content: @Composable () -> Unit) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        var shown by remember { mutableStateOf(anim == 2) }
        LaunchedEffect(Unit) { shown = true }
        val a by animateFloatAsState(
            targetValue = if (shown) 1f else 0f,
            animationSpec = tween(if (anim == 2) 0 else 220),
            label = "panelAlpha"
        )
        val sc by animateFloatAsState(
            targetValue = if (shown) 1f else 0.94f,
            animationSpec = tween(if (anim == 2) 0 else 220),
            label = "panelScale"
        )
        Box(
            Modifier
                .fillMaxSize()
                .navSound()
                .graphicsLayer {
                    alpha = a
                    scaleX = sc
                    scaleY = sc
                }
        ) {
            content()
        }
    }
}

// ---------- Wallpaper gallery: pick a picture, it is saved at 1920 x 1080 ----------

@Composable
private fun WallpaperGallery(
    cats: Int,
    tod: String,
    group: String,
    onPick: (String) -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    var urls by remember { mutableStateOf<List<String>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var round by remember { mutableIntStateOf(0) }
    val doneFocus = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { doneFocus.requestFocus() }
    }
    var bad by remember { mutableStateOf<Set<String>>(emptySet()) }
    LaunchedEffect(round) {
        loading = true
        val more = withContext(Dispatchers.IO) { Remote.galleryUrls(cats, tod, group, round) }
        urls = (urls + more).distinct()
        loading = false
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF5060A14))
            .padding(horizontal = 40.dp, vertical = 24.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    ScreenTitle("Wallpaper gallery")
                    Text(
                        text = "OK on a picture makes it your fixed wallpaper, cropped to 1920 x 1080 to fit the screen. The kinds of picture come from Settings > Wallpaper types.",
                        color = TextLo,
                        fontSize = 11.sp,
                        fontFamily = RoundedFont,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                ChipButton("More pictures", false) { round++ }
                Spacer(Modifier.width(10.dp))
                ChipButton("Done", true, doneFocus) { onClose() }
            }
            Spacer(Modifier.height(12.dp))
            if (loading) {
                Text(
                    text = "Loading pictures...",
                    color = TextLo,
                    fontSize = 13.sp,
                    fontFamily = RoundedFont
                )
            }
            LazyVerticalGrid(
                columns = GridCells.Adaptive(200.dp),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(8.dp)
            ) {
                itemsIndexed(urls.filter { it !in bad }, key = { _, u -> u }) { _, url ->
                    WallpaperThumb(url, { bad = bad + url }) { onPick(url) }
                }
            }
        }
    }
}

@Composable
private fun WallpaperThumb(url: String, onFail: () -> Unit, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    var bmp by remember(url) { mutableStateOf<ImageBitmap?>(null) }
    var failed by remember(url) { mutableStateOf(false) }
    LaunchedEffect(url) {
        val small = Remote.thumbUrl(url)
        val b = withContext(Dispatchers.IO) { Remote.loadBitmap(context, small, 520, if (small == url) 1400 else 0) }
        if (b != null) bmp = b.asImageBitmap() else {
            failed = true
            onFail()
        }
    }
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .scale(if (focused) 1.05f else 1f)
            .clip(shape)
            .background(Color(0x22FFFFFF))
            .border(if (focused) 3.dp else 1.dp, if (focused) accent else Color(0x44FFFFFF), shape)
            .tvClickable(source, null, onClick),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Text(
                text = if (failed) "too small" else "...",
                color = TextLo,
                fontSize = 11.sp,
                fontFamily = RoundedFont
            )
        }
    }
}

// ---------- Scroll back to the very top when the first row gets focus ----------

private fun Modifier.scrollTopOnFocus(state: ScrollState, scope: CoroutineScope): Modifier =
    this.onFocusChanged { f ->
        if (f.hasFocus) {
            scope.launch {
                delay(60L)
                state.animateScrollTo(0, tween(420, easing = FastOutSlowInEasing))
            }
        }
    }

private fun Modifier.scrollBottomOnFocus(state: ScrollState, scope: CoroutineScope): Modifier = this

// ---------- Drop-down list (opens inline, works with the remote) ----------

@Composable
private fun DropdownChip(
    options: List<String>,
    selected: Int,
    focusRequester: FocusRequester? = null,
    modifier: Modifier = Modifier,
    onSelect: (Int) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val own = remember { FocusRequester() }
    val field = focusRequester ?: own
    val current = remember { FocusRequester() }
    val scope = rememberCoroutineScope()
    val shown = options[selected.coerceIn(0, options.size - 1)]

    Column {
        Box(modifier) {
            ChipButton(shown + (if (open) "    ▴" else "    ▾"), false, field, wide = true) { open = !open }
        }
        if (open) {
            LaunchedEffect(Unit) {
                delay(80L)
                runCatching { current.requestFocus() }
            }
            Column(
                Modifier.padding(top = 6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                options.forEachIndexed { i, name ->
                    ChipButton(name, i == selected, if (i == selected) current else null, compact = true, wide = true) {
                        open = false
                        onSelect(i)
                        scope.launch {
                            delay(80L)
                            runCatching { field.requestFocus() }
                        }
                    }
                }
            }
        }
    }
}

// ---------- Weather card settings (open the weather card, then "Weather settings...") ----------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WeatherSettingsPanel(cfg: WeatherCfg, onChange: (WeatherCfg) -> Unit, onClose: () -> Unit) {
    val first = remember { FocusRequester() }
    val scroll = rememberScrollState()
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { first.requestFocus() }
    }

    SidePanel("Weather card", "Changes show on the card straight away.", scroll, onClose) {
        SettingCard(
            "Icon style",
            "Drawn sets are made inside the app. Meteocons and OpenWeather download once.",
            modifier = Modifier.scrollTopOnFocus(scroll, scope)
        ) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                maxItemsInEachRow = 3
            ) {
                listOf("Drawn 3D" to 2, "Deluxe" to 3, "Neon" to 4, "Meteocons" to 0, "OpenWeather" to 1).forEach { (n, v) ->
                    ChoiceTile(n, cfg.icons == v, if (v == cfg.icons) first else null, onClick = { onChange(cfg.copy(icons = v)) }) { _ ->
                        CompositionLocalProvider(LocalIconStyle provides v) {
                            Row {
                                WeatherArt(2, true, 2, Modifier.size(42.dp))
                                WeatherArt(61, true, 2, Modifier.size(42.dp))
                            }
                        }
                    }
                }
            }
        }

        SettingCard("Font") {
            DropdownChip(
                options = listOf("Default", "Black", "Thin", "Serif", "Mono", "Script"),
                selected = cfg.font
            ) { onChange(cfg.copy(font = it)) }
        }

        SettingCard("Temperature colour") {
            ChipRow {
                ChipButton("White", cfg.color == 0, compact = true) { onChange(cfg.copy(color = 0)) }
                ChipButton("Theme colour", cfg.color == 1, compact = true) { onChange(cfg.copy(color = 1)) }
            }
        }

        SettingCard("Show on the card") {
            ChipRow {
                ChipButton("Condition", (cfg.info and WX_COND) != 0, compact = true) { onChange(cfg.copy(info = cfg.info xor WX_COND)) }
                ChipButton("Weather icon", (cfg.info and WX_ICON) != 0, compact = true) { onChange(cfg.copy(info = cfg.info xor WX_ICON)) }
                ChipButton("5-day forecast", cfg.strip, compact = true) { onChange(cfg.copy(strip = !cfg.strip)) }
                ChipButton("Wind (speed, direction, gusts)", cfg.cardWind, compact = true) { onChange(cfg.copy(cardWind = !cfg.cardWind)) }
            }
        }

        SettingCard("Card size") {
            DropdownChip(
                options = listOf("Small (60%)", "Medium (80%)", "Large (100%)", "Extra large (120%)"),
                selected = cfg.size
            ) { onChange(cfg.copy(size = it)) }
        }

        SettingCard("Background") {
            ChipRow {
                ChipButton("London photos", cfg.photo == 0, compact = true) { onChange(cfg.copy(photo = 0)) }
                ChipButton("Sky art only", cfg.photo == 1, compact = true) { onChange(cfg.copy(photo = 1)) }
                ChipButton("See-through", cfg.photo == 2, compact = true) { onChange(cfg.copy(photo = 2)) }
            }
        }

        SettingCard("Timing") {
            SectionLabel("Weather updates every")
            ChipRow {
                listOf(10, 15, 30, 60).forEach { m ->
                    ChipButton(m.toString() + " min", cfg.refreshMin == m, compact = true) { onChange(cfg.copy(refreshMin = m)) }
                }
            }
            Spacer(Modifier.height(12.dp))
            SectionLabel("Photo changes every")
            ChipRow {
                listOf(10, 30, 60).forEach { m ->
                    ChipButton(m.toString() + " min", cfg.photoMin == m, compact = true) { onChange(cfg.copy(photoMin = m)) }
                }
            }
        }

        SettingCard("Forecast panel") {
            SectionLabel("Shows")
            ChipRow {
                ChipButton("High / low", (cfg.info and WX_HL) != 0, compact = true) { onChange(cfg.copy(info = cfg.info xor WX_HL)) }
                ChipButton("Wind", (cfg.info and WX_WIND) != 0, compact = true) { onChange(cfg.copy(info = cfg.info xor WX_WIND)) }
                ChipButton("Humidity", (cfg.info and WX_HUM) != 0, compact = true) { onChange(cfg.copy(info = cfg.info xor WX_HUM)) }
            }
            Spacer(Modifier.height(12.dp))
            SectionLabel("Days")
            ChipRow {
                listOf(3, 5, 6).forEach { d ->
                    ChipButton(d.toString() + " days", cfg.days == d, compact = true) { onChange(cfg.copy(days = d)) }
                }
            }
            Spacer(Modifier.height(12.dp))
            SectionLabel("Hours")
            ChipRow {
                listOf(6, 8, 10).forEach { h ->
                    ChipButton(h.toString() + " hours", cfg.hours == h, compact = true) { onChange(cfg.copy(hours = h)) }
                }
            }
        }

        ChipButton("Done", true) { onClose() }
    }
}

// ---------- Pictures stored on this device (wallpaper from a local file) ----------

@Composable
private fun LocalGallery(
    mediaTick: Int,
    onAsk: () -> Unit,
    onPickFile: () -> Unit,
    onPick: (Uri) -> Unit,
    onClose: () -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    var uris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var access by remember { mutableStateOf(Wallpaper.hasMediaAccess(context)) }
    var loaded by remember { mutableStateOf(false) }
    val doneFocus = remember { FocusRequester() }
    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()
    val requesters = remember(uris) { List(uris.size) { FocusRequester() } }

    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { doneFocus.requestFocus() }
    }
    LaunchedEffect(mediaTick) {
        access = Wallpaper.hasMediaAccess(context)
        if (access) uris = withContext(Dispatchers.IO) { Wallpaper.localPictures(context) }
        loaded = true
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF5060A14))
            .padding(horizontal = 40.dp, vertical = 24.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    ScreenTitle("Pictures on this device")
                    Text(
                        text = "OK on a picture makes it your fixed wallpaper, cropped to 1920 x 1080.",
                        color = TextLo,
                        fontSize = 11.sp,
                        fontFamily = RoundedFont,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                if (!access) {
                    ChipButton("Allow access", false) { onAsk() }
                    Spacer(Modifier.width(10.dp))
                }
                ChipButton("Pick a file...", false) { onPickFile() }
                Spacer(Modifier.width(10.dp))
                ChipButton("Done", true, doneFocus) { onClose() }
            }
            Spacer(Modifier.height(12.dp))
            if (!access) {
                Text(
                    text = "Allow access to list the pictures on this device, or use Pick a file.",
                    color = TextLo,
                    fontSize = 13.sp,
                    fontFamily = RoundedFont
                )
            } else if (loaded && uris.isEmpty()) {
                Text(
                    text = "No pictures found. Copy some to the Pictures or Download folder, or use Pick a file.",
                    color = TextLo,
                    fontSize = 13.sp,
                    fontFamily = RoundedFont
                )
            }
            LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Adaptive(200.dp),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(8.dp)
            ) {
                itemsIndexed(uris) { index, u ->
                    LocalThumb(
                        uri = u,
                        focusRequester = requesters[index],
                        onFocused = { scope.launch { revealGridItem(gridState, index) } },
                        onDpad = { code -> gridKey(code, scope, gridState, requesters, index) }
                    ) { onPick(u) }
                }
            }
        }
    }
}

@Composable
private fun LocalThumb(
    uri: Uri,
    focusRequester: FocusRequester,
    onFocused: () -> Unit,
    onDpad: (Int) -> Boolean,
    onClick: () -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    var bmp by remember(uri) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(uri) {
        bmp = withContext(Dispatchers.IO) { Wallpaper.decodeUri(context, uri, 520)?.asImageBitmap() }
    }
    LaunchedEffect(focused) {
        if (focused) onFocused()
    }
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .scale(if (focused) 1.05f else 1f)
            .clip(shape)
            .background(Color(0x22FFFFFF))
            .border(if (focused) 3.dp else 1.dp, if (focused) accent else Color(0x44FFFFFF), shape)
            .onPreviewKeyEvent { ev ->
                if (ev.type == KeyEventType.KeyDown) onDpad(ev.nativeKeyEvent.keyCode) else false
            }
            .focusRequester(focusRequester)
            .tvClickable(source, null, onClick),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Text(text = "...", color = TextLo, fontSize = 11.sp, fontFamily = RoundedFont)
        }
    }
}
