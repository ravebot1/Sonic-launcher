package com.streamerhome.launcher

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

private val Bg1 = Color(0xFF0B0E14)
private val Bg2 = Color(0xFF172033)
private val CardColor = Color(0xFF1C2233)
private val CardFocused = Color(0xFF2B3552)
private val Accent = Color(0xFF8AB4FF)
private val TextHi = Color(0xFFF2F4F8)
private val TextLo = Color(0xFF9AA3B5)

private val timeFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val dateFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE, d MMMM")

@Composable
fun HomeScreen(permissionTick: Int, resumeTick: Int, onAskLocation: () -> Unit) {
    val context = LocalContext.current
    var showApps by remember { mutableStateOf(false) }
    var showNet by remember { mutableStateOf(false) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var weather by remember { mutableStateOf<Weather?>(null) }
    var net by remember { mutableStateOf(NetworkReader.read(context)) }

    // A launcher should never "go back" to anything.
    BackHandler { showApps = false }

    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(1000L)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            val w = withContext(Dispatchers.IO) { WeatherApi.fetch() }
            if (w != null) weather = w
            delay(if (w != null) Config.WEATHER_REFRESH_MS else 60_000L)
        }
    }
    LaunchedEffect(permissionTick, resumeTick) {
        while (true) {
            net = NetworkReader.read(context)
            delay(4000L)
        }
    }

    val greeting = when (now.hour) {
        in 5..11 -> "Good morning"
        in 12..17 -> "Good afternoon"
        in 18..22 -> "Good evening"
        else -> "Good night"
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Bg2, Bg1)))
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 56.dp, vertical = 36.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text(
                        now.format(timeFmt),
                        color = TextHi,
                        fontSize = 76.sp,
                        fontWeight = FontWeight.Light
                    )
                    Text(
                        greeting + " · " + now.format(dateFmt),
                        color = TextLo,
                        fontSize = 20.sp
                    )
                }
                Spacer(Modifier.weight(1f))
                WeatherChip(weather)
                Spacer(Modifier.width(20.dp))
                WifiButton(net) { showNet = true }
            }

            Spacer(Modifier.height(24.dp))
            PhotoHero(resumeTick, Modifier.fillMaxWidth().weight(1f))
            Spacer(Modifier.height(24.dp))
            AppRow(resumeTick) { showApps = true }
        }

        if (showApps) {
            AllApps(resumeTick) { showApps = false }
        }
        if (showNet) {
            NetDialog(
                net = net,
                onClose = { showNet = false },
                onAskLocation = onAskLocation,
                onSettings = { openWifiSettings(context) }
            )
        }
    }
}

private fun openWifiSettings(context: Context) {
    try {
        context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e2: Exception) {
            // nothing else to try
        }
    }
}

// ---------- Top bar pieces ----------

@Composable
private fun WeatherChip(w: Weather?) {
    Row(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(CardColor)
            .padding(horizontal = 22.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (w == null) {
            Text("Weather…", color = TextLo, fontSize = 18.sp)
        } else {
            Text(w.emoji, fontSize = 38.sp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(
                    w.temp.toString() + "°",
                    color = TextHi,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    Config.CITY + " · " + w.label + " · H " + w.high + "° L " + w.low + "°",
                    color = TextLo,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun WifiButton(net: NetInfo, onClick: () -> Unit) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val active = if (net.level < 0) 0 else net.level.coerceAtLeast(1)
    Box(
        Modifier
            .size(60.dp)
            .clip(CircleShape)
            .background(if (focused) CardFocused else CardColor)
            .border(3.dp, if (focused) Accent else Color.Transparent, CircleShape)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(28.dp)) {
            val barW = size.width / 7f
            for (i in 0 until 4) {
                val h = size.height * (0.3f + 0.7f * (i + 1) / 4f)
                drawRoundRect(
                    color = if (i < active) TextHi else Color(0x44FFFFFF),
                    topLeft = Offset(i * barW * 2f, size.height - h),
                    size = Size(barW, h),
                    cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                )
            }
        }
    }
}

// ---------- Photo hero ----------

@Composable
private fun PhotoHero(resumeTick: Int, modifier: Modifier) {
    val context = LocalContext.current
    var files by remember { mutableStateOf<List<File>>(emptyList()) }
    var index by remember { mutableIntStateOf(0) }
    var bitmap by remember { mutableStateOf<ImageBitmap?>(null) }

    LaunchedEffect(resumeTick) {
        files = withContext(Dispatchers.IO) { Photos.list(context) }
        index = 0
    }
    LaunchedEffect(files, index) {
        if (files.isNotEmpty()) {
            val f = files[index % files.size]
            bitmap = withContext(Dispatchers.IO) { Photos.load(f)?.asImageBitmap() }
            delay(Config.SLIDE_INTERVAL_MS)
            index = (index + 1) % files.size
        } else {
            bitmap = null
        }
    }

    Box(modifier.clip(RoundedCornerShape(28.dp)).background(CardColor)) {
        Crossfade(targetState = bitmap, animationSpec = tween(1200), label = "photo") { bmp ->
            if (bmp != null) {
                Image(
                    bitmap = bmp,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Column(
                    Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("🖼️", fontSize = 44.sp)
                    Spacer(Modifier.height(10.dp))
                    Text("Your photo slideshow goes here", color = TextHi, fontSize = 20.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Copy photos to Android/data/com.streamerhome.launcher/files/photos",
                        color = TextLo,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(90.dp)
                .align(Alignment.BottomStart)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xAA000000))))
        )
    }
}

// ---------- App tiles ----------

@Composable
private fun AppRow(resumeTick: Int, onAllApps: () -> Unit) {
    val context = LocalContext.current
    val pm = context.packageManager
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(300L)
        runCatching { first.requestFocus() }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
        Config.tiles.forEachIndexed { index, spec ->
            val pkg = remember(resumeTick, spec) { Apps.firstInstalled(pm, spec.packages) }
            val icon = remember(pkg) { if (pkg != null) Apps.icon(pm, pkg) else null }
            AppTile(
                label = spec.label,
                accent = Color(spec.accent),
                icon = icon,
                modifier = Modifier.weight(1f),
                installed = pkg != null,
                focusRequester = if (index == 0) first else null
            ) {
                val p = Apps.firstInstalled(pm, spec.packages)
                if (p != null) Apps.launch(context, p) else Apps.launch(context, spec.packages.first())
            }
        }
        AppTile(
            label = "All apps",
            accent = Accent,
            icon = null,
            modifier = Modifier.weight(1f),
            glyph = "☰"
        ) { onAllApps() }
    }
}

@Composable
private fun AppTile(
    label: String,
    accent: Color,
    icon: ImageBitmap?,
    modifier: Modifier = Modifier,
    glyph: String? = null,
    installed: Boolean = true,
    focusRequester: FocusRequester? = null,
    onClick: () -> Unit
) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val scale by animateFloatAsState(if (focused) 1.07f else 1f, label = "tileScale")
    val shape = RoundedCornerShape(22.dp)
    Box(
        modifier = modifier
            .height(120.dp)
            .scale(scale)
            .alpha(if (installed) 1f else 0.45f)
            .clip(shape)
            .background(if (focused) CardFocused else CardColor)
            .border(3.dp, if (focused) Accent else Color.Transparent, shape)
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (icon != null) {
                Image(
                    bitmap = icon,
                    contentDescription = label,
                    modifier = Modifier.size(52.dp).clip(RoundedCornerShape(12.dp))
                )
            } else {
                Box(
                    Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(accent.copy(alpha = 0.25f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        glyph ?: label.take(1).uppercase(),
                        color = accent,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                label,
                color = TextHi,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// ---------- All apps overlay ----------

@Composable
private fun AllApps(resumeTick: Int, onClose: () -> Unit) {
    val context = LocalContext.current
    val pm = context.packageManager
    val apps = remember(resumeTick) { Apps.installed(context) }
    val first = remember { FocusRequester() }
    LaunchedEffect(apps) {
        delay(250L)
        runCatching { first.requestFocus() }
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF00B0E14))
            .padding(horizontal = 56.dp, vertical = 36.dp)
    ) {
        Column {
            Text("All apps", color = TextHi, fontSize = 34.sp, fontWeight = FontWeight.Light)
            Spacer(Modifier.height(20.dp))
            LazyVerticalGrid(
                columns = GridCells.Adaptive(150.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(8.dp)
            ) {
                itemsIndexed(apps) { index, app ->
                    val icon = remember(app.pkg) { Apps.icon(pm, app.pkg) }
                    AppTile(
                        label = app.label,
                        accent = Accent,
                        icon = icon,
                        modifier = Modifier.fillMaxWidth(),
                        focusRequester = if (index == 0) first else null
                    ) {
                        Apps.launch(context, app.pkg)
                        onClose()
                    }
                }
            }
        }
    }
}

// ---------- Network dialog ----------

@Composable
private fun NetDialog(
    net: NetInfo,
    onClose: () -> Unit,
    onAskLocation: () -> Unit,
    onSettings: () -> Unit
) {
    val closeFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { closeFocus.requestFocus() }
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .width(540.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(CardColor)
                .padding(36.dp)
        ) {
            Text("NETWORK", color = TextLo, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            Text(net.name, color = TextHi, fontSize = 34.sp, fontWeight = FontWeight.Medium)
            if (net.detail.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(net.detail, color = TextLo, fontSize = 17.sp)
            }
            if (net.needsLocation) {
                Spacer(Modifier.height(14.dp))
                Text(
                    "Android only shows the Wi-Fi name after location access is allowed.",
                    color = TextLo,
                    fontSize = 15.sp
                )
                Spacer(Modifier.height(12.dp))
                ActionButton("Allow access", true, null, onAskLocation)
            }
            Spacer(Modifier.height(26.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                ActionButton("Wi-Fi settings", false, null, onSettings)
                ActionButton("Close", true, closeFocus, onClose)
            }
        }
    }
}

@Composable
private fun ActionButton(
    text: String,
    primary: Boolean,
    focusRequester: FocusRequester?,
    onClick: () -> Unit
) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val shape = RoundedCornerShape(16.dp)
    val bg = if (focused) Accent else if (primary) CardFocused else Color(0xFF262E45)
    Box(
        Modifier
            .clip(shape)
            .background(bg)
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .clickable(interactionSource = source, indication = null, onClick = onClick)
            .padding(horizontal = 28.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (focused) Bg1 else TextHi,
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
