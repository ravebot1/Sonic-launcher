package com.streamerhome.launcher

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

// ---------- Look & feel ----------

private val Cyan = Color(0xFF4FE3FF)
private val Ink = Color(0xFF060A14)
private val PanelDark = Color(0xFF0E1626)
private val TextHi = Color(0xFFF2F7FF)
private val TextLo = Color(0xFFA5B4CC)

private val glassBorder = Brush.linearGradient(listOf(Color(0x80FFFFFF), Color(0x14FFFFFF)))
private val glassFill = Brush.linearGradient(listOf(Color(0x3DFFFFFF), Color(0x0FFFFFFF)))
private val glassFillFocused = Brush.linearGradient(listOf(Color(0x70FFFFFF), Color(0x2AFFFFFF)))

private val timeFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val dateFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE, d MMMM")

private fun glow(color: Color = Cyan, blur: Float = 28f) = TextStyle(
    shadow = Shadow(color = color.copy(alpha = 0.85f), offset = Offset.Zero, blurRadius = blur)
)

// Translucent "glass" surface with a soft sheen and a light edge.
private fun Modifier.glass(shape: Shape): Modifier =
    this.clip(shape).background(glassFill).border(1.dp, glassBorder, shape)

// Sci-fi corner brackets drawn just outside the element.
private fun Modifier.hudCorners(color: Color, len: Dp = 14.dp, stroke: Dp = 2.dp): Modifier =
    this.drawWithContent {
        drawContent()
        val l = len.toPx()
        val s = stroke.toPx()
        val h2 = s / 2f
        val w = size.width
        val h = size.height
        drawLine(color, Offset(0f, h2), Offset(l, h2), s)
        drawLine(color, Offset(h2, 0f), Offset(h2, l), s)
        drawLine(color, Offset(w - l, h2), Offset(w, h2), s)
        drawLine(color, Offset(w - h2, 0f), Offset(w - h2, l), s)
        drawLine(color, Offset(0f, h - h2), Offset(l, h - h2), s)
        drawLine(color, Offset(h2, h - l), Offset(h2, h), s)
        drawLine(color, Offset(w - l, h - h2), Offset(w, h - h2), s)
        drawLine(color, Offset(w - h2, h - l), Offset(w - h2, h), s)
    }

// ---------- Home screen ----------

@Composable
fun HomeScreen(permissionTick: Int, resumeTick: Int, onAskLocation: () -> Unit) {
    val context = LocalContext.current
    var showApps by remember { mutableStateOf(false) }
    var showNet by remember { mutableStateOf(false) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var weather by remember { mutableStateOf<Weather?>(null) }
    var net by remember { mutableStateOf(NetworkReader.read(context)) }

    // A launcher should never "go back" to anything.
    BackHandler { showApps = false }

    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(1000L)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            val w = withContext(Dispatchers.IO) { WeatherApi.fetch() }
            if (w != null) weather = w
            delay(if (w != null) Config.WEATHER_REFRESH_MS else 60_000L)
        }
    }
    LaunchedEffect(permissionTick, resumeTick) {
        while (true) {
            net = NetworkReader.read(context)
            delay(4000L)
        }
    }

    val greeting = when (now.hour) {
        in 5..11 -> "Good morning"
        in 12..17 -> "Good afternoon"
        in 18..22 -> "Good evening"
        else -> "Good night"
    }

    Box(Modifier.fillMaxSize().background(Ink)) {
        // Online background (space + landscapes), darkened for readability
        RotatingImage(Modifier.fillMaxSize(), 2200, Config.BG_INTERVAL_MS) { Remote.backgroundUrls() }
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xB3060A14), Color(0x59060A14), Color(0xCC060A14))
                    )
                )
        )
        GridOverlay()

        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 40.dp, vertical = 28.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                ClockPanel(now, greeting)
                Spacer(Modifier.weight(1f))
                WeatherPanel(weather)
                Spacer(Modifier.width(16.dp))
                WifiButton(net) { showNet = true }
            }
            Spacer(Modifier.weight(1f))
            AppRow(resumeTick) { showApps = true }
        }

        if (showApps) {
            AllApps(resumeTick) { showApps = false }
        }
        if (showNet) {
            NetDialog(
                net = net,
                onClose = { showNet = false },
                onAskLocation = onAskLocation,
                onSettings = { openWifiSettings(context) }
            )
        }
    }
}

private fun openWifiSettings(context: Context) {
    try {
        context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e2: Exception) {
            // nothing else to try
        }
    }
}

@Composable
private fun GridOverlay() {
    Canvas(Modifier.fillMaxSize()) {
        val step = 56.dp.toPx()
        val c = Color(0x0EFFFFFF)
        var x = 0f
        while (x < size.width) {
            drawLine(c, Offset(x, 0f), Offset(x, size.height), 1f)
            x += step
        }
        var y = 0f
        while (y < size.height) {
            drawLine(c, Offset(0f, y), Offset(size.width, y), 1f)
            y += step
        }
    }
}

// Cross-fading slideshow of remote images (downloaded once, cached on disk).
@Composable
private fun RotatingImage(
    modifier: Modifier,
    maxSide: Int,
    intervalMs: Long,
    fetchUrls: () -> List<String>
) {
    val context = LocalContext.current
    var bitmap by remember { mutableStateOf<ImageBitmap?>(null) }

    LaunchedEffect(Unit) {
        var urls: List<String> = emptyList()
        var index = 0
        while (true) {
            if (urls.isEmpty()) {
                urls = withContext(Dispatchers.IO) { fetchUrls() }
                index = 0
                if (urls.isEmpty()) {
                    delay(15_000L)
                    continue
                }
            }
            val url = urls[index]
            val bmp = withContext(Dispatchers.IO) { Remote.loadBitmap(context, url, maxSide) }
            if (bmp != null) {
                bitmap = bmp.asImageBitmap()
                delay(intervalMs)
            } else {
                delay(2000L)
            }
            index++
            if (index >= urls.size) urls = emptyList()
        }
    }

    Crossfade(targetState = bitmap, modifier = modifier, animationSpec = tween(1500), label = "remoteImage") { bmp ->
        if (bmp != null) {
            Image(
                bitmap = bmp,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(Modifier.fillMaxSize())
        }
    }
}

// ---------- Top bar pieces ----------

@Composable
private fun ClockPanel(now: LocalDateTime, greeting: String) {
    val sec = now.second
    Column(
        Modifier
            .hudCorners(Cyan.copy(alpha = 0.85f))
            .glass(RoundedCornerShape(16.dp))
            .padding(horizontal = 28.dp, vertical = 18.dp)
            .width(IntrinsicSize.Max)
    ) {
        Text(
            "LOCAL TIME // " + Config.CITY.uppercase(),
            color = Cyan,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 3.sp
        )
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                now.format(timeFmt),
                color = TextHi,
                fontSize = 76.sp,
                fontWeight = FontWeight.Thin,
                fontFamily = FontFamily.SansSerif,
                letterSpacing = 3.sp,
                style = glow()
            )
            Text(
                ":" + sec.toString().padStart(2, '0'),
                color = Cyan,
                fontSize = 26.sp,
                fontWeight = FontWeight.Light,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(start = 8.dp, bottom = 14.dp),
                style = glow(blur = 16f)
            )
        }
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(2.dp)
                .background(Color(0x26FFFFFF))
        ) {
            Box(
                Modifier
                    .fillMaxWidth(sec / 59f)
                    .fillMaxHeight()
                    .background(Brush.horizontalGradient(listOf(Cyan.copy(alpha = 0.15f), Cyan)))
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            (greeting + " · " + now.format(dateFmt)).uppercase(),
            color = TextLo,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 2.sp
        )
    }
}

@Composable
private fun WeatherPanel(w: Weather?) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        Modifier
            .width(340.dp)
            .height(140.dp)
            .hudCorners(Cyan.copy(alpha = 0.85f))
            .clip(shape)
            .background(PanelDark)
            .border(1.dp, glassBorder, shape)
    ) {
        // London photos
        RotatingImage(Modifier.fillMaxSize(), 1400, Config.LONDON_INTERVAL_MS) { Remote.londonUrls() }
        // Dark-to-clear scrim so the text on the left stays readable
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xE60A1020), Color(0x990A1020), Color(0x1A0A1020))
                    )
                )
        )
        Column(
            Modifier
                .align(Alignment.CenterStart)
                .padding(horizontal = 22.dp)
        ) {
            Text(
                "WEATHER // " + Config.CITY.uppercase(),
                color = Cyan,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 3.sp
            )
            if (w == null) {
                Spacer(Modifier.height(8.dp))
                Text("SYNCING…", color = TextLo, fontSize = 16.sp, fontFamily = FontFamily.Monospace)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        w.temp.toString() + "°",
                        color = TextHi,
                        fontSize = 52.sp,
                        fontWeight = FontWeight.Thin,
                        style = glow(blur = 22f)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(w.emoji, fontSize = 30.sp)
                }
                Text(
                    w.label.uppercase(),
                    color = TextHi,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    "H " + w.high + "°  L " + w.low + "°  ·  " + w.windMph + " MPH  ·  " + w.humidity + "%",
                    color = TextLo,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

@Composable
private fun WifiButton(net: NetInfo, onClick: () -> Unit) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val active = if (net.level < 0) 0 else net.level.coerceAtLeast(1)
    Box(
        Modifier
            .size(56.dp)
            .shadow(if (focused) 18.dp else 0.dp, CircleShape, false, Cyan, Cyan)
            .clip(CircleShape)
            .background(if (focused) glassFillFocused else glassFill)
            .border(if (focused) 2.dp else 1.dp, if (focused) Cyan else Color(0x44FFFFFF), CircleShape)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(26.dp)) {
            val barW = size.width / 7f
            for (i in 0 until 4) {
                val h = size.height * (0.3f + 0.7f * (i + 1) / 4f)
                drawRoundRect(
                    color = if (i < active) Cyan else Color(0x44FFFFFF),
                    topLeft = Offset(i * barW * 2f, size.height - h),
                    size = Size(barW, h),
                    cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                )
            }
        }
    }
}

// ---------- App tiles ----------

@Composable
private fun AppRow(resumeTick: Int, onAllApps: () -> Unit) {
    val context = LocalContext.current
    val pm = context.packageManager
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(300L)
        runCatching { first.requestFocus() }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Config.tiles.forEachIndexed { index, spec ->
            val pkg = remember(resumeTick, spec) { Apps.firstInstalled(pm, spec.packages) }
            val icon = remember(pkg) { if (pkg != null) Apps.icon(pm, pkg) else null }
            AppTile(
                label = spec.label,
                accent = Color(spec.accent),
                icon = icon,
                modifier = Modifier.weight(1f),
                installed = pkg != null,
                focusRequester = if (index == 0) first else null
            ) {
                val p = Apps.firstInstalled(pm, spec.packages)
                if (p != null) Apps.launch(context, p) else Apps.launch(context, spec.packages.first())
            }
        }
        AppTile(
            label = "All apps",
            accent = Cyan,
            icon = null,
            modifier = Modifier.weight(1f),
            glyph = "☰"
        ) { onAllApps() }
    }
}

@Composable
private fun AppTile(
    label: String,
    accent: Color,
    icon: ImageBitmap?,
    modifier: Modifier = Modifier,
    glyph: String? = null,
    installed: Boolean = true,
    focusRequester: FocusRequester? = null,
    onClick: () -> Unit
) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val scale by animateFloatAsState(if (focused) 1.06f else 1f, label = "tileScale")
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier = modifier
            .aspectRatio(1f)
            .scale(scale)
            .alpha(if (installed) 1f else 0.45f)
            .shadow(if (focused) 22.dp else 0.dp, shape, false, Cyan, Cyan)
            .clip(shape)
            .background(if (focused) glassFillFocused else glassFill)
            .border(if (focused) 2.5.dp else 1.dp, if (focused) Cyan else Color(0x44FFFFFF), shape)
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(10.dp)
        ) {
            if (icon != null) {
                Image(
                    bitmap = icon,
                    contentDescription = label,
                    modifier = Modifier
                        .fillMaxWidth(0.7f)
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(22.dp))
                )
            } else {
                Box(
                    Modifier
                        .fillMaxWidth(0.7f)
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(22.dp))
                        .background(accent.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        glyph ?: label.take(1).uppercase(),
                        color = accent,
                        fontSize = 40.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                label,
                color = TextHi,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// ---------- All apps overlay ----------

@Composable
private fun AllApps(resumeTick: Int, onClose: () -> Unit) {
    val context = LocalContext.current
    val pm = context.packageManager
    val apps = remember(resumeTick) { Apps.installed(context) }
    val first = remember { FocusRequester() }
    LaunchedEffect(apps) {
        delay(250L)
        runCatching { first.requestFocus() }
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xF2060A14))
            .padding(horizontal = 40.dp, vertical = 28.dp)
    ) {
        Column {
            Text(
                "ALL APPS",
                color = Cyan,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 4.sp
            )
            Spacer(Modifier.height(16.dp))
            LazyVerticalGrid(
                columns = GridCells.Adaptive(132.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(8.dp)
            ) {
                itemsIndexed(apps) { index, app ->
                    val icon = remember(app.pkg) { Apps.icon(pm, app.pkg) }
                    AppTile(
                        label = app.label,
                        accent = Cyan,
                        icon = icon,
                        modifier = Modifier.fillMaxWidth(),
                        focusRequester = if (index == 0) first else null
                    ) {
                        Apps.launch(context, app.pkg)
                        onClose()
                    }
                }
            }
        }
    }
}

// ---------- Network dialog ----------

@Composable
private fun NetDialog(
    net: NetInfo,
    onClose: () -> Unit,
    onAskLocation: () -> Unit,
    onSettings: () -> Unit
) {
    val closeFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(250L)
        runCatching { closeFocus.requestFocus() }
    }
    val shape = RoundedCornerShape(16.dp)
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .width(500.dp)
                .hudCorners(Cyan)
                .clip(shape)
                .background(PanelDark)
                .border(1.dp, glassBorder, shape)
                .padding(30.dp)
        ) {
            Text(
                "NETWORK",
                color = Cyan,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 4.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(net.name, color = TextHi, fontSize = 30.sp, fontWeight = FontWeight.Light, style = glow(blur = 18f))
            if (net.detail.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(net.detail, color = TextLo, fontSize = 15.sp)
            }
            if (net.needsLocation) {
                Spacer(Modifier.height(14.dp))
                Text(
                    "Android only shows the Wi-Fi name after location access is allowed.",
                    color = TextLo,
                    fontSize = 14.sp
                )
                Spacer(Modifier.height(12.dp))
                ActionButton("Allow access", true, null, onAskLocation)
            }
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                ActionButton("Wi-Fi settings", false, null, onSettings)
                ActionButton("Close", true, closeFocus, onClose)
            }
        }
    }
}

@Composable
private fun ActionButton(
    text: String,
    primary: Boolean,
    focusRequester: FocusRequester?,
    onClick: () -> Unit
) {
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val shape = RoundedCornerShape(12.dp)
    val bg = if (focused) Cyan else if (primary) Color(0xFF1F2B45) else Color(0xFF18223A)
    Box(
        Modifier
            .clip(shape)
            .background(bg)
            .border(1.dp, if (focused) Cyan else Color(0x44FFFFFF), shape)
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .clickable(interactionSource = source, indication = null, onClick = onClick)
            .padding(horizontal = 26.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (focused) Ink else TextHi,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
