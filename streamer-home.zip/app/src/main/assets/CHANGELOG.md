# Sonik Launcher changelog

## 1.9.21
- FIX: Settings: pressing Back twice (within 2 seconds) always closes Settings and returns to the home screen. A single Back or Left still goes to the category list, and now retries until the list takes focus.

## 1.9.20
- FIX: Settings: Back and Left from a page now really return to the category list. The category list is no longer "locked" while you are in a page (the lock stopped focus from going back), and Back/Left work from whichever button has focus.

## 1.9.19
- FIX: Settings: Back and Left now always return from a page to the category list (handled for the whole Settings window, and focus is restored if it is ever lost).
- FIX: home screen: focus can no longer disappear (Up from the bottom Wi-Fi icon goes straight to the tiles; a safety net restores focus if a focused card or tile goes away).
- New: soft tick when you move with the D-pad. Settings > Look > Sounds: Off / Clicks only / Clicks and movement.
- Settings drop-down options line up with the first button, so Left leaves them.

## 1.9.18
- FIX: Settings: when Close is selected, the category above it is no longer highlighted too.
- FIX: Left at the start of a row (Settings pages, Clock style, Weather card) goes back to where you came from instead of jumping to a button on another row. Settings reopens on the category you left.
- FIX: Back inside a Settings page returns to the category list (it was ignored).
- FIX: home row glow follows the focused tile while the row scrolls, so the first and last tile keep their full glow.
- FIX: Down from the top row lands on the tile you were on last, and falls back to normal navigation if that tile is off screen.
- New: up to 60 cinema films as wallpapers (was 20); More pictures in the gallery pages through the rest.
- New: animated wallpaper "London": Thames with boats, Big Ben, London Eye, Tower Bridge, the Shard, the Gherkin, Walkie Talkie and Canary Wharf; windows switch on and off, aircraft with strobes and contrails, buses and cars on the Embankment.
- New: sounds (Settings > Look > Sounds): a click for OK and a lower tone for Back, generated in the app.
- Code tidy: removed unused screens and parameters.

## 1.9.17
- FIX: Down from the clock, weather, Wi-Fi and Watch trailer reaches the tiles again.
- FIX: the last home tile (Settings) scrolls fully into view. Left at the first tile and Right at the last tile do nothing.
- FIX: updates install through the system installer (PackageInstaller) and show an error message if it fails.

## 1.9.16
- FIX: build error of 1.9.15 (same changes, now compiles).

## 1.9.15
- FIX: Home row: Left / Right stay on the tile row (no more jump to the Wi-Fi button). The first and last tile now scroll fully into view.
- FIX: Settings: Up / Down / Right can never leave a page. Left or Back returns to the category you came from.
- Settings scrolling is now smooth, and the focused button is white with a thick ring, so it never blends with selected options.
- Music visualiser: each style shows a small preview.
- Movies in cinema has its own card: Movies only / Mix with other types / No movies, with an explanation.
- New: Wi-Fi icon position (Settings > Look): four corners or hidden.

## 1.9.14
- FIX: Settings: Up and Down no longer leave a page. Only Left (at the start of a row) and Back return to the category you came from.
- FIX: Down from the now-playing card reaches the tiles.
- Notification access: Grant access opens the Special app access list (the screen where the switch stays on); extra button for Allow restricted settings.
- Wallpaper settings show only what matters for the chosen type: Rotating (types, movies key, interval, quality), Fixed (gallery, device), Animated (a drop-down for Abstract, Nature or City). Night mode applies to all. Hovering a type shows what it does.
- Animated wallpapers rebuilt with far more detail: lit clouds, noise-built mountains with snow and forest, a lake with glitter, Milky Way, light shafts (Nature); stepped towers, windows in warm and cool light, neon signs, haze, aircraft, wet road with lamps and headlights (City); additive light blobs, beams, ribbons and bokeh (Abstract).
- Music visualiser: 48 bands, peak markers that hang and fall, reflections, glow, colour shift across the spectrum, automatic gain, a LED meter with green, yellow and red zones, layered waves and a new Radial style. Without capture it plays a made-up groove (kick, snare, hats, melody).

## 1.9.13
- FIX: Settings: Left and Back from any page now return to the category list (the old "stay on this page" lock also blocked the way out).
- New wallpaper mode "Animated" (Settings > Wallpaper): Abstract, Nature or City, drawn live, following the time of day.
- Movies in cinema now has its own card: Movies only / Mix with other types / No movies, and "Check the key" shows how many films were found.
- Room temperature: "Find sensors..." lists the temperature sensors in Home Assistant so you just pick one. Settings can also be sent from a computer with adb (see the changelog of this build on GitHub).

## 1.9.12
- FIX: Settings no longer gets stuck after the system Notification access screen: focus is restored when you come back.
- New wallpaper type "Movies in cinema" (free TMDB key, Settings > Wallpaper): posters of films now showing. While one is on screen a "Watch trailer" button appears above the tiles and opens the trailer in YouTube.
- All apps redesigned: recently used apps on the top row, the rest A to Z, new tiles.
- Music visualiser (Settings > Playback): bars, mirror, pills, LED or wave along the bottom while music plays. Uses audio capture where the app allows it, otherwise a simulated animation.
- Room temperature next to the clock (Clock style > Show under the clock). Read through Home Assistant (Echo Dot has no public API); set up in Settings > Home.
- Modern look: pill buttons, glass dialogs, titled screens.

## 1.9.11
- FIX: Settings: Left from a page returns to its category, Back inside a page returns to the category list (Back on the list closes Settings).
- FIX: the first and last home tile are no longer cut off (the tile row now reaches the screen edge).
- FIX: Down from the Wi-Fi button reaches the tiles.
- Weather icons: two new sets drawn in the app, "Deluxe" (very detailed 3D) and "Neon" (glowing line art), with a preview of each in Weather settings.
- Clock: new Mini size; font picker shows every font; Opacity (5 to 100%) now fades the whole clock including its box; "Adapt to wallpaper" recolours each area of the clock against the picture behind it (pauses the slow wallpaper zoom).
- Clock style and Weather card panels redesigned like the Settings pages. No more all-caps text, coloured card headers everywhere.
- Settings header reads "Sonik Launcher".
- Picsum: skipped for 3 hours when its host cannot be reached, Commons nature pictures fill in.
- Commons: 4K accepts pictures from 2000 px and wider crops; the image status shows why pictures were rejected.

## 1.9.10
- Forecast: dark tinted boxes with coloured text (readable on any sky), sentence-case title and labels.
- Settings: Up/Down inside a page can no longer leave it (the page is a focus group).
- Tile glow is drawn on the whole screen behind the row, so it can no longer be cut at the left or right tile. Wallpaper glow is softer and starts lower.
- Drawn 3D icons are now the default and more detailed (more cloud puffs with lit rims, teardrop rain with ripples, sun corona ring).

## 1.9.9
- Updates now compare the version number (1.9.9 and so on), not the build number. versionCode follows the version, so an older zip is always offered the newest release. Release names carry the version.
- Forecast screen: compact layout that fits the screen (buttons on top), soft colours, sky backdrop, glass cards.
- Weather icons: new "OpenWeather (detailed)" style next to Meteocons and Drawn 3D.
- Weather card size is now a drop list: 60 / 80 / 100 / 120 %.
- Tile glow is drawn inside each tile's own space, so the first and last tile are no longer cut off.
- Settings: Down at the end of a page stays on the page; category icons instead of letters; What's new (changelog) screen under System.
- Wallpapers: all chosen types are fetched at the same time, so a new type shows sooner.

## 1.9.8
- FIX: Settings focus. Up/Down inside a page can no longer jump to the category list; Left returns to the category you came from; first and last cards scroll fully into view (System page included).
- Weather card sizes: 60 / 68 / 74 / 80 % of the old size.
- Weather settings > Done now returns to the home screen. Forecast screen redesigned (sky gradient, big icon, temperature colours, rain bars, day range bars).
- Settings cog removed from the top right (use the Settings tile). Tile glow no longer cut off at the first and last tile.
- Settings category list redesigned (gradient panel, badges, glowing selection).
- Wallpapers: space searches several tags (universe, planets, galaxy, nebula...) on the NASA library, Commons as backup; 4K mode falls back to Full HD pictures. Flickr feed read without JSON parsing (no more JSON exception).
- Grant access tries the direct detail screen for this app first.

## 1.9.7
- FIX: updates. Release tags are now "sonik-<run>" and the version code is 1000 + run, so an old high-numbered release can no longer be offered as "newest". Install this one by hand once; later updates work from Settings.
- New: Night mode (Settings > Wallpaper): same picture, darker and cooler after sunset (Off / Soft / Deep).
- New: clock colour "Blend with wallpaper" (takes a tone of the picture behind it).
- Weather card sizes are smaller: Extra large is now what Small used to be.
- Weather icons: three styles (Meteocons fill, Meteocons flat, Drawn 3D).
- Space wallpapers: NASA Image Library (no key, no 429) first, APOD only as extra and paused for an hour after a 429.
- Notification access: Grant access enables it directly when WRITE_SECURE_SETTINGS was granted once with adb.
- Settings: extra room at the bottom so the last option can scroll fully into view.
- Settings tile added to the home row, next to All apps.

## 1.9.6
- Settings redesigned: category list on the left (Look, Home, Wallpaper, Playback, System), cards on the right. Up / Down switch page, Right enters it, Left comes back.
- New: Banner tiles (16:9 TV artwork), ambient glow in the colour of the focused app, tiles lift with a coloured glow, accent colour "Auto (from wallpaper)".
- New: Settings > System > Default launcher (asks Android for the Home role, falls back to the Home app screen, shows the adb command).

## 1.9.5
- FIX: Wallpaper types: tapping a type when all are on now selects only that one (it used to switch it OFF, leaving the others such as Animals). "All" chip added.
- Weather icons: Meteocons (MIT) rendered from SVG, downloaded once; drawn art is the fallback. Switch in Weather settings > Weather icons.
- Playback card: the last played item is saved on disk (also by the notification service) and shown for 10 minutes after an app drops its session. Settings shows what Android reports for each media session.

## 1.9.4
- Weather card: resizing now scales everything inside it (text, icon, forecast strip, photo); border removed (a ring shows only while focused).
- Weather card: wind line (direction, speed, gusts) - switch in Weather settings > Show on the card. Forecast panel shows direction and gusts too.
- Weather settings: "Weather updates every" 10 / 15 / 30 / 60 min.
- London weather photos: Flickr falls back to smaller sizes after HTTP 403, Openverse added as a second source, Commons as backup.
- Commons: fixed "0 of 80 kept" (only 50 results carry picture info per request); 4K minimum width lowered to 3000 px.
- Playback card stays 10 minutes after an app drops its session (e.g. Back from Deezer); play reopens the app.
- Redrawn weather art: shaded volumetric clouds, tapered sun rays, depth rain, branched snowflakes.

## 1.9.3
- Weather card: size (Small to Extra large) and a See-through background (Settings > Weather card). Richer, shaded weather artwork (lit clouds, tapered rain, snowflakes, glowing lightning, soft fog).
- 4K wallpapers: Settings > Wallpaper quality. Sources: Bing daily pictures (UHD), Picsum (free Unsplash photos), Wikimedia Commons 3840 px and NASA. Gallery shows small previews and holds up to 40 pictures plus "More pictures".
- "Wallpaper changes every" is a drop-down; Never keeps one picture.
- Settings button is a proper cog icon.
- Updates: after the download the installer opens by itself, and an "Install downloaded update" button stays available.
- NASA space: retries a timeout and falls back to Commons space pictures. Image status now names the host for failed image downloads and shows why Commons pictures were rejected.

## 1.9.2
- FIX: Down from the weather card, the clock and the Settings button now jumps to the app tiles (or the playback card) by handling the key directly. 1.9.1 used a focus setting that may not have compiled.
- Weather card photos: London photos from Flickr tagged with the weather and time of day (rain, fog, snow, sunny, sunrise, sunset, night), Wikimedia Commons only as backup. Lighter shading so the photo is visible.
- Weather settings > Show on the card: new "5-day forecast" switch.

## 1.9.1
- Weather card: now shows the current temperature, the city and the next 5 days (icon, high, low) along the bottom. High / low and wind moved to the forecast panel (tap the card); Settings > Weather card > "Forecast panel shows" controls them.
- FIX: Down from the weather card or the Settings button now goes to the app tiles (or the playback card).
- FIX: wallpaper gallery "too small" tiles: London category pictures are now requested at 1920 px and small ones are filtered out; tiles that still fail are removed from the grid.
- FIX: "More pictures" now adds new pictures (new NASA picks, next pages of searches) instead of reshuffling the same ones.
- FIX: Wikimedia searches are sent one at a time with longer retries (rate limit), retry without the file-type filter when empty, and the image status names the search that found nothing.

## 1.9.0
- FIX: nothing behind an open panel can take focus any more (Left / Right in Settings no longer moves over the home tiles).
- FIX: Settings, Clock style and Weather settings jump back to the very top when you move up to the first row.
- Clock font is now a drop-down list (all 12 styles: Thin, Bold, Mono, Serif, Black, LED, Neon, Matrix, Slim, Italic, Outline, Pixel).
- Weather card: tap it, then "Weather settings..." (also in Settings > Weather card...): font, temperature colour, what the card shows, London photos or sky art only, photo interval, forecast days and hours.
- Weather photos: more search terms and categories, retry on rate limit, and the image status shows what was found.
- Wallpaper from this device: Settings > Wallpaper mode > "From this device..." (pictures list or system file picker), saved at 1920 x 1080.
- Wi-Fi and Settings buttons: smaller, no background (ring only when focused).

## 1.8.0
- FIX: Settings, All apps, Forecast, Clock, Home apps, Updates and the new Wallpaper gallery are now separate windows. The remote can no longer move focus onto the home tiles hidden behind them.
- FIX: removed the 1.7.0 focus overrides (up/down mapping) that could leave the home screen without a focus.
- Recent tiles are now recorded by the notification service itself (also while another app is open), including paused items.
- Four more clock styles: Slim, Italic, Outline, Pixel (next to LED, Neon, Matrix).
- Wallpaper gallery: pick a picture, it is saved at 1920 x 1080 as a fixed wallpaper. Settings > Wallpaper mode: Rotating / Fixed.

## 1.7.0
- Background grid lines removed.
- Up / Down in All apps and Choose home apps: focus now moves one row at a time (rows are scrolled in first). Down from the now-playing card goes to the app tiles and Up comes back.
- Tile size in Settings (Small / Medium / Large / Extra large).
- Recent tiles: the last things you played or watched (Deezer, YouTube, Tidal...) appear as tiles with their cover; tap reopens the app and resumes if it is still the active player. Settings: Off / 2 / 4 / 6 and Clear history.

## 1.6.1
- Name spelled Sonik Launcher (app label, Settings, About).

## 1.6.0
- Renamed to Sonic Launcher, new purple S icon and TV banner.
- Removed the footer text on the home screen; new About section in Settings.

## 1.5.0
- Smoother: the build is now optimised (R8, not debuggable), the clock ticks on its own instead of redrawing the whole screen every second, and Wi-Fi is read off the main thread.
- Space wallpapers use NASA's high-resolution files and any picture smaller than 1400 px is skipped.
- Clock fonts: LED, Neon and Matrix (drawn digits with glow and ghost segments).
- Sunrise / sunset: drawn icons with the words SUNRISE and SUNSET.
- Weather card: animated sky behind the photo (stars, sun glow, drifting clouds), known London photos as a fallback, and the image status shows what the card photos are doing.

## 1.4.2
- All apps / Choose home apps: the focused app is now always scrolled into view (focus used to move off-screen).
- Wallpapers and London photos: photos only (JPEG, landscape, large). Logos, maps, flags and NASA graphics are filtered out.
- Weather card: drawn weather artwork (sun, moon and stars, clouds, rain, snow, lightning, fog) instead of emoji; also in the forecast panel.
- Sunrise / sunset shown with sunrise and sunset symbols.

## 1.4.1
- Hold OK on a tile: the menu now opens when you let go of the button, so the release can no longer press "Open" by accident.

## 1.4
- Tap the weather card: hourly strip + 6-day forecast (rain chance, wind, humidity).
- Click the clock (or Settings > Clock style): font, size, box (none/glass/solid), text opacity, colour, 12/24h, seconds, and what shows under it (date, sunrise/sunset, day length, moon phase, tomorrow).
- Home apps: choose them in Settings, hold OK on a tile to open / app info / uninstall / move left-right / remove. Hold OK in All apps to add or remove.
- Now-playing card for Deezer, YouTube Music, Tidal (any media app): needs Notification access (Settings > Playback card). Prev / play-pause / next buttons.
- Updates from GitHub only when you press "Check for updates". Version code = GitHub run number (-PbuildNumber). Test builds toggle ignores pre-releases when off.
- Wallpaper type "London (time of day)": London pictures that follow time of day and weather.
- Animations (Full / Reduced / Off): staggered fade-in at start, springy tile focus with a light sweep, slow wallpaper zoom, panels fade/scale in, rain/snow on the weather card.


## 1.3
- Version number shown in Launcher Settings header.
- Two more wallpaper types: Animals and Art (Wikimedia Commons featured pictures). 'People' is not offered: no free source without an API key that is safe for a living-room TV.
- Already in the code: small tiles, London name on weather card, weather photos by time of day + weather (30 min), 6 colour themes, wallpaper interval 5-60 min, footer 'Created by Claudiu'.

## 1.3
- Settings button now opens Launcher Settings: 6 colour themes, wallpaper interval 5-60 min, wallpaper types (Space / Nature / City), image status line, shortcut to system settings.
- Weather card: "London" shown beside the temperature; London photo matches time of day + weather and changes every 30 min (sky-colour fallback behind it).
- App tiles about half the width/height (quarter of the area). "Created by Claudiu" at the bottom. Clock has no panel behind it.
- Wikimedia requests now send a contact User-Agent; status of online requests visible in Settings.

## 1.2
- Restored missing LazyVerticalGrid/GridCells/itemsIndexed imports (All apps grid).
- Fixed build errors in the Copilot-edited design (FontFamily.Rounded does not exist in Compose -> SansSerif; `catch (_: ...)` not allowed in Kotlin 1.9).
- Zip now has the project files at the root (no extra folder), as the GitHub workflow expects.
- Back button is swallowed on the home screen (launcher never "goes back").
- Kept Copilot's design: small bold clock, settings button under the Wi-Fi button, focus pop/offset on tiles.

## 1.1
- Online backgrounds (NASA space + Bing landscapes), London photos on the weather card, glass/HUD look, bigger square tiles, fixed signing key.

## 1.0
- First working build: clock, weather, Wi-Fi popup, app tiles, All apps.
