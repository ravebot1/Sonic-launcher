# Sonik Launcher changelog

## 1.8.0
- FIX: Settings, All apps, Forecast, Clock, Home apps, Updates and the new Wallpaper gallery are now separate windows. The remote can no longer move focus onto the home tiles hidden behind them.
- FIX: removed the 1.7.0 focus overrides (up/down mapping) that could leave the home screen without a focus.
- Recent tiles are now recorded by the notification service itself (also while another app is open), including paused items.
- Four more clock styles: Slim, Italic, Outline, Pixel (next to LED, Neon, Matrix).
- Wallpaper gallery: pick a picture, it is saved at 1920 x 1080 as a fixed wallpaper. Settings > Wallpaper mode: Rotating / Fixed.

## 1.7.0
- Background grid lines removed.
- Up / Down in All apps and Choose home apps: focus now moves one row at a time (rows are scrolled in first). Down from the now-playing card goes to the app tiles and Up comes back.
- Tile size in Settings (Small / Medium / Large / Extra large).
- Recent tiles: the last things you played or watched (Deezer, YouTube, Tidal...) appear as tiles with their cover; tap reopens the app and resumes if it is still the active player. Settings: Off / 2 / 4 / 6 and Clear history.

## 1.6.1
- Name spelled Sonik Launcher (app label, Settings, About).

## 1.6.0
- Renamed to Sonic Launcher, new purple S icon and TV banner.
- Removed the footer text on the home screen; new About section in Settings.

## 1.5.0
- Smoother: the build is now optimised (R8, not debuggable), the clock ticks on its own instead of redrawing the whole screen every second, and Wi-Fi is read off the main thread.
- Space wallpapers use NASA's high-resolution files and any picture smaller than 1400 px is skipped.
- Clock fonts: LED, Neon and Matrix (drawn digits with glow and ghost segments).
- Sunrise / sunset: drawn icons with the words SUNRISE and SUNSET.
- Weather card: animated sky behind the photo (stars, sun glow, drifting clouds), known London photos as a fallback, and the image status shows what the card photos are doing.

## 1.4.2
- All apps / Choose home apps: the focused app is now always scrolled into view (focus used to move off-screen).
- Wallpapers and London photos: photos only (JPEG, landscape, large). Logos, maps, flags and NASA graphics are filtered out.
- Weather card: drawn weather artwork (sun, moon and stars, clouds, rain, snow, lightning, fog) instead of emoji; also in the forecast panel.
- Sunrise / sunset shown with sunrise and sunset symbols.

## 1.4.1
- Hold OK on a tile: the menu now opens when you let go of the button, so the release can no longer press "Open" by accident.

## 1.4
- Tap the weather card: hourly strip + 6-day forecast (rain chance, wind, humidity).
- Click the clock (or Settings > Clock style): font, size, box (none/glass/solid), text opacity, colour, 12/24h, seconds, and what shows under it (date, sunrise/sunset, day length, moon phase, tomorrow).
- Home apps: choose them in Settings, hold OK on a tile to open / app info / uninstall / move left-right / remove. Hold OK in All apps to add or remove.
- Now-playing card for Deezer, YouTube Music, Tidal (any media app): needs Notification access (Settings > Playback card). Prev / play-pause / next buttons.
- Updates from GitHub only when you press "Check for updates". Version code = GitHub run number (-PbuildNumber). Test builds toggle ignores pre-releases when off.
- Wallpaper type "London (time of day)": London pictures that follow time of day and weather.
- Animations (Full / Reduced / Off): staggered fade-in at start, springy tile focus with a light sweep, slow wallpaper zoom, panels fade/scale in, rain/snow on the weather card.


## 1.3
- Version number shown in Launcher Settings header.
- Two more wallpaper types: Animals and Art (Wikimedia Commons featured pictures). 'People' is not offered: no free source without an API key that is safe for a living-room TV.
- Already in the code: small tiles, London name on weather card, weather photos by time of day + weather (30 min), 6 colour themes, wallpaper interval 5-60 min, footer 'Created by Claudiu'.

## 1.3
- Settings button now opens Launcher Settings: 6 colour themes, wallpaper interval 5-60 min, wallpaper types (Space / Nature / City), image status line, shortcut to system settings.
- Weather card: "London" shown beside the temperature; London photo matches time of day + weather and changes every 30 min (sky-colour fallback behind it).
- App tiles about half the width/height (quarter of the area). "Created by Claudiu" at the bottom. Clock has no panel behind it.
- Wikimedia requests now send a contact User-Agent; status of online requests visible in Settings.

## 1.2
- Restored missing LazyVerticalGrid/GridCells/itemsIndexed imports (All apps grid).
- Fixed build errors in the Copilot-edited design (FontFamily.Rounded does not exist in Compose -> SansSerif; `catch (_: ...)` not allowed in Kotlin 1.9).
- Zip now has the project files at the root (no extra folder), as the GitHub workflow expects.
- Back button is swallowed on the home screen (launcher never "goes back").
- Kept Copilot's design: small bold clock, settings button under the Wi-Fi button, focus pop/offset on tiles.

## 1.1
- Online backgrounds (NASA space + Bing landscapes), London photos on the weather card, glass/HUD look, bigger square tiles, fixed signing key.

## 1.0
- First working build: clock, weather, Wi-Fi popup, app tiles, All apps.
