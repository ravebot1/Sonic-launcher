package com.streamerhome.launcher

import android.Manifest
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {

    private var permissionTick by mutableIntStateOf(0)
    private var resumeTick by mutableIntStateOf(0)
    private var wallpaperTick by mutableIntStateOf(0)
    private var mediaTick by mutableIntStateOf(0)

    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            permissionTick++
        }

    private val mediaPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            mediaTick++
        }

    // System file picker: the chosen picture is saved as the fixed wallpaper (1920 x 1080)
    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                val app = applicationContext
                Thread {
                    val ok = Wallpaper.saveFromUri(app, uri)
                    runOnUiThread {
                        if (ok) {
                            Prefs.setWallMode(app, 1)
                            wallpaperTick++
                        }
                        Toast.makeText(
                            app,
                            if (ok) "Wallpaper saved" else "Could not use that picture",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }.start()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            HomeScreen(
                permissionTick = permissionTick,
                resumeTick = resumeTick,
                wallpaperTick = wallpaperTick,
                mediaTick = mediaTick,
                onAskLocation = {
                    locationPermission.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                },
                onAskMedia = {
                    mediaPermission.launch(Wallpaper.mediaPermission())
                },
                onPickFile = {
                    try {
                        pickImage.launch("image/*")
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "No file picker on this device", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }
}
