package com.streamerhome.launcher

import android.Manifest
import android.content.ComponentName
import android.content.pm.ApplicationInfo
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.FileProvider
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.widget.Toast
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

// ---------- Themes & saved settings ----------

data class ThemeSpec(val name: String, val accent: Color)

val Themes = listOf(
    ThemeSpec("Ice", Color(0xFF4FE3FF)),
    ThemeSpec("Violet", Color(0xFF9B8CFF)),
    ThemeSpec("Mint", Color(0xFF34D399)),
    ThemeSpec("Sunset", Color(0xFFFF8A4C)),
    ThemeSpec("Rose", Color(0xFFFF5C93)),
    ThemeSpec("Gold", Color(0xFFFFD166))
)

const val CAT_SPACE = 1
const val CAT_NATURE = 2
const val CAT_CITY = 4
const val CAT_ANIMALS = 8
const val CAT_ART = 16
const val CAT_LONDON = 32
const val CAT_ALL = 63

const val INFO_DATE = 1
const val INFO_SUN = 2
const val INFO_DAYLEN = 4
const val INFO_MOON = 8
const val INFO_TOMORROW = 16

data class ClockCfg(
    val style: Int = 1,        // 0 Thin, 1 Bold, 2 Mono, 3 Serif, 4 Black, 5 LED, 6 Neon, 7 Matrix, 8 Slim, 9 Italic, 10 Outline, 11 Pixel
    val box: Int = 0,          // 0 none, 1 glass, 2 solid
    val size: Int = 0,         // 0 small, 1 medium, 2 large
    val alpha: Int = 3,        // 0..3 = 45%, 65%, 85%, 100%
    val accentColor: Boolean = false,
    val h24: Boolean = true,
    val seconds: Boolean = false,
    val info: Int = INFO_DATE or INFO_SUN
)

const val WX_HL = 1
const val WX_WIND = 2
const val WX_HUM = 4
const val WX_COND = 8
const val WX_ICON = 16

data class WeatherCfg(
    val font: Int = 0,         // 0 Default, 1 Black, 2 Thin, 3 Serif, 4 Mono, 5 Script
    val color: Int = 0,        // 0 white, 1 theme colour (temperature)
    val info: Int = 31,        // WX_* bits shown on the card
    val photo: Int = 0,        // 0 London photos, 1 sky art only
    val photoMin: Int = 30,    // minutes between photos
    val days: Int = 6,         // forecast panel
    val hours: Int = 10
)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("streamer_home", Context.MODE_PRIVATE)

    fun themeIndex(c: Context): Int = sp(c).getInt("theme", 0).coerceIn(0, Themes.size - 1)
    fun setThemeIndex(c: Context, v: Int) = sp(c).edit().putInt("theme", v).apply()

    fun intervalMin(c: Context): Int = sp(c).getInt("interval", 10).coerceIn(5, 60)
    fun setIntervalMin(c: Context, v: Int) = sp(c).edit().putInt("interval", v).apply()

    // Home row: tile size (0 small .. 3 extra large) and how many "recently played" tiles to show
    fun tileSize(c: Context): Int = sp(c).getInt("tile_size", 1).coerceIn(0, 3)
    fun setTileSize(c: Context, v: Int) = sp(c).edit().putInt("tile_size", v).apply()
    // 0 = rotating wallpapers, 1 = the fixed one picked in the gallery
    fun wallMode(c: Context): Int = sp(c).getInt("wall_mode", 0).coerceIn(0, 1)
    fun setWallMode(c: Context, v: Int) = sp(c).edit().putInt("wall_mode", v).apply()
    fun recentCount(c: Context): Int = sp(c).getInt("recent_count", 4).coerceIn(0, 6)
    fun setRecentCount(c: Context, v: Int) = sp(c).edit().putInt("recent_count", v).apply()

    fun categories(c: Context): Int {
        val v = sp(c).getInt("cats", CAT_ALL) and CAT_ALL
        return if (v == 0) CAT_ALL else v
    }
    fun setCategories(c: Context, v: Int) = sp(c).edit().putInt("cats", v).apply()

    fun anim(c: Context): Int = sp(c).getInt("anim", 0).coerceIn(0, 2)
    fun setAnim(c: Context, v: Int) = sp(c).edit().putInt("anim", v).apply()

    fun clock(c: Context): ClockCfg {
        val p = sp(c)
        return ClockCfg(
            style = p.getInt("ck_style", 1).coerceIn(0, 11),
            box = p.getInt("ck_box", 0).coerceIn(0, 2),
            size = p.getInt("ck_size", 0).coerceIn(0, 2),
            alpha = p.getInt("ck_alpha", 3).coerceIn(0, 3),
            accentColor = p.getBoolean("ck_accent", false),
            h24 = p.getBoolean("ck_h24", true),
            seconds = p.getBoolean("ck_sec", false),
            info = p.getInt("ck_info", INFO_DATE or INFO_SUN) and 31
        )
    }

    fun setClock(c: Context, v: ClockCfg) {
        sp(c).edit()
            .putInt("ck_style", v.style)
            .putInt("ck_box", v.box)
            .putInt("ck_size", v.size)
            .putInt("ck_alpha", v.alpha)
            .putBoolean("ck_accent", v.accentColor)
            .putBoolean("ck_h24", v.h24)
            .putBoolean("ck_sec", v.seconds)
            .putInt("ck_info", v.info)
            .apply()
    }

    fun weather(c: Context): WeatherCfg {
        val p = sp(c)
        return WeatherCfg(
            font = p.getInt("wx_font", 0).coerceIn(0, 5),
            color = p.getInt("wx_color", 0).coerceIn(0, 1),
            info = p.getInt("wx_info", 31) and 31,
            photo = p.getInt("wx_photo", 0).coerceIn(0, 1),
            photoMin = p.getInt("wx_min", 30).coerceIn(5, 120),
            days = p.getInt("wx_days", 6).coerceIn(3, 6),
            hours = p.getInt("wx_hours", 10).coerceIn(4, 10)
        )
    }

    fun setWeather(c: Context, v: WeatherCfg) {
        sp(c).edit()
            .putInt("wx_font", v.font)
            .putInt("wx_color", v.color)
            .putInt("wx_info", v.info)
            .putInt("wx_photo", v.photo)
            .putInt("wx_min", v.photoMin)
            .putInt("wx_days", v.days)
            .putInt("wx_hours", v.hours)
            .apply()
    }

    // Home tiles: ordered package names. null = never customised (use the defaults from Config).
    fun tiles(c: Context): List<String>? {
        val s = sp(c).getString("tiles", null) ?: return null
        return s.split(",").filter { it.isNotBlank() }
    }
    fun setTiles(c: Context, list: List<String>) = sp(c).edit().putString("tiles", list.joinToString(",")).apply()
    fun clearTiles(c: Context) = sp(c).edit().remove("tiles").apply()

    // Updates: stable releases only unless "test builds" is switched on
    fun testBuilds(c: Context): Boolean = sp(c).getBoolean("test_builds", false)
    fun setTestBuilds(c: Context, v: Boolean) = sp(c).edit().putBoolean("test_builds", v).apply()
}

// ---------- Weather (Open-Meteo, no API key) ----------

data class DayForecast(val label: String, val code: Int, val high: Int, val low: Int, val rain: Int) {
    val emoji: String get() = describe(code).first
    val text: String get() = describe(code).second
}

data class HourForecast(val label: String, val code: Int, val temp: Int, val rain: Int) {
    val emoji: String get() = describe(code).first
}

data class Weather(
    val temp: Int,
    val code: Int,
    val high: Int,
    val low: Int,
    val windMph: Int,
    val humidity: Int,
    val isDay: Boolean,
    val sunriseMin: Int = 7 * 60,
    val sunsetMin: Int = 18 * 60,
    val days: List<DayForecast> = emptyList(),
    val hours: List<HourForecast> = emptyList()
) {
    val emoji: String get() = describe(code).first
    val label: String get() = describe(code).second

    // Used to pick matching photos: clear, cloud, rain, snow, fog, storm
    val group: String
        get() = when (code) {
            0, 1 -> "clear"
            2, 3 -> "cloud"
            45, 48 -> "fog"
            in 51..67, in 80..82 -> "rain"
            in 71..77, 85, 86 -> "snow"
            in 95..99 -> "storm"
            else -> "cloud"
        }
}

private fun describe(code: Int): Pair<String, String> = when (code) {
    0 -> "☀️" to "Clear"
    1 -> "🌤️" to "Mostly clear"
    2 -> "⛅" to "Partly cloudy"
    3 -> "☁️" to "Overcast"
    45, 48 -> "🌫️" to "Fog"
    in 51..57 -> "🌦️" to "Drizzle"
    in 61..67 -> "🌧️" to "Rain"
    in 71..77 -> "🌨️" to "Snow"
    in 80..82 -> "🌧️" to "Showers"
    85, 86 -> "🌨️" to "Snow showers"
    95, 96, 99 -> "⛈️" to "Thunderstorm"
    else -> "🌡️" to "Weather"
}

// sunrise / sunrise / day / night, based on the sun times (falls back to 07:00 - 18:00)
fun timeOfDay(nowMin: Int, w: Weather?): String {
    val sr = w?.sunriseMin ?: (7 * 60)
    val ss = w?.sunsetMin ?: (18 * 60)
    return when {
        kotlin.math.abs(nowMin - sr) <= 45 -> "sunrise"
        kotlin.math.abs(nowMin - ss) <= 45 -> "sunset"
        nowMin in sr..ss -> "day"
        else -> "night"
    }
}

fun formatMinutes(m: Int): String = String.format(Locale.US, "%02d:%02d", m / 60, m % 60)

fun moonPhase(date: LocalDate): Pair<String, String> {
    val ref = LocalDate.of(2000, 1, 6) // a new moon
    val days = ChronoUnit.DAYS.between(ref, date).toDouble()
    val synodic = 29.530588853
    val age = ((days % synodic) + synodic) % synodic
    val idx = ((age / synodic) * 8 + 0.5).toInt() % 8
    val emojis = listOf("🌑", "🌒", "🌓", "🌔", "🌕", "🌖", "🌗", "🌘")
    val names = listOf(
        "New moon", "Waxing crescent", "First quarter", "Waxing gibbous",
        "Full moon", "Waning gibbous", "Last quarter", "Waning crescent"
    )
    return Pair(emojis[idx], names[idx])
}

object WeatherApi {
    private fun minutesOf(iso: String): Int =
        iso.substring(11, 13).toInt() * 60 + iso.substring(14, 16).toInt()

    fun fetch(): Weather? {
        return try {
            val url = URL(
                "https://api.open-meteo.com/v1/forecast" +
                    "?latitude=${Config.LATITUDE}&longitude=${Config.LONGITUDE}" +
                    "&current=temperature_2m,weather_code,wind_speed_10m,relative_humidity_2m,is_day" +
                    "&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,precipitation_probability_max" +
                    "&hourly=temperature_2m,weather_code,precipitation_probability" +
                    "&wind_speed_unit=mph&timezone=auto&forecast_days=6"
            )
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 10000
            conn.readTimeout = 15000
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val json = JSONObject(text)
            val cur = json.getJSONObject("current")
            val daily = json.getJSONObject("daily")

            val dDate = daily.getJSONArray("time")
            val dCode = daily.getJSONArray("weather_code")
            val dMax = daily.getJSONArray("temperature_2m_max")
            val dMin = daily.getJSONArray("temperature_2m_min")
            val dRain = daily.optJSONArray("precipitation_probability_max")
            val dRise = daily.getJSONArray("sunrise")
            val dSet = daily.getJSONArray("sunset")

            val days = ArrayList<DayForecast>()
            for (i in 0 until minOf(6, dDate.length())) {
                val d = LocalDate.parse(dDate.getString(i))
                val label = if (i == 0) "TODAY"
                else d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()).uppercase()
                days.add(
                    DayForecast(
                        label,
                        dCode.getInt(i),
                        dMax.getDouble(i).roundToInt(),
                        dMin.getDouble(i).roundToInt(),
                        dRain?.optInt(i, 0) ?: 0
                    )
                )
            }

            val hours = ArrayList<HourForecast>()
            val hourly = json.optJSONObject("hourly")
            if (hourly != null) {
                val hTime = hourly.getJSONArray("time")
                val hCode = hourly.getJSONArray("weather_code")
                val hTemp = hourly.getJSONArray("temperature_2m")
                val hRain = hourly.optJSONArray("precipitation_probability")
                val nowStr = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:00").format(LocalDateTime.now())
                var start = 0
                while (start < hTime.length() && hTime.getString(start) < nowStr) start++
                var i = start
                while (i < hTime.length() && hours.size < 10) {
                    hours.add(
                        HourForecast(
                            hTime.getString(i).substring(11, 16),
                            hCode.getInt(i),
                            hTemp.getDouble(i).roundToInt(),
                            hRain?.optInt(i, 0) ?: 0
                        )
                    )
                    i++
                }
            }

            Weather(
                temp = cur.getDouble("temperature_2m").roundToInt(),
                code = cur.getInt("weather_code"),
                high = dMax.getDouble(0).roundToInt(),
                low = dMin.getDouble(0).roundToInt(),
                windMph = cur.getDouble("wind_speed_10m").roundToInt(),
                humidity = cur.getDouble("relative_humidity_2m").roundToInt(),
                isDay = cur.optInt("is_day", 1) == 1,
                sunriseMin = minutesOf(dRise.getString(0)),
                sunsetMin = minutesOf(dSet.getString(0)),
                days = days,
                hours = hours
            )
        } catch (e: Exception) {
            null
        }
    }
}

// ---------- Online images (backgrounds + weather photos) ----------

object Remote {
    private const val UA =
        "StreamerHome/1.3 (https://github.com/ravebot1/launcher; personal Android TV launcher)"

    // Human-readable status of the last network calls, shown in Settings.
    @Volatile
    var status: String = "No image requests yet"
    private val notes = LinkedHashMap<String, String>()

    @Synchronized
    private fun note(key: String, value: String) {
        notes[key] = value
        status = notes.entries.joinToString("\n") { it.key + ": " + it.value }
    }

    private val cache = HashMap<String, Pair<Long, List<String>>>()

    @Synchronized
    private fun cached(key: String): List<String>? {
        val e = cache[key] ?: return null
        val fresh = System.currentTimeMillis() - e.first < 60L * 60L * 1000L
        return if (fresh && e.second.isNotEmpty()) e.second.shuffled() else null
    }

    @Synchronized
    private fun store(key: String, list: List<String>) {
        cache[key] = System.currentTimeMillis() to list
    }

    private val gate = Any()
    private var lastApi = 0L

    // Wikimedia answers HTTP 429 when several searches arrive together: send API calls one at a time
    private fun commonsGate() {
        synchronized(gate) {
            val wait = lastApi + 400L - System.currentTimeMillis()
            if (wait > 0) Thread.sleep(wait)
            lastApi = System.currentTimeMillis()
        }
    }

    private fun httpGet(url: String, label: String): ByteArray? {
        var attempt = 0
        while (true) {
            try {
                if (url.contains("commons.wikimedia.org/w/api.php")) commonsGate()
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.setRequestProperty("User-Agent", UA)
                val code = conn.responseCode
                val bytes = if (code == 200) conn.inputStream.use { it.readBytes() } else null
                conn.disconnect()
                if ((code == 429 || code == 503) && attempt < 2) {
                    attempt++
                    Thread.sleep(2500L * attempt)
                    continue
                }
                note(label, if (code == 200) "ok" else "HTTP $code")
                return bytes
            } catch (e: Exception) {
                note(label, e.javaClass.simpleName)
                return null
            }
        }
    }

    private fun httpText(url: String, label: String): String? {
        val bytes = httpGet(url, label) ?: return null
        return String(bytes, Charsets.UTF_8)
    }

    private fun https(u: String): String = u.replaceFirst("http://", "https://")

    private fun nasaUrls(): List<String> {
        val out = ArrayList<String>()
        try {
            val text = httpText(
                "https://api.nasa.gov/planetary/apod?api_key=${Config.NASA_API_KEY}&count=12",
                "NASA space"
            )
            if (text != null) {
                val arr = JSONArray(text)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (o.optString("media_type") == "image") {
                        val hd = o.optString("hdurl")
                        val u = if (hd.isNotEmpty()) hd else o.optString("url")
                        if (u.isNotEmpty()) out.add(https(u))
                    }
                }
            }
        } catch (e: Exception) {
            note("NASA space", e.javaClass.simpleName)
        }
        return out
    }

    private fun bingUrls(): List<String> {
        val out = ArrayList<String>()
        try {
            val text = httpText(
                "https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=8&mkt=en-GB",
                "Bing nature"
            )
            if (text != null) {
                val arr = JSONObject(text).getJSONArray("images")
                for (i in 0 until arr.length()) {
                    val u = arr.getJSONObject(i).optString("url")
                    if (u.isNotEmpty()) {
                        out.add(if (u.startsWith("http")) https(u) else "https://www.bing.com" + u)
                    }
                }
            }
        } catch (e: Exception) {
            note("Bing nature", e.javaClass.simpleName)
        }
        return out
    }

    // Known London photographs on Wikimedia Commons, used when the search finds too little
    private val londonFallback = listOf(
        "Tower_Bridge_from_Shad_Thames.jpg",
        "London_Eye_Twilight_April_2006.jpg",
        "Palace_of_Westminster,_London_-_Feb_2007.jpg",
        "Tower_Bridge_London_Feb_2006.jpg",
        "London_Skyline_(125508655).jpeg"
    ).map { "https://commons.wikimedia.org/wiki/Special:FilePath/" + it + "?width=1920" }

    // Pictures that turned out to be too small for a wallpaper
    private val smallUrls: MutableSet<String> = java.util.Collections.synchronizedSet(HashSet<String>())

    // Words that mean "logo / map / diagram", not a photograph
    private val badTitleWords = setOf(
        "logo", "nasa", "iss", "icon", "map", "maps", "flag", "flags", "coat", "arms", "diagram",
        "emblem", "seal", "badge", "poster", "stamp", "chart", "plan", "svg", "screenshot",
        "signature", "crest", "symbol", "banner", "wordmark", "sign", "ticket"
    )

    // Reads the image list out of a Wikimedia Commons API answer (photos only: JPEG, landscape, big enough).
    private fun parseCommons(text: String, minWidth: Int, what: String = ""): List<String> {
        val out = ArrayList<String>()
        val root = JSONObject(text)
        val pages = root.optJSONObject("query")?.optJSONObject("pages")
        if (pages == null) {
            note("Commons reply", (root.optJSONObject("error")?.optString("code") ?: "no results") + " for " + what)
            return out
        }
        val total = pages.length()
        val keys = pages.keys()
        while (keys.hasNext()) {
            val page = pages.optJSONObject(keys.next()) ?: continue
            val title = page.optString("title", "").lowercase()
            val words = title.split(Regex("[^a-z0-9]+"))
            if (words.any { it in badTitleWords }) continue
            val info = page.optJSONArray("imageinfo") ?: continue
            val first = info.optJSONObject(0) ?: continue
            val w = first.optInt("width", 0)
            val h = first.optInt("height", 0)
            if (minWidth > 0 && (w < minWidth || w <= h || w > h * 3)) continue
            var u = first.optString("thumburl")
            if (u.isEmpty()) u = first.optString("url")
            val l = u.lowercase()
            if (l.endsWith(".jpg") || l.endsWith(".jpeg")) out.add(https(u))
        }
        note("Commons filter", out.size.toString() + " of " + total + " kept")
        return out
    }

    private fun commonsCategory(title: String, thumb: Int = 1920, minW: Int = 0): List<String> {
        return try {
            val text = httpText(
                "https://commons.wikimedia.org/w/api.php?action=query&generator=categorymembers" +
                    "&gcmtitle=Category:" + title +
                    "&gcmtype=file&gcmlimit=80&prop=imageinfo&iiprop=url%7Csize&iiurlwidth=" + thumb + "&format=json",
                "Commons London"
            )
            if (text != null) parseCommons(text, minW, title) else emptyList()
        } catch (e: Exception) {
            note("Commons London", e.javaClass.simpleName)
            emptyList()
        }
    }

    private fun commonsSearch(
        query: String,
        thumb: Int = 1280,
        minW: Int = if (thumb >= 1900) 1800 else 1200,
        offset: Int = 0
    ): List<String> {
        return try {
            var r = commonsQuery("$query filetype:bitmap", thumb, minW, offset)
            if (r.isEmpty()) r = commonsQuery(query, thumb, minW, offset)
            r
        } catch (e: Exception) {
            note("Commons photos", e.javaClass.simpleName)
            emptyList()
        }
    }

    private fun commonsQuery(search: String, thumb: Int, minW: Int, offset: Int): List<String> {
        val q = URLEncoder.encode(search, "UTF-8")
        val text = httpText(
            "https://commons.wikimedia.org/w/api.php?action=query&generator=search" +
                "&gsrsearch=" + q + "&gsroffset=" + offset +
                "&gsrnamespace=6&gsrlimit=40&prop=imageinfo&iiprop=url%7Csize&iiurlwidth=" + thumb + "&format=json",
            "Commons photos"
        )
        return if (text != null) parseCommons(text, minW, search) else emptyList()
    }

    // High-quality Commons pictures for a keyword (featured pictures first, plain search as fallback)
    private fun commonsFeatured(words: String): List<String> {
        val fp = commonsSearch(words + " incategory:\"Featured pictures on Wikimedia Commons\"", 1920)
        if (fp.size >= 4) return fp
        val plain = commonsSearch(words, 1920)
        return if (plain.size > fp.size) plain else fp
    }

    // Wallpapers for the chosen types (space = NASA, nature = Bing, city = London pictures)
    // London pictures that match the time of day (and the weather)
    private fun londonWallpaper(tod: String, group: String): List<String> {
        val words = ArrayList<String>()
        when (tod) {
            "night" -> words.add("night")
            "sunrise" -> words.add("sunrise")
            "sunset" -> words.add("sunset")
        }
        when (group) {
            "rain" -> words.add("rain")
            "snow" -> words.add("snow")
            "fog" -> words.add("fog")
            "storm" -> words.add("storm")
        }
        val queries = ArrayList<String>()
        queries.add(("London " + words.joinToString(" ")).trim())
        queries.add(
            when (tod) {
                "night" -> "London night skyline"
                "sunrise" -> "London sunrise"
                "sunset" -> "London sunset"
                else -> "London skyline"
            }
        )
        var result: List<String> = emptyList()
        for (q in queries) {
            val r = commonsSearch(q, 1920)
            if (r.size >= 6) {
                result = r
                break
            }
            if (r.size > result.size) result = r
        }
        if (result.size < 6) {
            val c = commonsCategory(Config.LONDON_CATEGORY, 1920, 1400)
            if (c.size > result.size) result = c
        }
        return if (result.size < 6) result + londonFallback else result
    }

    fun backgroundUrls(cats: Int, tod: String = "day", group: String = "cloud"): List<String> {
        val key = "bg-" + cats + (if ((cats and CAT_LONDON) != 0) "-" + tod + "-" + group else "")
        val hit = cached(key)
        if (hit != null) return hit
        val out = ArrayList<String>()
        if ((cats and CAT_SPACE) != 0) out.addAll(nasaUrls())
        if ((cats and CAT_NATURE) != 0) out.addAll(bingUrls())
        if ((cats and CAT_CITY) != 0) out.addAll(commonsCategory(Config.LONDON_CATEGORY, 1920, 1400))
        if ((cats and CAT_ANIMALS) != 0) {
            out.addAll(commonsFeatured("wildlife"))
            out.addAll(commonsFeatured("bird"))
        }
        if ((cats and CAT_ART) != 0) {
            out.addAll(commonsFeatured("landscape painting"))
            out.addAll(commonsFeatured("seascape"))
        }
        if ((cats and CAT_LONDON) != 0) out.addAll(londonWallpaper(tod, group))
        if (out.isEmpty()) {
            out.addAll(bingUrls())
            out.addAll(nasaUrls())
        }
        store(key, out)
        return out.shuffled()
    }

    // Wallpaper gallery: round 0 = the usual list, later rounds = new pictures (fresh NASA picks, next search pages)
    fun galleryUrls(cats: Int, tod: String, group: String, round: Int): List<String> {
        if (round == 0) return backgroundUrls(cats, tod, group).take(18)
        val out = ArrayList<String>()
        if ((cats and CAT_SPACE) != 0) out.addAll(nasaUrls())
        val topics = ArrayList<String>()
        if ((cats and CAT_NATURE) != 0) topics.addAll(listOf("mountain landscape", "forest", "lake", "coast sunset", "waterfall", "aurora", "desert"))
        if ((cats and CAT_CITY) != 0) topics.addAll(listOf("city skyline", "city night", "skyscrapers", "old town"))
        if ((cats and CAT_ANIMALS) != 0) topics.addAll(listOf("wildlife", "bird", "big cat", "butterfly", "fox"))
        if ((cats and CAT_ART) != 0) topics.addAll(listOf("landscape painting", "seascape painting", "impressionist painting"))
        if ((cats and CAT_LONDON) != 0) topics.addAll(listOf("London skyline", "London Thames", "London night", "London bridge"))
        if (topics.isNotEmpty()) {
            for (k in 0 until 2) {
                val n = round * 2 + k - 2
                out.addAll(commonsSearch(topics[n % topics.size], 1920, 1800, (n / topics.size) * 40))
            }
        }
        return out
    }

    // London photos that match the time of day and the weather
    fun weatherPhotoUrls(isDay: Boolean, group: String): List<String> {
        val key = "wp-" + (if (isDay) "d" else "n") + group
        val hit = cached(key)
        if (hit != null) return hit

        val cond = when (group) {
            "clear" -> if (isDay) "sunny" else ""
            "cloud" -> "cloudy"
            "rain" -> "rain"
            "snow" -> "snow"
            "fog" -> "fog"
            "storm" -> "storm"
            else -> ""
        }
        val night = if (isDay) "" else "night"
        val queries = listOf(
            "London $night $cond",
            "London $night",
            if (isDay) "London skyline" else "London night skyline",
            if (isDay) "London Thames" else "London lights evening"
        ).map { it.replace(Regex("\\s+"), " ").trim() }.distinct()

        val found = LinkedHashSet<String>()
        for (q in queries) {
            found.addAll(commonsSearch(q, 1280, 1000))
            if (found.size >= 8) break
        }
        if (found.size < 6) {
            val extra = when {
                !isDay -> "London_at_night"
                group == "snow" -> "Snow_in_London"
                group == "rain" -> "Rain_in_London"
                group == "fog" -> "Fog_in_London"
                else -> "London_skyline"
            }
            found.addAll(commonsCategory(extra, 1280, 900))
        }
        if (found.size < 4) found.addAll(commonsCategory(Config.LONDON_CATEGORY, 1280, 900))
        note("Weather photos", found.size.toString() + " found")
        val all = found.toList().shuffled() + (if (found.size < 6) londonFallback.shuffled() else emptyList())
        store(key, all)
        return all
    }

    // Downloads (once, cached on disk) and decodes an image, keeping its longest side <= maxSide.
    fun loadBitmap(context: Context, url: String, maxSide: Int, minSide: Int = 0): Bitmap? {
        if (smallUrls.contains(url)) return null
        return try {
            val dir = File(context.cacheDir, "remote")
            dir.mkdirs()
            val file = File(dir, Integer.toHexString(url.hashCode()) + ".img")
            if (!file.exists() || file.length() == 0L) {
                val bytes = httpGet(url, "Image files") ?: return null
                file.writeBytes(bytes)
                trimCache(dir)
            }
            if (minSide > 0) {
                val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.absolutePath, b)
                if (maxOf(b.outWidth, b.outHeight) < minSide) {
                    file.delete()
                    smallUrls.add(url)
                    note("Last image", "skipped, too small (" + b.outWidth + "x" + b.outHeight + ")")
                    return null
                }
            }
            val bmp = decode(file, maxSide)
            if (bmp == null) {
                file.delete()
                note("Last image", "could not decode")
            } else {
                note("Last image", "shown " + bmp.width + "x" + bmp.height)
            }
            bmp
        } catch (e: Throwable) {
            note("Last image", e.javaClass.simpleName)
            null
        }
    }

    private fun trimCache(dir: File, keep: Int = 60, maxBytes: Long = 160L * 1024L * 1024L) {
        val files = dir.listFiles()?.sortedByDescending { it.lastModified() } ?: return
        var total = 0L
        files.forEachIndexed { i, f ->
            total += f.length()
            if (i >= keep || total > maxBytes) f.delete()
        }
    }

    private fun decode(file: File, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(file.absolutePath, opts)
    }
}

// ---------- Network / Wi-Fi ----------

data class NetInfo(
    val kind: String,
    val name: String,
    val detail: String,
    val level: Int, // -1 = none, 0..4 = signal strength
    val needsLocation: Boolean = false
)

object NetworkReader {
    @Suppress("DEPRECATION")
    fun read(context: Context): NetInfo {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
            ?: return NetInfo("none", "Not connected", "Check your network settings", -1)
        val caps = cm.getNetworkCapabilities(network)
            ?: return NetInfo("none", "Not connected", "Check your network settings", -1)

        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
            return NetInfo("ethernet", "Ethernet", "Wired connection", 4)
        }
        if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            return NetInfo("other", "Connected", "", 3)
        }

        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val raw = info?.ssid ?: ""
        val ssid = raw.trim('"')
        val hidden = ssid.isEmpty() || ssid == "<unknown ssid>"
        val hasPerm = context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

        val rssi = info?.rssi ?: -100
        val level = WifiManager.calculateSignalLevel(rssi, 5)
        val percent = ((rssi + 100) * 2).coerceIn(0, 100)
        val freq = info?.frequency ?: 0
        val band = when {
            freq >= 5925 -> "6 GHz"
            freq >= 4900 -> "5 GHz"
            freq > 0 -> "2.4 GHz"
            else -> ""
        }
        val speed = info?.linkSpeed ?: 0

        val parts = ArrayList<String>()
        if (band.isNotEmpty()) parts.add(band)
        if (speed > 0) parts.add("$speed Mbps")
        parts.add("Signal $percent%")

        return if (hidden) {
            NetInfo(
                "wifi",
                "Wi-Fi connected",
                if (hasPerm) "Name hidden. Make sure Location is switched on in system settings. " + parts.joinToString(" · ")
                else parts.joinToString(" · "),
                level,
                needsLocation = !hasPerm
            )
        } else {
            NetInfo("wifi", ssid, parts.joinToString(" · "), level)
        }
    }
}

// ---------- Apps ----------

data class AppEntry(val label: String, val pkg: String)

object Apps {
    fun label(pm: PackageManager, pkg: String): String {
        return try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    fun isSystem(pm: PackageManager, pkg: String): Boolean {
        return try {
            (pm.getApplicationInfo(pkg, 0).flags and ApplicationInfo.FLAG_SYSTEM) != 0
        } catch (e: Exception) {
            false
        }
    }

    fun launchIntent(pm: PackageManager, pkg: String): Intent? =
        pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)

    fun firstInstalled(pm: PackageManager, pkgs: List<String>): String? =
        pkgs.firstOrNull { launchIntent(pm, it) != null }

    fun launch(context: Context, pkg: String) {
        val intent = launchIntent(context.packageManager, pkg)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "Could not open app", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "App not installed", Toast.LENGTH_SHORT).show()
        }
    }

    fun installed(context: Context): List<AppEntry> {
        val pm = context.packageManager
        val categories = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val out = ArrayList<AppEntry>()
        for (category in categories) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == context.packageName) continue
                if (!seen.add(pkg)) continue
                out.add(AppEntry(ri.loadLabel(pm).toString(), pkg))
            }
        }
        return out.sortedBy { it.label.lowercase() }
    }

    fun icon(pm: PackageManager, pkg: String): ImageBitmap? {
        return try {
            pm.getApplicationIcon(pkg).toBitmap(256, 256).asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }
}

// ---------- Now playing (media sessions) ----------

data class MediaInfo(
    val pkg: String,
    val title: String,
    val artist: String,
    val art: Bitmap?,
    val playing: Boolean
)

object NowPlaying {
    // Needs "Notification access" for this app (Android only lets listeners read media sessions)
    fun hasAccess(context: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    private fun controllers(context: Context): List<MediaController> {
        return try {
            val msm = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            msm.getActiveSessions(ComponentName(context, MediaListenerService::class.java))
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun read(context: Context): MediaInfo? {
        val list = controllers(context)
        var playing: MediaController? = null
        var paused: MediaController? = null
        for (c in list) {
            val st = c.playbackState?.state ?: continue
            if (st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING) {
                playing = c
                break
            }
            if (paused == null && st == PlaybackState.STATE_PAUSED) paused = c
        }
        val c = playing ?: paused ?: return null
        val md = c.metadata ?: return null
        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            ?: return null
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
            ?: ""
        val art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        return MediaInfo(c.packageName, title, artist, art, c.playbackState?.state == PlaybackState.STATE_PLAYING)
    }

    // action: 0 = previous, 1 = play/pause, 2 = next
    fun control(context: Context, pkg: String, action: Int) {
        try {
            val c = controllers(context).firstOrNull { it.packageName == pkg } ?: return
            val t = c.transportControls
            when (action) {
                0 -> t.skipToPrevious()
                1 -> {
                    if (c.playbackState?.state == PlaybackState.STATE_PLAYING) t.pause() else t.play()
                }
                else -> t.skipToNext()
            }
        } catch (e: Exception) {
            // ignore
        }
    }
}

// ---------- Updates from GitHub (only when you ask) ----------

data class ReleaseInfo(
    val tag: String,
    val build: Int,
    val name: String,
    val notes: String,
    val apkUrl: String,
    val sizeMb: Double
)

object Updater {
    private const val UA = "StreamerHome (https://github.com/" + Config.GITHUB_REPO + ")"

    @Suppress("DEPRECATION")
    fun installedBuild(context: Context): Int {
        return try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionCode
        } catch (e: Exception) {
            0
        }
    }

    // Returns the newest release that has an .apk, or an error message
    fun fetchLatest(includeTests: Boolean = false): Pair<ReleaseInfo?, String> {
        return try {
            val conn = URL("https://api.github.com/repos/" + Config.GITHUB_REPO + "/releases?per_page=8")
                .openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            val code = conn.responseCode
            if (code != 200) {
                conn.disconnect()
                return Pair<ReleaseInfo?, String>(null, "GitHub answered HTTP " + code)
            }
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val arr = JSONArray(text)
            var best: ReleaseInfo? = null
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optBoolean("draft", false)) continue
                if (o.optBoolean("prerelease", false) && !includeTests) continue
                val tag = o.optString("tag_name")
                val build = tag.substringAfter("build-", "").toIntOrNull() ?: continue
                val assets = o.optJSONArray("assets") ?: continue
                var url = ""
                var size = 0L
                for (j in 0 until assets.length()) {
                    val a = assets.getJSONObject(j)
                    if (a.optString("name").endsWith(".apk")) {
                        url = a.optString("browser_download_url")
                        size = a.optLong("size", 0L)
                        break
                    }
                }
                if (url.isEmpty()) continue
                val current = best
                if (current == null || build > current.build) {
                    val date = o.optString("published_at").take(10)
                    best = ReleaseInfo(
                        tag,
                        build,
                        o.optString("name", tag),
                        if (date.isEmpty()) "" else "Published " + date,
                        url,
                        size / 1048576.0
                    )
                }
            }
            val found = best
            if (found == null) Pair<ReleaseInfo?, String>(null, if (includeTests) "No releases found" else "No stable release yet")
            else Pair<ReleaseInfo?, String>(found, "")
        } catch (e: Exception) {
            Pair<ReleaseInfo?, String>(null, "Could not reach GitHub (" + e.javaClass.simpleName + ")")
        }
    }

    fun download(context: Context, url: String, onProgress: (Int) -> Unit): File? {
        return try {
            val dir = File(context.cacheDir, "update")
            dir.mkdirs()
            val file = File(dir, "streamer-home.apk")
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", UA)
            if (conn.responseCode != 200) {
                conn.disconnect()
                return null
            }
            val total = conn.contentLength
            conn.inputStream.use { input ->
                file.outputStream().use { output ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var last = -1
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val p = (done * 100L / total).toInt()
                            if (p != last) {
                                last = p
                                onProgress(p)
                            }
                        }
                    }
                }
            }
            conn.disconnect()
            file
        } catch (e: Exception) {
            null
        }
    }

    fun canInstall(context: Context): Boolean = context.packageManager.canRequestPackageInstalls()

    fun openInstallPermission(context: Context) {
        try {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + context.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            try {
                context.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e2: Exception) {
                // nothing else to try
            }
        }
    }

    fun install(context: Context, file: File): Boolean {
        return try {
            val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, "application/vnd.android.package-archive")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }
}

// ---------- Recently played / watched (tiles on the home row) ----------

data class RecentItem(val id: String, val pkg: String, val title: String, val artist: String)

object Recent {
    private fun sp(c: Context) = c.getSharedPreferences("streamer_home_recent", Context.MODE_PRIVATE)

    private fun dir(c: Context): File {
        val d = File(c.filesDir, "recent")
        d.mkdirs()
        return d
    }

    private fun idOf(pkg: String, title: String, artist: String): String =
        Integer.toHexString((pkg + "|" + title + "|" + artist).hashCode())

    fun list(c: Context): List<RecentItem> {
        val out = ArrayList<RecentItem>()
        try {
            val arr = JSONArray(sp(c).getString("items", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    RecentItem(
                        o.getString("id"),
                        o.getString("pkg"),
                        o.getString("title"),
                        o.optString("artist")
                    )
                )
            }
        } catch (e: Exception) {
            // empty list
        }
        return out
    }

    private fun save(c: Context, items: List<RecentItem>) {
        val arr = JSONArray()
        for (r in items) {
            val o = JSONObject()
            o.put("id", r.id)
            o.put("pkg", r.pkg)
            o.put("title", r.title)
            o.put("artist", r.artist)
            arr.put(o)
        }
        sp(c).edit().putString("items", arr.toString()).apply()
    }

    // Remembers what is playing: newest first, at most 12, with a small cover picture.
    @Synchronized
    fun add(c: Context, pkg: String, title: String, artist: String, art: Bitmap?) {
        val id = idOf(pkg, title, artist)
        val items = ArrayList<RecentItem>()
        items.add(RecentItem(id, pkg, title, artist))
        for (r in list(c)) {
            if (r.id != id) items.add(r)
        }
        val kept = items.take(12)
        save(c, kept)
        if (art != null) {
            try {
                val scale = 256f / maxOf(art.width, art.height)
                val small = if (scale < 1f) {
                    Bitmap.createScaledBitmap(
                        art,
                        (art.width * scale).toInt().coerceAtLeast(1),
                        (art.height * scale).toInt().coerceAtLeast(1),
                        true
                    )
                } else {
                    art
                }
                java.io.FileOutputStream(File(dir(c), id + ".jpg")).use {
                    small.compress(Bitmap.CompressFormat.JPEG, 85, it)
                }
            } catch (e: Exception) {
                // no picture, the app icon is used instead
            }
        }
        val keep = kept.map { it.id + ".jpg" }.toSet()
        dir(c).listFiles()?.forEach {
            if (it.name !in keep) it.delete()
        }
    }

    fun art(c: Context, item: RecentItem): ImageBitmap? {
        return try {
            val f = File(dir(c), item.id + ".jpg")
            if (!f.exists()) null else BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }

    fun clear(c: Context) {
        sp(c).edit().remove("items").apply()
        dir(c).listFiles()?.forEach { it.delete() }
    }

    // Opens the app. If that app is still playing this very item, bring its player back and press play.
    fun open(c: Context, item: RecentItem) {
        try {
            val msm = c.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val ctl = msm.getActiveSessions(ComponentName(c, MediaListenerService::class.java))
                .firstOrNull { it.packageName == item.pkg }
            if (ctl != null) {
                val title = ctl.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
                if (title == item.title) {
                    ctl.transportControls.play()
                    val pi = ctl.sessionActivity
                    if (pi != null) {
                        pi.send()
                        return
                    }
                }
            }
        } catch (e: Exception) {
            // fall through and just open the app
        }
        Apps.launch(c, item.pkg)
    }
}

// ---------- Fixed wallpaper (gallery or a picture on this device), saved at exactly 1920 x 1080 ----------

object Wallpaper {
    private fun file(c: Context) = File(c.filesDir, "wallpaper.jpg")

    fun exists(c: Context): Boolean = file(c).exists()

    // Crops to fill 16:9 and stores at 1920 x 1080
    private fun cropSave(c: Context, src: Bitmap): Boolean {
        return try {
            val tw = 1920
            val th = 1080
            val scale = maxOf(tw.toFloat() / src.width, th.toFloat() / src.height)
            val sw = maxOf(tw, (src.width * scale).toInt())
            val sh = maxOf(th, (src.height * scale).toInt())
            val scaled = Bitmap.createScaledBitmap(src, sw, sh, true)
            val out = Bitmap.createBitmap(scaled, (sw - tw) / 2, (sh - th) / 2, tw, th)
            java.io.FileOutputStream(file(c)).use { out.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            true
        } catch (e: Throwable) {
            false
        }
    }

    fun saveFixed(c: Context, url: String): Boolean {
        val src = Remote.loadBitmap(c, url, 2600, 1400) ?: return false
        return cropSave(c, src)
    }

    fun saveFromUri(c: Context, uri: Uri): Boolean {
        val src = decodeUri(c, uri, 2600) ?: return false
        return cropSave(c, src)
    }

    fun loadFixed(c: Context): ImageBitmap? {
        return try {
            val f = file(c)
            if (!f.exists()) null else BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap()
        } catch (e: Throwable) {
            null
        }
    }

    // Decodes a picture from a content Uri, longest side <= maxSide
    fun decodeUri(c: Context, uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, b) }
            if (b.outWidth <= 0 || b.outHeight <= 0) return null
            var sample = 1
            while (maxOf(b.outWidth, b.outHeight) / sample > maxSide) sample *= 2
            val o = BitmapFactory.Options().apply { inSampleSize = sample }
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        } catch (e: Throwable) {
            null
        }
    }

    fun mediaPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasMediaAccess(c: Context): Boolean =
        c.checkSelfPermission(mediaPermission()) == PackageManager.PERMISSION_GRANTED

    // Newest pictures in the device's media store (needs the media permission)
    fun localPictures(c: Context): List<Uri> {
        val out = ArrayList<Uri>()
        try {
            val base = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            c.contentResolver.query(
                base,
                arrayOf(android.provider.MediaStore.Images.Media._ID),
                null,
                null,
                android.provider.MediaStore.Images.Media.DATE_ADDED + " DESC"
            )?.use { cur ->
                val idCol = cur.getColumnIndexOrThrow(android.provider.MediaStore.Images.Media._ID)
                while (cur.moveToNext() && out.size < 60) {
                    out.add(android.content.ContentUris.withAppendedId(base, cur.getLong(idCol)))
                }
            }
        } catch (e: Exception) {
            // empty list
        }
        return out
    }
}
